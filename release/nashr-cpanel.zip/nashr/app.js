// Startup file for cPanel "Setup Node.js App" (Phusion Passenger). The server itself is server/main.mjs.
// A file named PRELAUNCH beside this one puts the site behind the Coming soon page (touch it to switch on, delete it to launch; restart either way).
import('node:fs').then(({ existsSync }) => { if (existsSync(`${typeof __dirname === 'string' ? __dirname : process.cwd()}/PRELAUNCH`)) process.env.PRELAUNCH ||= '1' })
  .then(() => import('./server/main.mjs')).catch(e => { console.error(e); process.exit(1) })
