// Startup file for cPanel "Setup Node.js App" (Phusion Passenger). The server itself is server/main.mjs.
import('./server/main.mjs').catch(e => { console.error(e); process.exit(1) })
