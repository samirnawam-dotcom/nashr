import { createRequire as __cr } from 'node:module'; const require = __cr(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from2, except, desc) => {
  if (from2 && typeof from2 === "object" || typeof from2 === "function") {
    for (let key of __getOwnPropNames(from2))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from2[key], enumerable: !(desc = __getOwnPropDesc(from2, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/postgres-array/index.js
var require_postgres_array = __commonJS({
  "node_modules/postgres-array/index.js"(exports) {
    "use strict";
    exports.parse = function(source, transform) {
      return new ArrayParser(source, transform).parse();
    };
    var ArrayParser = class _ArrayParser {
      constructor(source, transform) {
        this.source = source;
        this.transform = transform || identity;
        this.position = 0;
        this.entries = [];
        this.recorded = [];
        this.dimension = 0;
      }
      isEof() {
        return this.position >= this.source.length;
      }
      nextCharacter() {
        var character = this.source[this.position++];
        if (character === "\\") {
          return {
            value: this.source[this.position++],
            escaped: true
          };
        }
        return {
          value: character,
          escaped: false
        };
      }
      record(character) {
        this.recorded.push(character);
      }
      newEntry(includeEmpty) {
        var entry;
        if (this.recorded.length > 0 || includeEmpty) {
          entry = this.recorded.join("");
          if (entry === "NULL" && !includeEmpty) {
            entry = null;
          }
          if (entry !== null) entry = this.transform(entry);
          this.entries.push(entry);
          this.recorded = [];
        }
      }
      consumeDimensions() {
        if (this.source[0] === "[") {
          while (!this.isEof()) {
            var char = this.nextCharacter();
            if (char.value === "=") break;
          }
        }
      }
      parse(nested) {
        var character, parser, quote;
        this.consumeDimensions();
        while (!this.isEof()) {
          character = this.nextCharacter();
          if (character.value === "{" && !quote) {
            this.dimension++;
            if (this.dimension > 1) {
              parser = new _ArrayParser(this.source.substr(this.position - 1), this.transform);
              this.entries.push(parser.parse(true));
              this.position += parser.position - 2;
            }
          } else if (character.value === "}" && !quote) {
            this.dimension--;
            if (!this.dimension) {
              this.newEntry();
              if (nested) return this.entries;
            }
          } else if (character.value === '"' && !character.escaped) {
            if (quote) this.newEntry(true);
            quote = !quote;
          } else if (character.value === "," && !quote) {
            this.newEntry();
          } else {
            this.record(character.value);
          }
        }
        if (this.dimension !== 0) {
          throw new Error("array dimension not balanced");
        }
        return this.entries;
      }
    };
    function identity(value) {
      return value;
    }
  }
});

// node_modules/pg-types/lib/arrayParser.js
var require_arrayParser = __commonJS({
  "node_modules/pg-types/lib/arrayParser.js"(exports, module) {
    var array = require_postgres_array();
    module.exports = {
      create: function(source, transform) {
        return {
          parse: function() {
            return array.parse(source, transform);
          }
        };
      }
    };
  }
});

// node_modules/postgres-date/index.js
var require_postgres_date = __commonJS({
  "node_modules/postgres-date/index.js"(exports, module) {
    "use strict";
    var DATE_TIME = /(\d{1,})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})(\.\d{1,})?.*?( BC)?$/;
    var DATE = /^(\d{1,})-(\d{2})-(\d{2})( BC)?$/;
    var TIME_ZONE = /([Z+-])(\d{2})?:?(\d{2})?:?(\d{2})?/;
    var INFINITY = /^-?infinity$/;
    module.exports = function parseDate(isoDate) {
      if (INFINITY.test(isoDate)) {
        return Number(isoDate.replace("i", "I"));
      }
      var matches2 = DATE_TIME.exec(isoDate);
      if (!matches2) {
        return getDate(isoDate) || null;
      }
      var isBC = !!matches2[8];
      var year = parseInt(matches2[1], 10);
      if (isBC) {
        year = bcYearToNegativeYear(year);
      }
      var month = parseInt(matches2[2], 10) - 1;
      var day2 = matches2[3];
      var hour = parseInt(matches2[4], 10);
      var minute = parseInt(matches2[5], 10);
      var second = parseInt(matches2[6], 10);
      var ms = matches2[7];
      ms = ms ? 1e3 * parseFloat(ms) : 0;
      var date;
      var offset2 = timeZoneOffset(isoDate);
      if (offset2 != null) {
        date = new Date(Date.UTC(year, month, day2, hour, minute, second, ms));
        if (is0To99(year)) {
          date.setUTCFullYear(year);
        }
        if (offset2 !== 0) {
          date.setTime(date.getTime() - offset2);
        }
      } else {
        date = new Date(year, month, day2, hour, minute, second, ms);
        if (is0To99(year)) {
          date.setFullYear(year);
        }
      }
      return date;
    };
    function getDate(isoDate) {
      var matches2 = DATE.exec(isoDate);
      if (!matches2) {
        return;
      }
      var year = parseInt(matches2[1], 10);
      var isBC = !!matches2[4];
      if (isBC) {
        year = bcYearToNegativeYear(year);
      }
      var month = parseInt(matches2[2], 10) - 1;
      var day2 = matches2[3];
      var date = new Date(year, month, day2);
      if (is0To99(year)) {
        date.setFullYear(year);
      }
      return date;
    }
    function timeZoneOffset(isoDate) {
      if (isoDate.endsWith("+00")) {
        return 0;
      }
      var zone = TIME_ZONE.exec(isoDate.split(" ")[1]);
      if (!zone) return;
      var type = zone[1];
      if (type === "Z") {
        return 0;
      }
      var sign = type === "-" ? -1 : 1;
      var offset2 = parseInt(zone[2], 10) * 3600 + parseInt(zone[3] || 0, 10) * 60 + parseInt(zone[4] || 0, 10);
      return offset2 * sign * 1e3;
    }
    function bcYearToNegativeYear(year) {
      return -(year - 1);
    }
    function is0To99(num) {
      return num >= 0 && num < 100;
    }
  }
});

// node_modules/xtend/mutable.js
var require_mutable = __commonJS({
  "node_modules/xtend/mutable.js"(exports, module) {
    module.exports = extend;
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    function extend(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
          if (hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    }
  }
});

// node_modules/postgres-interval/index.js
var require_postgres_interval = __commonJS({
  "node_modules/postgres-interval/index.js"(exports, module) {
    "use strict";
    var extend = require_mutable();
    module.exports = PostgresInterval;
    function PostgresInterval(raw) {
      if (!(this instanceof PostgresInterval)) {
        return new PostgresInterval(raw);
      }
      extend(this, parse(raw));
    }
    var properties = ["seconds", "minutes", "hours", "days", "months", "years"];
    PostgresInterval.prototype.toPostgres = function() {
      var filtered = properties.filter(this.hasOwnProperty, this);
      if (this.milliseconds && filtered.indexOf("seconds") < 0) {
        filtered.push("seconds");
      }
      if (filtered.length === 0) return "0";
      return filtered.map(function(property) {
        var value = this[property] || 0;
        if (property === "seconds" && this.milliseconds) {
          value = (value + this.milliseconds / 1e3).toFixed(6).replace(/\.?0+$/, "");
        }
        return value + " " + property;
      }, this).join(" ");
    };
    var propertiesISOEquivalent = {
      years: "Y",
      months: "M",
      days: "D",
      hours: "H",
      minutes: "M",
      seconds: "S"
    };
    var dateProperties = ["years", "months", "days"];
    var timeProperties = ["hours", "minutes", "seconds"];
    PostgresInterval.prototype.toISOString = PostgresInterval.prototype.toISO = function() {
      var datePart = dateProperties.map(buildProperty, this).join("");
      var timePart = timeProperties.map(buildProperty, this).join("");
      return "P" + datePart + "T" + timePart;
      function buildProperty(property) {
        var value = this[property] || 0;
        if (property === "seconds" && this.milliseconds) {
          value = (value + this.milliseconds / 1e3).toFixed(6).replace(/0+$/, "");
        }
        return value + propertiesISOEquivalent[property];
      }
    };
    var NUMBER = "([+-]?\\d+)";
    var YEAR = NUMBER + "\\s+years?";
    var MONTH = NUMBER + "\\s+mons?";
    var DAY2 = NUMBER + "\\s+days?";
    var TIME = "([+-])?([\\d]*):(\\d\\d):(\\d\\d)\\.?(\\d{1,6})?";
    var INTERVAL = new RegExp([YEAR, MONTH, DAY2, TIME].map(function(regexString) {
      return "(" + regexString + ")?";
    }).join("\\s*"));
    var positions = {
      years: 2,
      months: 4,
      days: 6,
      hours: 9,
      minutes: 10,
      seconds: 11,
      milliseconds: 12
    };
    var negatives = ["hours", "minutes", "seconds", "milliseconds"];
    function parseMilliseconds(fraction) {
      var microseconds = fraction + "000000".slice(fraction.length);
      return parseInt(microseconds, 10) / 1e3;
    }
    function parse(interval) {
      if (!interval) return {};
      var matches2 = INTERVAL.exec(interval);
      var isNegative = matches2[8] === "-";
      return Object.keys(positions).reduce(function(parsed, property) {
        var position = positions[property];
        var value = matches2[position];
        if (!value) return parsed;
        value = property === "milliseconds" ? parseMilliseconds(value) : parseInt(value, 10);
        if (!value) return parsed;
        if (isNegative && ~negatives.indexOf(property)) {
          value *= -1;
        }
        parsed[property] = value;
        return parsed;
      }, {});
    }
  }
});

// node_modules/postgres-bytea/index.js
var require_postgres_bytea = __commonJS({
  "node_modules/postgres-bytea/index.js"(exports, module) {
    "use strict";
    var bufferFrom = Buffer.from || Buffer;
    module.exports = function parseBytea(input) {
      if (/^\\x/.test(input)) {
        return bufferFrom(input.substr(2), "hex");
      }
      var output = "";
      var i = 0;
      while (i < input.length) {
        if (input[i] !== "\\") {
          output += input[i];
          ++i;
        } else {
          if (/[0-7]{3}/.test(input.substr(i + 1, 3))) {
            output += String.fromCharCode(parseInt(input.substr(i + 1, 3), 8));
            i += 4;
          } else {
            var backslashes = 1;
            while (i + backslashes < input.length && input[i + backslashes] === "\\") {
              backslashes++;
            }
            for (var k = 0; k < Math.floor(backslashes / 2); ++k) {
              output += "\\";
            }
            i += Math.floor(backslashes / 2) * 2;
          }
        }
      }
      return bufferFrom(output, "binary");
    };
  }
});

// node_modules/pg-types/lib/textParsers.js
var require_textParsers = __commonJS({
  "node_modules/pg-types/lib/textParsers.js"(exports, module) {
    var array = require_postgres_array();
    var arrayParser = require_arrayParser();
    var parseDate = require_postgres_date();
    var parseInterval = require_postgres_interval();
    var parseByteA = require_postgres_bytea();
    function allowNull(fn) {
      return function nullAllowed(value) {
        if (value === null) return value;
        return fn(value);
      };
    }
    function parseBool(value) {
      if (value === null) return value;
      return value === "TRUE" || value === "t" || value === "true" || value === "y" || value === "yes" || value === "on" || value === "1";
    }
    function parseBoolArray(value) {
      if (!value) return null;
      return array.parse(value, parseBool);
    }
    function parseBaseTenInt(string) {
      return parseInt(string, 10);
    }
    function parseIntegerArray(value) {
      if (!value) return null;
      return array.parse(value, allowNull(parseBaseTenInt));
    }
    function parseBigIntegerArray(value) {
      if (!value) return null;
      return array.parse(value, allowNull(function(entry) {
        return parseBigInteger(entry).trim();
      }));
    }
    var parsePointArray = function(value) {
      if (!value) {
        return null;
      }
      var p = arrayParser.create(value, function(entry) {
        if (entry !== null) {
          entry = parsePoint(entry);
        }
        return entry;
      });
      return p.parse();
    };
    var parseFloatArray = function(value) {
      if (!value) {
        return null;
      }
      var p = arrayParser.create(value, function(entry) {
        if (entry !== null) {
          entry = parseFloat(entry);
        }
        return entry;
      });
      return p.parse();
    };
    var parseStringArray = function(value) {
      if (!value) {
        return null;
      }
      var p = arrayParser.create(value);
      return p.parse();
    };
    var parseDateArray = function(value) {
      if (!value) {
        return null;
      }
      var p = arrayParser.create(value, function(entry) {
        if (entry !== null) {
          entry = parseDate(entry);
        }
        return entry;
      });
      return p.parse();
    };
    var parseIntervalArray = function(value) {
      if (!value) {
        return null;
      }
      var p = arrayParser.create(value, function(entry) {
        if (entry !== null) {
          entry = parseInterval(entry);
        }
        return entry;
      });
      return p.parse();
    };
    var parseByteAArray = function(value) {
      if (!value) {
        return null;
      }
      return array.parse(value, allowNull(parseByteA));
    };
    var parseInteger = function(value) {
      return parseInt(value, 10);
    };
    var parseBigInteger = function(value) {
      var valStr = String(value);
      if (/^\d+$/.test(valStr)) {
        return valStr;
      }
      return value;
    };
    var parseJsonArray = function(value) {
      if (!value) {
        return null;
      }
      return array.parse(value, allowNull(JSON.parse));
    };
    var parsePoint = function(value) {
      if (value[0] !== "(") {
        return null;
      }
      value = value.substring(1, value.length - 1).split(",");
      return {
        x: parseFloat(value[0]),
        y: parseFloat(value[1])
      };
    };
    var parseCircle = function(value) {
      if (value[0] !== "<" && value[1] !== "(") {
        return null;
      }
      var point = "(";
      var radius = "";
      var pointParsed = false;
      for (var i = 2; i < value.length - 1; i++) {
        if (!pointParsed) {
          point += value[i];
        }
        if (value[i] === ")") {
          pointParsed = true;
          continue;
        } else if (!pointParsed) {
          continue;
        }
        if (value[i] === ",") {
          continue;
        }
        radius += value[i];
      }
      var result = parsePoint(point);
      result.radius = parseFloat(radius);
      return result;
    };
    var init = function(register) {
      register(20, parseBigInteger);
      register(21, parseInteger);
      register(23, parseInteger);
      register(26, parseInteger);
      register(700, parseFloat);
      register(701, parseFloat);
      register(16, parseBool);
      register(1082, parseDate);
      register(1114, parseDate);
      register(1184, parseDate);
      register(600, parsePoint);
      register(651, parseStringArray);
      register(718, parseCircle);
      register(1e3, parseBoolArray);
      register(1001, parseByteAArray);
      register(1005, parseIntegerArray);
      register(1007, parseIntegerArray);
      register(1028, parseIntegerArray);
      register(1016, parseBigIntegerArray);
      register(1017, parsePointArray);
      register(1021, parseFloatArray);
      register(1022, parseFloatArray);
      register(1231, parseFloatArray);
      register(1014, parseStringArray);
      register(1015, parseStringArray);
      register(1008, parseStringArray);
      register(1009, parseStringArray);
      register(1040, parseStringArray);
      register(1041, parseStringArray);
      register(1115, parseDateArray);
      register(1182, parseDateArray);
      register(1185, parseDateArray);
      register(1186, parseInterval);
      register(1187, parseIntervalArray);
      register(17, parseByteA);
      register(114, JSON.parse.bind(JSON));
      register(3802, JSON.parse.bind(JSON));
      register(199, parseJsonArray);
      register(3807, parseJsonArray);
      register(3907, parseStringArray);
      register(2951, parseStringArray);
      register(791, parseStringArray);
      register(1183, parseStringArray);
      register(1270, parseStringArray);
    };
    module.exports = {
      init
    };
  }
});

// node_modules/pg-int8/index.js
var require_pg_int8 = __commonJS({
  "node_modules/pg-int8/index.js"(exports, module) {
    "use strict";
    var BASE2 = 1e6;
    function readInt8(buffer) {
      var high = buffer.readInt32BE(0);
      var low = buffer.readUInt32BE(4);
      var sign = "";
      if (high < 0) {
        high = ~high + (low === 0);
        low = ~low + 1 >>> 0;
        sign = "-";
      }
      var result = "";
      var carry;
      var t;
      var digits;
      var pad;
      var l;
      var i;
      {
        carry = high % BASE2;
        high = high / BASE2 >>> 0;
        t = 4294967296 * carry + low;
        low = t / BASE2 >>> 0;
        digits = "" + (t - BASE2 * low);
        if (low === 0 && high === 0) {
          return sign + digits + result;
        }
        pad = "";
        l = 6 - digits.length;
        for (i = 0; i < l; i++) {
          pad += "0";
        }
        result = pad + digits + result;
      }
      {
        carry = high % BASE2;
        high = high / BASE2 >>> 0;
        t = 4294967296 * carry + low;
        low = t / BASE2 >>> 0;
        digits = "" + (t - BASE2 * low);
        if (low === 0 && high === 0) {
          return sign + digits + result;
        }
        pad = "";
        l = 6 - digits.length;
        for (i = 0; i < l; i++) {
          pad += "0";
        }
        result = pad + digits + result;
      }
      {
        carry = high % BASE2;
        high = high / BASE2 >>> 0;
        t = 4294967296 * carry + low;
        low = t / BASE2 >>> 0;
        digits = "" + (t - BASE2 * low);
        if (low === 0 && high === 0) {
          return sign + digits + result;
        }
        pad = "";
        l = 6 - digits.length;
        for (i = 0; i < l; i++) {
          pad += "0";
        }
        result = pad + digits + result;
      }
      {
        carry = high % BASE2;
        t = 4294967296 * carry + low;
        digits = "" + t % BASE2;
        return sign + digits + result;
      }
    }
    module.exports = readInt8;
  }
});

// node_modules/pg-types/lib/binaryParsers.js
var require_binaryParsers = __commonJS({
  "node_modules/pg-types/lib/binaryParsers.js"(exports, module) {
    var parseInt64 = require_pg_int8();
    var parseBits = function(data, bits, offset2, invert, callback) {
      offset2 = offset2 || 0;
      invert = invert || false;
      callback = callback || function(lastValue, newValue, bits2) {
        return lastValue * Math.pow(2, bits2) + newValue;
      };
      var offsetBytes = offset2 >> 3;
      var inv = function(value) {
        if (invert) {
          return ~value & 255;
        }
        return value;
      };
      var mask = 255;
      var firstBits = 8 - offset2 % 8;
      if (bits < firstBits) {
        mask = 255 << 8 - bits & 255;
        firstBits = bits;
      }
      if (offset2) {
        mask = mask >> offset2 % 8;
      }
      var result = 0;
      if (offset2 % 8 + bits >= 8) {
        result = callback(0, inv(data[offsetBytes]) & mask, firstBits);
      }
      var bytes = bits + offset2 >> 3;
      for (var i = offsetBytes + 1; i < bytes; i++) {
        result = callback(result, inv(data[i]), 8);
      }
      var lastBits = (bits + offset2) % 8;
      if (lastBits > 0) {
        result = callback(result, inv(data[bytes]) >> 8 - lastBits, lastBits);
      }
      return result;
    };
    var parseFloatFromBits = function(data, precisionBits, exponentBits) {
      var bias = Math.pow(2, exponentBits - 1) - 1;
      var sign = parseBits(data, 1);
      var exponent = parseBits(data, exponentBits, 1);
      if (exponent === 0) {
        return 0;
      }
      var precisionBitsCounter = 1;
      var parsePrecisionBits = function(lastValue, newValue, bits) {
        if (lastValue === 0) {
          lastValue = 1;
        }
        for (var i = 1; i <= bits; i++) {
          precisionBitsCounter /= 2;
          if ((newValue & 1 << bits - i) > 0) {
            lastValue += precisionBitsCounter;
          }
        }
        return lastValue;
      };
      var mantissa = parseBits(data, precisionBits, exponentBits + 1, false, parsePrecisionBits);
      if (exponent == Math.pow(2, exponentBits + 1) - 1) {
        if (mantissa === 0) {
          return sign === 0 ? Infinity : -Infinity;
        }
        return NaN;
      }
      return (sign === 0 ? 1 : -1) * Math.pow(2, exponent - bias) * mantissa;
    };
    var parseInt16 = function(value) {
      if (parseBits(value, 1) == 1) {
        return -1 * (parseBits(value, 15, 1, true) + 1);
      }
      return parseBits(value, 15, 1);
    };
    var parseInt32 = function(value) {
      if (parseBits(value, 1) == 1) {
        return -1 * (parseBits(value, 31, 1, true) + 1);
      }
      return parseBits(value, 31, 1);
    };
    var parseFloat32 = function(value) {
      return parseFloatFromBits(value, 23, 8);
    };
    var parseFloat64 = function(value) {
      return parseFloatFromBits(value, 52, 11);
    };
    var parseNumeric = function(value) {
      var sign = parseBits(value, 16, 32);
      if (sign == 49152) {
        return NaN;
      }
      var weight = Math.pow(1e4, parseBits(value, 16, 16));
      var result = 0;
      var digits = [];
      var ndigits = parseBits(value, 16);
      for (var i = 0; i < ndigits; i++) {
        result += parseBits(value, 16, 64 + 16 * i) * weight;
        weight /= 1e4;
      }
      var scale = Math.pow(10, parseBits(value, 16, 48));
      return (sign === 0 ? 1 : -1) * Math.round(result * scale) / scale;
    };
    var parseDate = function(isUTC, value) {
      var sign = parseBits(value, 1);
      var rawValue = parseBits(value, 63, 1);
      var result = new Date((sign === 0 ? 1 : -1) * rawValue / 1e3 + 9466848e5);
      if (!isUTC) {
        result.setTime(result.getTime() + result.getTimezoneOffset() * 6e4);
      }
      result.usec = rawValue % 1e3;
      result.getMicroSeconds = function() {
        return this.usec;
      };
      result.setMicroSeconds = function(value2) {
        this.usec = value2;
      };
      result.getUTCMicroSeconds = function() {
        return this.usec;
      };
      return result;
    };
    var parseArray = function(value) {
      var dim = parseBits(value, 32);
      var flags = parseBits(value, 32, 32);
      var elementType = parseBits(value, 32, 64);
      var offset2 = 96;
      var dims = [];
      for (var i = 0; i < dim; i++) {
        dims[i] = parseBits(value, 32, offset2);
        offset2 += 32;
        offset2 += 32;
      }
      var parseElement = function(elementType2) {
        var length = parseBits(value, 32, offset2);
        offset2 += 32;
        if (length == 4294967295) {
          return null;
        }
        var result;
        if (elementType2 == 23 || elementType2 == 20) {
          result = parseBits(value, length * 8, offset2);
          offset2 += length * 8;
          return result;
        } else if (elementType2 == 25) {
          result = value.toString(this.encoding, offset2 >> 3, (offset2 += length << 3) >> 3);
          return result;
        } else {
          console.log("ERROR: ElementType not implemented: " + elementType2);
        }
      };
      var parse = function(dimension, elementType2) {
        var array = [];
        var i2;
        if (dimension.length > 1) {
          var count = dimension.shift();
          for (i2 = 0; i2 < count; i2++) {
            array[i2] = parse(dimension, elementType2);
          }
          dimension.unshift(count);
        } else {
          for (i2 = 0; i2 < dimension[0]; i2++) {
            array[i2] = parseElement(elementType2);
          }
        }
        return array;
      };
      return parse(dims, elementType);
    };
    var parseText = function(value) {
      return value.toString("utf8");
    };
    var parseBool = function(value) {
      if (value === null) return null;
      return parseBits(value, 8) > 0;
    };
    var init = function(register) {
      register(20, parseInt64);
      register(21, parseInt16);
      register(23, parseInt32);
      register(26, parseInt32);
      register(1700, parseNumeric);
      register(700, parseFloat32);
      register(701, parseFloat64);
      register(16, parseBool);
      register(1114, parseDate.bind(null, false));
      register(1184, parseDate.bind(null, true));
      register(1e3, parseArray);
      register(1007, parseArray);
      register(1016, parseArray);
      register(1008, parseArray);
      register(1009, parseArray);
      register(25, parseText);
    };
    module.exports = {
      init
    };
  }
});

// node_modules/pg-types/lib/builtins.js
var require_builtins = __commonJS({
  "node_modules/pg-types/lib/builtins.js"(exports, module) {
    module.exports = {
      BOOL: 16,
      BYTEA: 17,
      CHAR: 18,
      INT8: 20,
      INT2: 21,
      INT4: 23,
      REGPROC: 24,
      TEXT: 25,
      OID: 26,
      TID: 27,
      XID: 28,
      CID: 29,
      JSON: 114,
      XML: 142,
      PG_NODE_TREE: 194,
      SMGR: 210,
      PATH: 602,
      POLYGON: 604,
      CIDR: 650,
      FLOAT4: 700,
      FLOAT8: 701,
      ABSTIME: 702,
      RELTIME: 703,
      TINTERVAL: 704,
      CIRCLE: 718,
      MACADDR8: 774,
      MONEY: 790,
      MACADDR: 829,
      INET: 869,
      ACLITEM: 1033,
      BPCHAR: 1042,
      VARCHAR: 1043,
      DATE: 1082,
      TIME: 1083,
      TIMESTAMP: 1114,
      TIMESTAMPTZ: 1184,
      INTERVAL: 1186,
      TIMETZ: 1266,
      BIT: 1560,
      VARBIT: 1562,
      NUMERIC: 1700,
      REFCURSOR: 1790,
      REGPROCEDURE: 2202,
      REGOPER: 2203,
      REGOPERATOR: 2204,
      REGCLASS: 2205,
      REGTYPE: 2206,
      UUID: 2950,
      TXID_SNAPSHOT: 2970,
      PG_LSN: 3220,
      PG_NDISTINCT: 3361,
      PG_DEPENDENCIES: 3402,
      TSVECTOR: 3614,
      TSQUERY: 3615,
      GTSVECTOR: 3642,
      REGCONFIG: 3734,
      REGDICTIONARY: 3769,
      JSONB: 3802,
      REGNAMESPACE: 4089,
      REGROLE: 4096
    };
  }
});

// node_modules/pg-types/index.js
var require_pg_types = __commonJS({
  "node_modules/pg-types/index.js"(exports) {
    var textParsers = require_textParsers();
    var binaryParsers = require_binaryParsers();
    var arrayParser = require_arrayParser();
    var builtinTypes = require_builtins();
    exports.getTypeParser = getTypeParser;
    exports.setTypeParser = setTypeParser;
    exports.arrayParser = arrayParser;
    exports.builtins = builtinTypes;
    var typeParsers = {
      text: {},
      binary: {}
    };
    function noParse(val) {
      return String(val);
    }
    function getTypeParser(oid, format) {
      format = format || "text";
      if (!typeParsers[format]) {
        return noParse;
      }
      return typeParsers[format][oid] || noParse;
    }
    function setTypeParser(oid, format, parseFn) {
      if (typeof format == "function") {
        parseFn = format;
        format = "text";
      }
      typeParsers[format][oid] = parseFn;
    }
    textParsers.init(function(oid, converter) {
      typeParsers.text[oid] = converter;
    });
    binaryParsers.init(function(oid, converter) {
      typeParsers.binary[oid] = converter;
    });
  }
});

// node_modules/pg/lib/defaults.js
var require_defaults = __commonJS({
  "node_modules/pg/lib/defaults.js"(exports, module) {
    "use strict";
    var user2;
    try {
      user2 = process.platform === "win32" ? process.env.USERNAME : process.env.USER;
    } catch {
    }
    module.exports = {
      // database host. defaults to localhost
      host: "localhost",
      // database user's name
      user: user2,
      // name of database to connect
      database: void 0,
      // database user's password
      password: null,
      // a Postgres connection string to be used instead of setting individual connection items
      // NOTE:  Setting this value will cause it to override any other value (such as database or user) defined
      // in the defaults object.
      connectionString: void 0,
      // database port
      port: 5432,
      // number of rows to return at a time from a prepared statement's
      // portal. 0 will return all rows at once
      rows: 0,
      // binary result mode
      binary: false,
      // Connection pool options - see https://github.com/brianc/node-pg-pool
      // number of connections to use in connection pool
      // 0 will disable connection pooling
      max: 10,
      // max milliseconds a client can go unused before it is removed
      // from the pool and destroyed
      idleTimeoutMillis: 3e4,
      client_encoding: "",
      ssl: false,
      // SSL negotiation style: 'postgres' (traditional SSLRequest) or 'direct'
      sslnegotiation: void 0,
      application_name: void 0,
      fallback_application_name: void 0,
      options: void 0,
      parseInputDatesAsUTC: false,
      // max milliseconds any query using this connection will execute for before timing out in error.
      // false=unlimited
      statement_timeout: false,
      // Abort any statement that waits longer than the specified duration in milliseconds while attempting to acquire a lock.
      // false=unlimited
      lock_timeout: false,
      // Terminate any session with an open transaction that has been idle for longer than the specified duration in milliseconds
      // false=unlimited
      idle_in_transaction_session_timeout: false,
      // max milliseconds to wait for query to complete (client side)
      query_timeout: false,
      connect_timeout: 0,
      keepalives: 1,
      keepalives_idle: 0
    };
    var pgTypes = require_pg_types();
    var parseBigInteger = pgTypes.getTypeParser(20, "text");
    var parseBigIntegerArray = pgTypes.getTypeParser(1016, "text");
    module.exports.__defineSetter__("parseInt8", function(val) {
      pgTypes.setTypeParser(20, "text", val ? pgTypes.getTypeParser(23, "text") : parseBigInteger);
      pgTypes.setTypeParser(1016, "text", val ? pgTypes.getTypeParser(1007, "text") : parseBigIntegerArray);
    });
  }
});

// node_modules/pg/lib/utils.js
var require_utils = __commonJS({
  "node_modules/pg/lib/utils.js"(exports, module) {
    "use strict";
    var defaults2 = require_defaults();
    var nodeUtils = __require("util");
    var { isDate } = __require("util/types");
    var invalidDateDeprecationNotice = nodeUtils.deprecate(
      () => {
      },
      "Sending an invalid date to Postgres is deprecated and will throw an error in the next major version of pg. Ensure any Date object passed as a query parameter is valid.",
      "PG_INVALID_DATE"
    );
    function escapeElement(elementRepresentation) {
      const escaped = elementRepresentation.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
      return '"' + escaped + '"';
    }
    function arrayString(val) {
      let result = "{";
      for (let i = 0; i < val.length; i++) {
        if (i > 0) {
          result += ",";
        }
        let item = val[i];
        if (item == null) {
          result += "NULL";
        } else if (Array.isArray(item)) {
          result += arrayString(item);
        } else if (ArrayBuffer.isView(item)) {
          if (!(item instanceof Buffer)) {
            item = Buffer.from(item.buffer, item.byteOffset, item.byteLength);
          }
          result += "\\\\x" + item.toString("hex");
        } else {
          result += escapeElement(prepareValue(item));
        }
      }
      result += "}";
      return result;
    }
    var prepareValue = function(val, seen) {
      if (val == null) {
        return null;
      }
      if (typeof val === "object") {
        if (val instanceof Buffer) {
          return val;
        }
        if (ArrayBuffer.isView(val)) {
          return Buffer.from(val.buffer, val.byteOffset, val.byteLength);
        }
        if (isDate(val)) {
          if (isNaN(val.getTime())) {
            invalidDateDeprecationNotice();
          }
          if (defaults2.parseInputDatesAsUTC) {
            return dateToStringUTC(val);
          } else {
            return dateToString(val);
          }
        }
        if (Array.isArray(val)) {
          return arrayString(val);
        }
        return prepareObject(val, seen);
      }
      return val.toString();
    };
    function prepareObject(val, seen) {
      if (val && typeof val.toPostgres === "function") {
        seen = seen || [];
        if (seen.indexOf(val) !== -1) {
          throw new Error('circular reference detected while preparing "' + val + '" for query');
        }
        seen.push(val);
        return prepareValue(val.toPostgres(prepareValue), seen);
      }
      return JSON.stringify(val);
    }
    function dateToString(date) {
      let offset2 = -date.getTimezoneOffset();
      let year = date.getFullYear();
      const isBCYear = year < 1;
      if (isBCYear) year = Math.abs(year) + 1;
      let ret = String(year).padStart(4, "0") + "-" + String(date.getMonth() + 1).padStart(2, "0") + "-" + String(date.getDate()).padStart(2, "0") + "T" + String(date.getHours()).padStart(2, "0") + ":" + String(date.getMinutes()).padStart(2, "0") + ":" + String(date.getSeconds()).padStart(2, "0") + "." + String(date.getMilliseconds()).padStart(3, "0");
      if (offset2 < 0) {
        ret += "-";
        offset2 *= -1;
      } else {
        ret += "+";
      }
      ret += String(Math.floor(offset2 / 60)).padStart(2, "0") + ":" + String(offset2 % 60).padStart(2, "0");
      if (isBCYear) ret += " BC";
      return ret;
    }
    function dateToStringUTC(date) {
      let year = date.getUTCFullYear();
      const isBCYear = year < 1;
      if (isBCYear) year = Math.abs(year) + 1;
      let ret = String(year).padStart(4, "0") + "-" + String(date.getUTCMonth() + 1).padStart(2, "0") + "-" + String(date.getUTCDate()).padStart(2, "0") + "T" + String(date.getUTCHours()).padStart(2, "0") + ":" + String(date.getUTCMinutes()).padStart(2, "0") + ":" + String(date.getUTCSeconds()).padStart(2, "0") + "." + String(date.getUTCMilliseconds()).padStart(3, "0");
      ret += "+00:00";
      if (isBCYear) ret += " BC";
      return ret;
    }
    function normalizeQueryConfig(config, values, callback) {
      config = typeof config === "string" ? { text: config } : cloneQueryConfig(config);
      if (values) {
        if (typeof values === "function") {
          config.callback = values;
        } else {
          config.values = values;
        }
      }
      if (callback) {
        config.callback = callback;
      }
      return config;
    }
    function cloneQueryConfig(config) {
      if (config == null) {
        return config;
      }
      return Object.defineProperties(Object.create(Object.getPrototypeOf(config)), Object.getOwnPropertyDescriptors(config));
    }
    var escapeIdentifier2 = function(str) {
      return '"' + str.replace(/"/g, '""') + '"';
    };
    var escapeLiteral2 = function(str) {
      let hasBackslash = false;
      let escaped = "'";
      if (str == null) {
        return "''";
      }
      if (typeof str !== "string") {
        return "''";
      }
      for (let i = 0; i < str.length; i++) {
        const c = str[i];
        if (c === "'") {
          escaped += c + c;
        } else if (c === "\\") {
          escaped += c + c;
          hasBackslash = true;
        } else {
          escaped += c;
        }
      }
      escaped += "'";
      if (hasBackslash === true) {
        escaped = " E" + escaped;
      }
      return escaped;
    };
    module.exports = {
      prepareValue: function prepareValueWrapper(value) {
        return prepareValue(value);
      },
      normalizeQueryConfig,
      escapeIdentifier: escapeIdentifier2,
      escapeLiteral: escapeLiteral2
    };
  }
});

// node_modules/pg/lib/crypto/utils.js
var require_utils2 = __commonJS({
  "node_modules/pg/lib/crypto/utils.js"(exports, module) {
    var nodeCrypto = __require("crypto");
    module.exports = {
      postgresMd5PasswordHash,
      randomBytes: randomBytes3,
      deriveKey,
      sha256,
      hashByName,
      hmacSha256,
      md5
    };
    var webCrypto = nodeCrypto.webcrypto || globalThis.crypto;
    var subtleCrypto = webCrypto.subtle;
    var textEncoder = new TextEncoder();
    function randomBytes3(length) {
      return webCrypto.getRandomValues(Buffer.alloc(length));
    }
    async function md5(string) {
      try {
        return nodeCrypto.createHash("md5").update(string, "utf-8").digest("hex");
      } catch (e) {
        const data = typeof string === "string" ? textEncoder.encode(string) : string;
        const hash = await subtleCrypto.digest("MD5", data);
        return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, "0")).join("");
      }
    }
    async function postgresMd5PasswordHash(user2, password, salt) {
      const inner = await md5(password + user2);
      const outer = await md5(Buffer.concat([Buffer.from(inner), salt]));
      return "md5" + outer;
    }
    async function sha256(text) {
      return await subtleCrypto.digest("SHA-256", text);
    }
    async function hashByName(hashName, text) {
      return await subtleCrypto.digest(hashName, text);
    }
    async function hmacSha256(keyBuffer, msg) {
      const key = await subtleCrypto.importKey("raw", keyBuffer, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
      return await subtleCrypto.sign("HMAC", key, textEncoder.encode(msg));
    }
    async function deriveKey(password, salt, iterations) {
      const key = await subtleCrypto.importKey("raw", textEncoder.encode(password), "PBKDF2", false, ["deriveBits"]);
      const params = { name: "PBKDF2", hash: "SHA-256", salt, iterations };
      return await subtleCrypto.deriveBits(params, key, 32 * 8, ["deriveBits"]);
    }
  }
});

// node_modules/pg/lib/crypto/cert-signatures.js
var require_cert_signatures = __commonJS({
  "node_modules/pg/lib/crypto/cert-signatures.js"(exports, module) {
    function x509Error(msg, cert) {
      return new Error("SASL channel binding: " + msg + " when parsing public certificate " + cert.toString("base64"));
    }
    function readASN1Length(data, index) {
      let length = data[index++];
      if (length < 128) return { length, index };
      const lengthBytes = length & 127;
      if (lengthBytes > 4) throw x509Error("bad length", data);
      length = 0;
      for (let i = 0; i < lengthBytes; i++) {
        length = length << 8 | data[index++];
      }
      return { length, index };
    }
    function readASN1OID(data, index) {
      if (data[index++] !== 6) throw x509Error("non-OID data", data);
      const { length: OIDLength, index: indexAfterOIDLength } = readASN1Length(data, index);
      index = indexAfterOIDLength;
      const lastIndex = index + OIDLength;
      const byte1 = data[index++];
      let oid = (byte1 / 40 >> 0) + "." + byte1 % 40;
      while (index < lastIndex) {
        let value = 0;
        while (index < lastIndex) {
          const nextByte = data[index++];
          value = value << 7 | nextByte & 127;
          if (nextByte < 128) break;
        }
        oid += "." + value;
      }
      return { oid, index };
    }
    function expectASN1Seq(data, index) {
      if (data[index++] !== 48) throw x509Error("non-sequence data", data);
      return readASN1Length(data, index);
    }
    function signatureAlgorithmHashFromCertificate(data, index) {
      if (index === void 0) index = 0;
      index = expectASN1Seq(data, index).index;
      const { length: certInfoLength, index: indexAfterCertInfoLength } = expectASN1Seq(data, index);
      index = indexAfterCertInfoLength + certInfoLength;
      index = expectASN1Seq(data, index).index;
      const { oid, index: indexAfterOID } = readASN1OID(data, index);
      switch (oid) {
        // RSA
        case "1.2.840.113549.1.1.4":
          return "MD5";
        case "1.2.840.113549.1.1.5":
          return "SHA-1";
        case "1.2.840.113549.1.1.11":
          return "SHA-256";
        case "1.2.840.113549.1.1.12":
          return "SHA-384";
        case "1.2.840.113549.1.1.13":
          return "SHA-512";
        case "1.2.840.113549.1.1.14":
          return "SHA-224";
        case "1.2.840.113549.1.1.15":
          return "SHA512-224";
        case "1.2.840.113549.1.1.16":
          return "SHA512-256";
        // ECDSA
        case "1.2.840.10045.4.1":
          return "SHA-1";
        case "1.2.840.10045.4.3.1":
          return "SHA-224";
        case "1.2.840.10045.4.3.2":
          return "SHA-256";
        case "1.2.840.10045.4.3.3":
          return "SHA-384";
        case "1.2.840.10045.4.3.4":
          return "SHA-512";
        // RSASSA-PSS: hash is indicated separately
        case "1.2.840.113549.1.1.10": {
          index = indexAfterOID;
          index = expectASN1Seq(data, index).index;
          if (data[index++] !== 160) throw x509Error("non-tag data", data);
          index = readASN1Length(data, index).index;
          index = expectASN1Seq(data, index).index;
          const { oid: hashOID } = readASN1OID(data, index);
          switch (hashOID) {
            // standalone hash OIDs
            case "1.2.840.113549.2.5":
              return "MD5";
            case "1.3.14.3.2.26":
              return "SHA-1";
            case "2.16.840.1.101.3.4.2.1":
              return "SHA-256";
            case "2.16.840.1.101.3.4.2.2":
              return "SHA-384";
            case "2.16.840.1.101.3.4.2.3":
              return "SHA-512";
          }
          throw x509Error("unknown hash OID " + hashOID, data);
        }
        // Ed25519 -- see https://github.com/openssl/openssl/issues/15477
        case "1.3.101.110":
        case "1.3.101.112":
          return "SHA-512";
        // Ed448 -- still not in pg 17.2 (if supported, digest would be SHAKE256 x 64 bytes)
        case "1.3.101.111":
        case "1.3.101.113":
          throw x509Error("Ed448 certificate channel binding is not currently supported by Postgres");
      }
      throw x509Error("unknown OID " + oid, data);
    }
    module.exports = { signatureAlgorithmHashFromCertificate };
  }
});

// node_modules/pg/lib/crypto/sasl.js
var require_sasl = __commonJS({
  "node_modules/pg/lib/crypto/sasl.js"(exports, module) {
    "use strict";
    var crypto = require_utils2();
    var { signatureAlgorithmHashFromCertificate } = require_cert_signatures();
    function saslprep(password) {
      const nonAsciiSpace = /[\u00A0\u1680\u2000-\u200B\u202F\u205F\u3000]/g;
      const mappedToNothing = /[\u00AD\u034F\u1806\u180B\u180C\u180D\u200C\u200D\u2060\uFE00-\uFE0F\uFEFF]/g;
      return password.replace(nonAsciiSpace, " ").replace(mappedToNothing, "").normalize("NFKC");
    }
    var DEFAULT_MAX_SCRAM_ITERATIONS = 1e5;
    function startSession(mechanisms, stream, scramMaxIterations = DEFAULT_MAX_SCRAM_ITERATIONS) {
      const candidates = ["SCRAM-SHA-256"];
      if (stream) candidates.unshift("SCRAM-SHA-256-PLUS");
      const mechanism = candidates.find((candidate) => mechanisms.includes(candidate));
      if (!mechanism) {
        throw new Error("SASL: Only mechanism(s) " + candidates.join(" and ") + " are supported");
      }
      if (mechanism === "SCRAM-SHA-256-PLUS" && typeof stream.getPeerCertificate !== "function") {
        throw new Error("SASL: Mechanism SCRAM-SHA-256-PLUS requires a certificate");
      }
      const clientNonce = crypto.randomBytes(18).toString("base64");
      const gs2Header = mechanism === "SCRAM-SHA-256-PLUS" ? "p=tls-server-end-point" : stream ? "y" : "n";
      return {
        mechanism,
        clientNonce,
        response: gs2Header + ",,n=*,r=" + clientNonce,
        message: "SASLInitialResponse",
        scramMaxIterations
      };
    }
    async function continueSession(session, password, serverData, stream) {
      if (session.message !== "SASLInitialResponse") {
        throw new Error("SASL: Last message was not SASLInitialResponse");
      }
      if (typeof password !== "string") {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: client password must be a string");
      }
      if (password === "") {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: client password must be a non-empty string");
      }
      if (typeof serverData !== "string") {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: serverData must be a string");
      }
      const sv = parseServerFirstMessage(serverData);
      if (!sv.nonce.startsWith(session.clientNonce)) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: server nonce does not start with client nonce");
      } else if (sv.nonce.length === session.clientNonce.length) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: server nonce is too short");
      }
      const scramMaxIterations = typeof session.scramMaxIterations === "number" ? session.scramMaxIterations : DEFAULT_MAX_SCRAM_ITERATIONS;
      if (scramMaxIterations !== 0 && sv.iteration > scramMaxIterations) {
        throw new Error(
          "SASL: SCRAM-SERVER-FIRST-MESSAGE: iteration count " + sv.iteration + " exceeds scramMaxIterations of " + scramMaxIterations
        );
      }
      const clientFirstMessageBare = "n=*,r=" + session.clientNonce;
      const serverFirstMessage = "r=" + sv.nonce + ",s=" + sv.salt + ",i=" + sv.iteration;
      let channelBinding = stream ? "eSws" : "biws";
      if (session.mechanism === "SCRAM-SHA-256-PLUS") {
        const peerCert = stream.getPeerCertificate().raw;
        let hashName = signatureAlgorithmHashFromCertificate(peerCert);
        if (hashName === "MD5" || hashName === "SHA-1") hashName = "SHA-256";
        const certHash = await crypto.hashByName(hashName, peerCert);
        const bindingData = Buffer.concat([Buffer.from("p=tls-server-end-point,,"), Buffer.from(certHash)]);
        channelBinding = bindingData.toString("base64");
      }
      const clientFinalMessageWithoutProof = "c=" + channelBinding + ",r=" + sv.nonce;
      const authMessage = clientFirstMessageBare + "," + serverFirstMessage + "," + clientFinalMessageWithoutProof;
      const saltBytes = Buffer.from(sv.salt, "base64");
      const saltedPassword = await crypto.deriveKey(saslprep(password), saltBytes, sv.iteration);
      const clientKey = await crypto.hmacSha256(saltedPassword, "Client Key");
      const storedKey = await crypto.sha256(clientKey);
      const clientSignature = await crypto.hmacSha256(storedKey, authMessage);
      const clientProof = xorBuffers(Buffer.from(clientKey), Buffer.from(clientSignature)).toString("base64");
      const serverKey = await crypto.hmacSha256(saltedPassword, "Server Key");
      const serverSignatureBytes = await crypto.hmacSha256(serverKey, authMessage);
      session.message = "SASLResponse";
      session.serverSignature = Buffer.from(serverSignatureBytes).toString("base64");
      session.response = clientFinalMessageWithoutProof + ",p=" + clientProof;
    }
    function finalizeSession(session, serverData) {
      if (session.message !== "SASLResponse") {
        throw new Error("SASL: Last message was not SASLResponse");
      }
      if (typeof serverData !== "string") {
        throw new Error("SASL: SCRAM-SERVER-FINAL-MESSAGE: serverData must be a string");
      }
      const { serverSignature } = parseServerFinalMessage(serverData);
      if (serverSignature !== session.serverSignature) {
        throw new Error("SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature does not match");
      }
    }
    function isPrintableChars(text) {
      if (typeof text !== "string") {
        throw new TypeError("SASL: text must be a string");
      }
      return text.split("").map((_, i) => text.charCodeAt(i)).every((c) => c >= 33 && c <= 43 || c >= 45 && c <= 126);
    }
    function isBase64(text) {
      return /^(?:[a-zA-Z0-9+/]{4})*(?:[a-zA-Z0-9+/]{2}==|[a-zA-Z0-9+/]{3}=)?$/.test(text);
    }
    function parseAttributePairs(text) {
      if (typeof text !== "string") {
        throw new TypeError("SASL: attribute pairs text must be a string");
      }
      return new Map(
        text.split(",").map((attrValue) => {
          if (!/^.=/.test(attrValue)) {
            throw new Error("SASL: Invalid attribute pair entry");
          }
          const name = attrValue[0];
          const value = attrValue.substring(2);
          return [name, value];
        })
      );
    }
    function parseServerFirstMessage(data) {
      const attrPairs = parseAttributePairs(data);
      const nonce = attrPairs.get("r");
      if (!nonce) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: nonce missing");
      } else if (!isPrintableChars(nonce)) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: nonce must only contain printable characters");
      }
      const salt = attrPairs.get("s");
      if (!salt) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: salt missing");
      } else if (!isBase64(salt)) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: salt must be base64");
      }
      const iterationText = attrPairs.get("i");
      if (!iterationText) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: iteration missing");
      } else if (!/^[1-9][0-9]*$/.test(iterationText)) {
        throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: invalid iteration count");
      }
      const iteration = parseInt(iterationText, 10);
      return {
        nonce,
        salt,
        iteration
      };
    }
    function parseServerFinalMessage(serverData) {
      const attrPairs = parseAttributePairs(serverData);
      const error = attrPairs.get("e");
      const serverSignature = attrPairs.get("v");
      if (error) {
        throw new Error(`SASL: SCRAM-SERVER-FINAL-MESSAGE: server returned error: "${error}"`);
      }
      if (!serverSignature) {
        throw new Error("SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature is missing");
      } else if (!isBase64(serverSignature)) {
        throw new Error("SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature must be base64");
      }
      return {
        serverSignature
      };
    }
    function xorBuffers(a, b) {
      if (!Buffer.isBuffer(a)) {
        throw new TypeError("first argument must be a Buffer");
      }
      if (!Buffer.isBuffer(b)) {
        throw new TypeError("second argument must be a Buffer");
      }
      if (a.length !== b.length) {
        throw new Error("Buffer lengths must match");
      }
      if (a.length === 0) {
        throw new Error("Buffers cannot be empty");
      }
      return Buffer.from(a.map((_, i) => a[i] ^ b[i]));
    }
    module.exports = {
      startSession,
      continueSession,
      finalizeSession,
      DEFAULT_MAX_SCRAM_ITERATIONS
    };
  }
});

// node_modules/pg/lib/type-overrides.js
var require_type_overrides = __commonJS({
  "node_modules/pg/lib/type-overrides.js"(exports, module) {
    "use strict";
    var types2 = require_pg_types();
    function TypeOverrides2(userTypes) {
      this._types = userTypes || types2;
      this.text = {};
      this.binary = {};
    }
    TypeOverrides2.prototype.getOverrides = function(format) {
      switch (format) {
        case "text":
          return this.text;
        case "binary":
          return this.binary;
        default:
          return {};
      }
    };
    TypeOverrides2.prototype.setTypeParser = function(oid, format, parseFn) {
      if (typeof format === "function") {
        parseFn = format;
        format = "text";
      }
      this.getOverrides(format)[oid] = parseFn;
    };
    TypeOverrides2.prototype.getTypeParser = function(oid, format) {
      format = format || "text";
      return this.getOverrides(format)[oid] || this._types.getTypeParser(oid, format);
    };
    module.exports = TypeOverrides2;
  }
});

// node_modules/pg-connection-string/index.js
var require_pg_connection_string = __commonJS({
  "node_modules/pg-connection-string/index.js"(exports, module) {
    "use strict";
    function parse(str, options = {}) {
      if (str.charAt(0) === "/") {
        const config2 = str.split(" ");
        return { host: config2[0], database: config2[1] };
      }
      const config = /* @__PURE__ */ Object.create(null);
      let result;
      let dummyHost = false;
      if (/ |%[^a-f0-9]|%[a-f0-9][^a-f0-9]/i.test(str)) {
        str = encodeURI(str).replace(/%25(\d\d)/g, "%$1");
      }
      try {
        try {
          result = new URL(str, "postgres://base");
        } catch (e) {
          result = new URL(str.replace("@/", "@___DUMMY___/"), "postgres://base");
          dummyHost = true;
        }
      } catch (err) {
        err.input && (err.input = "*****REDACTED*****");
        throw err;
      }
      for (const entry of result.searchParams.entries()) {
        config[entry[0]] = entry[1];
      }
      config.user = config.user || decodeURIComponent(result.username);
      config.password = config.password || decodeURIComponent(result.password);
      if (result.protocol == "socket:") {
        config.host = decodeURI(result.pathname);
        config.database = result.searchParams.get("db");
        config.client_encoding = result.searchParams.get("encoding");
        return config;
      }
      const hostname = (dummyHost ? "" : result.hostname).replace(/^\[(.+)\]$/, "$1");
      if (!config.host) {
        config.host = decodeURIComponent(hostname);
      } else if (hostname && /^%2f/i.test(hostname)) {
        result.pathname = hostname + result.pathname;
      }
      if (!config.port) {
        config.port = result.port;
      }
      const pathname = result.pathname.slice(1) || null;
      config.database = pathname ? decodeURI(pathname) : null;
      if (config.ssl === "true" || config.ssl === "1") {
        config.ssl = true;
      }
      if (config.ssl === "0") {
        config.ssl = false;
      }
      if (config.sslcert || config.sslkey || config.sslrootcert || config.sslmode) {
        config.ssl = {};
      }
      if (config.sslnegotiation === "direct" && config.ssl === void 0) {
        config.ssl = true;
      }
      const fs = config.sslcert || config.sslkey || config.sslrootcert ? __require("fs") : null;
      if (config.sslcert) {
        config.ssl.cert = fs.readFileSync(config.sslcert).toString();
      }
      if (config.sslkey) {
        config.ssl.key = fs.readFileSync(config.sslkey).toString();
      }
      if (config.sslrootcert) {
        config.ssl.ca = fs.readFileSync(config.sslrootcert).toString();
      }
      if (options.useLibpqCompat && config.uselibpqcompat) {
        throw new Error("Both useLibpqCompat and uselibpqcompat are set. Please use only one of them.");
      }
      if (config.uselibpqcompat === "true" || options.useLibpqCompat) {
        switch (config.sslmode) {
          case "disable": {
            config.ssl = false;
            break;
          }
          case "prefer": {
            config.ssl.rejectUnauthorized = false;
            break;
          }
          case "require": {
            if (config.sslrootcert) {
              config.ssl.checkServerIdentity = function() {
              };
            } else {
              config.ssl.rejectUnauthorized = false;
            }
            break;
          }
          case "verify-ca": {
            if (!config.ssl.ca) {
              throw new Error(
                "SECURITY WARNING: Using sslmode=verify-ca requires specifying a CA with sslrootcert. If a public CA is used, verify-ca allows connections to a server that somebody else may have registered with the CA, making you vulnerable to Man-in-the-Middle attacks. Either specify a custom CA certificate with sslrootcert parameter or use sslmode=verify-full for proper security."
              );
            }
            config.ssl.checkServerIdentity = function() {
            };
            break;
          }
          case "verify-full": {
            break;
          }
        }
      } else {
        switch (config.sslmode) {
          case "disable": {
            config.ssl = false;
            break;
          }
          case "prefer":
          case "require":
          case "verify-ca":
          case "verify-full": {
            if (config.sslmode !== "verify-full") {
              deprecatedSslModeWarning(config.sslmode);
            }
            break;
          }
          case "no-verify": {
            config.ssl.rejectUnauthorized = false;
            break;
          }
        }
      }
      return config;
    }
    function toConnectionOptions(sslConfig) {
      const connectionOptions = Object.entries(sslConfig).reduce((c, [key, value]) => {
        if (value !== void 0 && value !== null) {
          c[key] = value;
        }
        return c;
      }, /* @__PURE__ */ Object.create(null));
      return connectionOptions;
    }
    function toClientConfig(config) {
      const poolConfig = Object.entries(config).reduce((c, [key, value]) => {
        if (key === "ssl") {
          const sslConfig = value;
          if (typeof sslConfig === "boolean") {
            c[key] = sslConfig;
          }
          if (typeof sslConfig === "object") {
            c[key] = toConnectionOptions(sslConfig);
          }
        } else if (value !== void 0 && value !== null) {
          if (key === "port") {
            if (value !== "") {
              const v = parseInt(value, 10);
              if (isNaN(v)) {
                throw new Error(`Invalid ${key}: ${value}`);
              }
              c[key] = v;
            }
          } else {
            c[key] = value;
          }
        }
        return c;
      }, /* @__PURE__ */ Object.create(null));
      return poolConfig;
    }
    function parseIntoClientConfig(str) {
      return toClientConfig(parse(str));
    }
    function deprecatedSslModeWarning(sslmode) {
      if (!deprecatedSslModeWarning.warned && typeof process !== "undefined" && process.emitWarning) {
        deprecatedSslModeWarning.warned = true;
        process.emitWarning(`SECURITY WARNING: The SSL modes 'prefer', 'require', and 'verify-ca' are treated as aliases for 'verify-full'.
In the next major version (pg-connection-string v3.0.0 and pg v9.0.0), these modes will adopt standard libpq semantics, which have weaker security guarantees.

To prepare for this change:
- If you want the current behavior, explicitly use 'sslmode=verify-full'
- If you want libpq compatibility now, use 'uselibpqcompat=true&sslmode=${sslmode}'

See https://www.postgresql.org/docs/current/libpq-ssl.html for libpq SSL mode definitions.`);
      }
    }
    module.exports = parse;
    parse.parse = parse;
    parse.toClientConfig = toClientConfig;
    parse.parseIntoClientConfig = parseIntoClientConfig;
  }
});

// node_modules/pg/lib/connection-parameters.js
var require_connection_parameters = __commonJS({
  "node_modules/pg/lib/connection-parameters.js"(exports, module) {
    "use strict";
    var dns = __require("dns");
    var defaults2 = require_defaults();
    var parse = require_pg_connection_string().parse;
    var val = function(key, config, envVar) {
      if (config[key]) {
        return config[key];
      }
      if (envVar === void 0) {
        envVar = process.env["PG" + key.toUpperCase()];
      } else if (envVar === false) {
      } else {
        envVar = process.env[envVar];
      }
      return envVar || defaults2[key];
    };
    var readSSLConfigFromEnvironment = function() {
      switch (process.env.PGSSLMODE) {
        case "disable":
          return false;
        case "prefer":
        case "require":
        case "verify-ca":
        case "verify-full":
          return true;
        case "no-verify":
          return { rejectUnauthorized: false };
      }
      return defaults2.ssl;
    };
    var quoteParamValue = function(value) {
      return "'" + ("" + value).replace(/\\/g, "\\\\").replace(/'/g, "\\'") + "'";
    };
    var add = function(params, config, paramName) {
      const value = config[paramName];
      if (value !== void 0 && value !== null) {
        params.push(paramName + "=" + quoteParamValue(value));
      }
    };
    var ConnectionParameters = class {
      constructor(config) {
        config = typeof config === "string" ? parse(config) : config || {};
        if (config.connectionString) {
          config = Object.assign({}, config, parse(config.connectionString));
        }
        this.user = val("user", config);
        this.database = val("database", config);
        if (this.database === void 0) {
          this.database = this.user;
        }
        this.port = parseInt(val("port", config), 10);
        this.host = val("host", config);
        Object.defineProperty(this, "password", {
          configurable: true,
          enumerable: false,
          writable: true,
          value: val("password", config)
        });
        this.binary = val("binary", config);
        this.options = val("options", config);
        this.ssl = typeof config.ssl === "undefined" ? readSSLConfigFromEnvironment() : config.ssl;
        if (typeof this.ssl === "string") {
          if (this.ssl === "true") {
            this.ssl = true;
          }
        }
        if (this.ssl === "no-verify") {
          this.ssl = { rejectUnauthorized: false };
        }
        if (this.ssl && this.ssl.key) {
          Object.defineProperty(this.ssl, "key", {
            enumerable: false
          });
        }
        this.sslnegotiation = val("sslnegotiation", config, "PGSSLNEGOTIATION");
        if (this.sslnegotiation !== void 0 && this.sslnegotiation !== "postgres" && this.sslnegotiation !== "direct") {
          throw new Error(
            `Invalid sslnegotiation value: "${this.sslnegotiation}". Valid values are "postgres" and "direct".`
          );
        }
        if (this.sslnegotiation === "direct" && !this.ssl) {
          throw new Error("sslnegotiation=direct requires SSL to be enabled");
        }
        this.client_encoding = val("client_encoding", config);
        this.replication = val("replication", config);
        this.isDomainSocket = !(this.host || "").indexOf("/");
        this.application_name = val("application_name", config, "PGAPPNAME");
        this.fallback_application_name = val("fallback_application_name", config, false);
        this.statement_timeout = val("statement_timeout", config, false);
        this.lock_timeout = val("lock_timeout", config, false);
        this.idle_in_transaction_session_timeout = val("idle_in_transaction_session_timeout", config, false);
        this.query_timeout = val("query_timeout", config, false);
        if (config.connectionTimeoutMillis === void 0) {
          this.connect_timeout = process.env.PGCONNECT_TIMEOUT || 0;
        } else {
          this.connect_timeout = Math.floor(config.connectionTimeoutMillis / 1e3);
        }
        if (config.keepAlive === false) {
          this.keepalives = 0;
        } else if (config.keepAlive === true) {
          this.keepalives = 1;
        }
        if (typeof config.keepAliveInitialDelayMillis === "number") {
          this.keepalives_idle = Math.floor(config.keepAliveInitialDelayMillis / 1e3);
        }
      }
      getLibpqConnectionString(cb) {
        const params = [];
        add(params, this, "user");
        add(params, this, "password");
        add(params, this, "port");
        add(params, this, "application_name");
        add(params, this, "fallback_application_name");
        add(params, this, "connect_timeout");
        add(params, this, "options");
        const ssl = typeof this.ssl === "object" ? this.ssl : this.ssl ? { sslmode: this.ssl } : {};
        add(params, ssl, "sslmode");
        add(params, ssl, "sslca");
        add(params, ssl, "sslkey");
        add(params, ssl, "sslcert");
        add(params, ssl, "sslrootcert");
        add(params, this, "sslnegotiation");
        if (this.database) {
          params.push("dbname=" + quoteParamValue(this.database));
        }
        if (this.replication) {
          params.push("replication=" + quoteParamValue(this.replication));
        }
        if (this.host) {
          params.push("host=" + quoteParamValue(this.host));
        }
        if (this.isDomainSocket) {
          return cb(null, params.join(" "));
        }
        if (this.client_encoding) {
          params.push("client_encoding=" + quoteParamValue(this.client_encoding));
        }
        dns.lookup(this.host, function(err, address) {
          if (err) return cb(err, null);
          params.push("hostaddr=" + quoteParamValue(address));
          return cb(null, params.join(" "));
        });
      }
    };
    module.exports = ConnectionParameters;
  }
});

// node_modules/pg/lib/result.js
var require_result = __commonJS({
  "node_modules/pg/lib/result.js"(exports, module) {
    "use strict";
    var types2 = require_pg_types();
    var matchRegexp = /^([A-Za-z]+)(?: (\d+))?(?: (\d+))?/;
    var Result2 = class {
      constructor(rowMode, types3) {
        this.command = null;
        this.rowCount = null;
        this.oid = null;
        this.rows = [];
        this.fields = [];
        this._parsers = void 0;
        this._types = types3;
        this.RowCtor = null;
        this.rowAsArray = rowMode === "array";
        if (this.rowAsArray) {
          this.parseRow = this._parseRowAsArray;
        }
        this._prebuiltEmptyResultObject = null;
      }
      // adds a command complete message
      addCommandComplete(msg) {
        let match;
        if (msg.text) {
          match = matchRegexp.exec(msg.text);
        } else {
          match = matchRegexp.exec(msg.command);
        }
        if (match) {
          this.command = match[1];
          if (match[3]) {
            this.oid = parseInt(match[2], 10);
            this.rowCount = parseInt(match[3], 10);
          } else if (match[2]) {
            this.rowCount = parseInt(match[2], 10);
          }
        }
      }
      _parseRowAsArray(rowData) {
        const row = new Array(rowData.length);
        for (let i = 0, len = rowData.length; i < len; i++) {
          const rawValue = rowData[i];
          if (rawValue !== null) {
            row[i] = this._parsers[i](rawValue);
          } else {
            row[i] = null;
          }
        }
        return row;
      }
      parseRow(rowData) {
        const row = { ...this._prebuiltEmptyResultObject };
        for (let i = 0, len = rowData.length; i < len; i++) {
          const rawValue = rowData[i];
          const field = this.fields[i].name;
          if (rawValue !== null) {
            const v = this.fields[i].format === "binary" ? Buffer.from(rawValue) : rawValue;
            row[field] = this._parsers[i](v);
          } else {
            row[field] = null;
          }
        }
        return row;
      }
      addRow(row) {
        this.rows.push(row);
      }
      addFields(fieldDescriptions) {
        this.fields = fieldDescriptions;
        if (this.fields.length) {
          this._parsers = new Array(fieldDescriptions.length);
        }
        const row = /* @__PURE__ */ Object.create(null);
        for (let i = 0; i < fieldDescriptions.length; i++) {
          const desc = fieldDescriptions[i];
          row[desc.name] = null;
          if (this._types) {
            this._parsers[i] = this._types.getTypeParser(desc.dataTypeID, desc.format || "text");
          } else {
            this._parsers[i] = types2.getTypeParser(desc.dataTypeID, desc.format || "text");
          }
        }
        this._prebuiltEmptyResultObject = { ...row };
      }
    };
    module.exports = Result2;
  }
});

// node_modules/pg/lib/query.js
var require_query = __commonJS({
  "node_modules/pg/lib/query.js"(exports, module) {
    "use strict";
    var { EventEmitter: EventEmitter2 } = __require("events");
    var Result2 = require_result();
    var utils = require_utils();
    var Query2 = class extends EventEmitter2 {
      constructor(config, values, callback) {
        super();
        config = utils.normalizeQueryConfig(config, values, callback);
        this.text = config.text;
        this.values = config.values;
        this.rows = config.rows;
        this.types = config.types;
        this.name = config.name;
        this.queryMode = config.queryMode;
        this.binary = config.binary;
        this.portal = config.portal || "";
        this.callback = config.callback;
        this._rowMode = config.rowMode;
        if (process.domain && config.callback) {
          this.callback = process.domain.bind(config.callback);
        }
        this._result = new Result2(this._rowMode, this.types);
        this._results = this._result;
        this._canceledDueToError = false;
      }
      requiresPreparation() {
        if (this.queryMode === "extended") {
          return true;
        }
        if (this.name) {
          return true;
        }
        if (this.rows) {
          return true;
        }
        if (!this.text) {
          return false;
        }
        if (!this.values) {
          return false;
        }
        return this.values.length > 0;
      }
      _checkForMultirow() {
        if (this._result.command) {
          if (!Array.isArray(this._results)) {
            this._results = [this._result];
          }
          this._result = new Result2(this._rowMode, this._result._types);
          this._results.push(this._result);
        }
      }
      // associates row metadata from the supplied
      // message with this query object
      // metadata used when parsing row results
      handleRowDescription(msg) {
        this._checkForMultirow();
        this._result.addFields(msg.fields);
        this._accumulateRows = this.callback || !this.listeners("row").length;
      }
      handleDataRow(msg) {
        let row;
        if (this._canceledDueToError) {
          return;
        }
        try {
          row = this._result.parseRow(msg.fields);
        } catch (err) {
          this._canceledDueToError = err;
          return;
        }
        this.emit("row", row, this._result);
        if (this._accumulateRows) {
          this._result.addRow(row);
        }
      }
      handleCommandComplete(msg, connection) {
        this._checkForMultirow();
        this._result.addCommandComplete(msg);
        if (this.rows) {
          connection.sync();
        }
      }
      // if a named prepared statement is created with empty query text
      // the backend will send an emptyQuery message but *not* a command complete message
      // since we pipeline sync immediately after execute we don't need to do anything here
      // unless we have rows specified, in which case we did not pipeline the initial sync call
      handleEmptyQuery(connection) {
        if (this.rows) {
          connection.sync();
        }
      }
      handleError(err, connection) {
        if (this._canceledDueToError) {
          err = this._canceledDueToError;
          this._canceledDueToError = false;
        }
        if (this.callback) {
          return this.callback(err);
        }
        this.emit("error", err);
      }
      handleReadyForQuery(con) {
        if (this._canceledDueToError) {
          return this.handleError(this._canceledDueToError, con);
        }
        if (this.callback) {
          try {
            this.callback(null, this._results);
          } catch (err) {
            process.nextTick(() => {
              throw err;
            });
          }
        }
        this.emit("end", this._results);
      }
      submit(connection) {
        if (typeof this.text !== "string" && typeof this.name !== "string") {
          return new Error("A query must have either text or a name. Supplying neither is unsupported.");
        }
        const previous = connection.parsedStatements[this.name] || connection.submittedNamedStatements[this.name];
        if (this.text && previous && this.text !== previous) {
          return new Error(`Prepared statements must be unique - '${this.name}' was used for a different statement`);
        }
        if (this.values && !Array.isArray(this.values)) {
          return new Error("Query values must be an array");
        }
        if (this.requiresPreparation()) {
          connection.stream.cork && connection.stream.cork();
          try {
            this.prepare(connection);
          } finally {
            connection.stream.uncork && connection.stream.uncork();
          }
        } else {
          connection.query(this.text);
        }
        return null;
      }
      hasBeenParsed(connection) {
        return this.name && (connection.parsedStatements[this.name] !== void 0 || connection.submittedNamedStatements[this.name] !== void 0);
      }
      handlePortalSuspended(connection) {
        this._getRows(connection, this.rows);
      }
      _getRows(connection, rows) {
        connection.execute({
          portal: this.portal,
          rows
        });
        if (!rows) {
          connection.sync();
        } else {
          connection.flush();
        }
      }
      // http://developer.postgresql.org/pgdocs/postgres/protocol-flow.html#PROTOCOL-FLOW-EXT-QUERY
      prepare(connection) {
        if (!this.hasBeenParsed(connection)) {
          connection.parse({
            text: this.text,
            name: this.name,
            types: this.types
          });
          if (this.name) {
            connection.submittedNamedStatements[this.name] = this.text;
          }
        }
        try {
          connection.bind({
            portal: this.portal,
            statement: this.name,
            values: this.values,
            binary: this.binary,
            valueMapper: utils.prepareValue
          });
        } catch (err) {
          connection.close({ type: "S", name: this.name });
          connection.sync();
          this.handleError(err, connection);
          return;
        }
        connection.describe({
          type: "P",
          name: this.portal || ""
        });
        this._getRows(connection, this.rows);
      }
      handleCopyInResponse(connection) {
        connection.sendCopyFail("No source stream defined");
      }
      handleCopyData(msg, connection) {
      }
    };
    module.exports = Query2;
  }
});

// node_modules/pg-protocol/dist/messages.js
var require_messages = __commonJS({
  "node_modules/pg-protocol/dist/messages.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.NoticeMessage = exports.DataRowMessage = exports.CommandCompleteMessage = exports.ReadyForQueryMessage = exports.NotificationResponseMessage = exports.BackendKeyDataMessage = exports.AuthenticationMD5Password = exports.ParameterStatusMessage = exports.ParameterDescriptionMessage = exports.RowDescriptionMessage = exports.Field = exports.CopyResponse = exports.CopyDataMessage = exports.DatabaseError = exports.copyDone = exports.emptyQuery = exports.replicationStart = exports.portalSuspended = exports.noData = exports.closeComplete = exports.bindComplete = exports.parseComplete = void 0;
    exports.parseComplete = {
      name: "parseComplete",
      length: 5
    };
    exports.bindComplete = {
      name: "bindComplete",
      length: 5
    };
    exports.closeComplete = {
      name: "closeComplete",
      length: 5
    };
    exports.noData = {
      name: "noData",
      length: 5
    };
    exports.portalSuspended = {
      name: "portalSuspended",
      length: 5
    };
    exports.replicationStart = {
      name: "replicationStart",
      length: 4
    };
    exports.emptyQuery = {
      name: "emptyQuery",
      length: 4
    };
    exports.copyDone = {
      name: "copyDone",
      length: 4
    };
    var DatabaseError2 = class extends Error {
      constructor(message, length, name) {
        super(message);
        this.length = length;
        this.name = name;
      }
    };
    exports.DatabaseError = DatabaseError2;
    var CopyDataMessage = class {
      constructor(length, chunk) {
        this.length = length;
        this.chunk = chunk;
        this.name = "copyData";
      }
    };
    exports.CopyDataMessage = CopyDataMessage;
    var CopyResponse = class {
      constructor(length, name, binary, columnCount) {
        this.length = length;
        this.name = name;
        this.binary = binary;
        this.columnTypes = new Array(columnCount);
      }
    };
    exports.CopyResponse = CopyResponse;
    var Field = class {
      constructor(name, tableID, columnID, dataTypeID, dataTypeSize, dataTypeModifier, format) {
        this.name = name;
        this.tableID = tableID;
        this.columnID = columnID;
        this.dataTypeID = dataTypeID;
        this.dataTypeSize = dataTypeSize;
        this.dataTypeModifier = dataTypeModifier;
        this.format = format;
      }
    };
    exports.Field = Field;
    var RowDescriptionMessage = class {
      constructor(length, fieldCount) {
        this.length = length;
        this.fieldCount = fieldCount;
        this.name = "rowDescription";
        this.fields = new Array(this.fieldCount);
      }
    };
    exports.RowDescriptionMessage = RowDescriptionMessage;
    var ParameterDescriptionMessage = class {
      constructor(length, parameterCount) {
        this.length = length;
        this.parameterCount = parameterCount;
        this.name = "parameterDescription";
        this.dataTypeIDs = new Array(this.parameterCount);
      }
    };
    exports.ParameterDescriptionMessage = ParameterDescriptionMessage;
    var ParameterStatusMessage = class {
      constructor(length, parameterName, parameterValue) {
        this.length = length;
        this.parameterName = parameterName;
        this.parameterValue = parameterValue;
        this.name = "parameterStatus";
      }
    };
    exports.ParameterStatusMessage = ParameterStatusMessage;
    var AuthenticationMD5Password = class {
      constructor(length, salt) {
        this.length = length;
        this.salt = salt;
        this.name = "authenticationMD5Password";
      }
    };
    exports.AuthenticationMD5Password = AuthenticationMD5Password;
    var BackendKeyDataMessage = class {
      constructor(length, processID, secretKey) {
        this.length = length;
        this.processID = processID;
        this.secretKey = secretKey;
        this.name = "backendKeyData";
      }
    };
    exports.BackendKeyDataMessage = BackendKeyDataMessage;
    var NotificationResponseMessage = class {
      constructor(length, processId, channel, payload) {
        this.length = length;
        this.processId = processId;
        this.channel = channel;
        this.payload = payload;
        this.name = "notification";
      }
    };
    exports.NotificationResponseMessage = NotificationResponseMessage;
    var ReadyForQueryMessage = class {
      constructor(length, status) {
        this.length = length;
        this.status = status;
        this.name = "readyForQuery";
      }
    };
    exports.ReadyForQueryMessage = ReadyForQueryMessage;
    var CommandCompleteMessage = class {
      constructor(length, text) {
        this.length = length;
        this.text = text;
        this.name = "commandComplete";
      }
    };
    exports.CommandCompleteMessage = CommandCompleteMessage;
    var DataRowMessage = class {
      constructor(length, fields) {
        this.length = length;
        this.fields = fields;
        this.name = "dataRow";
        this.fieldCount = fields.length;
      }
    };
    exports.DataRowMessage = DataRowMessage;
    var NoticeMessage = class {
      constructor(length, message) {
        this.length = length;
        this.message = message;
        this.name = "notice";
      }
    };
    exports.NoticeMessage = NoticeMessage;
  }
});

// node_modules/pg-protocol/dist/buffer-writer.js
var require_buffer_writer = __commonJS({
  "node_modules/pg-protocol/dist/buffer-writer.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Writer = void 0;
    var Writer = class {
      constructor(size = 256) {
        this.size = size;
        this.offset = 5;
        this.headerPosition = 0;
        this.buffer = Buffer.allocUnsafe(size);
      }
      ensure(size) {
        const remaining = this.buffer.length - this.offset;
        if (remaining < size) {
          const oldBuffer = this.buffer;
          const newSize = oldBuffer.length + (oldBuffer.length >> 1) + size;
          this.buffer = Buffer.allocUnsafe(newSize);
          oldBuffer.copy(this.buffer, 0, 0, this.offset);
        }
      }
      addInt32(num) {
        this.ensure(4);
        this.buffer[this.offset++] = num >>> 24 & 255;
        this.buffer[this.offset++] = num >>> 16 & 255;
        this.buffer[this.offset++] = num >>> 8 & 255;
        this.buffer[this.offset++] = num >>> 0 & 255;
        return this;
      }
      addInt16(num) {
        this.ensure(2);
        this.buffer[this.offset++] = num >>> 8 & 255;
        this.buffer[this.offset++] = num >>> 0 & 255;
        return this;
      }
      addCString(string) {
        if (!string) {
          this.ensure(1);
        } else {
          const len = Buffer.byteLength(string);
          this.ensure(len + 1);
          this.buffer.write(string, this.offset, "utf-8");
          this.offset += len;
        }
        this.buffer[this.offset++] = 0;
        return this;
      }
      addString(string = "") {
        const len = Buffer.byteLength(string);
        this.ensure(len);
        this.buffer.write(string, this.offset);
        this.offset += len;
        return this;
      }
      // Write an Int32 byte-length prefix immediately followed by the string's UTF-8
      // bytes. Postgres' Bind wire format prefixes every parameter with its length,
      // and doing it in one method computes Buffer.byteLength ONCE — the previous
      // `addInt32(Buffer.byteLength(s)).addString(s)` pairing scanned the string
      // three times (byteLength for the prefix, byteLength again inside addString,
      // then the encode), which is costly for large text parameters.
      addInt32PrefixedString(string) {
        const len = Buffer.byteLength(string);
        this.ensure(4 + len);
        const buffer = this.buffer;
        let offset2 = this.offset;
        buffer[offset2++] = len >>> 24 & 255;
        buffer[offset2++] = len >>> 16 & 255;
        buffer[offset2++] = len >>> 8 & 255;
        buffer[offset2++] = len >>> 0 & 255;
        buffer.write(string, offset2, "utf-8");
        this.offset = offset2 + len;
        return this;
      }
      add(otherBuffer) {
        this.ensure(otherBuffer.length);
        otherBuffer.copy(this.buffer, this.offset);
        this.offset += otherBuffer.length;
        return this;
      }
      /**
       * Appends an uninitialized block of {@link size} bytes to the buffer and returns its offset.
       */
      reserveUnsafe(size) {
        const offset2 = this.offset;
        this.ensure(size);
        this.offset += size;
        return offset2;
      }
      join(code) {
        if (code) {
          this.buffer[this.headerPosition] = code;
          const length = this.offset - (this.headerPosition + 1);
          this.buffer.writeInt32BE(length, this.headerPosition + 1);
        }
        return this.buffer.slice(code ? 0 : 5, this.offset);
      }
      flush(code) {
        const result = this.join(code);
        this.offset = 5;
        this.headerPosition = 0;
        this.buffer = Buffer.allocUnsafe(this.size);
        return result;
      }
      clear() {
        this.offset = 5;
        this.headerPosition = 0;
      }
    };
    exports.Writer = Writer;
  }
});

// node_modules/pg-protocol/dist/serializer.js
var require_serializer = __commonJS({
  "node_modules/pg-protocol/dist/serializer.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.serialize = void 0;
    var buffer_writer_1 = require_buffer_writer();
    var writer = new buffer_writer_1.Writer();
    var startup = (opts) => {
      writer.addInt16(3).addInt16(0);
      for (const key of Object.keys(opts)) {
        writer.addCString(key).addCString(opts[key]);
      }
      writer.addCString("client_encoding").addCString("UTF8");
      const bodyBuffer = writer.addCString("").flush();
      const length = bodyBuffer.length + 4;
      return new buffer_writer_1.Writer().addInt32(length).add(bodyBuffer).flush();
    };
    var requestSsl = () => {
      const response = Buffer.allocUnsafe(8);
      response.writeInt32BE(8, 0);
      response.writeInt32BE(80877103, 4);
      return response;
    };
    var password = (password2) => {
      return writer.addCString(password2).flush(
        112
        /* code.startup */
      );
    };
    var sendSASLInitialResponseMessage = function(mechanism, initialResponse) {
      writer.addCString(mechanism).addInt32PrefixedString(initialResponse);
      return writer.flush(
        112
        /* code.startup */
      );
    };
    var sendSCRAMClientFinalMessage = function(additionalData) {
      return writer.addString(additionalData).flush(
        112
        /* code.startup */
      );
    };
    var query = (text) => {
      return writer.addCString(text).flush(
        81
        /* code.query */
      );
    };
    var emptyArray = [];
    var parse = (query2) => {
      const name = query2.name || "";
      if (name.length > 63) {
        console.error("Warning! Postgres only supports 63 characters for query names.");
        console.error("You supplied %s (%s)", name, name.length);
        console.error("This can cause conflicts and silent errors executing queries");
      }
      const types2 = query2.types || emptyArray;
      const len = types2.length;
      const buffer = writer.addCString(name).addCString(query2.text).addInt16(len);
      for (let i = 0; i < len; i++) {
        buffer.addInt32(types2[i]);
      }
      return writer.flush(
        80
        /* code.parse */
      );
    };
    var writeValues = function(values, valueMapper, formatsOffset) {
      const len = values.length;
      for (let i = 0; i < len; i++) {
        const mappedVal = valueMapper ? valueMapper(values[i], i) : values[i];
        let formatByte = 0;
        if (mappedVal == null) {
          writer.addInt32(-1);
        } else if (mappedVal instanceof Buffer) {
          formatByte = 1;
          writer.addInt32(mappedVal.length);
          writer.add(mappedVal);
        } else {
          writer.addInt32PrefixedString(mappedVal);
        }
        const buf = writer.buffer;
        buf[formatsOffset++] = 0;
        buf[formatsOffset++] = formatByte;
      }
    };
    var bind = (config = {}) => {
      const portal = config.portal || "";
      const statement = config.statement || "";
      const binary = config.binary || false;
      const values = config.values || emptyArray;
      const len = values.length;
      writer.addCString(portal).addCString(statement);
      writer.addInt16(len);
      const formatsOffset = writer.reserveUnsafe(len * 2);
      writer.addInt16(len);
      try {
        writeValues(values, config.valueMapper, formatsOffset);
      } catch (err) {
        writer.clear();
        throw err;
      }
      writer.addInt16(1);
      writer.addInt16(
        binary ? 1 : 0
        /* ParamType.STRING */
      );
      return writer.flush(
        66
        /* code.bind */
      );
    };
    var emptyExecute = Buffer.from([69, 0, 0, 0, 9, 0, 0, 0, 0, 0]);
    var execute = (config) => {
      if (!config || !config.portal && !config.rows) {
        return emptyExecute;
      }
      const portal = config.portal || "";
      const rows = config.rows || 0;
      const portalLength = Buffer.byteLength(portal);
      const len = 4 + portalLength + 1 + 4;
      const buff = Buffer.allocUnsafe(1 + len);
      buff[0] = 69;
      buff.writeInt32BE(len, 1);
      buff.write(portal, 5, "utf-8");
      buff[portalLength + 5] = 0;
      buff.writeUInt32BE(rows, buff.length - 4);
      return buff;
    };
    var cancel = (processID, secretKey) => {
      const buffer = Buffer.allocUnsafe(16);
      buffer.writeInt32BE(16, 0);
      buffer.writeInt16BE(1234, 4);
      buffer.writeInt16BE(5678, 6);
      buffer.writeInt32BE(processID, 8);
      buffer.writeInt32BE(secretKey, 12);
      return buffer;
    };
    var cstringMessage = (code, string) => {
      const stringLen = Buffer.byteLength(string);
      const len = 4 + stringLen + 1;
      const buffer = Buffer.allocUnsafe(1 + len);
      buffer[0] = code;
      buffer.writeInt32BE(len, 1);
      buffer.write(string, 5, "utf-8");
      buffer[len] = 0;
      return buffer;
    };
    var emptyDescribePortal = writer.addCString("P").flush(
      68
      /* code.describe */
    );
    var emptyDescribeStatement = writer.addCString("S").flush(
      68
      /* code.describe */
    );
    var describe2 = (msg) => {
      return msg.name ? cstringMessage(68, `${msg.type}${msg.name || ""}`) : msg.type === "P" ? emptyDescribePortal : emptyDescribeStatement;
    };
    var close = (msg) => {
      const text = `${msg.type}${msg.name || ""}`;
      return cstringMessage(67, text);
    };
    var copyData = (chunk) => {
      return writer.add(chunk).flush(
        100
        /* code.copyFromChunk */
      );
    };
    var copyFail = (message) => {
      return cstringMessage(102, message);
    };
    var codeOnlyBuffer = (code) => Buffer.from([code, 0, 0, 0, 4]);
    var flushBuffer = codeOnlyBuffer(
      72
      /* code.flush */
    );
    var syncBuffer = codeOnlyBuffer(
      83
      /* code.sync */
    );
    var endBuffer = codeOnlyBuffer(
      88
      /* code.end */
    );
    var copyDoneBuffer = codeOnlyBuffer(
      99
      /* code.copyDone */
    );
    var serialize = {
      startup,
      password,
      requestSsl,
      sendSASLInitialResponseMessage,
      sendSCRAMClientFinalMessage,
      query,
      parse,
      bind,
      execute,
      describe: describe2,
      close,
      flush: () => flushBuffer,
      sync: () => syncBuffer,
      end: () => endBuffer,
      copyData,
      copyDone: () => copyDoneBuffer,
      copyFail,
      cancel
    };
    exports.serialize = serialize;
  }
});

// node_modules/pg-protocol/dist/buffer-reader.js
var require_buffer_reader = __commonJS({
  "node_modules/pg-protocol/dist/buffer-reader.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.BufferReader = void 0;
    var BufferReader = class {
      constructor(offset2 = 0) {
        this.offset = offset2;
        this.buffer = Buffer.allocUnsafe(0);
        this.encoding = "utf-8";
      }
      setBuffer(offset2, buffer) {
        this.offset = offset2;
        this.buffer = buffer;
      }
      int16() {
        const result = this.buffer.readInt16BE(this.offset);
        this.offset += 2;
        return result;
      }
      byte() {
        const result = this.buffer[this.offset];
        this.offset++;
        return result;
      }
      int32() {
        const result = this.buffer.readInt32BE(this.offset);
        this.offset += 4;
        return result;
      }
      uint32() {
        const result = this.buffer.readUInt32BE(this.offset);
        this.offset += 4;
        return result;
      }
      string(length) {
        const result = this.buffer.toString(this.encoding, this.offset, this.offset + length);
        this.offset += length;
        return result;
      }
      cstring() {
        const start = this.offset;
        let end = start;
        while (this.buffer[end++]) {
        }
        this.offset = end;
        return this.buffer.toString(this.encoding, start, end - 1);
      }
      bytes(length) {
        const result = this.buffer.slice(this.offset, this.offset + length);
        this.offset += length;
        return result;
      }
    };
    exports.BufferReader = BufferReader;
  }
});

// node_modules/pg-protocol/dist/parser.js
var require_parser = __commonJS({
  "node_modules/pg-protocol/dist/parser.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Parser = void 0;
    var messages_1 = require_messages();
    var buffer_reader_1 = require_buffer_reader();
    var CODE_LENGTH = 1;
    var LEN_LENGTH = 4;
    var HEADER_LENGTH = CODE_LENGTH + LEN_LENGTH;
    var LATEINIT_LENGTH = -1;
    var emptyBuffer = Buffer.allocUnsafe(0);
    var Parser = class {
      constructor(opts) {
        this.buffer = emptyBuffer;
        this.bufferLength = 0;
        this.bufferOffset = 0;
        this.reader = new buffer_reader_1.BufferReader();
        if ((opts === null || opts === void 0 ? void 0 : opts.mode) === "binary") {
          throw new Error("Binary mode not supported yet");
        }
        this.mode = (opts === null || opts === void 0 ? void 0 : opts.mode) || "text";
      }
      parse(buffer, callback) {
        this.mergeBuffer(buffer);
        const bufferFullLength = this.bufferOffset + this.bufferLength;
        let offset2 = this.bufferOffset;
        while (offset2 + HEADER_LENGTH <= bufferFullLength) {
          const code = this.buffer[offset2];
          const length = this.buffer.readUInt32BE(offset2 + CODE_LENGTH);
          const fullMessageLength = CODE_LENGTH + length;
          if (fullMessageLength + offset2 <= bufferFullLength) {
            const message = this.handlePacket(offset2 + HEADER_LENGTH, code, length, this.buffer);
            callback(message);
            offset2 += fullMessageLength;
          } else {
            break;
          }
        }
        if (offset2 === bufferFullLength) {
          this.buffer = emptyBuffer;
          this.bufferLength = 0;
          this.bufferOffset = 0;
        } else {
          this.bufferLength = bufferFullLength - offset2;
          this.bufferOffset = offset2;
        }
      }
      mergeBuffer(buffer) {
        if (this.bufferLength > 0) {
          const newLength = this.bufferLength + buffer.byteLength;
          const newFullLength = newLength + this.bufferOffset;
          if (newFullLength > this.buffer.byteLength) {
            let newBuffer;
            if (newLength <= this.buffer.byteLength && this.bufferOffset >= this.bufferLength) {
              newBuffer = this.buffer;
            } else {
              let newBufferLength = this.buffer.byteLength * 2;
              while (newLength >= newBufferLength) {
                newBufferLength *= 2;
              }
              newBuffer = Buffer.allocUnsafe(newBufferLength);
            }
            this.buffer.copy(newBuffer, 0, this.bufferOffset, this.bufferOffset + this.bufferLength);
            this.buffer = newBuffer;
            this.bufferOffset = 0;
          }
          buffer.copy(this.buffer, this.bufferOffset + this.bufferLength);
          this.bufferLength = newLength;
        } else {
          this.buffer = buffer;
          this.bufferOffset = 0;
          this.bufferLength = buffer.byteLength;
        }
      }
      handlePacket(offset2, code, length, bytes) {
        const { reader } = this;
        reader.setBuffer(offset2, bytes);
        let message;
        switch (code) {
          case 50:
            message = messages_1.bindComplete;
            break;
          case 49:
            message = messages_1.parseComplete;
            break;
          case 51:
            message = messages_1.closeComplete;
            break;
          case 110:
            message = messages_1.noData;
            break;
          case 115:
            message = messages_1.portalSuspended;
            break;
          case 99:
            message = messages_1.copyDone;
            break;
          case 87:
            message = messages_1.replicationStart;
            break;
          case 73:
            message = messages_1.emptyQuery;
            break;
          case 68:
            message = parseDataRowMessage(reader);
            break;
          case 67:
            message = parseCommandCompleteMessage(reader);
            break;
          case 90:
            message = parseReadyForQueryMessage(reader);
            break;
          case 65:
            message = parseNotificationMessage(reader);
            break;
          case 82:
            message = parseAuthenticationResponse(reader, length);
            break;
          case 83:
            message = parseParameterStatusMessage(reader);
            break;
          case 75:
            message = parseBackendKeyData(reader);
            break;
          case 69:
            message = parseErrorMessage(reader, "error");
            break;
          case 78:
            message = parseErrorMessage(reader, "notice");
            break;
          case 84:
            message = parseRowDescriptionMessage(reader);
            break;
          case 116:
            message = parseParameterDescriptionMessage(reader);
            break;
          case 71:
            message = parseCopyInMessage(reader);
            break;
          case 72:
            message = parseCopyOutMessage(reader);
            break;
          case 100:
            message = parseCopyData(reader, length);
            break;
          default:
            return new messages_1.DatabaseError("received invalid response: " + code.toString(16), length, "error");
        }
        reader.setBuffer(0, emptyBuffer);
        message.length = length;
        return message;
      }
    };
    exports.Parser = Parser;
    var parseReadyForQueryMessage = (reader) => {
      const status = reader.string(1);
      return new messages_1.ReadyForQueryMessage(LATEINIT_LENGTH, status);
    };
    var parseCommandCompleteMessage = (reader) => {
      const text = reader.cstring();
      return new messages_1.CommandCompleteMessage(LATEINIT_LENGTH, text);
    };
    var parseCopyData = (reader, length) => {
      const chunk = reader.bytes(length - 4);
      return new messages_1.CopyDataMessage(LATEINIT_LENGTH, chunk);
    };
    var parseCopyInMessage = (reader) => parseCopyMessage(reader, "copyInResponse");
    var parseCopyOutMessage = (reader) => parseCopyMessage(reader, "copyOutResponse");
    var parseCopyMessage = (reader, messageName) => {
      const isBinary = reader.byte() !== 0;
      const columnCount = reader.int16();
      const message = new messages_1.CopyResponse(LATEINIT_LENGTH, messageName, isBinary, columnCount);
      for (let i = 0; i < columnCount; i++) {
        message.columnTypes[i] = reader.int16();
      }
      return message;
    };
    var parseNotificationMessage = (reader) => {
      const processId = reader.int32();
      const channel = reader.cstring();
      const payload = reader.cstring();
      return new messages_1.NotificationResponseMessage(LATEINIT_LENGTH, processId, channel, payload);
    };
    var parseRowDescriptionMessage = (reader) => {
      const fieldCount = reader.int16();
      const message = new messages_1.RowDescriptionMessage(LATEINIT_LENGTH, fieldCount);
      for (let i = 0; i < fieldCount; i++) {
        message.fields[i] = parseField(reader);
      }
      return message;
    };
    var parseField = (reader) => {
      const name = reader.cstring();
      const tableID = reader.uint32();
      const columnID = reader.int16();
      const dataTypeID = reader.uint32();
      const dataTypeSize = reader.int16();
      const dataTypeModifier = reader.int32();
      const mode = reader.int16() === 0 ? "text" : "binary";
      return new messages_1.Field(name, tableID, columnID, dataTypeID, dataTypeSize, dataTypeModifier, mode);
    };
    var parseParameterDescriptionMessage = (reader) => {
      const parameterCount = reader.int16();
      const message = new messages_1.ParameterDescriptionMessage(LATEINIT_LENGTH, parameterCount);
      for (let i = 0; i < parameterCount; i++) {
        message.dataTypeIDs[i] = reader.uint32();
      }
      return message;
    };
    var parseDataRowMessage = (reader) => {
      const fieldCount = reader.int16();
      const fields = new Array(fieldCount);
      for (let i = 0; i < fieldCount; i++) {
        const len = reader.int32();
        fields[i] = len === -1 ? null : reader.string(len);
      }
      return new messages_1.DataRowMessage(LATEINIT_LENGTH, fields);
    };
    var parseParameterStatusMessage = (reader) => {
      const name = reader.cstring();
      const value = reader.cstring();
      return new messages_1.ParameterStatusMessage(LATEINIT_LENGTH, name, value);
    };
    var parseBackendKeyData = (reader) => {
      const processID = reader.int32();
      const secretKey = reader.int32();
      return new messages_1.BackendKeyDataMessage(LATEINIT_LENGTH, processID, secretKey);
    };
    var parseAuthenticationResponse = (reader, length) => {
      const code = reader.int32();
      const message = {
        name: "authenticationOk",
        length
      };
      switch (code) {
        case 0:
          break;
        case 3:
          if (message.length === 8) {
            message.name = "authenticationCleartextPassword";
          }
          break;
        case 5:
          if (message.length === 12) {
            message.name = "authenticationMD5Password";
            const salt = reader.bytes(4);
            return new messages_1.AuthenticationMD5Password(LATEINIT_LENGTH, salt);
          }
          break;
        case 10:
          {
            message.name = "authenticationSASL";
            message.mechanisms = [];
            let mechanism;
            do {
              mechanism = reader.cstring();
              if (mechanism) {
                message.mechanisms.push(mechanism);
              }
            } while (mechanism);
          }
          break;
        case 11:
          message.name = "authenticationSASLContinue";
          message.data = reader.string(length - 8);
          break;
        case 12:
          message.name = "authenticationSASLFinal";
          message.data = reader.string(length - 8);
          break;
        default:
          throw new Error("Unknown authenticationOk message type " + code);
      }
      return message;
    };
    var parseErrorMessage = (reader, name) => {
      const fields = {};
      let fieldType = reader.string(1);
      while (fieldType !== "\0") {
        fields[fieldType] = reader.cstring();
        fieldType = reader.string(1);
      }
      const messageValue = fields.M;
      const message = name === "notice" ? new messages_1.NoticeMessage(LATEINIT_LENGTH, messageValue) : new messages_1.DatabaseError(messageValue, LATEINIT_LENGTH, name);
      message.severity = fields.S;
      message.code = fields.C;
      message.detail = fields.D;
      message.hint = fields.H;
      message.position = fields.P;
      message.internalPosition = fields.p;
      message.internalQuery = fields.q;
      message.where = fields.W;
      message.schema = fields.s;
      message.table = fields.t;
      message.column = fields.c;
      message.dataType = fields.d;
      message.constraint = fields.n;
      message.file = fields.F;
      message.line = fields.L;
      message.routine = fields.R;
      return message;
    };
  }
});

// node_modules/pg-protocol/dist/index.js
var require_dist = __commonJS({
  "node_modules/pg-protocol/dist/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.DatabaseError = exports.serialize = void 0;
    exports.parse = parse;
    var messages_1 = require_messages();
    Object.defineProperty(exports, "DatabaseError", { enumerable: true, get: function() {
      return messages_1.DatabaseError;
    } });
    var serializer_1 = require_serializer();
    Object.defineProperty(exports, "serialize", { enumerable: true, get: function() {
      return serializer_1.serialize;
    } });
    var parser_1 = require_parser();
    function parse(stream, callback) {
      const parser = new parser_1.Parser();
      stream.on("data", (buffer) => parser.parse(buffer, callback));
      return new Promise((resolve) => stream.on("end", () => resolve()));
    }
  }
});

// node_modules/pg-cloudflare/dist/empty.js
var require_empty = __commonJS({
  "node_modules/pg-cloudflare/dist/empty.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = {};
  }
});

// node_modules/pg/lib/stream.js
var require_stream = __commonJS({
  "node_modules/pg/lib/stream.js"(exports, module) {
    var { getStream, getSecureStream } = getStreamFuncs();
    module.exports = {
      /**
       * Get a socket stream compatible with the current runtime environment.
       * @returns {Duplex}
       */
      getStream,
      /**
       * Get a TLS secured socket, compatible with the current environment,
       * using the socket and other settings given in `options`.
       * @returns {Duplex}
       */
      getSecureStream
    };
    function getNodejsStreamFuncs() {
      function getStream2(ssl) {
        const net = __require("net");
        return new net.Socket();
      }
      function getSecureStream2(options) {
        const tls = __require("tls");
        return tls.connect(options);
      }
      return {
        getStream: getStream2,
        getSecureStream: getSecureStream2
      };
    }
    function getCloudflareStreamFuncs() {
      function getStream2(ssl) {
        const { CloudflareSocket } = require_empty();
        return new CloudflareSocket(ssl);
      }
      function getSecureStream2(options) {
        options.socket.startTls(options);
        return options.socket;
      }
      return {
        getStream: getStream2,
        getSecureStream: getSecureStream2
      };
    }
    function isCloudflareRuntime() {
      if (typeof navigator === "object" && navigator !== null && typeof navigator.userAgent === "string") {
        return navigator.userAgent === "Cloudflare-Workers";
      }
      if (typeof Response === "function") {
        const resp = new Response(null, { cf: { thing: true } });
        if (typeof resp.cf === "object" && resp.cf !== null && resp.cf.thing) {
          return true;
        }
      }
      return false;
    }
    function getStreamFuncs() {
      if (isCloudflareRuntime()) {
        return getCloudflareStreamFuncs();
      }
      return getNodejsStreamFuncs();
    }
  }
});

// node_modules/pg/lib/connection.js
var require_connection = __commonJS({
  "node_modules/pg/lib/connection.js"(exports, module) {
    "use strict";
    var EventEmitter2 = __require("events").EventEmitter;
    var { parse, serialize } = require_dist();
    var stream = require_stream();
    var { getStream } = stream;
    var flushBuffer = serialize.flush();
    var syncBuffer = serialize.sync();
    var endBuffer = serialize.end();
    var Connection2 = class extends EventEmitter2 {
      constructor(config) {
        super();
        config = config || {};
        this.stream = config.stream || getStream(config.ssl);
        if (typeof this.stream === "function") {
          this.stream = this.stream(config);
        }
        this._keepAlive = config.keepAlive;
        this._keepAliveInitialDelayMillis = config.keepAliveInitialDelayMillis;
        this.parsedStatements = {};
        this.submittedNamedStatements = {};
        this.ssl = config.ssl || false;
        this.sslNegotiation = config.sslNegotiation || "postgres";
        this._ending = false;
        this._emitMessage = false;
        const self = this;
        this.on("newListener", function(eventName) {
          if (eventName === "message") {
            self._emitMessage = true;
          }
        });
      }
      connect(port, host) {
        const self = this;
        this._connecting = true;
        this.stream.setNoDelay(true);
        this.stream.connect(port, host);
        this.stream.once("connect", function() {
          if (self._keepAlive) {
            self.stream.setKeepAlive(true, self._keepAliveInitialDelayMillis);
          }
          self.emit("connect");
        });
        const reportStreamError = function(error) {
          if (self._ending && (error.code === "ECONNRESET" || error.code === "EPIPE")) {
            return;
          }
          self.emit("error", error);
        };
        this.stream.on("error", reportStreamError);
        this.stream.on("close", function() {
          self.emit("end");
        });
        if (!this.ssl) {
          return this.attachListeners(this.stream);
        }
        if (this.sslNegotiation === "direct") {
          return this.stream.once("connect", function() {
            self.upgradeToSSL(host, reportStreamError);
          });
        }
        this.stream.once("data", function(buffer) {
          const responseCode = buffer.toString("utf8");
          switch (responseCode) {
            case "S":
              break;
            case "N":
              self.stream.end();
              return self.emit("error", new Error("The server does not support SSL connections"));
            default:
              self.stream.end();
              return self.emit("error", new Error("There was an error establishing an SSL connection"));
          }
          self.upgradeToSSL(host, reportStreamError);
        });
      }
      upgradeToSSL(host, reportStreamError) {
        const self = this;
        const options = {
          socket: self.stream,
          // tls.connect checks the server identity against `servername`, falling
          // back to `host` and then to 'localhost'. `servername` must stay unset
          // for IP addresses (see below), so `host` is needed to keep certificate
          // validation working when connecting to an IP address.
          host
        };
        if (self.ssl !== true) {
          Object.assign(options, self.ssl);
          if ("key" in self.ssl) {
            options.key = self.ssl.key;
          }
        }
        if (self.sslNegotiation === "direct") {
          options.ALPNProtocols = ["postgresql"];
        }
        const net = __require("net");
        if (net.isIP && net.isIP(host) === 0) {
          options.servername = host;
        }
        try {
          self.stream = stream.getSecureStream(options);
        } catch (err) {
          return self.emit("error", err);
        }
        self.attachListeners(self.stream);
        self.stream.on("error", reportStreamError);
        self.emit("sslconnect");
      }
      attachListeners(stream2) {
        parse(stream2, (msg) => {
          const eventName = msg.name === "error" ? "errorMessage" : msg.name;
          if (this._emitMessage) {
            this.emit("message", msg);
          }
          this.emit(eventName, msg);
        });
      }
      requestSsl() {
        this.stream.write(serialize.requestSsl());
      }
      startup(config) {
        this.stream.write(serialize.startup(config));
      }
      cancel(processID, secretKey) {
        this._send(serialize.cancel(processID, secretKey));
      }
      password(password) {
        this._send(serialize.password(password));
      }
      sendSASLInitialResponseMessage(mechanism, initialResponse) {
        this._send(serialize.sendSASLInitialResponseMessage(mechanism, initialResponse));
      }
      sendSCRAMClientFinalMessage(additionalData) {
        this._send(serialize.sendSCRAMClientFinalMessage(additionalData));
      }
      _send(buffer) {
        if (!this.stream.writable) {
          return false;
        }
        return this.stream.write(buffer);
      }
      query(text) {
        this._send(serialize.query(text));
      }
      // send parse message
      parse(query) {
        this._send(serialize.parse(query));
      }
      // send bind message
      bind(config) {
        this._send(serialize.bind(config));
      }
      // send execute message
      execute(config) {
        this._send(serialize.execute(config));
      }
      flush() {
        if (this.stream.writable) {
          this.stream.write(flushBuffer);
        }
      }
      sync() {
        this._send(syncBuffer);
      }
      ref() {
        this.stream.ref();
      }
      unref() {
        this.stream.unref();
      }
      end() {
        this._ending = true;
        if (!this._connecting || !this.stream.writable) {
          this.stream.end();
          return;
        }
        return this.stream.write(endBuffer, () => {
          this.stream.end();
        });
      }
      close(msg) {
        this._send(serialize.close(msg));
      }
      describe(msg) {
        this._send(serialize.describe(msg));
      }
      sendCopyFromChunk(chunk) {
        this._send(serialize.copyData(chunk));
      }
      endCopyFrom() {
        this._send(serialize.copyDone());
      }
      sendCopyFail(msg) {
        this._send(serialize.copyFail(msg));
      }
    };
    module.exports = Connection2;
  }
});

// node_modules/split2/index.js
var require_split2 = __commonJS({
  "node_modules/split2/index.js"(exports, module) {
    "use strict";
    var { Transform } = __require("stream");
    var { StringDecoder } = __require("string_decoder");
    var kLast = /* @__PURE__ */ Symbol("last");
    var kDecoder = /* @__PURE__ */ Symbol("decoder");
    function transform(chunk, enc, cb) {
      let list2;
      if (this.overflow) {
        const buf = this[kDecoder].write(chunk);
        list2 = buf.split(this.matcher);
        if (list2.length === 1) return cb();
        list2.shift();
        this.overflow = false;
      } else {
        this[kLast] += this[kDecoder].write(chunk);
        list2 = this[kLast].split(this.matcher);
      }
      this[kLast] = list2.pop();
      for (let i = 0; i < list2.length; i++) {
        try {
          push(this, this.mapper(list2[i]));
        } catch (error) {
          return cb(error);
        }
      }
      this.overflow = this[kLast].length > this.maxLength;
      if (this.overflow && !this.skipOverflow) {
        cb(new Error("maximum buffer reached"));
        return;
      }
      cb();
    }
    function flush(cb) {
      this[kLast] += this[kDecoder].end();
      if (this[kLast]) {
        try {
          push(this, this.mapper(this[kLast]));
        } catch (error) {
          return cb(error);
        }
      }
      cb();
    }
    function push(self, val) {
      if (val !== void 0) {
        self.push(val);
      }
    }
    function noop(incoming) {
      return incoming;
    }
    function split2(matcher, mapper, options) {
      matcher = matcher || /\r?\n/;
      mapper = mapper || noop;
      options = options || {};
      switch (arguments.length) {
        case 1:
          if (typeof matcher === "function") {
            mapper = matcher;
            matcher = /\r?\n/;
          } else if (typeof matcher === "object" && !(matcher instanceof RegExp) && !matcher[Symbol.split]) {
            options = matcher;
            matcher = /\r?\n/;
          }
          break;
        case 2:
          if (typeof matcher === "function") {
            options = mapper;
            mapper = matcher;
            matcher = /\r?\n/;
          } else if (typeof mapper === "object") {
            options = mapper;
            mapper = noop;
          }
      }
      options = Object.assign({}, options);
      options.autoDestroy = true;
      options.transform = transform;
      options.flush = flush;
      options.readableObjectMode = true;
      const stream = new Transform(options);
      stream[kLast] = "";
      stream[kDecoder] = new StringDecoder("utf8");
      stream.matcher = matcher;
      stream.mapper = mapper;
      stream.maxLength = options.maxLength;
      stream.skipOverflow = options.skipOverflow || false;
      stream.overflow = false;
      stream._destroy = function(err, cb) {
        this._writableState.errorEmitted = false;
        cb(err);
      };
      return stream;
    }
    module.exports = split2;
  }
});

// node_modules/pgpass/lib/helper.js
var require_helper = __commonJS({
  "node_modules/pgpass/lib/helper.js"(exports, module) {
    "use strict";
    var path = __require("path");
    var Stream = __require("stream").Stream;
    var split2 = require_split2();
    var util = __require("util");
    var defaultPort = 5432;
    var isWin = process.platform === "win32";
    var warnStream = process.stderr;
    var S_IRWXG = 56;
    var S_IRWXO = 7;
    var S_IFMT = 61440;
    var S_IFREG = 32768;
    function isRegFile(mode) {
      return (mode & S_IFMT) == S_IFREG;
    }
    var fieldNames = ["host", "port", "database", "user", "password"];
    var nrOfFields = fieldNames.length;
    var passKey = fieldNames[nrOfFields - 1];
    function warn() {
      var isWritable = warnStream instanceof Stream && true === warnStream.writable;
      if (isWritable) {
        var args = Array.prototype.slice.call(arguments).concat("\n");
        warnStream.write(util.format.apply(util, args));
      }
    }
    Object.defineProperty(module.exports, "isWin", {
      get: function() {
        return isWin;
      },
      set: function(val) {
        isWin = val;
      }
    });
    module.exports.warnTo = function(stream) {
      var old = warnStream;
      warnStream = stream;
      return old;
    };
    module.exports.getFileName = function(rawEnv) {
      var env = rawEnv || process.env;
      var file = env.PGPASSFILE || (isWin ? path.join(env.APPDATA || "./", "postgresql", "pgpass.conf") : path.join(env.HOME || "./", ".pgpass"));
      return file;
    };
    module.exports.usePgPass = function(stats, fname) {
      if (Object.prototype.hasOwnProperty.call(process.env, "PGPASSWORD")) {
        return false;
      }
      if (isWin) {
        return true;
      }
      fname = fname || "<unkn>";
      if (!isRegFile(stats.mode)) {
        warn('WARNING: password file "%s" is not a plain file', fname);
        return false;
      }
      if (stats.mode & (S_IRWXG | S_IRWXO)) {
        warn('WARNING: password file "%s" has group or world access; permissions should be u=rw (0600) or less', fname);
        return false;
      }
      return true;
    };
    var matcher = module.exports.match = function(connInfo, entry) {
      return fieldNames.slice(0, -1).reduce(function(prev, field, idx) {
        if (idx == 1) {
          if (Number(connInfo[field] || defaultPort) === Number(entry[field])) {
            return prev && true;
          }
        }
        return prev && (entry[field] === "*" || entry[field] === connInfo[field]);
      }, true);
    };
    module.exports.getPassword = function(connInfo, stream, cb) {
      var pass;
      var lineStream = stream.pipe(split2());
      function onLine(line) {
        var entry = parseLine(line);
        if (entry && isValidEntry(entry) && matcher(connInfo, entry)) {
          pass = entry[passKey];
          lineStream.end();
        }
      }
      var onEnd = function() {
        stream.destroy();
        cb(pass);
      };
      var onErr = function(err) {
        stream.destroy();
        warn("WARNING: error on reading file: %s", err);
        cb(void 0);
      };
      stream.on("error", onErr);
      lineStream.on("data", onLine).on("end", onEnd).on("error", onErr);
    };
    var parseLine = module.exports.parseLine = function(line) {
      if (line.length < 11 || line.match(/^\s+#/)) {
        return null;
      }
      var curChar = "";
      var prevChar = "";
      var fieldIdx = 0;
      var startIdx = 0;
      var endIdx = 0;
      var obj = {};
      var isLastField = false;
      var addToObj = function(idx, i0, i1) {
        var field = line.substring(i0, i1);
        if (!Object.hasOwnProperty.call(process.env, "PGPASS_NO_DEESCAPE")) {
          field = field.replace(/\\([:\\])/g, "$1");
        }
        obj[fieldNames[idx]] = field;
      };
      for (var i = 0; i < line.length - 1; i += 1) {
        curChar = line.charAt(i + 1);
        prevChar = line.charAt(i);
        isLastField = fieldIdx == nrOfFields - 1;
        if (isLastField) {
          addToObj(fieldIdx, startIdx);
          break;
        }
        if (i >= 0 && curChar == ":" && prevChar !== "\\") {
          addToObj(fieldIdx, startIdx, i + 1);
          startIdx = i + 2;
          fieldIdx += 1;
        }
      }
      obj = Object.keys(obj).length === nrOfFields ? obj : null;
      return obj;
    };
    var isValidEntry = module.exports.isValidEntry = function(entry) {
      var rules = {
        // host
        0: function(x) {
          return x.length > 0;
        },
        // port
        1: function(x) {
          if (x === "*") {
            return true;
          }
          x = Number(x);
          return isFinite(x) && x > 0 && x < 9007199254740992 && Math.floor(x) === x;
        },
        // database
        2: function(x) {
          return x.length > 0;
        },
        // username
        3: function(x) {
          return x.length > 0;
        },
        // password
        4: function(x) {
          return x.length > 0;
        }
      };
      for (var idx = 0; idx < fieldNames.length; idx += 1) {
        var rule = rules[idx];
        var value = entry[fieldNames[idx]] || "";
        var res = rule(value);
        if (!res) {
          return false;
        }
      }
      return true;
    };
  }
});

// node_modules/pgpass/lib/index.js
var require_lib = __commonJS({
  "node_modules/pgpass/lib/index.js"(exports, module) {
    "use strict";
    var path = __require("path");
    var fs = __require("fs");
    var helper = require_helper();
    module.exports = function(connInfo, cb) {
      var file = helper.getFileName();
      fs.stat(file, function(err, stat) {
        if (err || !helper.usePgPass(stat, file)) {
          return cb(void 0);
        }
        var st = fs.createReadStream(file);
        helper.getPassword(connInfo, st, cb);
      });
    };
    module.exports.warnTo = helper.warnTo;
  }
});

// node_modules/pg/lib/client.js
var require_client = __commonJS({
  "node_modules/pg/lib/client.js"(exports, module) {
    var EventEmitter2 = __require("events").EventEmitter;
    var utils = require_utils();
    var nodeUtils = __require("util");
    var sasl = require_sasl();
    var TypeOverrides2 = require_type_overrides();
    var ConnectionParameters = require_connection_parameters();
    var Query2 = require_query();
    var defaults2 = require_defaults();
    var Connection2 = require_connection();
    var crypto = require_utils2();
    var activeQueryDeprecationNotice = nodeUtils.deprecate(
      () => {
      },
      "Client.activeQuery is deprecated and will be removed in pg@9.0"
    );
    var queryQueueDeprecationNotice = nodeUtils.deprecate(
      () => {
      },
      "Client.queryQueue is deprecated and will be removed in pg@9.0."
    );
    var pgPassDeprecationNotice = nodeUtils.deprecate(
      () => {
      },
      "pgpass support is deprecated and will be removed in pg@9.0. You can provide an async function as the password property to the Client/Pool constructor that returns a password instead. Within this function you can call the pgpass module in your own code."
    );
    var byoPromiseDeprecationNotice = nodeUtils.deprecate(
      () => {
      },
      "Passing a custom Promise implementation to the Client/Pool constructor is deprecated and will be removed in pg@9.0."
    );
    var queryQueueLengthDeprecationNotice = nodeUtils.deprecate(
      () => {
      },
      "Calling client.query() when the client is already executing a query is deprecated and will be removed in pg@9.0. Use async/await or an external async flow control mechanism instead."
    );
    function coerceNumberOrDefault(value, defaultValue) {
      if (typeof value === "number") {
        return Number.isFinite(value) ? value : defaultValue;
      }
      if (typeof value === "string" && value.trim() !== "") {
        const n2 = Number(value);
        return Number.isFinite(n2) ? n2 : defaultValue;
      }
      return defaultValue;
    }
    var Client2 = class extends EventEmitter2 {
      constructor(config) {
        super();
        this.connectionParameters = new ConnectionParameters(config);
        this.user = this.connectionParameters.user;
        this.database = this.connectionParameters.database;
        this.port = this.connectionParameters.port;
        this.host = this.connectionParameters.host;
        Object.defineProperty(this, "password", {
          configurable: true,
          enumerable: false,
          writable: true,
          value: this.connectionParameters.password
        });
        this.replication = this.connectionParameters.replication;
        const c = config || {};
        if (c.Promise) {
          byoPromiseDeprecationNotice();
        }
        this._Promise = c.Promise || global.Promise;
        this._types = new TypeOverrides2(c.types);
        this._ending = false;
        this._ended = false;
        this._connecting = false;
        this._connected = false;
        this._connectionError = false;
        this._queryable = true;
        this._activeQuery = null;
        this._txStatus = null;
        this.enableChannelBinding = Boolean(c.enableChannelBinding);
        this.scramMaxIterations = coerceNumberOrDefault(c.scramMaxIterations, sasl.DEFAULT_MAX_SCRAM_ITERATIONS);
        this.connection = c.connection || new Connection2({
          stream: c.stream,
          ssl: this.connectionParameters.ssl,
          sslNegotiation: this.connectionParameters.sslnegotiation,
          keepAlive: c.keepAlive || false,
          keepAliveInitialDelayMillis: c.keepAliveInitialDelayMillis || 0,
          encoding: this.connectionParameters.client_encoding || "utf8"
        });
        this._queryQueue = [];
        this._sentQueryQueue = [];
        this.pipeline = Boolean(c.pipeline);
        this.binary = c.binary || defaults2.binary;
        this.processID = null;
        this.secretKey = null;
        this.ssl = this.connectionParameters.ssl || false;
        this.sslNegotiation = this.connectionParameters.sslnegotiation || "postgres";
        if (this.ssl && this.ssl.key) {
          Object.defineProperty(this.ssl, "key", {
            enumerable: false
          });
        }
        this._connectionTimeoutMillis = c.connectionTimeoutMillis || 0;
      }
      get activeQuery() {
        activeQueryDeprecationNotice();
        return this._activeQuery;
      }
      set activeQuery(val) {
        activeQueryDeprecationNotice();
        this._activeQuery = val;
      }
      _getActiveQuery() {
        return this._activeQuery;
      }
      _errorAllQueries(err) {
        const enqueueError = (query) => {
          process.nextTick(() => {
            query.handleError(err, this.connection);
          });
        };
        const activeQuery = this._getActiveQuery();
        if (activeQuery) {
          enqueueError(activeQuery);
          this._activeQuery = null;
        }
        this._sentQueryQueue.forEach(enqueueError);
        this._sentQueryQueue.length = 0;
        this._queryQueue.forEach(enqueueError);
        this._queryQueue.length = 0;
      }
      _connect(callback) {
        const self = this;
        const con = this.connection;
        this._connectionCallback = callback;
        if (this._connecting || this._connected) {
          const err = new Error("Client has already been connected. You cannot reuse a client.");
          process.nextTick(() => {
            callback(err);
          });
          return;
        }
        this._connecting = true;
        if (this._connectionTimeoutMillis > 0) {
          this.connectionTimeoutHandle = setTimeout(() => {
            con._ending = true;
            con.stream.destroy(new Error("timeout expired"));
          }, this._connectionTimeoutMillis);
          if (this.connectionTimeoutHandle.unref) {
            this.connectionTimeoutHandle.unref();
          }
        }
        if (this.host && this.host.indexOf("/") === 0) {
          con.connect(this.host + "/.s.PGSQL." + this.port);
        } else {
          con.connect(this.port, this.host);
        }
        con.on("connect", function() {
          if (self.ssl) {
            if (self.sslNegotiation !== "direct") {
              con.requestSsl();
            }
          } else {
            con.startup(self.getStartupConf());
          }
        });
        con.on("sslconnect", function() {
          con.startup(self.getStartupConf());
        });
        this._attachListeners(con);
        con.once("end", () => {
          const error = this._ending ? new Error("Connection terminated") : new Error("Connection terminated unexpectedly");
          clearTimeout(this.connectionTimeoutHandle);
          this._errorAllQueries(error);
          this._ended = true;
          if (!this._ending) {
            if (this._connecting && !this._connectionError) {
              if (this._connectionCallback) {
                this._connectionCallback(error);
              } else {
                this._handleErrorEvent(error);
              }
            } else if (!this._connectionError) {
              this._handleErrorEvent(error);
            }
          }
          process.nextTick(() => {
            this.emit("end");
          });
        });
      }
      connect(callback) {
        if (callback) {
          this._connect(callback);
          return;
        }
        return new this._Promise((resolve, reject) => {
          this._connect((error) => {
            if (error) {
              reject(error);
            } else {
              resolve(this);
            }
          });
        });
      }
      _attachListeners(con) {
        con.on("authenticationCleartextPassword", this._handleAuthCleartextPassword.bind(this));
        con.on("authenticationMD5Password", this._handleAuthMD5Password.bind(this));
        con.on("authenticationSASL", this._handleAuthSASL.bind(this));
        con.on("authenticationSASLContinue", this._handleAuthSASLContinue.bind(this));
        con.on("authenticationSASLFinal", this._handleAuthSASLFinal.bind(this));
        con.on("backendKeyData", this._handleBackendKeyData.bind(this));
        con.on("error", this._handleErrorEvent.bind(this));
        con.on("errorMessage", this._handleErrorMessage.bind(this));
        con.on("readyForQuery", this._handleReadyForQuery.bind(this));
        con.on("notice", this._handleNotice.bind(this));
        con.on("rowDescription", this._handleRowDescription.bind(this));
        con.on("dataRow", this._handleDataRow.bind(this));
        con.on("portalSuspended", this._handlePortalSuspended.bind(this));
        con.on("emptyQuery", this._handleEmptyQuery.bind(this));
        con.on("commandComplete", this._handleCommandComplete.bind(this));
        con.on("parseComplete", this._handleParseComplete.bind(this));
        con.on("copyInResponse", this._handleCopyInResponse.bind(this));
        con.on("copyData", this._handleCopyData.bind(this));
        con.on("notification", this._handleNotification.bind(this));
      }
      _getPassword(cb) {
        const con = this.connection;
        if (typeof this.password === "function") {
          this._Promise.resolve().then(() => this.password(this.connectionParameters)).then((pass) => {
            if (pass !== void 0) {
              if (typeof pass !== "string") {
                con.emit("error", new TypeError("Password must be a string"));
                return;
              }
              this.connectionParameters.password = this.password = pass;
            } else {
              this.connectionParameters.password = this.password = null;
            }
            cb();
          }).catch((err) => {
            con.emit("error", err);
          });
        } else if (this.password !== null) {
          cb();
        } else {
          try {
            const pgPass = require_lib();
            pgPass(this.connectionParameters, (pass) => {
              if (void 0 !== pass) {
                pgPassDeprecationNotice();
                this.connectionParameters.password = this.password = pass;
              }
              cb();
            });
          } catch (e) {
            this.emit("error", e);
          }
        }
      }
      _handleAuthCleartextPassword(msg) {
        this._getPassword(() => {
          this.connection.password(this.password);
        });
      }
      _handleAuthMD5Password(msg) {
        this._getPassword(async () => {
          try {
            const hashedPassword = await crypto.postgresMd5PasswordHash(this.user, this.password, msg.salt);
            this.connection.password(hashedPassword);
          } catch (e) {
            this.emit("error", e);
          }
        });
      }
      _handleAuthSASL(msg) {
        this._getPassword(() => {
          try {
            this.saslSession = sasl.startSession(
              msg.mechanisms,
              this.enableChannelBinding && this.connection.stream,
              this.scramMaxIterations
            );
            this.connection.sendSASLInitialResponseMessage(this.saslSession.mechanism, this.saslSession.response);
          } catch (err) {
            this.connection.emit("error", err);
          }
        });
      }
      async _handleAuthSASLContinue(msg) {
        try {
          await sasl.continueSession(
            this.saslSession,
            this.password,
            msg.data,
            this.enableChannelBinding && this.connection.stream
          );
          this.connection.sendSCRAMClientFinalMessage(this.saslSession.response);
        } catch (err) {
          this.connection.emit("error", err);
        }
      }
      _handleAuthSASLFinal(msg) {
        try {
          sasl.finalizeSession(this.saslSession, msg.data);
          this.saslSession = null;
        } catch (err) {
          this.connection.emit("error", err);
        }
      }
      _handleBackendKeyData(msg) {
        this.processID = msg.processID;
        this.secretKey = msg.secretKey;
      }
      _handleReadyForQuery(msg) {
        if (this._connecting) {
          this._connecting = false;
          this._connected = true;
          clearTimeout(this.connectionTimeoutHandle);
          if (this._connectionCallback) {
            this._connectionCallback(null, this);
            this._connectionCallback = null;
          }
          this.emit("connect");
        }
        const activeQuery = this._getActiveQuery();
        this._activeQuery = null;
        this._txStatus = msg?.status ?? null;
        this.readyForQuery = true;
        if (activeQuery) {
          activeQuery.handleReadyForQuery(this.connection);
        }
        this._pulseQueryQueue();
      }
      // if we receive an error event or error message
      // during the connection process we handle it here
      _handleErrorWhileConnecting(err) {
        if (this._connectionError) {
          return;
        }
        this._connectionError = true;
        clearTimeout(this.connectionTimeoutHandle);
        if (this._connectionCallback) {
          return this._connectionCallback(err);
        }
        this.emit("error", err);
      }
      // if we're connected and we receive an error event from the connection
      // this means the socket is dead - do a hard abort of all queries and emit
      // the socket error on the client as well
      _handleErrorEvent(err) {
        if (this._connecting) {
          return this._handleErrorWhileConnecting(err);
        }
        this._queryable = false;
        this._errorAllQueries(err);
        this.emit("error", err);
      }
      // handle error messages from the postgres backend
      _handleErrorMessage(msg) {
        if (this._connecting) {
          return this._handleErrorWhileConnecting(msg);
        }
        const activeQuery = this._getActiveQuery();
        if (!activeQuery) {
          this._handleErrorEvent(msg);
          return;
        }
        this._activeQuery = null;
        if (activeQuery.name) {
          delete this.connection.submittedNamedStatements[activeQuery.name];
        }
        activeQuery.handleError(msg, this.connection);
      }
      _handleRowDescription(msg) {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected rowDescription message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        activeQuery.handleRowDescription(msg);
      }
      _handleDataRow(msg) {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected dataRow message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        activeQuery.handleDataRow(msg);
      }
      _handlePortalSuspended(msg) {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected portalSuspended message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        activeQuery.handlePortalSuspended(this.connection);
      }
      _handleEmptyQuery(msg) {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected emptyQuery message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        activeQuery.handleEmptyQuery(this.connection);
      }
      _handleCommandComplete(msg) {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected commandComplete message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        activeQuery.handleCommandComplete(msg, this.connection);
      }
      _handleParseComplete() {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected parseComplete message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        if (activeQuery.name) {
          this.connection.parsedStatements[activeQuery.name] = activeQuery.text;
          delete this.connection.submittedNamedStatements[activeQuery.name];
        }
      }
      _handleCopyInResponse(msg) {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected copyInResponse message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        activeQuery.handleCopyInResponse(this.connection);
      }
      _handleCopyData(msg) {
        const activeQuery = this._getActiveQuery();
        if (activeQuery == null) {
          const error = new Error("Received unexpected copyData message from backend.");
          this._handleErrorEvent(error);
          return;
        }
        activeQuery.handleCopyData(msg, this.connection);
      }
      _handleNotification(msg) {
        this.emit("notification", msg);
      }
      _handleNotice(msg) {
        this.emit("notice", msg);
      }
      getStartupConf() {
        const params = this.connectionParameters;
        const data = {
          user: params.user,
          database: params.database
        };
        const appName = params.application_name || params.fallback_application_name;
        if (appName) {
          data.application_name = appName;
        }
        if (params.replication) {
          data.replication = "" + params.replication;
        }
        if (params.statement_timeout) {
          data.statement_timeout = String(parseInt(params.statement_timeout, 10));
        }
        if (params.lock_timeout) {
          data.lock_timeout = String(parseInt(params.lock_timeout, 10));
        }
        if (params.idle_in_transaction_session_timeout) {
          data.idle_in_transaction_session_timeout = String(parseInt(params.idle_in_transaction_session_timeout, 10));
        }
        if (params.options) {
          data.options = params.options;
        }
        return data;
      }
      cancel(client, query) {
        if (client.activeQuery === query) {
          const con = this.connection;
          if (this.host && this.host.indexOf("/") === 0) {
            con.connect(this.host + "/.s.PGSQL." + this.port);
          } else {
            con.connect(this.port, this.host);
          }
          con.on("connect", function() {
            con.cancel(client.processID, client.secretKey);
          });
        } else if (client._queryQueue.indexOf(query) !== -1) {
          client._queryQueue.splice(client._queryQueue.indexOf(query), 1);
        } else if (client._sentQueryQueue.indexOf(query) !== -1) {
          query.callback = () => {
          };
        }
      }
      setTypeParser(oid, format, parseFn) {
        return this._types.setTypeParser(oid, format, parseFn);
      }
      getTypeParser(oid, format) {
        return this._types.getTypeParser(oid, format);
      }
      // escapeIdentifier and escapeLiteral moved to utility functions & exported
      // on PG
      // re-exported here for backwards compatibility
      escapeIdentifier(str) {
        return utils.escapeIdentifier(str);
      }
      escapeLiteral(str) {
        return utils.escapeLiteral(str);
      }
      _pulseQueryQueue() {
        if (this.pipeline) {
          this._pulsePipelinedQueryQueue();
          return;
        }
        if (this.readyForQuery === true) {
          this._activeQuery = this._queryQueue.shift();
          const activeQuery = this._getActiveQuery();
          if (activeQuery) {
            this.readyForQuery = false;
            this.hasExecuted = true;
            const queryError = activeQuery.submit(this.connection);
            if (queryError) {
              process.nextTick(() => {
                activeQuery.handleError(queryError, this.connection);
                this.readyForQuery = true;
                this._pulseQueryQueue();
              });
            }
          } else if (this.hasExecuted) {
            this._activeQuery = null;
            this.emit("drain");
          }
        }
      }
      _pulsePipelinedQueryQueue() {
        if (!this._connected || !this._queryable) {
          return;
        }
        while (this._queryQueue.length > 0) {
          const query = this._queryQueue.shift();
          this.hasExecuted = true;
          const queryError = query.submit(this.connection);
          if (queryError) {
            process.nextTick(() => {
              query.handleError(queryError, this.connection);
            });
            continue;
          }
          this._sentQueryQueue.push(query);
        }
        if (this.readyForQuery && !this._activeQuery && this._sentQueryQueue.length > 0) {
          this._activeQuery = this._sentQueryQueue.shift();
          this.readyForQuery = false;
        }
        if (!this._activeQuery && this._sentQueryQueue.length === 0 && this._queryQueue.length === 0 && this.hasExecuted) {
          this.emit("drain");
        }
      }
      query(config, values, callback) {
        let query;
        let result;
        if (config == null) {
          throw new TypeError("Client was passed a null or undefined query");
        }
        if (typeof config.submit === "function") {
          result = query = config;
          if (!query.callback) {
            if (typeof values === "function") {
              query.callback = values;
            } else if (callback) {
              query.callback = callback;
            }
          }
        } else {
          query = new Query2(config, values, callback);
          if (!query.callback) {
            result = new this._Promise((resolve, reject) => {
              query.callback = (err, res) => err ? reject(err) : resolve(res);
            }).catch((err) => {
              Error.captureStackTrace(err);
              throw err;
            });
          } else if (typeof query.callback !== "function") {
            throw new TypeError("callback is not a function");
          }
        }
        const readTimeout = config.query_timeout || this.connectionParameters.query_timeout;
        if (readTimeout) {
          const queryCallback = query.callback || (() => {
          });
          const readTimeoutTimer = setTimeout(() => {
            const error = new Error("Query read timeout");
            process.nextTick(() => {
              query.handleError(error, this.connection);
            });
            queryCallback(error);
            query.callback = () => {
            };
            const index = this._queryQueue.indexOf(query);
            if (index > -1) {
              this._queryQueue.splice(index, 1);
            } else if (this.pipeline) {
              this.connection.stream.destroy();
              return;
            }
            this._pulseQueryQueue();
          }, readTimeout);
          query.callback = (err, res) => {
            clearTimeout(readTimeoutTimer);
            queryCallback(err, res);
          };
        }
        if (this.binary && !query.binary) {
          query.binary = true;
        }
        if (query._result && !query._result._types) {
          query._result._types = this._types;
        }
        if (this.pipeline) {
          const portalQuery = typeof config.submit === "function" && !(query instanceof Query2) ? "Custom query classes such as pg-cursor and pg-query-stream are" : query.rows ? "The `rows` option is" : null;
          if (portalQuery) {
            process.nextTick(() => {
              query.handleError(new Error(`${portalQuery} not supported in pipeline mode`), this.connection);
            });
            return result;
          }
        }
        if (!this._queryable) {
          process.nextTick(() => {
            query.handleError(new Error("Client has encountered a connection error and is not queryable"), this.connection);
          });
          return result;
        }
        if (this._ending) {
          process.nextTick(() => {
            query.handleError(new Error("Client was closed and is not queryable"), this.connection);
          });
          return result;
        }
        if (this._queryQueue.length > 0 && !this.pipeline) {
          queryQueueLengthDeprecationNotice();
        }
        this._queryQueue.push(query);
        this._pulseQueryQueue();
        return result;
      }
      ref() {
        this.connection.ref();
      }
      unref() {
        this.connection.unref();
      }
      getTransactionStatus() {
        return this._txStatus;
      }
      end(cb) {
        this._ending = true;
        if (!this.connection._connecting || this._ended) {
          if (cb) {
            cb();
            return;
          } else {
            return this._Promise.resolve();
          }
        }
        if (!this._queryable) {
          this.connection.stream.destroy();
        } else if (this.pipeline && (this._getActiveQuery() || this._sentQueryQueue.length > 0 || this._queryQueue.length > 0)) {
          this.once("drain", () => this.connection.end());
        } else if (this._getActiveQuery()) {
          this.connection.stream.destroy();
        } else {
          this.connection.end();
        }
        if (cb) {
          this.connection.once("end", cb);
        } else {
          return new this._Promise((resolve) => {
            this.connection.once("end", resolve);
          });
        }
      }
      get queryQueue() {
        queryQueueDeprecationNotice();
        return this._queryQueue;
      }
    };
    Client2.Query = Query2;
    module.exports = Client2;
  }
});

// node_modules/pg-pool/index.js
var require_pg_pool = __commonJS({
  "node_modules/pg-pool/index.js"(exports, module) {
    "use strict";
    var EventEmitter2 = __require("events").EventEmitter;
    var NOOP = function() {
    };
    var removeWhere = (list2, predicate) => {
      const i = list2.findIndex(predicate);
      return i === -1 ? void 0 : list2.splice(i, 1)[0];
    };
    var IdleItem = class {
      constructor(client, idleListener, timeoutId) {
        this.client = client;
        this.idleListener = idleListener;
        this.timeoutId = timeoutId;
      }
    };
    var PendingItem = class {
      constructor(callback) {
        this.callback = callback;
      }
    };
    function throwOnDoubleRelease() {
      throw new Error("Release called on client which has already been released to the pool.");
    }
    function promisify(Promise2, callback) {
      if (callback) {
        return { callback, result: void 0 };
      }
      let rej;
      let res;
      const cb = function(err, client) {
        err ? rej(err) : res(client);
      };
      const result = new Promise2(function(resolve, reject) {
        res = resolve;
        rej = reject;
      }).catch((err) => {
        Error.captureStackTrace(err);
        throw err;
      });
      return { callback: cb, result };
    }
    function makeIdleListener(pool2, client) {
      return function idleListener(err) {
        err.client = client;
        client.removeListener("error", idleListener);
        client.on("error", () => {
          pool2.log("additional client error after disconnection due to error", err);
        });
        pool2._remove(client);
        pool2.emit("error", err, client);
      };
    }
    var Pool2 = class extends EventEmitter2 {
      constructor(options, Client2) {
        super();
        this.options = Object.assign({}, options);
        if (options != null && "password" in options) {
          Object.defineProperty(this.options, "password", {
            configurable: true,
            enumerable: false,
            writable: true,
            value: options.password
          });
        }
        if (options != null && options.ssl && options.ssl.key) {
          Object.defineProperty(this.options.ssl, "key", {
            enumerable: false
          });
        }
        this.options.max = this.options.max || this.options.poolSize || 10;
        this.options.min = this.options.min || 0;
        this.options.maxUses = this.options.maxUses || Infinity;
        this.options.allowExitOnIdle = this.options.allowExitOnIdle || false;
        this.options.maxLifetimeSeconds = this.options.maxLifetimeSeconds || 0;
        this.log = this.options.log || function() {
        };
        this.Client = this.options.Client || Client2 || require_lib2().Client;
        this.Promise = this.options.Promise || global.Promise;
        if (typeof this.options.idleTimeoutMillis === "undefined") {
          this.options.idleTimeoutMillis = 1e4;
        }
        this._clients = [];
        this._idle = [];
        this._expired = /* @__PURE__ */ new WeakSet();
        this._pendingQueue = [];
        this._endCallback = void 0;
        this.ending = false;
        this.ended = false;
      }
      _promiseTry(f) {
        const Promise2 = this.Promise;
        if (typeof Promise2.try === "function") {
          return Promise2.try(f);
        }
        return new Promise2((resolve) => resolve(f()));
      }
      _isFull() {
        return this._clients.length >= this.options.max;
      }
      _isAboveMin() {
        return this._clients.length > this.options.min;
      }
      _pulseQueue() {
        this.log("pulse queue");
        if (this.ended) {
          this.log("pulse queue ended");
          return;
        }
        if (this.ending) {
          this.log("pulse queue on ending");
          if (this._idle.length) {
            this._idle.slice().map((item) => {
              this._remove(item.client);
            });
          }
          if (!this._clients.length) {
            this.ended = true;
            this._endCallback();
          }
          return;
        }
        if (!this._pendingQueue.length) {
          this.log("no queued requests");
          return;
        }
        if (!this._idle.length && this._isFull()) {
          return;
        }
        const pendingItem = this._pendingQueue.shift();
        if (this._idle.length) {
          const idleItem = this._idle.pop();
          clearTimeout(idleItem.timeoutId);
          const client = idleItem.client;
          client.ref && client.ref();
          const idleListener = idleItem.idleListener;
          return this._acquireClient(client, pendingItem, idleListener, false);
        }
        if (!this._isFull()) {
          return this.newClient(pendingItem);
        }
        throw new Error("unexpected condition");
      }
      _remove(client, callback) {
        const removed = removeWhere(this._idle, (item) => item.client === client);
        if (removed !== void 0) {
          clearTimeout(removed.timeoutId);
        }
        this._clients = this._clients.filter((c) => c !== client);
        const context2 = this;
        client.end(() => {
          context2.emit("remove", client);
          if (typeof callback === "function") {
            callback();
          }
        });
      }
      connect(cb) {
        if (this.ending) {
          const err = new Error("Cannot use a pool after calling end on the pool");
          return cb ? cb(err) : this.Promise.reject(err);
        }
        const response = promisify(this.Promise, cb);
        const result = response.result;
        if (this._isFull() || this._idle.length) {
          if (this._idle.length) {
            process.nextTick(() => this._pulseQueue());
          }
          if (!this.options.connectionTimeoutMillis) {
            this._pendingQueue.push(new PendingItem(response.callback));
            return result;
          }
          const queueCallback = (err, res, done) => {
            clearTimeout(tid);
            response.callback(err, res, done);
          };
          const pendingItem = new PendingItem(queueCallback);
          const tid = setTimeout(() => {
            removeWhere(this._pendingQueue, (i) => i.callback === queueCallback);
            pendingItem.timedOut = true;
            response.callback(new Error("timeout exceeded when trying to connect"));
          }, this.options.connectionTimeoutMillis);
          if (tid.unref) {
            tid.unref();
          }
          this._pendingQueue.push(pendingItem);
          return result;
        }
        this.newClient(new PendingItem(response.callback));
        return result;
      }
      newClient(pendingItem) {
        const client = new this.Client(this.options);
        this._clients.push(client);
        const idleListener = makeIdleListener(this, client);
        this.log("checking client timeout");
        let tid;
        let timeoutHit = false;
        if (this.options.connectionTimeoutMillis) {
          tid = setTimeout(() => {
            if (client.connection) {
              this.log("ending client due to timeout");
              timeoutHit = true;
              client.connection.stream.destroy();
            } else if (!client.isConnected()) {
              this.log("ending client due to timeout");
              timeoutHit = true;
              client.end();
            }
          }, this.options.connectionTimeoutMillis);
        }
        this.log("connecting new client");
        client.connect((err) => {
          if (tid) {
            clearTimeout(tid);
          }
          client.on("error", idleListener);
          if (err) {
            this.log("client failed to connect", err);
            this._clients = this._clients.filter((c) => c !== client);
            if (timeoutHit) {
              err = new Error("Connection terminated due to connection timeout", { cause: err });
            }
            this._pulseQueue();
            if (!pendingItem.timedOut) {
              pendingItem.callback(err, void 0, NOOP);
            }
          } else {
            this.log("new client connected");
            if (this.options.onConnect) {
              this._promiseTry(() => this.options.onConnect(client)).then(
                () => {
                  this._afterConnect(client, pendingItem, idleListener);
                },
                (hookErr) => {
                  this._clients = this._clients.filter((c) => c !== client);
                  client.end(() => {
                    this._pulseQueue();
                    if (!pendingItem.timedOut) {
                      pendingItem.callback(hookErr, void 0, NOOP);
                    }
                  });
                }
              );
              return;
            }
            return this._afterConnect(client, pendingItem, idleListener);
          }
        });
      }
      _afterConnect(client, pendingItem, idleListener) {
        if (this.options.maxLifetimeSeconds !== 0) {
          const maxLifetimeTimeout = setTimeout(() => {
            this.log("ending client due to expired lifetime");
            this._expired.add(client);
            const idleIndex = this._idle.findIndex((idleItem) => idleItem.client === client);
            if (idleIndex !== -1) {
              this._acquireClient(
                client,
                new PendingItem((err, client2, clientRelease) => clientRelease()),
                idleListener,
                false
              );
            }
          }, this.options.maxLifetimeSeconds * 1e3);
          maxLifetimeTimeout.unref();
          client.once("end", () => clearTimeout(maxLifetimeTimeout));
        }
        return this._acquireClient(client, pendingItem, idleListener, true);
      }
      // acquire a client for a pending work item
      _acquireClient(client, pendingItem, idleListener, isNew) {
        if (isNew) {
          this.emit("connect", client);
        }
        this.emit("acquire", client);
        client.release = this._releaseOnce(client, idleListener);
        client.removeListener("error", idleListener);
        if (!pendingItem.timedOut) {
          if (isNew && this.options.verify) {
            this.options.verify(client, (err) => {
              if (err) {
                client.release(err);
                return pendingItem.callback(err, void 0, NOOP);
              }
              pendingItem.callback(void 0, client, client.release);
            });
          } else {
            pendingItem.callback(void 0, client, client.release);
          }
        } else {
          if (isNew && this.options.verify) {
            this.options.verify(client, client.release);
          } else {
            client.release();
          }
        }
      }
      // returns a function that wraps _release and throws if called more than once
      _releaseOnce(client, idleListener) {
        let released = false;
        return (err) => {
          if (released) {
            throwOnDoubleRelease();
          }
          released = true;
          this._release(client, idleListener, err);
        };
      }
      // release a client back to the poll, include an error
      // to remove it from the pool
      _release(client, idleListener, err) {
        client.on("error", idleListener);
        client._poolUseCount = (client._poolUseCount || 0) + 1;
        this.emit("release", err, client);
        if (err || this.ending || !client._queryable || client._ending || client._poolUseCount >= this.options.maxUses) {
          if (client._poolUseCount >= this.options.maxUses) {
            this.log("remove expended client");
          }
          return this._remove(client, this._pulseQueue.bind(this));
        }
        const isExpired = this._expired.has(client);
        if (isExpired) {
          this.log("remove expired client");
          this._expired.delete(client);
          return this._remove(client, this._pulseQueue.bind(this));
        }
        let tid;
        if (this.options.idleTimeoutMillis && this._isAboveMin()) {
          tid = setTimeout(() => {
            if (this._isAboveMin()) {
              this.log("remove idle client");
              this._remove(client, this._pulseQueue.bind(this));
            }
          }, this.options.idleTimeoutMillis);
          if (this.options.allowExitOnIdle) {
            tid.unref();
          }
        }
        if (this.options.allowExitOnIdle) {
          client.unref();
        }
        this._idle.push(new IdleItem(client, idleListener, tid));
        this._pulseQueue();
      }
      query(text, values, cb) {
        if (typeof text === "function") {
          const response2 = promisify(this.Promise, text);
          setImmediate(function() {
            return response2.callback(new Error("Passing a function as the first parameter to pool.query is not supported"));
          });
          return response2.result;
        }
        if (typeof values === "function") {
          cb = values;
          values = void 0;
        }
        const response = promisify(this.Promise, cb);
        cb = response.callback;
        this.connect((err, client) => {
          if (err) {
            return cb(err);
          }
          let clientReleased = false;
          const onError = (err2) => {
            if (clientReleased) {
              return;
            }
            clientReleased = true;
            client.release(err2);
            cb(err2);
          };
          client.once("error", onError);
          this.log("dispatching query");
          try {
            client.query(text, values, (err2, res) => {
              this.log("query dispatched");
              client.removeListener("error", onError);
              if (clientReleased) {
                return;
              }
              clientReleased = true;
              client.release(err2);
              if (err2) {
                return cb(err2);
              }
              return cb(void 0, res);
            });
          } catch (err2) {
            client.release(err2);
            return cb(err2);
          }
        });
        return response.result;
      }
      end(cb) {
        this.log("ending");
        if (this.ending) {
          const err = new Error("Called end on pool more than once");
          return cb ? cb(err) : this.Promise.reject(err);
        }
        this.ending = true;
        const promised = promisify(this.Promise, cb);
        this._endCallback = promised.callback;
        this._pulseQueue();
        return promised.result;
      }
      get waitingCount() {
        return this._pendingQueue.length;
      }
      get idleCount() {
        return this._idle.length;
      }
      get expiredCount() {
        return this._clients.reduce((acc, client) => acc + (this._expired.has(client) ? 1 : 0), 0);
      }
      get totalCount() {
        return this._clients.length;
      }
    };
    module.exports = Pool2;
  }
});

// node_modules/pg/lib/native/query.js
var require_query2 = __commonJS({
  "node_modules/pg/lib/native/query.js"(exports, module) {
    "use strict";
    var EventEmitter2 = __require("events").EventEmitter;
    var util = __require("util");
    var utils = require_utils();
    var NativeQuery = module.exports = function(config, values, callback) {
      EventEmitter2.call(this);
      config = utils.normalizeQueryConfig(config, values, callback);
      this.text = config.text;
      this.values = config.values;
      this.name = config.name;
      this.queryMode = config.queryMode;
      this.callback = config.callback;
      this.state = "new";
      this._arrayMode = config.rowMode === "array";
      this._emitRowEvents = false;
      this.on(
        "newListener",
        function(event) {
          if (event === "row") this._emitRowEvents = true;
        }.bind(this)
      );
    };
    util.inherits(NativeQuery, EventEmitter2);
    var errorFieldMap = {
      sqlState: "code",
      statementPosition: "position",
      messagePrimary: "message",
      messageDetail: "detail",
      messageHint: "hint",
      context: "where",
      schemaName: "schema",
      tableName: "table",
      columnName: "column",
      dataTypeName: "dataType",
      constraintName: "constraint",
      sourceFile: "file",
      sourceLine: "line",
      sourceFunction: "routine"
    };
    NativeQuery.prototype.handleError = function(err) {
      const fields = this.native && this.native.pq.resultErrorFields();
      if (fields) {
        for (const key in fields) {
          const normalizedFieldName = errorFieldMap[key] || key;
          err[normalizedFieldName] = fields[key];
        }
      }
      if (this.callback) {
        this.callback(err);
      } else {
        this.emit("error", err);
      }
      this.state = "error";
    };
    NativeQuery.prototype.then = function(onSuccess, onFailure) {
      return this._getPromise().then(onSuccess, onFailure);
    };
    NativeQuery.prototype.catch = function(callback) {
      return this._getPromise().catch(callback);
    };
    NativeQuery.prototype._getPromise = function() {
      if (this._promise) return this._promise;
      this._promise = new Promise(
        function(resolve, reject) {
          this._once("end", resolve);
          this._once("error", reject);
        }.bind(this)
      );
      return this._promise;
    };
    NativeQuery.prototype.submit = function(client) {
      this.state = "running";
      const self = this;
      this.native = client.native;
      client.native.arrayMode = this._arrayMode;
      let after = function(err, rows, results) {
        client.native.arrayMode = false;
        setImmediate(function() {
          self.emit("_done");
        });
        if (err) {
          return self.handleError(err);
        }
        if (self._emitRowEvents) {
          if (results.length > 1) {
            rows.forEach((rowOfRows, i) => {
              rowOfRows.forEach((row) => {
                self.emit("row", row, results[i]);
              });
            });
          } else {
            rows.forEach(function(row) {
              self.emit("row", row, results);
            });
          }
        }
        self.state = "end";
        self.emit("end", results);
        if (self.callback) {
          self.callback(null, results);
        }
      };
      if (process.domain) {
        after = process.domain.bind(after);
      }
      if (this.name) {
        if (this.name.length > 63) {
          console.error("Warning! Postgres only supports 63 characters for query names.");
          console.error("You supplied %s (%s)", this.name, this.name.length);
          console.error("This can cause conflicts and silent errors executing queries");
        }
        const values = (this.values || []).map(utils.prepareValue);
        if (client.namedQueries[this.name] !== void 0) {
          if (this.text && client.namedQueries[this.name] !== this.text) {
            const err = new Error(`Prepared statements must be unique - '${this.name}' was used for a different statement`);
            return after(err);
          }
          return client.native.execute(this.name, values, after);
        }
        return client.native.prepare(this.name, this.text, values.length, function(err) {
          if (err) return after(err);
          client.namedQueries[self.name] = self.text;
          return self.native.execute(self.name, values, after);
        });
      } else if (this.values) {
        if (!Array.isArray(this.values)) {
          const err = new Error("Query values must be an array");
          return after(err);
        }
        const vals = this.values.map(utils.prepareValue);
        client.native.query(this.text, vals, after);
      } else if (this.queryMode === "extended") {
        client.native.query(this.text, [], after);
      } else {
        client.native.query(this.text, after);
      }
    };
  }
});

// node_modules/pg/lib/native/client.js
var require_client2 = __commonJS({
  "node_modules/pg/lib/native/client.js"(exports, module) {
    var nodeUtils = __require("util");
    var Native;
    try {
      Native = __require("pg-native");
    } catch (e) {
      throw e;
    }
    var TypeOverrides2 = require_type_overrides();
    var EventEmitter2 = __require("events").EventEmitter;
    var util = __require("util");
    var ConnectionParameters = require_connection_parameters();
    var NativeQuery = require_query2();
    var queryQueueLengthDeprecationNotice = nodeUtils.deprecate(
      () => {
      },
      "Calling client.query() when the client is already executing a query is deprecated and will be removed in pg@9.0. Use async/await or an external async flow control mechanism instead."
    );
    var Client2 = module.exports = function(config) {
      EventEmitter2.call(this);
      config = config || {};
      this._Promise = config.Promise || global.Promise;
      this._types = new TypeOverrides2(config.types);
      this.native = new Native({
        types: this._types
      });
      this._queryQueue = [];
      this._ending = false;
      this._connecting = false;
      this._connected = false;
      this._queryable = true;
      this.pipeline = Boolean(config.pipeline);
      this._pipelineInFlight = false;
      const cp = this.connectionParameters = new ConnectionParameters(config);
      if (config.nativeConnectionString) cp.nativeConnectionString = config.nativeConnectionString;
      this.user = cp.user;
      Object.defineProperty(this, "password", {
        configurable: true,
        enumerable: false,
        writable: true,
        value: cp.password
      });
      this.database = cp.database;
      this.host = cp.host;
      this.port = cp.port;
      this.namedQueries = {};
    };
    Client2.Query = NativeQuery;
    util.inherits(Client2, EventEmitter2);
    Client2.prototype._errorAllQueries = function(err) {
      const enqueueError = (query) => {
        process.nextTick(() => {
          query.native = this.native;
          query.handleError(err);
        });
      };
      if (this._hasActiveQuery()) {
        enqueueError(this._activeQuery);
        this._activeQuery = null;
      }
      this._queryQueue.forEach(enqueueError);
      this._queryQueue.length = 0;
    };
    Client2.prototype._connect = function(cb) {
      const self = this;
      if (this._connecting) {
        process.nextTick(() => cb(new Error("Client has already been connected. You cannot reuse a client.")));
        return;
      }
      this._connecting = true;
      this.connectionParameters.getLibpqConnectionString(function(err, conString) {
        if (self.connectionParameters.nativeConnectionString) conString = self.connectionParameters.nativeConnectionString;
        if (err) return cb(err);
        self.native.connect(conString, function(err2) {
          if (err2) {
            self.native.end();
            return cb(err2);
          }
          self._connected = true;
          self.native.on("error", function(err3) {
            self._queryable = false;
            self._errorAllQueries(err3);
            self.emit("error", err3);
          });
          self.native.on("notification", function(msg) {
            self.emit("notification", {
              channel: msg.relname,
              payload: msg.extra
            });
          });
          self.emit("connect");
          self._pulseQueryQueue(true);
          cb(null, this);
        });
      });
    };
    Client2.prototype.connect = function(callback) {
      if (callback) {
        this._connect(callback);
        return;
      }
      return new this._Promise((resolve, reject) => {
        this._connect((error) => {
          if (error) {
            reject(error);
          } else {
            resolve(this);
          }
        });
      });
    };
    Client2.prototype.query = function(config, values, callback) {
      let query;
      let result;
      let readTimeout;
      let readTimeoutTimer;
      let queryCallback;
      if (config === null || config === void 0) {
        throw new TypeError("Client was passed a null or undefined query");
      } else if (typeof config.submit === "function") {
        readTimeout = config.query_timeout || this.connectionParameters.query_timeout;
        result = query = config;
        if (typeof values === "function") {
          config.callback = values;
        }
      } else {
        readTimeout = config.query_timeout || this.connectionParameters.query_timeout;
        query = new NativeQuery(config, values, callback);
        if (!query.callback) {
          let resolveOut, rejectOut;
          result = new this._Promise((resolve, reject) => {
            resolveOut = resolve;
            rejectOut = reject;
          }).catch((err) => {
            Error.captureStackTrace(err);
            throw err;
          });
          query.callback = (err, res) => err ? rejectOut(err) : resolveOut(res);
        }
      }
      if (readTimeout) {
        queryCallback = query.callback || (() => {
        });
        readTimeoutTimer = setTimeout(() => {
          const error = new Error("Query read timeout");
          process.nextTick(() => {
            query.handleError(error, this.connection);
          });
          queryCallback(error);
          query.callback = () => {
          };
          const index = this._queryQueue.indexOf(query);
          if (index > -1) {
            this._queryQueue.splice(index, 1);
          }
          this._pulseQueryQueue();
        }, readTimeout);
        query.callback = (err, res) => {
          clearTimeout(readTimeoutTimer);
          queryCallback(err, res);
        };
      }
      if (!this._queryable) {
        query.native = this.native;
        process.nextTick(() => {
          query.handleError(new Error("Client has encountered a connection error and is not queryable"));
        });
        return result;
      }
      if (this._ending) {
        query.native = this.native;
        process.nextTick(() => {
          query.handleError(new Error("Client was closed and is not queryable"));
        });
        return result;
      }
      if (this._queryQueue.length > 0 && !this.pipeline) {
        queryQueueLengthDeprecationNotice();
      }
      this._queryQueue.push(query);
      this._pulseQueryQueue();
      return result;
    };
    Client2.prototype.end = function(cb) {
      const self = this;
      this._ending = true;
      if (this._connecting && !this._connected) {
        this.once("connect", () => {
          this.end(() => {
          });
        });
      }
      let result;
      if (!cb) {
        result = new this._Promise(function(resolve, reject) {
          cb = (err) => err ? reject(err) : resolve();
        });
      }
      const doEnd = function() {
        self.native.end(function() {
          self._connected = false;
          self._errorAllQueries(new Error("Connection terminated"));
          process.nextTick(() => {
            self.emit("end");
            if (cb) cb();
          });
        });
      };
      if (this.pipeline && (this._pipelineInFlight || this._queryQueue.length > 0)) {
        this.once("drain", doEnd);
      } else {
        doEnd();
      }
      return result;
    };
    Client2.prototype._hasActiveQuery = function() {
      return this._activeQuery && this._activeQuery.state !== "error" && this._activeQuery.state !== "end";
    };
    Client2.prototype._pulseQueryQueue = function(initialConnection) {
      if (!this._connected) {
        return;
      }
      if (this.pipeline && !initialConnection) {
        return this._pulsePipelinedQueryQueue();
      }
      if (this._hasActiveQuery()) {
        return;
      }
      const query = this._queryQueue.shift();
      if (!query) {
        if (!initialConnection) {
          this.emit("drain");
        }
        return;
      }
      this._activeQuery = query;
      query.submit(this);
      const self = this;
      query.once("_done", function() {
        self._pulseQueryQueue();
      });
    };
    Client2.prototype._pulsePipelinedQueryQueue = function() {
      if (!this._connected || this._pipelineInFlight) {
        return;
      }
      if (this._queryQueue.length === 0) {
        if (this.hasExecuted) {
          this.emit("drain");
        }
        return;
      }
      this._pipelineInFlight = true;
      const self = this;
      const queries = [];
      const nativeQueries = [];
      const utils = require_utils();
      while (this._queryQueue.length > 0) {
        const query = this._queryQueue.shift();
        this.hasExecuted = true;
        nativeQueries.push(query);
        const values = query.values ? query.values.map(utils.prepareValue) : null;
        const pipelineEntry = { text: query.text, name: query.name, arrayMode: query._arrayMode };
        if (values) {
          pipelineEntry.values = values;
        }
        if (query.name && this.namedQueries[query.name]) {
          pipelineEntry._alreadyPrepared = true;
        }
        queries.push(pipelineEntry);
      }
      this.native.pipeline(queries, function(err, results) {
        self._pipelineInFlight = false;
        if (err) {
          self._connected = false;
          self._queryable = false;
          for (let i = 0; i < nativeQueries.length; i++) {
            const q = nativeQueries[i];
            q.native = self.native;
            q.handleError(err);
          }
          self._errorAllQueries(err);
          self.emit("error", err);
          self.emit("end");
          return;
        }
        for (let i = 0; i < nativeQueries.length; i++) {
          const q = nativeQueries[i];
          const r = results[i];
          q.native = self.native;
          if (r.err) {
            q.handleError(r.err);
          } else {
            if (q.name) {
              self.namedQueries[q.name] = q.text;
            }
            q.state = "end";
            q.emit("end", r.result);
            if (q.callback) {
              q.callback(null, r.result);
            }
          }
          setImmediate(function() {
            q.emit("_done");
          });
        }
        self._pulsePipelinedQueryQueue();
      });
    };
    Client2.prototype.cancel = function(query) {
      if (this._activeQuery === query) {
        this.native.cancel(function() {
        });
      } else if (this._queryQueue.indexOf(query) !== -1) {
        this._queryQueue.splice(this._queryQueue.indexOf(query), 1);
      }
    };
    Client2.prototype.ref = function() {
    };
    Client2.prototype.unref = function() {
    };
    Client2.prototype.setTypeParser = function(oid, format, parseFn) {
      return this._types.setTypeParser(oid, format, parseFn);
    };
    Client2.prototype.getTypeParser = function(oid, format) {
      return this._types.getTypeParser(oid, format);
    };
    Client2.prototype.isConnected = function() {
      return this._connected;
    };
    Client2.prototype.getTransactionStatus = function() {
      return this.native.getTransactionStatus();
    };
  }
});

// node_modules/pg/lib/native/index.js
var require_native = __commonJS({
  "node_modules/pg/lib/native/index.js"(exports, module) {
    "use strict";
    module.exports = require_client2();
  }
});

// node_modules/pg/lib/index.js
var require_lib2 = __commonJS({
  "node_modules/pg/lib/index.js"(exports, module) {
    "use strict";
    var Client2 = require_client();
    var defaults2 = require_defaults();
    var Connection2 = require_connection();
    var Result2 = require_result();
    var utils = require_utils();
    var Pool2 = require_pg_pool();
    var TypeOverrides2 = require_type_overrides();
    var { DatabaseError: DatabaseError2 } = require_dist();
    var { escapeIdentifier: escapeIdentifier2, escapeLiteral: escapeLiteral2 } = require_utils();
    var poolFactory = (Client3) => {
      return class BoundPool extends Pool2 {
        constructor(options) {
          super(options, Client3);
        }
      };
    };
    var PG = function(clientConstructor2) {
      this.defaults = defaults2;
      this.Client = clientConstructor2;
      this.Query = this.Client.Query;
      this.Pool = poolFactory(this.Client);
      this._pools = [];
      this.Connection = Connection2;
      this.types = require_pg_types();
      this.DatabaseError = DatabaseError2;
      this.TypeOverrides = TypeOverrides2;
      this.escapeIdentifier = escapeIdentifier2;
      this.escapeLiteral = escapeLiteral2;
      this.Result = Result2;
      this.utils = utils;
    };
    var clientConstructor = Client2;
    var forceNative = false;
    try {
      forceNative = !!process.env.NODE_PG_FORCE_NATIVE;
    } catch {
    }
    if (forceNative) {
      clientConstructor = require_native();
    }
    module.exports = new PG(clientConstructor);
    Object.defineProperty(module.exports, "native", {
      configurable: true,
      enumerable: false,
      get() {
        let native = null;
        try {
          native = new PG(require_native());
        } catch (err) {
          if (err.code !== "MODULE_NOT_FOUND") {
            throw err;
          }
        }
        Object.defineProperty(module.exports, "native", {
          value: native
        });
        return native;
      }
    });
  }
});

// server/demo-audiences.ts
var DEMO_AUDIENCES = [
  ["Skyline FM", ["commuters", "young_professionals", "affluent_expats", "parents"]],
  ["Dubai One TV", ["arabic_families", "affluent_expats", "sports_fans", "parents"]],
  ["Gulf News", ["executives", "property_investors", "affluent_expats", "south_asian_community", "luxury_shoppers"]],
  ["Khaleej Times", ["executives", "tech_adopters", "young_professionals", "south_asian_community", "luxury_shoppers"]],
  ["The Majlis Podcast", ["executives", "young_professionals", "students"]]
];
async function applyDemoAudiences(db) {
  let n2 = 0;
  for (const [name, audiences] of DEMO_AUDIENCES) n2 += (await db.query(`update outlets set audiences = $2 where name = $1`, [name, audiences])).rowCount ?? 0;
  return n2;
}

// server/core/live.ts
import { EventEmitter } from "node:events";

// node_modules/pg/esm/index.mjs
var import_lib = __toESM(require_lib2(), 1);
var Client = import_lib.default.Client;
var Pool = import_lib.default.Pool;
var Connection = import_lib.default.Connection;
var types = import_lib.default.types;
var Query = import_lib.default.Query;
var DatabaseError = import_lib.default.DatabaseError;
var escapeIdentifier = import_lib.default.escapeIdentifier;
var escapeLiteral = import_lib.default.escapeLiteral;
var Result = import_lib.default.Result;
var TypeOverrides = import_lib.default.TypeOverrides;
var defaults = import_lib.default.defaults;
var esm_default = import_lib.default;

// server/core/live.ts
var live = new EventEmitter();
live.setMaxListeners(0);
var CHANNEL = "nashr_live";
var listening = false;
var emitLocal = (s) => {
  const i = s.indexOf(":");
  const kind = s.slice(0, i), id = s.slice(i + 1);
  if (kind === "notification" || kind === "slot") live.emit(kind, id);
};
function deliver(s) {
  if (!listening) return emitLocal(s);
  pool.query(`select pg_notify($1, $2)`, [CHANNEL, s]).catch(() => emitLocal(s));
}
var waiting = /* @__PURE__ */ new WeakMap();
function holdSignals(client) {
  waiting.set(client, /* @__PURE__ */ new Set());
}
function releaseSignals(client, committed) {
  const queue2 = waiting.get(client);
  waiting.delete(client);
  if (committed && queue2) for (const s of queue2) deliver(s);
}
var raise = (db, kind, id) => {
  const q = waiting.get(db);
  if (q) q.add(`${kind}:${id}`);
  else deliver(`${kind}:${id}`);
};
var signalCompany = (db, companyId) => raise(db, "notification", companyId);
var signalSlot = (db, slotId) => raise(db, "slot", slotId);

// server/core/db.ts
esm_default.types.setTypeParser(20, Number);
var pool = new esm_default.Pool({ connectionString: process.env.DATABASE_URL });
var later = /* @__PURE__ */ new WeakMap();
var running = /* @__PURE__ */ new Set();
var runLater = (f, onError) => {
  const p = new Promise((resolve) => setImmediate(resolve)).then(f).catch(onError);
  running.add(p);
  p.finally(() => running.delete(p));
};
function afterCommit(db, f) {
  const q = later.get(db);
  if (q) q.push(f);
  else runLater(f, () => {
  });
}
async function tx(fn) {
  const c = await pool.connect();
  try {
    await c.query("begin");
    holdSignals(c);
    later.set(c, []);
    const out = await fn(c);
    await c.query("commit");
    releaseSignals(c, true);
    for (const f of later.get(c) ?? []) runLater(f, (e) => console.error(JSON.stringify({ t: (/* @__PURE__ */ new Date()).toISOString(), job: "after-commit", error: String(e?.stack ?? e) })));
    later.delete(c);
    return out;
  } catch (e) {
    releaseSignals(c, false);
    later.delete(c);
    await c.query("rollback");
    throw e;
  } finally {
    c.release();
  }
}
async function one(db, text, values = []) {
  const { rows } = await db.query(text, values);
  if (rows.length !== 1) throw new Error(`expected 1 row, got ${rows.length}`);
  return rows[0];
}

// server/core/migrate.ts
import { readdirSync, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
var dir = fileURLToPath(new URL("../migrations/", import.meta.url));
async function migrate() {
  const lock = await pool.connect();
  try {
    await lock.query("select pg_advisory_lock(7310002)");
    await pool.query("create table if not exists schema_migrations (name text primary key, at timestamptz not null default now())");
    const done = new Set((await pool.query("select name from schema_migrations")).rows.map((r) => r.name));
    for (const name of readdirSync(dir).filter((f) => f.endsWith(".sql")).sort()) {
      if (done.has(name)) continue;
      await tx(async (c) => {
        await c.query(readFileSync(dir + name, "utf8"));
        await c.query("insert into schema_migrations (name) values ($1)", [name]);
      });
    }
  } finally {
    await lock.query("select pg_advisory_unlock(7310002)").catch(() => {
    });
    lock.release();
  }
}
if (/[\/]migrate\.(ts|mjs)$/.test(process.argv[1] ?? "")) await migrate().finally(() => pool.end());

// server/auth/crypto.ts
import { createHash, createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
function hashPassword(password) {
  const salt = randomBytes(16);
  return `scrypt$${salt.toString("base64")}$${scryptSync(password, salt, 64).toString("base64")}`;
}

// server/core/audit.ts
async function audit(db, actor, action, entity, entityId, detail, at) {
  await db.query(
    `insert into audit_log (at, actor, action, entity, entity_id, detail) values ($1, $2, $3, $4, $5, $6)`,
    [at, actor, action, entity, entityId, detail == null ? null : JSON.stringify(detail)]
  );
}

// server/core/settings.ts
async function setting(db, key, at) {
  const { rows } = await db.query(
    `select value from settings where key = $1 and valid_from <= $2 order by valid_from desc limit 1`,
    [key, at]
  );
  if (!rows.length) throw new Error(`setting ${key} not set`);
  return rows[0].value;
}
async function commissionBp(db, publisherId, at) {
  const own = await db.query(
    `select value from settings where key = $1 and valid_from <= $2 order by valid_from desc limit 1`,
    [`commission:${publisherId}`, at]
  );
  return own.rows.length ? own.rows[0].value : setting(db, "default_commission_bp", at);
}
async function ratesFor(db, publisherId, at) {
  const pub = await one(db, `select vat_registered from companies where id = $1`, [publisherId]);
  return {
    commissionBp: await commissionBp(db, publisherId, at),
    mediaVatBp: pub.vat_registered ? await setting(db, "media_vat_bp", at) : 0,
    feeVatBp: await setting(db, "nashr_vat_registered", at) ? await setting(db, "nashr_vat_bp", at) : 0
  };
}

// server/core/market.ts
var MARKETS = {
  AE: { offset: "+04:00", currency: "AED", weekend: [6, 7] },
  // Saturday, Sunday
  SA: { offset: "+03:00", currency: "SAR", weekend: [5, 6] }
  // Friday, Saturday
};
var offsetMs = (m) => {
  const [h, min] = MARKETS[m].offset.slice(1).split(":").map(Number);
  return (h * 60 + min) * 6e4;
};
function localDay(at, m) {
  const local = new Date(at.getTime() + offsetMs(m));
  return { date: local.toISOString().slice(0, 10), weekday: local.getUTCDay() || 7 };
}
var atLocal = (date, time, m) => /* @__PURE__ */ new Date(`${date}T${time}:00${MARKETS[m].offset}`);
async function addWorkingDays(db, from2, days, m) {
  const holidays = new Set(await setting(db, `holidays_${m}`, from2).catch(() => []));
  let t = from2;
  for (let left = days; left > 0; ) {
    t = new Date(t.getTime() + 864e5);
    const d = localDay(t, m);
    if (!MARKETS[m].weekend.includes(d.weekday) && !holidays.has(d.date)) left--;
  }
  return t;
}

// server/core/money.ts
var pct = (amount, bp) => Math.floor((amount * bp + 5e3) / 1e4);
function split(price, r) {
  const mediaVat = pct(price, r.mediaVatBp);
  const fee = pct(price, r.commissionBp);
  const feeVat = pct(fee, r.feeVatBp);
  return { price, mediaVat, buyerPays: price + mediaVat, fee, feeVat, payout: price + mediaVat - fee - feeVat };
}
var minNextBid = (top, stepBp) => Math.ceil((top + pct(top, stepBp)) / 100) * 100;

// server/core/smtp.ts
function smtpConfig(env = process.env) {
  if (!env.SMTP_HOST || !env.SMTP_FROM) return null;
  const port = Number(env.SMTP_PORT || 587);
  return {
    host: env.SMTP_HOST,
    port,
    user: env.SMTP_USER || void 0,
    pass: env.SMTP_PASS || void 0,
    from: env.SMTP_FROM,
    implicitTls: env.SMTP_SECURE ? env.SMTP_SECURE === "tls" : port === 465,
    rejectUnauthorized: env.SMTP_TLS_INSECURE !== "yes"
  };
}

// web/src/i18n-ar-buyer.ts
var AR_BUYER = {
  // Notifications
  "The publisher accepted. Pay to secure the slot.": "\u0648\u0627\u0641\u0642 \u0627\u0644\u0646\u0627\u0634\u0631. \u0627\u062F\u0641\u0639 \u0644\u062A\u0623\u0645\u064A\u0646 \u0627\u0644\u0645\u0633\u0627\u062D\u0629.",
  "Your request was not selected.": "\u0644\u0645 \u064A\u064F\u062E\u062A\u0631 \u0637\u0644\u0628\u0643.",
  "The payment window passed and the booking lapsed.": "\u0627\u0646\u062A\u0647\u062A \u0645\u0647\u0644\u0629 \u0627\u0644\u062F\u0641\u0639 \u0648\u0633\u0642\u0637 \u0627\u0644\u062D\u062C\u0632.",
  "Payment is secured.": "\u062A\u0645 \u062A\u0623\u0645\u064A\u0646 \u0627\u0644\u062F\u0641\u0639\u0629.",
  "The booking was cancelled.": "\u0623\u064F\u0644\u063A\u064A \u0627\u0644\u062D\u062C\u0632.",
  "A refund was issued.": "\u0635\u062F\u0631 \u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0644\u0644\u0645\u0628\u0644\u063A.",
  "Payment was released.": "\u062D\u064F\u0631\u0651\u0631\u062A \u0627\u0644\u062F\u0641\u0639\u0629.",
  "New buy-now request.": "\u0637\u0644\u0628 \u0634\u0631\u0627\u0621 \u0641\u0648\u0631\u064A \u062C\u062F\u064A\u062F.",
  "New booking to decide on.": "\u062D\u062C\u0632 \u062C\u062F\u064A\u062F \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0642\u0631\u0627\u0631\u0643.",
  "You were outbid on {slot}.": "\u062A\u062C\u0627\u0648\u0632\u0643 \u0645\u0632\u0627\u064A\u062F \u0622\u062E\u0631 \u0639\u0644\u0649 {slot}.",
  "a slot": "\u0645\u0633\u0627\u062D\u0629",
  "New creative to review.": "\u0645\u0627\u062F\u0629 \u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u062C\u062F\u064A\u062F\u0629 \u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629.",
  "Your creative was approved.": "\u0627\u0639\u062A\u064F\u0645\u062F\u062A \u0645\u0627\u062F\u062A\u0643 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "The publisher asked for changes: {reason}": "\u0637\u0644\u0628 \u0627\u0644\u0646\u0627\u0634\u0631 \u062A\u0639\u062F\u064A\u0644\u0627\u062A: {reason}",
  "The publisher asked for changes.": "\u0637\u0644\u0628 \u0627\u0644\u0646\u0627\u0634\u0631 \u062A\u0639\u062F\u064A\u0644\u0627\u062A.",
  "Your file has a technical problem. Upload a fixed version.": "\u0641\u064A \u0645\u0644\u0641\u0643 \u0645\u0634\u0643\u0644\u0629 \u0641\u0646\u064A\u0629. \u0627\u0631\u0641\u0639 \u0646\u0633\u062E\u0629 \u0645\u0635\u062D\u0651\u062D\u0629.",
  "Your creative was rejected.": "\u0631\u064F\u0641\u0636\u062A \u0645\u0627\u062F\u062A\u0643 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "Proof is ready for your review.": "\u0627\u0644\u0625\u062B\u0628\u0627\u062A \u062C\u0627\u0647\u0632 \u0644\u0645\u0631\u0627\u062C\u0639\u062A\u0643.",
  "Reminder: a booking request is waiting for your decision.": "\u062A\u0630\u0643\u064A\u0631: \u0637\u0644\u0628 \u062D\u062C\u0632 \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0642\u0631\u0627\u0631\u0643.",
  "Reminder: pay to secure your booking before the deadline.": "\u062A\u0630\u0643\u064A\u0631: \u0627\u062F\u0641\u0639 \u0644\u062A\u0623\u0645\u064A\u0646 \u062D\u062C\u0632\u0643 \u0642\u0628\u0644 \u0627\u0646\u062A\u0647\u0627\u0621 \u0627\u0644\u0645\u0647\u0644\u0629.",
  "Reminder: review the proof. The money is released automatically at the deadline.": "\u062A\u0630\u0643\u064A\u0631: \u0631\u0627\u062C\u0639 \u0627\u0644\u0625\u062B\u0628\u0627\u062A. \u064A\u064F\u062D\u0631\u064E\u0651\u0631 \u0627\u0644\u0645\u0628\u0644\u063A \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627 \u0639\u0646\u062F \u0627\u0646\u062A\u0647\u0627\u0621 \u0627\u0644\u0645\u0647\u0644\u0629.",
  "Reminder: respond to the reported issue, or it goes to Nashr to decide.": "\u062A\u0630\u0643\u064A\u0631: \u0631\u062F\u0651 \u0639\u0644\u0649 \u0627\u0644\u0645\u0634\u0643\u0644\u0629 \u0627\u0644\u0645\u064F\u0628\u0644\u063A \u0639\u0646\u0647\u0627\u060C \u0648\u0625\u0644\u0627 \u0623\u064F\u062D\u064A\u0644\u062A \u0625\u0644\u0649 \u0646\u0634\u0631 \u0644\u062A\u0642\u0631\u0631.",
  "The buyer reported an issue.": "\u0623\u0628\u0644\u063A \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0639\u0646 \u0645\u0634\u0643\u0644\u0629.",
  "The publisher offered a fix for your issue.": "\u0639\u0631\u0636 \u0627\u0644\u0646\u0627\u0634\u0631 \u062D\u0644\u064B\u0627 \u0644\u0645\u0634\u0643\u0644\u062A\u0643.",
  "The issue was resolved.": "\u062D\u064F\u0644\u0651\u062A \u0627\u0644\u0645\u0634\u0643\u0644\u0629.",
  "A dispute was opened.": "\u0641\u064F\u062A\u062D \u0646\u0632\u0627\u0639.",
  "Nashr decided the dispute: the payment is released to the publisher.": "\u0642\u0631\u0631\u062A \u0646\u0634\u0631 \u0641\u064A \u0627\u0644\u0646\u0632\u0627\u0639: \u062A\u064F\u062D\u0631\u064E\u0651\u0631 \u0627\u0644\u062F\u0641\u0639\u0629 \u0644\u0644\u0646\u0627\u0634\u0631.",
  "Nashr decided the dispute: full refund to the buyer.": "\u0642\u0631\u0631\u062A \u0646\u0634\u0631 \u0641\u064A \u0627\u0644\u0646\u0632\u0627\u0639: \u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0643\u0627\u0645\u0644 \u0644\u0644\u0645\u0634\u062A\u0631\u064A.",
  "Nashr decided the dispute: a partial refund to the buyer.": "\u0642\u0631\u0631\u062A \u0646\u0634\u0631 \u0641\u064A \u0627\u0644\u0646\u0632\u0627\u0639: \u0627\u0633\u062A\u0631\u062F\u0627\u062F \u062C\u0632\u0626\u064A \u0644\u0644\u0645\u0634\u062A\u0631\u064A.",
  "Nashr decided the dispute: the ad runs again.": "\u0642\u0631\u0631\u062A \u0646\u0634\u0631 \u0641\u064A \u0627\u0644\u0646\u0632\u0627\u0639: \u064A\u064F\u0639\u0627\u062F \u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646.",
  "Nashr decided the dispute.": "\u0642\u0631\u0631\u062A \u0646\u0634\u0631 \u0641\u064A \u0627\u0644\u0646\u0632\u0627\u0639.",
  "Confirm the final version before air.": "\u0623\u0643\u0651\u062F \u0627\u0644\u0646\u0633\u062E\u0629 \u0627\u0644\u0646\u0647\u0627\u0626\u064A\u0629 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B.",
  "Confirm the slot and creative before air.": "\u0623\u0643\u0651\u062F \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0648\u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B.",
  "{company} requested access.": "\u0637\u0644\u0628\u062A {company} \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645.",
  "Someone": "\u0634\u062E\u0635 \u0645\u0627",
  "Quote requested for {outlet}.": "\u0637\u064F\u0644\u0628 \u0639\u0631\u0636 \u0633\u0639\u0631 \u0644\u0640{outlet}.",
  "an outlet": "\u0645\u0646\u0635\u0629",
  "1 new slot matches your search \u201C{name}\u201D.": "\u0645\u0633\u0627\u062D\u0629 \u062C\u062F\u064A\u062F\u0629 \u0648\u0627\u062D\u062F\u0629 \u062A\u0637\u0627\u0628\u0642 \u0628\u062D\u062B\u0643 \u201C{name}\u201D.",
  "{n} new slots match your search \u201C{name}\u201D.": "{n} \u0645\u0633\u0627\u062D\u0627\u062A \u062C\u062F\u064A\u062F\u0629 \u062A\u0637\u0627\u0628\u0642 \u0628\u062D\u062B\u0643 \u201C{name}\u201D.",
  "Notifications, {n} unread": "\u0627\u0644\u0625\u0634\u0639\u0627\u0631\u0627\u062A\u060C {n} \u063A\u064A\u0631 \u0645\u0642\u0631\u0648\u0621\u0629",
  "Notifications": "\u0627\u0644\u0625\u0634\u0639\u0627\u0631\u0627\u062A",
  "Nothing yet.": "\u0644\u0627 \u0634\u064A\u0621 \u0628\u0639\u062F.",
  // Ratings
  "Rated {score} out of 5 from {n} bookings": "\u0627\u0644\u062A\u0642\u064A\u064A\u0645 {score} \u0645\u0646 5 \u0645\u0646 {n} \u062D\u062C\u0648\u0632\u0627\u062A",
  "Rated {score} out of 5": "\u0627\u0644\u062A\u0642\u064A\u064A\u0645 {score} \u0645\u0646 5",
  "Poor": "\u0636\u0639\u064A\u0641",
  "Below expectations": "\u062F\u0648\u0646 \u0627\u0644\u062A\u0648\u0642\u0639\u0627\u062A",
  "Good": "\u062C\u064A\u062F",
  "Very good": "\u062C\u064A\u062F \u062C\u062F\u064B\u0627",
  "Excellent": "\u0645\u0645\u062A\u0627\u0632",
  "{n} of 5 stars": "{n} \u0645\u0646 5 \u0646\u062C\u0648\u0645",
  "Your rating of {outlet}": "\u062A\u0642\u064A\u064A\u0645\u0643 \u0644\u0640{outlet}",
  "Nashr has hidden this rating from the outlet page.": "\u0623\u062E\u0641\u062A \u0646\u0634\u0631 \u0647\u0630\u0627 \u0627\u0644\u062A\u0642\u064A\u064A\u0645 \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0646\u0635\u0629.",
  "Change rating": "\u062A\u063A\u064A\u064A\u0631 \u0627\u0644\u062A\u0642\u064A\u064A\u0645",
  "How was {outlet}?": "\u0643\u064A\u0641 \u0643\u0627\u0646\u062A \u062A\u062C\u0631\u0628\u062A\u0643 \u0645\u0639 {outlet}\u061F",
  "Your rating helps other buyers choose. It shows on the outlet page as a verified booking, without your company's name.": "\u064A\u0633\u0627\u0639\u062F \u062A\u0642\u064A\u064A\u0645\u0643 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u0627\u0644\u0622\u062E\u0631\u064A\u0646 \u0639\u0644\u0649 \u0627\u0644\u0627\u062E\u062A\u064A\u0627\u0631. \u064A\u0638\u0647\u0631 \u0641\u064A \u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0646\u0635\u0629 \u0643\u062D\u062C\u0632 \u0645\u0648\u062B\u0651\u0642\u060C \u062F\u0648\u0646 \u0627\u0633\u0645 \u0634\u0631\u0643\u062A\u0643.",
  "Your rating": "\u062A\u0642\u064A\u064A\u0645\u0643",
  "Comment (optional)": "\u062A\u0639\u0644\u064A\u0642 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Did it air as booked? How was working with them?": "\u0647\u0644 \u0628\u064F\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0643\u0645\u0627 \u062D\u064F\u062C\u0632\u061F \u0643\u064A\u0641 \u0643\u0627\u0646 \u0627\u0644\u062A\u0639\u0627\u0645\u0644 \u0645\u0639\u0647\u0645\u061F",
  "Save rating": "\u062D\u0641\u0638 \u0627\u0644\u062A\u0642\u064A\u064A\u0645",
  "Submit rating": "\u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u062A\u0642\u064A\u064A\u0645",
  "Cancel": "\u0625\u0644\u063A\u0627\u0621",
  // Bookings list and statuses
  "Every booking from bid to proof, with your payment held until you approve that the ad ran.": "\u0643\u0644 \u062D\u062C\u0648\u0632\u0627\u062A\u0643 \u0645\u0646 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u062D\u062A\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A\u060C \u0648\u062F\u0641\u0639\u062A\u0643 \u0645\u062D\u0641\u0648\u0638\u0629 \u062D\u062A\u0649 \u062A\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u0623\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0642\u062F \u0628\u064F\u062B.",
  "Receipts and invoices": "\u0627\u0644\u0625\u064A\u0635\u0627\u0644\u0627\u062A \u0648\u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631",
  "No bookings yet. Bid on a slot in the calendar, or send a buy-now request.": "\u0644\u0627 \u062D\u062C\u0648\u0632\u0627\u062A \u0628\u0639\u062F. \u0632\u0627\u064A\u062F \u0639\u0644\u0649 \u0645\u0633\u0627\u062D\u0629 \u0641\u064A \u0627\u0644\u062A\u0642\u0648\u064A\u0645\u060C \u0623\u0648 \u0623\u0631\u0633\u0644 \u0637\u0644\u0628 \u0634\u0631\u0627\u0621 \u0641\u0648\u0631\u064A.",
  "Order": "\u0627\u0644\u0637\u0644\u0628",
  "Slot": "\u0627\u0644\u0645\u0633\u0627\u062D\u0629",
  "Airs": "\u0645\u0648\u0639\u062F \u0627\u0644\u0628\u062B",
  "Total": "\u0627\u0644\u0625\u062C\u0645\u0627\u0644\u064A",
  "Status": "\u0627\u0644\u062D\u0627\u0644\u0629",
  "Awaiting publisher": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0646\u0627\u0634\u0631",
  "Accepted, pay now": "\u0645\u0642\u0628\u0648\u0644\u060C \u0627\u062F\u0641\u0639 \u0627\u0644\u0622\u0646",
  "Payment secured": "\u0627\u0644\u062F\u0641\u0639\u0629 \u0645\u0624\u0645\u0651\u0646\u0629",
  "Proof ready, review": "\u0627\u0644\u0625\u062B\u0628\u0627\u062A \u062C\u0627\u0647\u0632\u060C \u0631\u0627\u062C\u0639\u0647",
  "Issue reported": "\u0623\u064F\u0628\u0644\u063A \u0639\u0646 \u0645\u0634\u0643\u0644\u0629",
  "Disputed": "\u0645\u062D\u0644 \u0646\u0632\u0627\u0639",
  "Released": "\u0645\u062D\u0631\u0651\u0631\u0629",
  "Complete": "\u0645\u0643\u062A\u0645\u0644",
  "Not selected": "\u0644\u0645 \u064A\u064F\u062E\u062A\u0631",
  "Lapsed": "\u0633\u0627\u0642\u0637",
  "Cancelled": "\u0645\u0644\u063A\u0649",
  "Refunded": "\u0645\u0633\u062A\u0631\u062F",
  // Booking page
  "Visa \u2022\u2022\u2022\u2022 4242": "Visa \u2022\u2022\u2022\u2022 4242",
  "Visa \u2022\u2022\u2022\u2022 3155 (bank asks to confirm)": "Visa \u2022\u2022\u2022\u2022 3155 (\u064A\u0637\u0644\u0628 \u0627\u0644\u0628\u0646\u0643 \u0627\u0644\u062A\u0623\u0643\u064A\u062F)",
  "Visa \u2022\u2022\u2022\u2022 0002 (declined)": "Visa \u2022\u2022\u2022\u2022 0002 (\u0645\u0631\u0641\u0648\u0636\u0629)",
  "Request sent": "\u0623\u064F\u0631\u0633\u0644 \u0627\u0644\u0637\u0644\u0628",
  "Publisher accepted": "\u0648\u0627\u0641\u0642 \u0627\u0644\u0646\u0627\u0634\u0631",
  "Publisher did not reply in time": "\u0644\u0645 \u064A\u0631\u062F\u0651 \u0627\u0644\u0646\u0627\u0634\u0631 \u0641\u064A \u0627\u0644\u0648\u0642\u062A \u0627\u0644\u0645\u062D\u062F\u062F",
  "Slot went to another buyer": "\u0630\u0647\u0628\u062A \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0625\u0644\u0649 \u0645\u0634\u062A\u0631\u064D \u0622\u062E\u0631",
  "Payment window passed": "\u0627\u0646\u062A\u0647\u062A \u0645\u0647\u0644\u0629 \u0627\u0644\u062F\u0641\u0639",
  "Proof sent": "\u0623\u064F\u0631\u0633\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "You approved the proof": "\u0648\u0627\u0641\u0642\u062A \u0639\u0644\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "Released automatically after the review window": "\u062D\u064F\u0631\u0651\u0631\u062A \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627 \u0628\u0639\u062F \u0627\u0646\u062A\u0647\u0627\u0621 \u0645\u0647\u0644\u0629 \u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629",
  "You reported an issue": "\u0623\u0628\u0644\u063A\u062A \u0639\u0646 \u0645\u0634\u0643\u0644\u0629",
  "Corrected proof sent": "\u0623\u064F\u0631\u0633\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0627\u0644\u0645\u0635\u062D\u0651\u062D",
  "Make-good agreed": "\u0627\u062A\u064F\u0641\u0642 \u0639\u0644\u0649 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0628\u062B",
  "Partial refund agreed": "\u0627\u062A\u064F\u0641\u0642 \u0639\u0644\u0649 \u0627\u0633\u062A\u0631\u062F\u0627\u062F \u062C\u0632\u0626\u064A",
  "Escalated to Nashr": "\u0623\u064F\u062D\u064A\u0644\u062A \u0625\u0644\u0649 \u0646\u0634\u0631",
  "Nashr released the payment": "\u062D\u0631\u0651\u0631\u062A \u0646\u0634\u0631 \u0627\u0644\u062F\u0641\u0639\u0629",
  "Publisher paid": "\u062F\u064F\u0641\u0639 \u0644\u0644\u0646\u0627\u0634\u0631",
  "You cancelled": "\u0623\u0644\u063A\u064A\u062A \u0627\u0644\u062D\u062C\u0632",
  "Publisher cancelled": "\u0623\u0644\u063A\u0649 \u0627\u0644\u0646\u0627\u0634\u0631 \u0627\u0644\u062D\u062C\u0632",
  "Creative deadline missed": "\u0641\u0627\u062A \u0627\u0644\u0645\u0648\u0639\u062F \u0627\u0644\u0646\u0647\u0627\u0626\u064A \u0644\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Proof not sent in time, refunded": "\u0644\u0645 \u064A\u064F\u0631\u0633\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0641\u064A \u0627\u0644\u0648\u0642\u062A \u0627\u0644\u0645\u062D\u062F\u062F\u060C \u0648\u0627\u0633\u062A\u064F\u0631\u062F \u0627\u0644\u0645\u0628\u0644\u063A",
  "With the publisher": "\u0644\u062F\u0649 \u0627\u0644\u0646\u0627\u0634\u0631",
  "Approved": "\u0645\u0639\u062A\u0645\u062F\u0629",
  "Changes requested": "\u0637\u064F\u0644\u0628\u062A \u062A\u0639\u062F\u064A\u0644\u0627\u062A",
  "Technical problem": "\u0645\u0634\u0643\u0644\u0629 \u0641\u0646\u064A\u0629",
  "Rejected": "\u0645\u0631\u0641\u0648\u0636\u0629",
  "The ad did not run": "\u0644\u0645 \u064A\u064F\u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  "Wrong time or date": "\u0648\u0642\u062A \u0623\u0648 \u062A\u0627\u0631\u064A\u062E \u062E\u0627\u0637\u0626",
  "Wrong position or page": "\u0645\u0648\u0636\u0639 \u0623\u0648 \u0635\u0641\u062D\u0629 \u062E\u0627\u0637\u0626\u0629",
  "The creative was altered": "\u0639\u064F\u062F\u0651\u0644\u062A \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Poor quality": "\u062C\u0648\u062F\u0629 \u0631\u062F\u064A\u0626\u0629",
  "Something else": "\u0633\u0628\u0628 \u0622\u062E\u0631",
  "Download": "\u062A\u0646\u0632\u064A\u0644",
  "Booking progress": "\u062A\u0642\u062F\u0651\u0645 \u0627\u0644\u062D\u062C\u0632",
  "Requested": "\u0637\u064F\u0644\u0628",
  "Accepted": "\u0642\u064F\u0628\u0644",
  "Paid": "\u0645\u062F\u0641\u0648\u0639",
  "Aired": "\u0628\u064F\u062B",
  "Version {n} sent to the publisher.": "\u0623\u064F\u0631\u0633\u0644\u062A \u0627\u0644\u0646\u0633\u062E\u0629 {n} \u0625\u0644\u0649 \u0627\u0644\u0646\u0627\u0634\u0631.",
  "Update your card and try again.": "\u062D\u062F\u0651\u062B \u0628\u0637\u0627\u0642\u062A\u0643 \u0648\u062D\u0627\u0648\u0644 \u0645\u062C\u062F\u062F\u064B\u0627.",
  "Your bank needs you to confirm this payment.": "\u064A\u0637\u0644\u0628 \u0628\u0646\u0643\u0643 \u062A\u0623\u0643\u064A\u062F \u0647\u0630\u0647 \u0627\u0644\u062F\u0641\u0639\u0629.",
  "Order {ref}": "\u0627\u0644\u0637\u0644\u0628 {ref}",
  "Pre-run check": "\u062A\u062D\u0642\u0642 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B",
  "Your ad airs soon. Confirm the publisher has the final version of your creative.": "\u0633\u064A\u064F\u0628\u062B \u0625\u0639\u0644\u0627\u0646\u0643 \u0642\u0631\u064A\u0628\u064B\u0627. \u0623\u0643\u0651\u062F \u0623\u0646 \u0627\u0644\u0646\u0627\u0634\u0631 \u0644\u062F\u064A\u0647 \u0627\u0644\u0646\u0633\u062E\u0629 \u0627\u0644\u0646\u0647\u0627\u0626\u064A\u0629 \u0645\u0646 \u0645\u0627\u062F\u062A\u0643 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "Thanks. The publisher has been told.": "\u0634\u0643\u0631\u064B\u0627. \u0623\u064F\u0628\u0644\u063A \u0627\u0644\u0646\u0627\u0634\u0631.",
  "Confirm final version": "\u062A\u0623\u0643\u064A\u062F \u0627\u0644\u0646\u0633\u062E\u0629 \u0627\u0644\u0646\u0647\u0627\u0626\u064A\u0629",
  "Proof the ad ran": "\u0625\u062B\u0628\u0627\u062A \u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  "As-run log": "\u0633\u062C\u0644 \u0627\u0644\u0628\u062B",
  "Audio clip": "\u0627\u0644\u0645\u0642\u0637\u0639 \u0627\u0644\u0635\u0648\u062A\u064A",
  "Video clip": "\u0645\u0642\u0637\u0639 \u0627\u0644\u0641\u064A\u062F\u064A\u0648",
  "Tearsheet": "\u0646\u0633\u062E\u0629 \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0629",
  "Dated screenshots": "\u0644\u0642\u0637\u0627\u062A \u0634\u0627\u0634\u0629 \u0645\u0624\u0631\u0651\u062E\u0629",
  "Start time": "\u0648\u0642\u062A \u0627\u0644\u0628\u062F\u0621",
  "End time": "\u0648\u0642\u062A \u0627\u0644\u0627\u0646\u062A\u0647\u0627\u0621",
  "Episode link": "\u0631\u0627\u0628\u0637 \u0627\u0644\u062D\u0644\u0642\u0629",
  "Live link": "\u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0645\u0628\u0627\u0634\u0631",
  "Time of the ad in the episode": "\u062A\u0648\u0642\u064A\u062A \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0641\u064A \u0627\u0644\u062D\u0644\u0642\u0629",
  "Approve to release the payment to the publisher. If you do nothing, it is released automatically on {date}.": "\u0648\u0627\u0641\u0642 \u0644\u062A\u062D\u0631\u064A\u0631 \u0627\u0644\u062F\u0641\u0639\u0629 \u0644\u0644\u0646\u0627\u0634\u0631. \u0625\u0630\u0627 \u0644\u0645 \u062A\u062A\u062E\u0630 \u0623\u064A \u0625\u062C\u0631\u0627\u0621\u060C \u062A\u064F\u062D\u0631\u064E\u0651\u0631 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627 \u0641\u064A {date}.",
  "Approve to release the payment to the publisher.": "\u0648\u0627\u0641\u0642 \u0644\u062A\u062D\u0631\u064A\u0631 \u0627\u0644\u062F\u0641\u0639\u0629 \u0644\u0644\u0646\u0627\u0634\u0631.",
  "Approve proof": "\u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 \u0639\u0644\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "Report an issue": "\u0627\u0644\u0625\u0628\u0644\u0627\u063A \u0639\u0646 \u0645\u0634\u0643\u0644\u0629",
  "What went wrong": "\u0645\u0627 \u0627\u0644\u0645\u0634\u0643\u0644\u0629",
  "Choose\u2026": "\u0627\u062E\u062A\u0631\u2026",
  "Details": "\u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644",
  "The publisher can send corrected proof, offer a make-good or a partial refund. Changing your mind or results below expectations are not issues.": "\u064A\u0645\u0643\u0646 \u0644\u0644\u0646\u0627\u0634\u0631 \u0625\u0631\u0633\u0627\u0644 \u0625\u062B\u0628\u0627\u062A \u0645\u0635\u062D\u0651\u062D \u0623\u0648 \u0639\u0631\u0636 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0628\u062B \u0623\u0648 \u0627\u0633\u062A\u0631\u062F\u0627\u062F \u062C\u0632\u0626\u064A. \u062A\u063A\u064A\u064A\u0631 \u0631\u0623\u064A\u0643 \u0623\u0648 \u0646\u062A\u0627\u0626\u062C \u062F\u0648\u0646 \u0627\u0644\u062A\u0648\u0642\u0639\u0627\u062A \u0644\u0627 \u062A\u064F\u0639\u062F \u0645\u0634\u0643\u0644\u0629.",
  "Issue reported. The publisher has 48 hours to respond.": "\u0623\u064F\u0628\u0644\u063A \u0639\u0646 \u0627\u0644\u0645\u0634\u0643\u0644\u0629. \u0644\u062F\u0649 \u0627\u0644\u0646\u0627\u0634\u0631 48 \u0633\u0627\u0639\u0629 \u0644\u0644\u0631\u062F.",
  "Report issue": "\u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0628\u0644\u0627\u063A",
  "Back": "\u0631\u062C\u0648\u0639",
  "Issue: {reason}": "\u0627\u0644\u0645\u0634\u0643\u0644\u0629: {reason}",
  "Nashr's team is looking at this and will decide the outcome.": "\u064A\u062F\u0631\u0633 \u0641\u0631\u064A\u0642 \u0646\u0634\u0631 \u0627\u0644\u0623\u0645\u0631 \u0648\u0633\u064A\u0642\u0631\u0631 \u0627\u0644\u0646\u062A\u064A\u062C\u0629.",
  "The publisher offers:": "\u064A\u0639\u0631\u0636 \u0627\u0644\u0646\u0627\u0634\u0631:",
  "a make-good on {date}": "\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0628\u062B \u0641\u064A {date}",
  "a partial refund of {amount}": "\u0627\u0633\u062A\u0631\u062F\u0627\u062F\u064B\u0627 \u062C\u0632\u0626\u064A\u064B\u0627 \u0628\u0642\u064A\u0645\u0629 {amount}",
  "corrected proof (shown above)": "\u0625\u062B\u0628\u0627\u062A\u064B\u0627 \u0645\u0635\u062D\u0651\u062D\u064B\u0627 (\u0645\u0639\u0631\u0648\u0636 \u0623\u0639\u0644\u0627\u0647)",
  "Offer accepted.": "\u0642\u064F\u0628\u0644 \u0627\u0644\u0639\u0631\u0636.",
  "Accept offer": "\u0642\u0628\u0648\u0644 \u0627\u0644\u0639\u0631\u0636",
  "Sent to Nashr to decide.": "\u0623\u064F\u062D\u064A\u0644 \u0625\u0644\u0649 \u0646\u0634\u0631 \u0644\u062A\u0642\u0631\u0631.",
  "Decline, ask Nashr to decide": "\u0631\u0641\u0636\u060C \u0648\u062F\u0639 \u0646\u0634\u0631 \u062A\u0642\u0631\u0631",
  "Waiting for the publisher's response.": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0631\u062F \u0627\u0644\u0646\u0627\u0634\u0631.",
  "Settled: {amount} refunded to your card, VAT included.": "\u062A\u0645\u062A \u0627\u0644\u062A\u0633\u0648\u064A\u0629: \u0627\u0633\u062A\u064F\u0631\u062F {amount} \u0625\u0644\u0649 \u0628\u0637\u0627\u0642\u062A\u0643\u060C \u0634\u0627\u0645\u0644\u064B\u0627 \u0627\u0644\u0636\u0631\u064A\u0628\u0629.",
  "Settled: the ad runs again on {date}.": "\u062A\u0645\u062A \u0627\u0644\u062A\u0633\u0648\u064A\u0629: \u064A\u064F\u0639\u0627\u062F \u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0641\u064A {date}.",
  "Settled: corrected proof accepted.": "\u062A\u0645\u062A \u0627\u0644\u062A\u0633\u0648\u064A\u0629: \u0642\u064F\u0628\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0627\u0644\u0645\u0635\u062D\u0651\u062D.",
  "Creative": "\u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Due {date} (Dubai time). Technical fixes don't count as a change round.": "\u0627\u0644\u0645\u0648\u0639\u062F \u0627\u0644\u0646\u0647\u0627\u0626\u064A {date} (\u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A). \u0627\u0644\u0625\u0635\u0644\u0627\u062D\u0627\u062A \u0627\u0644\u0641\u0646\u064A\u0629 \u0644\u0627 \u062A\u064F\u062D\u062A\u0633\u0628 \u062C\u0648\u0644\u0629 \u062A\u0639\u062F\u064A\u0644.",
  "Upload a new version": "\u0627\u0631\u0641\u0639 \u0646\u0633\u062E\u0629 \u062C\u062F\u064A\u062F\u0629",
  "Upload your creative": "\u0627\u0631\u0641\u0639 \u0645\u0627\u062F\u062A\u0643 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Timeline": "\u0627\u0644\u0633\u062C\u0644 \u0627\u0644\u0632\u0645\u0646\u064A",
  "VAT (charged by the publisher)": "\u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629 (\u064A\u0641\u0631\u0636\u0647\u0627 \u0627\u0644\u0646\u0627\u0634\u0631)",
  "The publisher accepted. Please pay by {date}.": "\u0648\u0627\u0641\u0642 \u0627\u0644\u0646\u0627\u0634\u0631. \u064A\u064F\u0631\u062C\u0649 \u0627\u0644\u062F\u0641\u0639 \u0642\u0628\u0644 {date}.",
  "The publisher accepted. Please pay.": "\u0648\u0627\u0641\u0642 \u0627\u0644\u0646\u0627\u0634\u0631. \u064A\u064F\u0631\u062C\u0649 \u0627\u0644\u062F\u0641\u0639.",
  "Card": "\u0627\u0644\u0628\u0637\u0627\u0642\u0629",
  "The money is held securely and released to the publisher only after you approve proof that the ad ran. You get a payment receipt from Nashr and a tax invoice from the publisher.": "\u064A\u064F\u062D\u0641\u0638 \u0627\u0644\u0645\u0628\u0644\u063A \u0628\u0623\u0645\u0627\u0646 \u0648\u0644\u0627 \u064A\u064F\u062D\u0631\u064E\u0651\u0631 \u0644\u0644\u0646\u0627\u0634\u0631 \u0625\u0644\u0627 \u0628\u0639\u062F \u0645\u0648\u0627\u0641\u0642\u062A\u0643 \u0639\u0644\u0649 \u0625\u062B\u0628\u0627\u062A \u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646. \u062A\u062D\u0635\u0644 \u0639\u0644\u0649 \u0625\u064A\u0635\u0627\u0644 \u062F\u0641\u0639 \u0645\u0646 \u0646\u0634\u0631 \u0648\u0641\u0627\u062A\u0648\u0631\u0629 \u0636\u0631\u064A\u0628\u064A\u0629 \u0645\u0646 \u0627\u0644\u0646\u0627\u0634\u0631.",
  "By paying you agree to the": "\u0628\u0627\u0644\u062F\u0641\u0639\u060C \u0641\u0625\u0646\u0643 \u062A\u0648\u0627\u0641\u0642 \u0639\u0644\u0649",
  "terms": "\u0627\u0644\u0634\u0631\u0648\u0637",
  "and the": "\u0648",
  "refund and cancellation policy": "\u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0648\u0627\u0644\u0625\u0644\u063A\u0627\u0621",
  "Pay {amount}": "\u0627\u062F\u0641\u0639 {amount}",
  "Waiting for the publisher's decision. You'll be asked to pay once they accept.": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0642\u0631\u0627\u0631 \u0627\u0644\u0646\u0627\u0634\u0631. \u0633\u064A\u064F\u0637\u0644\u0628 \u0645\u0646\u0643 \u0627\u0644\u062F\u0641\u0639 \u0628\u0639\u062F \u0645\u0648\u0627\u0641\u0642\u062A\u0647.",
  "Reason: {reason}": "\u0627\u0644\u0633\u0628\u0628: {reason}",
  "Cancel booking\u2026": "\u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u062D\u062C\u0632\u2026",
  "If you cancel now": "\u0625\u0630\u0627 \u0623\u0644\u063A\u064A\u062A \u0627\u0644\u0622\u0646",
  "(inside the free cancellation window)": "(\u0636\u0645\u0646 \u0641\u062A\u0631\u0629 \u0627\u0644\u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u0645\u062C\u0627\u0646\u064A)",
  "You paid": "\u062F\u0641\u0639\u062A",
  "Kept by the publisher (cancellation fee)": "\u064A\u062D\u062A\u0641\u0638 \u0628\u0647 \u0627\u0644\u0646\u0627\u0634\u0631 (\u0631\u0633\u0648\u0645 \u0627\u0644\u0625\u0644\u063A\u0627\u0621)",
  "Card processing cost of the refund": "\u062A\u0643\u0644\u0641\u0629 \u0645\u0639\u0627\u0644\u062C\u0629 \u0627\u0644\u0628\u0637\u0627\u0642\u0629 \u0644\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F",
  "Refunded to your card": "\u064A\u064F\u0633\u062A\u0631\u062F \u0625\u0644\u0649 \u0628\u0637\u0627\u0642\u062A\u0643",
  "Confirm cancellation": "\u062A\u0623\u0643\u064A\u062F \u0627\u0644\u0625\u0644\u063A\u0627\u0621",
  "Keep the booking": "\u0627\u0644\u0625\u0628\u0642\u0627\u0621 \u0639\u0644\u0649 \u0627\u0644\u062D\u062C\u0632",
  // Dashboard
  "Pay": "\u0627\u062F\u0641\u0639",
  "Pay to secure the booking": "\u0627\u062F\u0641\u0639 \u0644\u062A\u0623\u0645\u064A\u0646 \u0627\u0644\u062D\u062C\u0632",
  "Ad": "\u0625\u0639\u0644\u0627\u0646",
  "Send your creative": "\u0623\u0631\u0633\u0644 \u0645\u0627\u062F\u062A\u0643 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Proof": "\u0625\u062B\u0628\u0627\u062A",
  "Review the proof": "\u0631\u0627\u062C\u0639 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "Issue": "\u0645\u0634\u0643\u0644\u0629",
  "Answer the publisher": "\u0631\u062F\u0651 \u0639\u0644\u0649 \u0627\u0644\u0646\u0627\u0634\u0631",
  "Good morning": "\u0635\u0628\u0627\u062D \u0627\u0644\u062E\u064A\u0631",
  "Good afternoon": "\u0645\u0633\u0627\u0621 \u0627\u0644\u062E\u064A\u0631",
  "Good evening": "\u0645\u0633\u0627\u0621 \u0627\u0644\u062E\u064A\u0631",
  "Find slots": "\u0627\u0628\u062D\u062B \u0639\u0646 \u0645\u0633\u0627\u062D\u0627\u062A",
  "Held for you now": "\u0627\u0644\u0645\u062D\u0641\u0648\u0638 \u0644\u0643 \u0627\u0644\u0622\u0646",
  "1 paid booking, released to the publisher only after you approve proof.": "\u062D\u062C\u0632 \u0645\u062F\u0641\u0648\u0639 \u0648\u0627\u062D\u062F\u060C \u0644\u0627 \u064A\u064F\u062D\u0631\u064E\u0651\u0631 \u0644\u0644\u0646\u0627\u0634\u0631 \u0625\u0644\u0627 \u0628\u0639\u062F \u0645\u0648\u0627\u0641\u0642\u062A\u0643 \u0639\u0644\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A.",
  "{n} paid bookings, released to publishers only after you approve proof.": "{n} \u062D\u062C\u0648\u0632\u0627\u062A \u0645\u062F\u0641\u0648\u0639\u0629\u060C \u0644\u0627 \u062A\u064F\u062D\u0631\u064E\u0651\u0631 \u0644\u0644\u0646\u0627\u0634\u0631\u064A\u0646 \u0625\u0644\u0627 \u0628\u0639\u062F \u0645\u0648\u0627\u0641\u0642\u062A\u0643 \u0639\u0644\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A.",
  "Nothing held: paid bookings appear here until their ad has run.": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u062D\u0641\u0648\u0638: \u062A\u0638\u0647\u0631 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0629 \u0647\u0646\u0627 \u062D\u062A\u0649 \u064A\u064F\u0628\u062B \u0625\u0639\u0644\u0627\u0646\u0647\u0627.",
  "Paid in the last 30 days:": "\u0627\u0644\u0645\u062F\u0641\u0648\u0639 \u0641\u064A \u0622\u062E\u0631 30 \u064A\u0648\u0645\u064B\u0627:",
  "Booked and paid, by week (excluding VAT)": "\u0627\u0644\u0645\u062D\u062C\u0648\u0632 \u0648\u0627\u0644\u0645\u062F\u0641\u0648\u0639 \u0623\u0633\u0628\u0648\u0639\u064A\u064B\u0627 (\u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629)",
  "To pay": "\u0644\u0644\u062F\u0641\u0639",
  "Nothing": "\u0644\u0627 \u0634\u064A\u0621",
  "1 accepted booking": "\u062D\u062C\u0632 \u0645\u0642\u0628\u0648\u0644 \u0648\u0627\u062D\u062F",
  "{n} accepted bookings": "{n} \u062D\u062C\u0648\u0632\u0627\u062A \u0645\u0642\u0628\u0648\u0644\u0629",
  ", first by": "\u060C \u0623\u0648\u0644\u0647\u0627 \u0642\u0628\u0644",
  "Every accepted booking is paid.": "\u062C\u0645\u064A\u0639 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u0645\u0642\u0628\u0648\u0644\u0629 \u0645\u062F\u0641\u0648\u0639\u0629.",
  "Live bids": "\u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0627\u062A \u0627\u0644\u062C\u0627\u0631\u064A\u0629",
  "{n} leading": "{n} \u0641\u064A \u0627\u0644\u0645\u0642\u062F\u0645\u0629",
  "{n} outbid": "{n} \u0645\u062A\u062C\u0627\u0648\u064E\u0632\u0629",
  "No open bids.": "\u0644\u0627 \u0645\u0632\u0627\u064A\u062F\u0627\u062A \u0645\u0641\u062A\u0648\u062D\u0629.",
  "Needs you": "\u0628\u062D\u0627\u062C\u0629 \u0625\u0644\u064A\u0643",
  "Payments, creative and proof to review": "\u0645\u062F\u0641\u0648\u0639\u0627\u062A \u0648\u0645\u0648\u0627\u062F \u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0648\u0625\u062B\u0628\u0627\u062A\u0627\u062A \u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629",
  "All clear": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u0639\u0644\u0651\u0642",
  "Outlets booked": "\u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0627\u0644\u0645\u062D\u062C\u0648\u0632\u0629",
  "{n} paid bookings so far": "{n} \u062D\u062C\u0648\u0632\u0627\u062A \u0645\u062F\u0641\u0648\u0639\u0629 \u062D\u062A\u0649 \u0627\u0644\u0622\u0646",
  "soonest first": "\u0627\u0644\u0623\u0642\u0631\u0628 \u0623\u0648\u0644\u064B\u0627",
  "All bookings": "\u0643\u0644 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A",
  "Nothing waiting on you. New requests appear here once a publisher accepts.": "\u0644\u0627 \u0634\u064A\u0621 \u0628\u0627\u0646\u062A\u0638\u0627\u0631\u0643. \u062A\u0638\u0647\u0631 \u0627\u0644\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u062C\u062F\u064A\u062F\u0629 \u0647\u0646\u0627 \u0628\u0639\u062F \u0645\u0648\u0627\u0641\u0642\u0629 \u0627\u0644\u0646\u0627\u0634\u0631.",
  "by {when}": "\u0642\u0628\u0644 {when}",
  "Your bids": "\u0645\u0632\u0627\u064A\u062F\u0627\u062A\u0643",
  "No open bids. Find a slot on the calendar.": "\u0644\u0627 \u0645\u0632\u0627\u064A\u062F\u0627\u062A \u0645\u0641\u062A\u0648\u062D\u0629. \u0627\u0628\u062D\u062B \u0639\u0646 \u0645\u0633\u0627\u062D\u0629 \u0641\u064A \u0627\u0644\u062A\u0642\u0648\u064A\u0645.",
  "airs {date}": "\u064A\u064F\u0628\u062B {date}",
  "closing": "\u064A\u064F\u063A\u0644\u0642 \u0642\u0631\u064A\u0628\u064B\u0627",
  "Leading": "\u0641\u064A \u0627\u0644\u0645\u0642\u062F\u0645\u0629",
  "top {price}": "\u0627\u0644\u0623\u0639\u0644\u0649 {price}",
  "Campaign budgets": "\u0645\u064A\u0632\u0627\u0646\u064A\u0627\u062A \u0627\u0644\u062D\u0645\u0644\u0627\u062A",
  "No active campaigns.": "\u0644\u0627 \u062D\u0645\u0644\u0627\u062A \u0646\u0634\u0637\u0629.",
  "Plan a campaign": "\u062E\u0637\u0651\u0637 \u062D\u0645\u0644\u0629",
  "to track spend against a budget.": "\u0644\u0645\u062A\u0627\u0628\u0639\u0629 \u0627\u0644\u0625\u0646\u0641\u0627\u0642 \u0648\u0641\u0642 \u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629.",
  "{amount} committed": "{amount} \u0645\u0644\u062A\u0632\u0645 \u0628\u0647",
  "{amount} waiting": "{amount} \u0642\u064A\u062F \u0627\u0644\u0627\u0646\u062A\u0638\u0627\u0631",
  "{amount} left": "{amount} \u0645\u062A\u0628\u0642\u064D",
  "of {amount}": "\u0645\u0646 {amount}",
  "Where your budget went (last 90 days, excluding VAT)": "\u0623\u064A\u0646 \u0630\u0647\u0628\u062A \u0645\u064A\u0632\u0627\u0646\u064A\u062A\u0643 (\u0622\u062E\u0631 90 \u064A\u0648\u0645\u064B\u0627\u060C \u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629)",
  "No paid bookings in the last 90 days.": "\u0644\u0627 \u062D\u062C\u0648\u0632\u0627\u062A \u0645\u062F\u0641\u0648\u0639\u0629 \u0641\u064A \u0622\u062E\u0631 90 \u064A\u0648\u0645\u064B\u0627.",
  "1 booking": "\u062D\u062C\u0632 \u0648\u0627\u062D\u062F",
  "{n} bookings": "{n} \u062D\u062C\u0648\u0632\u0627\u062A",
  "Coming up on air": "\u0642\u0631\u064A\u0628\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0647\u0648\u0627\u0621",
  "Nothing booked to run yet.": "\u0644\u0627 \u062D\u062C\u0648\u0632\u0627\u062A \u0644\u0644\u0628\u062B \u0628\u0639\u062F.",
  "Paid, money held": "\u0645\u062F\u0641\u0648\u0639\u060C \u0648\u0627\u0644\u0645\u0628\u0644\u063A \u0645\u062D\u0641\u0648\u0638",
  "Accepted, waiting for payment": "\u0645\u0642\u0628\u0648\u0644\u060C \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u062F\u0641\u0639",
  // Bid window
  "Bidding closes {date}, {time} (Dubai time)": "\u062A\u064F\u063A\u0644\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 {date}\u060C {time} (\u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A)",
  "{n} seconds": "{n} \u062B\u0627\u0646\u064A\u0629",
  "Asking price": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0645\u0637\u0644\u0648\u0628",
  "Current top bid": "\u0623\u0639\u0644\u0649 \u0645\u0632\u0627\u064A\u062F\u0629 \u062D\u0627\u0644\u064A\u0629",
  "No bids yet": "\u0644\u0627 \u0645\u0632\u0627\u064A\u062F\u0627\u062A \u0628\u0639\u062F",
  "{n} bids \xB7 bidders anonymous": "{n} \u0645\u0632\u0627\u064A\u062F\u0627\u062A \xB7 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0648\u0646 \u0645\u062C\u0647\u0648\u0644\u0648 \u0627\u0644\u0647\u0648\u064A\u0629",
  "Minimum next bid": "\u0623\u062F\u0646\u0649 \u0645\u0632\u0627\u064A\u062F\u0629 \u062A\u0627\u0644\u064A\u0629",
  "Buy now": "\u0634\u0631\u0627\u0621 \u0641\u0648\u0631\u064A",
  "Request to book: the publisher must accept": "\u0637\u0644\u0628 \u062D\u062C\u0632: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0648\u0627\u0641\u0642 \u0627\u0644\u0646\u0627\u0634\u0631",
  "Your bid (excl. VAT)": "\u0645\u0632\u0627\u064A\u062F\u062A\u0643 (\u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629)",
  "AED": "\u062F\u0631\u0647\u0645",
  "Raise your bid": "\u0627\u0631\u0641\u0639 \u0645\u0632\u0627\u064A\u062F\u062A\u0643",
  "Auto-bid": "\u0645\u0632\u0627\u064A\u062F\u0629 \u062A\u0644\u0642\u0627\u0626\u064A\u0629",
  "Maximum bid": "\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u0642\u0635\u0649 \u0644\u0644\u0645\u0632\u0627\u064A\u062F\u0629",
  "We raise your bid in 3% steps when you're outbid, up to this maximum.": "\u0646\u0631\u0641\u0639 \u0645\u0632\u0627\u064A\u062F\u062A\u0643 \u0628\u0632\u064A\u0627\u062F\u0627\u062A 3% \u0639\u0646\u062F\u0645\u0627 \u064A\u062A\u062C\u0627\u0648\u0632\u0643 \u0622\u062E\u0631\u0648\u0646\u060C \u062D\u062A\u0649 \u0647\u0630\u0627 \u0627\u0644\u062D\u062F \u0627\u0644\u0623\u0642\u0635\u0649.",
  "Your offer (AED, optional, not below the asking price)": "\u0639\u0631\u0636\u0643 (\u0628\u0627\u0644\u062F\u0631\u0647\u0645\u060C \u0627\u062E\u062A\u064A\u0627\u0631\u064A\u060C \u0644\u0627 \u064A\u0642\u0644 \u0639\u0646 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0645\u0637\u0644\u0648\u0628)",
  "Booking brief": "\u0645\u0648\u062C\u0632 \u0627\u0644\u062D\u062C\u0632",
  "Advertiser or brand": "\u0627\u0644\u0645\u0639\u0644\u0646 \u0623\u0648 \u0627\u0644\u0639\u0644\u0627\u0645\u0629 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629",
  "Industry": "\u0627\u0644\u0642\u0637\u0627\u0639",
  "What the ad will say": "\u0645\u062D\u062A\u0648\u0649 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  "Creative language": "\u0644\u063A\u0629 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "English": "\u0627\u0644\u0625\u0646\u062C\u0644\u064A\u0632\u064A\u0629",
  "Arabic": "\u0627\u0644\u0639\u0631\u0628\u064A\u0629",
  "Bilingual": "\u062B\u0646\u0627\u0626\u064A\u0629 \u0627\u0644\u0644\u063A\u0629",
  "Landing page link": "\u0631\u0627\u0628\u0637 \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0642\u0635\u0648\u062F\u0629",
  "Creative to follow": "\u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0644\u0627\u062D\u0642\u064B\u0627",
  "Notes for the publisher": "\u0645\u0644\u0627\u062D\u0638\u0627\u062A \u0644\u0644\u0646\u0627\u0634\u0631",
  "Emails and phone numbers are not allowed. Talk to the publisher through Nashr.": "\u0644\u0627 \u064A\u064F\u0633\u0645\u062D \u0628\u0639\u0646\u0627\u0648\u064A\u0646 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0648\u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0647\u0648\u0627\u062A\u0641. \u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0627\u0644\u0646\u0627\u0634\u0631 \u0639\u0628\u0631 \u0646\u0634\u0631.",
  "Campaign": "\u0627\u0644\u062D\u0645\u0644\u0629",
  "No campaign": "\u0628\u062F\u0648\u0646 \u062D\u0645\u0644\u0629",
  "You'll be asked to pay once the publisher accepts. Nothing is charged now.": "\u0633\u064A\u064F\u0637\u0644\u0628 \u0645\u0646\u0643 \u0627\u0644\u062F\u0641\u0639 \u0628\u0639\u062F \u0645\u0648\u0627\u0641\u0642\u0629 \u0627\u0644\u0646\u0627\u0634\u0631. \u0644\u0627 \u064A\u064F\u062E\u0635\u0645 \u0623\u064A \u0645\u0628\u0644\u063A \u0627\u0644\u0622\u0646.",
  "Your bid is in.": "\u0633\u064F\u062C\u0651\u0644\u062A \u0645\u0632\u0627\u064A\u062F\u062A\u0643.",
  "Place bid {amount}": "\u0632\u0627\u064A\u062F \u0628\u0640{amount}",
  "The publisher has your interest.": "\u0623\u064F\u0628\u0644\u063A \u0627\u0644\u0646\u0627\u0634\u0631 \u0628\u0627\u0647\u062A\u0645\u0627\u0645\u0643.",
  "Show interest": "\u0623\u0628\u062F\u0650 \u0627\u0647\u062A\u0645\u0627\u0645\u0643",
  "Request sent. The publisher will reply within 24 hours.": "\u0623\u064F\u0631\u0633\u0644 \u0627\u0644\u0637\u0644\u0628. \u0633\u064A\u0631\u062F \u0627\u0644\u0646\u0627\u0634\u0631 \u062E\u0644\u0627\u0644 24 \u0633\u0627\u0639\u0629.",
  "Request at {price}": "\u0627\u0637\u0644\u0628 \u0628\u0640{price}",
  "Banking": "\u0627\u0644\u0645\u0635\u0627\u0631\u0641",
  "Real estate": "\u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062A",
  "Retail": "\u0627\u0644\u062A\u062C\u0632\u0626\u0629",
  "Technology": "\u0627\u0644\u062A\u0642\u0646\u064A\u0629",
  "Hospitality": "\u0627\u0644\u0636\u064A\u0627\u0641\u0629",
  "Health": "\u0627\u0644\u0635\u062D\u0629",
  "Automotive": "\u0627\u0644\u0633\u064A\u0627\u0631\u0627\u062A",
  "Education": "\u0627\u0644\u062A\u0639\u0644\u064A\u0645",
  "Government": "\u0627\u0644\u062D\u0643\u0648\u0645\u0629",
  "Other": "\u0623\u062E\u0631\u0649",
  // Saved searches
  "That saved search was deleted, so the calendar shows every slot.": "\u062D\u064F\u0630\u0641 \u0647\u0630\u0627 \u0627\u0644\u0628\u062D\u062B \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u060C \u0644\u0630\u0627 \u064A\u0639\u0631\u0636 \u0627\u0644\u062A\u0642\u0648\u064A\u0645 \u0643\u0644 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A.",
  "Saved. We will alert you when new slots match.": "\u062A\u0645 \u0627\u0644\u062D\u0641\u0638. \u0633\u0646\u0646\u0628\u0651\u0647\u0643 \u0639\u0646\u062F \u062A\u0648\u0641\u0651\u0631 \u0645\u0633\u0627\u062D\u0627\u062A \u062C\u062F\u064A\u062F\u0629 \u0645\u0637\u0627\u0628\u0642\u0629.",
  "Saved.": "\u062A\u0645 \u0627\u0644\u062D\u0641\u0638.",
  "Deleted \u201C{name}\u201D.": "\u062D\u064F\u0630\u0641 \u201C{name}\u201D.",
  "Saved searches": "\u0639\u0645\u0644\u064A\u0627\u062A \u0627\u0644\u0628\u062D\u062B \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629",
  "Set the filters below, then save the search to get an alert when new slots match.": "\u062D\u062F\u0651\u062F \u0639\u0648\u0627\u0645\u0644 \u0627\u0644\u062A\u0635\u0641\u064A\u0629 \u0623\u062F\u0646\u0627\u0647\u060C \u062B\u0645 \u0627\u062D\u0641\u0638 \u0627\u0644\u0628\u062D\u062B \u0644\u062A\u062A\u0644\u0642\u0649 \u062A\u0646\u0628\u064A\u0647\u064B\u0627 \u0639\u0646\u062F \u062A\u0648\u0641\u0651\u0631 \u0645\u0633\u0627\u062D\u0627\u062A \u062C\u062F\u064A\u062F\u0629 \u0645\u0637\u0627\u0628\u0642\u0629.",
  "Turn off alerts for {name}": "\u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0644\u0640{name}",
  "Turn on alerts for {name}": "\u062A\u0634\u063A\u064A\u0644 \u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0644\u0640{name}",
  "Alerts on": "\u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0645\u0641\u0639\u0651\u0644\u0629",
  "Alerts off": "\u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0645\u062A\u0648\u0642\u0641\u0629",
  "Delete {name}": "\u062D\u0630\u0641 {name}",
  "Delete": "\u062D\u0630\u0641",
  "Save this search": "\u0627\u062D\u0641\u0638 \u0647\u0630\u0627 \u0627\u0644\u0628\u062D\u062B",
  "Name": "\u0627\u0644\u0627\u0633\u0645",
  "Alert me when new slots match": "\u0646\u0628\u0651\u0647\u0646\u064A \u0639\u0646\u062F \u062A\u0648\u0641\u0651\u0631 \u0645\u0633\u0627\u062D\u0627\u062A \u062C\u062F\u064A\u062F\u0629 \u0645\u0637\u0627\u0628\u0642\u0629",
  "Save": "\u062D\u0641\u0638",
  "All channels": "\u0643\u0644 \u0627\u0644\u0642\u0646\u0648\u0627\u062A",
  "under {price}": "\u0623\u0642\u0644 \u0645\u0646 {price}",
  "morning": "\u0627\u0644\u0635\u0628\u0627\u062D",
  "afternoon": "\u0627\u0644\u0638\u0647\u064A\u0631\u0629",
  "evening": "\u0627\u0644\u0645\u0633\u0627\u0621",
  "all day": "\u0637\u0648\u0627\u0644 \u0627\u0644\u064A\u0648\u0645",
  "auctions": "\u0627\u0644\u0645\u0632\u0627\u062F\u0627\u062A",
  "quick sales": "\u0627\u0644\u0628\u064A\u0639 \u0627\u0644\u0633\u0631\u064A\u0639",
  ", ": "\u060C ",
  // Campaigns and media plan
  "Committed and pending against the budget": "\u0627\u0644\u0645\u0644\u062A\u0632\u0645 \u0628\u0647 \u0648\u0642\u064A\u062F \u0627\u0644\u0627\u0646\u062A\u0638\u0627\u0631 \u0645\u0642\u0627\u0628\u0644 \u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629",
  "Plan outlets against a budget. Bids and requests tagged to a campaign count against it.": "\u062E\u0637\u0651\u0637 \u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0648\u0641\u0642 \u0645\u064A\u0632\u0627\u0646\u064A\u0629. \u062A\u064F\u062D\u062A\u0633\u0628 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0627\u062A \u0648\u0627\u0644\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u0645\u0631\u062A\u0628\u0637\u0629 \u0628\u0627\u0644\u062D\u0645\u0644\u0629 \u0645\u0646 \u0645\u064A\u0632\u0627\u0646\u064A\u062A\u0647\u0627.",
  "New campaign": "\u062D\u0645\u0644\u0629 \u062C\u062F\u064A\u062F\u0629",
  "Budget (AED, excl. VAT)": "\u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629 (\u0628\u0627\u0644\u062F\u0631\u0647\u0645\u060C \u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629)",
  "Launch date": "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0625\u0637\u0644\u0627\u0642",
  "Objective": "\u0627\u0644\u0647\u062F\u0641",
  "Awareness, launch, footfall\u2026": "\u0627\u0644\u0648\u0639\u064A\u060C \u0627\u0644\u0625\u0637\u0644\u0627\u0642\u060C \u0632\u064A\u0627\u062F\u0629 \u0627\u0644\u0632\u0648\u0627\u0631\u2026",
  "Create": "\u0625\u0646\u0634\u0627\u0621",
  "No campaigns yet. Create one to plan outlets and track spend against a budget.": "\u0644\u0627 \u062D\u0645\u0644\u0627\u062A \u0628\u0639\u062F. \u0623\u0646\u0634\u0626 \u062D\u0645\u0644\u0629 \u0644\u062A\u062E\u0637\u064A\u0637 \u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0648\u0645\u062A\u0627\u0628\u0639\u0629 \u0627\u0644\u0625\u0646\u0641\u0627\u0642 \u0648\u0641\u0642 \u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629.",
  "Launch": "\u0627\u0644\u0625\u0637\u0644\u0627\u0642",
  "Budget": "\u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629",
  "Committed": "\u0627\u0644\u0645\u0644\u062A\u0632\u0645 \u0628\u0647",
  "Active": "\u0646\u0634\u0637\u0629",
  "Completed": "\u0645\u0643\u062A\u0645\u0644\u0629",
  "Plan saved.": "\u062D\u064F\u0641\u0638\u062A \u0627\u0644\u062E\u0637\u0629.",
  "Launches {date}": "\u062A\u0646\u0637\u0644\u0642 \u0641\u064A {date}",
  "Media plan (PDF)": "\u0627\u0644\u062E\u0637\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u0629 (PDF)",
  "Mark completed": "\u062A\u0639\u064A\u064A\u0646 \u0643\u0645\u0643\u062A\u0645\u0644\u0629",
  "Reopen": "\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0641\u062A\u062D",
  "Awaiting publishers": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646",
  "Remaining": "\u0627\u0644\u0645\u062A\u0628\u0642\u064A",
  "Prices excl. VAT. Committed means accepted by the publisher; tag bids to this campaign from the bid drawer.": '\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629. "\u0627\u0644\u0645\u0644\u062A\u0632\u0645 \u0628\u0647" \u064A\u0639\u0646\u064A \u0645\u0627 \u0648\u0627\u0641\u0642 \u0639\u0644\u064A\u0647 \u0627\u0644\u0646\u0627\u0634\u0631\u061B \u0627\u0631\u0628\u0637 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0627\u062A \u0628\u0647\u0630\u0647 \u0627\u0644\u062D\u0645\u0644\u0629 \u0645\u0646 \u0646\u0627\u0641\u0630\u0629 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629.',
  "Plan": "\u0627\u0644\u062E\u0637\u0629",
  "Planned (AED)": "\u0627\u0644\u0645\u062E\u0637\u0637 (\u0628\u0627\u0644\u062F\u0631\u0647\u0645)",
  "Quote needed": "\u064A\u0644\u0632\u0645 \u0639\u0631\u0636 \u0633\u0639\u0631",
  "Planned amount": "\u0627\u0644\u0645\u0628\u0644\u063A \u0627\u0644\u0645\u062E\u0637\u0637",
  "Remove {name}": "\u0625\u0632\u0627\u0644\u0629 {name}",
  "Remove": "\u0625\u0632\u0627\u0644\u0629",
  "Add outlet": "\u0625\u0636\u0627\u0641\u0629 \u0645\u0646\u0635\u0629",
  "Add an outlet\u2026": "\u0623\u0636\u0641 \u0645\u0646\u0635\u0629\u2026",
  "Add": "\u0625\u0636\u0627\u0641\u0629",
  "Save plan": "\u062D\u0641\u0638 \u0627\u0644\u062E\u0637\u0629",
  "Nothing booked yet.": "\u0644\u0627 \u062D\u062C\u0648\u0632\u0627\u062A \u0628\u0639\u062F.",
  "media plan": "\u0627\u0644\u062E\u0637\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u0629",
  "Back to the campaign": "\u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u0627\u0644\u062D\u0645\u0644\u0629",
  "Print or save as PDF": "\u0637\u0628\u0627\u0639\u0629 \u0623\u0648 \u062D\u0641\u0638 PDF",
  "In the print dialog, choose \u201CSave as PDF\u201D.": '\u0641\u064A \u0646\u0627\u0641\u0630\u0629 \u0627\u0644\u0637\u0628\u0627\u0639\u0629\u060C \u0627\u062E\u062A\u0631 "\u062D\u0641\u0638 \u0643\u0645\u0644\u0641 PDF".',
  "Media plan": "\u0627\u0644\u062E\u0637\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u0629",
  "Prepared {date}": "\u0623\u064F\u0639\u062F\u0651\u062A \u0641\u064A {date}",
  "Planned": "\u0627\u0644\u0645\u062E\u0637\u0637",
  "Channel mix": "\u062A\u0648\u0632\u064A\u0639 \u0627\u0644\u0642\u0646\u0648\u0627\u062A",
  "By outlet in the plan: the amount committed, or the amount planned while that is higher.": "\u062D\u0633\u0628 \u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0641\u064A \u0627\u0644\u062E\u0637\u0629: \u0627\u0644\u0645\u0628\u0644\u063A \u0627\u0644\u0645\u0644\u062A\u0632\u0645 \u0628\u0647\u060C \u0623\u0648 \u0627\u0644\u0645\u0628\u0644\u063A \u0627\u0644\u0645\u062E\u0637\u0637 \u0645\u0627 \u062F\u0627\u0645 \u0623\u0639\u0644\u0649.",
  "The plan": "\u0627\u0644\u062E\u0637\u0629",
  "No outlets in the plan yet.": "\u0644\u0627 \u0645\u0646\u0635\u0627\u062A \u0641\u064A \u0627\u0644\u062E\u0637\u0629 \u0628\u0639\u062F.",
  "Outlet and slot": "\u0627\u0644\u0645\u0646\u0635\u0629 \u0648\u0627\u0644\u0645\u0633\u0627\u062D\u0629",
  "Prices in AED, excluding VAT. Times in Dubai time. Payments are held by Nashr until the publisher proves the ad ran.": "\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0628\u0627\u0644\u062F\u0631\u0647\u0645 \u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629. \u0627\u0644\u0623\u0648\u0642\u0627\u062A \u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A. \u062A\u062D\u062A\u0641\u0638 \u0646\u0634\u0631 \u0628\u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A \u062D\u062A\u0649 \u064A\u064F\u062B\u0628\u062A \u0627\u0644\u0646\u0627\u0634\u0631 \u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646.",
  "Figures as of {date}; planned amounts are estimates until a publisher accepts.": "\u0627\u0644\u0623\u0631\u0642\u0627\u0645 \u062D\u062A\u0649 {date}\u061B \u0648\u0627\u0644\u0645\u0628\u0627\u0644\u063A \u0627\u0644\u0645\u062E\u0637\u0637\u0629 \u062A\u0642\u062F\u064A\u0631\u064A\u0629 \u062D\u062A\u0649 \u064A\u0648\u0627\u0641\u0642 \u0627\u0644\u0646\u0627\u0634\u0631.",
  // Charts
  "vs previous 30 days": "\u0645\u0642\u0627\u0631\u0646\u0629 \u0628\u0627\u0644\u064030 \u064A\u0648\u0645\u064B\u0627 \u0627\u0644\u0633\u0627\u0628\u0642\u0629",
  "New: none in the 30 days before": "\u062C\u062F\u064A\u062F: \u0644\u0627 \u0634\u064A\u0621 \u0641\u064A \u0627\u0644\u064030 \u064A\u0648\u0645\u064B\u0627 \u0627\u0644\u0633\u0627\u0628\u0642\u0629",
  "Value": "\u0627\u0644\u0642\u064A\u0645\u0629",
  "Week of {week}: {value}": "\u0623\u0633\u0628\u0648\u0639 {week}: {value}",
  "This week": "\u0647\u0630\u0627 \u0627\u0644\u0623\u0633\u0628\u0648\u0639",
  "Week of {week}": "\u0623\u0633\u0628\u0648\u0639 {week}",
  "Show as table": "\u0639\u0631\u0636 \u0643\u062C\u062F\u0648\u0644",
  "Week of": "\u0623\u0633\u0628\u0648\u0639",
  // Receipts and invoices
  "Payment receipt": "\u0625\u064A\u0635\u0627\u0644 \u062F\u0641\u0639",
  "Tax invoice (media)": "\u0641\u0627\u062A\u0648\u0631\u0629 \u0636\u0631\u064A\u0628\u064A\u0629 (\u0625\u0639\u0644\u0627\u0645)",
  "Commission invoice": "\u0641\u0627\u062A\u0648\u0631\u0629 \u0627\u0644\u0639\u0645\u0648\u0644\u0629",
  "Credit note": "\u0625\u0634\u0639\u0627\u0631 \u062F\u0627\u0626\u0646",
  "Payment receipts, tax invoices and credit notes for every booking.": "\u0625\u064A\u0635\u0627\u0644\u0627\u062A \u0627\u0644\u062F\u0641\u0639 \u0648\u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629 \u0648\u0627\u0644\u0625\u0634\u0639\u0627\u0631\u0627\u062A \u0627\u0644\u062F\u0627\u0626\u0646\u0629 \u0644\u0643\u0644 \u062D\u062C\u0632.",
  "Nothing yet. You get a receipt from Nashr and a tax invoice from the publisher when you pay.": "\u0644\u0627 \u0634\u064A\u0621 \u0628\u0639\u062F. \u062A\u062D\u0635\u0644 \u0639\u0644\u0649 \u0625\u064A\u0635\u0627\u0644 \u0645\u0646 \u0646\u0634\u0631 \u0648\u0641\u0627\u062A\u0648\u0631\u0629 \u0636\u0631\u064A\u0628\u064A\u0629 \u0645\u0646 \u0627\u0644\u0646\u0627\u0634\u0631 \u0639\u0646\u062F \u0627\u0644\u062F\u0641\u0639.",
  "Document": "\u0627\u0644\u0645\u0633\u062A\u0646\u062F",
  "Number": "\u0627\u0644\u0631\u0642\u0645",
  "Date": "\u0627\u0644\u062A\u0627\u0631\u064A\u062E",
  "Tax invoice": "\u0641\u0627\u062A\u0648\u0631\u0629 \u0636\u0631\u064A\u0628\u064A\u0629",
  "Invoice": "\u0641\u0627\u062A\u0648\u0631\u0629",
  "Publisher's uploaded invoice": "\u0627\u0644\u0641\u0627\u062A\u0648\u0631\u0629 \u0627\u0644\u062A\u064A \u0631\u0641\u0639\u0647\u0627 \u0627\u0644\u0646\u0627\u0634\u0631",
  "Issued {date}": "\u0635\u062F\u0631\u062A \u0641\u064A {date}",
  "Credits {ref}": "\u064A\u064F\u0642\u064A\u0651\u062F \u0644\u0635\u0627\u0644\u062D {ref}",
  "TRN": "\u0627\u0644\u0631\u0642\u0645 \u0627\u0644\u0636\u0631\u064A\u0628\u064A",
  "Issued by Nashr on the publisher's behalf": "\u0635\u0627\u062F\u0631\u0629 \u0645\u0646 \u0646\u0634\u0631 \u0646\u064A\u0627\u0628\u0629\u064B \u0639\u0646 \u0627\u0644\u0646\u0627\u0634\u0631",
  "To": "\u0625\u0644\u0649",
  "Description": "\u0627\u0644\u0648\u0635\u0641",
  "Amount": "\u0627\u0644\u0645\u0628\u0644\u063A",
  "Subtotal": "\u0627\u0644\u0645\u062C\u0645\u0648\u0639 \u0627\u0644\u0641\u0631\u0639\u064A",
  "VAT {rate}%": "\u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629 {rate}%",
  "Payment received by Nashr on behalf of the publisher. This is not a tax invoice; the publisher's tax invoice is issued separately.": "\u0627\u0633\u062A\u0644\u0645\u062A \u0646\u0634\u0631 \u0627\u0644\u062F\u0641\u0639\u0629 \u0646\u064A\u0627\u0628\u0629\u064B \u0639\u0646 \u0627\u0644\u0646\u0627\u0634\u0631. \u0647\u0630\u0647 \u0644\u064A\u0633\u062A \u0641\u0627\u062A\u0648\u0631\u0629 \u0636\u0631\u064A\u0628\u064A\u0629\u061B \u062A\u0635\u062F\u0631 \u0627\u0644\u0641\u0627\u062A\u0648\u0631\u0629 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629 \u0644\u0644\u0646\u0627\u0634\u0631 \u0628\u0634\u0643\u0644 \u0645\u0646\u0641\u0635\u0644.",
  // Athena
  "Athena will turn a campaign brief into a suggested set of bookable slots across UAE media, based on real winning prices, audiences and results on Nashr.": "\u0633\u062A\u062D\u0648\u0651\u0644 \u0623\u062B\u064A\u0646\u0627 \u0645\u0648\u062C\u0632 \u0627\u0644\u062D\u0645\u0644\u0629 \u0625\u0644\u0649 \u0645\u062C\u0645\u0648\u0639\u0629 \u0645\u0642\u062A\u0631\u062D\u0629 \u0645\u0646 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u062D\u062C\u0632 \u0641\u064A \u0648\u0633\u0627\u0626\u0644 \u0627\u0644\u0625\u0639\u0644\u0627\u0645 \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A\u064A\u0629\u060C \u0627\u0633\u062A\u0646\u0627\u062F\u064B\u0627 \u0625\u0644\u0649 \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0641\u0627\u0626\u0632\u0629 \u0627\u0644\u0641\u0639\u0644\u064A\u0629 \u0648\u0627\u0644\u062C\u0645\u0627\u0647\u064A\u0631 \u0648\u0627\u0644\u0646\u062A\u0627\u0626\u062C \u0639\u0644\u0649 \u0646\u0634\u0631.",
  "We're collecting that data now with every booking. Until then, plan with": "\u0646\u062C\u0645\u0639 \u0647\u0630\u0647 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0622\u0646 \u0645\u0639 \u0643\u0644 \u062D\u062C\u0632. \u0648\u062D\u062A\u0649 \u0630\u0644\u0643 \u0627\u0644\u062D\u064A\u0646\u060C \u062E\u0637\u0651\u0637 \u0628\u0627\u0633\u062A\u062E\u062F\u0627\u0645",
  "Tell me when Athena launches": "\u0623\u0628\u0644\u063A\u0646\u064A \u0639\u0646\u062F \u0625\u0637\u0644\u0627\u0642 \u0623\u062B\u064A\u0646\u0627",
  "The publisher's tax invoice is issued separately.": "\u062A\u0635\u062F\u0631 \u0627\u0644\u0641\u0627\u062A\u0648\u0631\u0629 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629 \u0644\u0644\u0646\u0627\u0634\u0631 \u0628\u0634\u0643\u0644 \u0645\u0646\u0641\u0635\u0644.",
  "Check availability": "\u062A\u062D\u0642\u0651\u0642 \u0645\u0646 \u0627\u0644\u062A\u0648\u0641\u0651\u0631",
  "Logo chosen. It is saved with the client.": "\u062A\u0645 \u0627\u062E\u062A\u064A\u0627\u0631 \u0627\u0644\u0634\u0639\u0627\u0631. \u064A\u064F\u062D\u0641\u0638 \u0645\u0639 \u0627\u0644\u0639\u0645\u064A\u0644.",
  "Optional": "\u0627\u062E\u062A\u064A\u0627\u0631\u064A",
  "Add your brief and creative first.": "\u0623\u0636\u0641 \u0627\u0644\u0645\u0644\u062E\u0635 \u0648\u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0623\u0648\u0644\u064B\u0627.",
  "Upload the creative.": "\u0627\u0631\u0641\u0639 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629."
};

// web/src/i18n-ar-seller.ts
var AR_SELLER = {
  // Statuses, tasks and run-time labels
  "Your decision": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0642\u0631\u0627\u0631\u0643",
  "Accepted, buyer paying": "\u0645\u0642\u0628\u0648\u0644\u0629\u060C \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u064A\u062F\u0641\u0639",
  "Paid, to fulfil": "\u0645\u062F\u0641\u0648\u0639\u0629\u060C \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u062A\u0646\u0641\u064A\u0630",
  "Proof with buyer": "\u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0644\u062F\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "With Nashr": "\u0644\u062F\u0649 \u0646\u0634\u0631",
  "Paid out": "\u062D\u064F\u0648\u0651\u0644\u062A \u0625\u0644\u064A\u0643",
  "Declined": "\u0645\u0631\u0641\u0648\u0636\u0629",
  "Buyer did not pay": "\u0644\u0645 \u064A\u062F\u0641\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "On sale": "\u0645\u0639\u0631\u0648\u0636\u0629 \u0644\u0644\u0628\u064A\u0639",
  "Choose next bid": "\u0627\u062E\u062A\u0631 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629",
  "Booked": "\u0645\u062D\u062C\u0648\u0632\u0629",
  "Off sale": "\u062E\u0627\u0631\u062C \u0627\u0644\u0628\u064A\u0639",
  "Unavailable (overlaps a booking)": "\u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629 (\u062A\u062A\u062F\u0627\u062E\u0644 \u0645\u0639 \u062D\u062C\u0632)",
  "Unsold": "\u0644\u0645 \u062A\u064F\u0628\u0639",
  "Decide": "\u0642\u0631\u0651\u0631",
  "Choose a bid": "\u0627\u062E\u062A\u0631 \u0645\u0632\u0627\u064A\u062F\u0629",
  "Review": "\u0631\u0627\u062C\u0650\u0639",
  "Send proof": "\u0623\u0631\u0633\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "Respond": "\u0631\u062F\u0651",
  "Confirm": "\u0623\u0643\u0651\u062F",
  "Upload": "\u0627\u0631\u0641\u0639",
  "Open": "\u0641\u062A\u062D",
  "Accept or decline": "\u0627\u0642\u0628\u0644 \u0623\u0648 \u0627\u0631\u0641\u0636",
  "Choose the next bid": "\u0627\u062E\u062A\u0631 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629",
  "Review creative": "\u0631\u0627\u062C\u0650\u0639 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Creative not received": "\u0644\u0645 \u062A\u0635\u0644 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Respond to an issue": "\u0631\u062F\u0651 \u0639\u0644\u0649 \u0645\u0634\u0643\u0644\u0629",
  "Confirm the pre-run check": "\u0623\u0643\u0651\u062F \u0641\u062D\u0635 \u0645\u0627 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B",
  "Upload your invoice": "\u0627\u0631\u0641\u0639 \u0641\u0627\u062A\u0648\u0631\u062A\u0643",
  "Bid": "\u0645\u0632\u0627\u064A\u062F\u0629",
  "Interest": "\u0627\u0647\u062A\u0645\u0627\u0645",
  "To decide": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0642\u0631\u0627\u0631",
  "In progress": "\u0642\u064A\u062F \u0627\u0644\u062A\u0646\u0641\u064A\u0630",
  "Closed": "\u0645\u063A\u0644\u0642\u0629",
  "radio": "\u0627\u0644\u0625\u0630\u0627\u0639\u0629",
  "print": "\u0627\u0644\u0645\u0637\u0628\u0648\u0639\u0627\u062A",
  "digital": "\u0627\u0644\u0631\u0642\u0645\u064A",
  "podcast": "\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A",
  "active": "\u0646\u0634\u0637\u0629",
  "outbid": "\u062A\u064F\u062C\u0648\u0648\u0632\u062A",
  "selected": "\u0645\u062E\u062A\u0627\u0631\u0629",
  "not selected": "\u0644\u0645 \u062A\u064F\u062E\u062A\u0631",
  "withdrawn": "\u0645\u0633\u062D\u0648\u0628\u0629",
  "Pending": "\u0642\u064A\u062F \u0627\u0644\u0627\u0646\u062A\u0638\u0627\u0631",
  "Add your outlet profile": "\u0623\u0636\u0641 \u0645\u0644\u0641 \u0645\u0646\u0635\u062A\u0643",
  "Connect your payout account": "\u0627\u0631\u0628\u0637 \u062D\u0633\u0627\u0628 \u0627\u0633\u062A\u0644\u0627\u0645 \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A",
  "Add your TRN and invoice choice": "\u0623\u0636\u0641 \u0631\u0642\u0645\u0643 \u0627\u0644\u0636\u0631\u064A\u0628\u064A \u0648\u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u0641\u0648\u062A\u0631\u0629",
  "Add your first placement": "\u0623\u0636\u0641 \u0623\u0648\u0644 \u0645\u0633\u0627\u062D\u0629 \u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Put slots on sale": "\u0627\u0639\u0631\u0636 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0644\u0644\u0628\u064A\u0639",
  "Request received": "\u0648\u0635\u0644 \u0627\u0644\u0637\u0644\u0628",
  "You accepted": "\u0642\u0628\u0644\u062A \u0627\u0644\u0637\u0644\u0628",
  "You declined": "\u0631\u0641\u0636\u062A \u0627\u0644\u0637\u0644\u0628",
  "Expired without a decision": "\u0627\u0646\u062A\u0647\u062A \u0627\u0644\u0645\u0647\u0644\u0629 \u062F\u0648\u0646 \u0642\u0631\u0627\u0631",
  "Another request was accepted": "\u0642\u064F\u0628\u0644 \u0637\u0644\u0628 \u0622\u062E\u0631",
  "Buyer paid": "\u062F\u0641\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "Buyer did not pay in time": "\u0644\u0645 \u064A\u062F\u0641\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0641\u064A \u0627\u0644\u0648\u0642\u062A \u0627\u0644\u0645\u062D\u062F\u062F",
  "You sent proof": "\u0623\u0631\u0633\u0644\u062A \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "Buyer approved": "\u0648\u0627\u0641\u0642 \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "Released automatically": "\u062D\u064F\u0631\u0651\u0631\u062A \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627",
  "Buyer reported an issue": "\u0623\u0628\u0644\u063A \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0639\u0646 \u0645\u0634\u0643\u0644\u0629",
  "Corrected proof accepted": "\u0642\u064F\u0628\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0627\u0644\u0645\u0635\u062D\u0651\u062D",
  "Escalated to Nashr": "\u0623\u064F\u062D\u064A\u0644\u062A \u0625\u0644\u0649 \u0646\u0634\u0631",
  "Nashr released": "\u062D\u0631\u0651\u0631\u062A \u0646\u0634\u0631 \u0627\u0644\u062F\u0641\u0639\u0629",
  "Refunded": "\u0645\u0633\u062A\u0631\u062F",
  "Paid to your bank": "\u062D\u064F\u0648\u0651\u0644\u062A \u0625\u0644\u0649 \u062D\u0633\u0627\u0628\u0643 \u0627\u0644\u0628\u0646\u0643\u064A",
  "Buyer cancelled": "\u0623\u0644\u063A\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "You cancelled": "\u0623\u0644\u063A\u064A\u062A \u0627\u0644\u062D\u062C\u0632",
  "Released: creative not received": "\u062D\u064F\u0631\u0651\u0631\u062A: \u0644\u0645 \u062A\u0635\u0644 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Refunded: proof not sent in time": "\u0627\u0633\u062A\u064F\u0631\u062F\u0651\u062A: \u0644\u0645 \u064A\u064F\u0631\u0633\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0641\u064A \u0627\u0644\u0648\u0642\u062A \u0627\u0644\u0645\u062D\u062F\u062F",
  "Waiting for your review": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0645\u0631\u0627\u062C\u0639\u062A\u0643",
  "Rejected": "\u0645\u0631\u0641\u0648\u0636\u0629",
  "Doesn't match the booking brief": "\u0644\u0627 \u062A\u0637\u0627\u0628\u0642 \u0645\u0644\u062E\u0635 \u0627\u0644\u062D\u062C\u0632",
  "Breaks content standards": "\u062A\u062E\u0627\u0644\u0641 \u0645\u0639\u0627\u064A\u064A\u0631 \u0627\u0644\u0645\u062D\u062A\u0648\u0649",
  "Wrong specifications": "\u0645\u0648\u0627\u0635\u0641\u0627\u062A \u062E\u0627\u0637\u0626\u0629",
  "Other (Nashr reviews it)": "\u0633\u0628\u0628 \u0622\u062E\u0631 (\u062A\u0631\u0627\u062C\u0639\u0647 \u0646\u0634\u0631)",
  "The ad did not run": "\u0644\u0645 \u064A\u064F\u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  "Wrong time or date": "\u0648\u0642\u062A \u0623\u0648 \u062A\u0627\u0631\u064A\u062E \u062E\u0627\u0637\u0626",
  "Wrong position or page": "\u0645\u0648\u0636\u0639 \u0623\u0648 \u0635\u0641\u062D\u0629 \u062E\u0627\u0637\u0626\u0629",
  "The creative was altered": "\u0639\u064F\u062F\u0651\u0644\u062A \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Poor quality": "\u062C\u0648\u062F\u0629 \u0631\u062F\u064A\u0626\u0629",
  "Needs your decision": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0642\u0631\u0627\u0631\u0643",
  "Off sale or taken": "\u062E\u0627\u0631\u062C \u0627\u0644\u0628\u064A\u0639 \u0623\u0648 \u0645\u062D\u062C\u0648\u0632\u0629",
  "Position {n}": "\u0627\u0644\u0645\u0648\u0636\u0639 {n}",
  "Break {n}": "\u0627\u0644\u0641\u0627\u0635\u0644 {n}",
  "from 1 buyer \xB7 {month} buyers this month": "\u0645\u0646 \u0645\u0634\u062A\u0631\u064D \u0648\u0627\u062D\u062F \xB7 {month} \u0645\u0634\u062A\u0631\u064A\u0646 \u0647\u0630\u0627 \u0627\u0644\u0634\u0647\u0631",
  "from {n} buyers \xB7 {month} buyers this month": "\u0645\u0646 {n} \u0645\u0634\u062A\u0631\u064A\u0646 \xB7 {month} \u0645\u0634\u062A\u0631\u064A\u0646 \u0647\u0630\u0627 \u0627\u0644\u0634\u0647\u0631",
  // Task list
  "overdue": "\u0645\u062A\u0623\u062E\u0631\u0629",
  "due in {n}h": "\u062E\u0644\u0627\u0644 {n} \u0633\u0627\u0639\u0629",
  "due {day}": "\u062A\u0633\u062A\u062D\u0642 {day}",
  "Nothing needs you right now.": "\u0644\u0627 \u0634\u064A\u0621 \u064A\u062D\u062A\u0627\u062C\u0643 \u0627\u0644\u0622\u0646.",
  "This buyer will pay now": "\u0633\u064A\u062F\u0641\u0639 \u0647\u0630\u0627 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0641\u0648\u0631\u064B\u0627",
  "Below your reserve": "\u0623\u0642\u0644 \u0645\u0646 \u0633\u0639\u0631\u0643 \u0627\u0644\u0623\u062F\u0646\u0649",
  // Dashboard
  "No decisions yet": "\u0644\u0627 \u0642\u0631\u0627\u0631\u0627\u062A \u0628\u0639\u062F",
  "{n} min": "{n} \u062F\u0642\u064A\u0642\u0629",
  "{n} h": "{n} \u0633\u0627\u0639\u0629",
  "Add a placement": "\u0623\u0636\u0641 \u0645\u0633\u0627\u062D\u0629 \u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Get ready to sell \xB7 {done} of {total}": "\u0627\u0633\u062A\u0639\u062F \u0644\u0644\u0628\u064A\u0639 \xB7 {done} \u0645\u0646 {total}",
  "Earned in the last 30 days": "\u0623\u0631\u0628\u0627\u062D \u0622\u062E\u0631 30 \u064A\u0648\u0645\u064B\u0627",
  "Paid out to you after proof is approved, net of Nashr's commission.": "\u062A\u064F\u062D\u0648\u064E\u0651\u0644 \u0625\u0644\u064A\u0643 \u0628\u0639\u062F \u0627\u0639\u062A\u0645\u0627\u062F \u0627\u0644\u0625\u062B\u0628\u0627\u062A\u060C \u0628\u0639\u062F \u062E\u0635\u0645 \u0639\u0645\u0648\u0644\u0629 \u0646\u0634\u0631.",
  "Held for bookings in progress": "\u0645\u062D\u062C\u0648\u0632\u0629 \u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0642\u064A\u062F \u0627\u0644\u062A\u0646\u0641\u064A\u0630",
  "Released, being paid out": "\u0645\u062D\u0631\u0651\u0631\u0629\u060C \u0642\u064A\u062F \u0627\u0644\u062A\u062D\u0648\u064A\u0644",
  "Owed to Nashr (next payout)": "\u0645\u0633\u062A\u062D\u0642\u0629 \u0644\u0646\u0634\u0631 (\u0645\u0646 \u0627\u0644\u062A\u062D\u0648\u064A\u0644 \u0627\u0644\u0642\u0627\u062F\u0645)",
  "Your earnings by week": "\u0623\u0631\u0628\u0627\u062D\u0643 \u0623\u0633\u0628\u0648\u0639\u064A\u064B\u0627",
  "Earned": "\u0627\u0644\u0623\u0631\u0628\u0627\u062D",
  "Decisions, creative and proof": "\u0642\u0631\u0627\u0631\u0627\u062A \u0648\u0645\u0648\u0627\u062F \u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0648\u0625\u062B\u0628\u0627\u062A\u0627\u062A",
  "Sold in the last 30 days": "\u0627\u0644\u0645\u0628\u064A\u0639\u0627\u062A \u0641\u064A \u0622\u062E\u0631 30 \u064A\u0648\u0645\u064B\u0627",
  "Bids this week": "\u0645\u0632\u0627\u064A\u062F\u0627\u062A \u0647\u0630\u0627 \u0627\u0644\u0623\u0633\u0628\u0648\u0639",
  "Price above starting": "\u0627\u0644\u0632\u064A\u0627\u062F\u0629 \u0639\u0644\u0649 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0627\u0628\u062A\u062F\u0627\u0626\u064A",
  "No auctions yet": "\u0644\u0627 \u0645\u0632\u0627\u062F\u0627\u062A \u0628\u0639\u062F",
  "average over {n} auctions, last 90 days": "\u0645\u062A\u0648\u0633\u0637 {n} \u0645\u0632\u0627\u062F\u0627\u062A\u060C \u0622\u062E\u0631 90 \u064A\u0648\u0645\u064B\u0627",
  "Auctions show how far bidding lifts your price": "\u062A\u064F\u0638\u0647\u0631 \u0627\u0644\u0645\u0632\u0627\u062F\u0627\u062A \u0645\u0642\u062F\u0627\u0631 \u0627\u0631\u062A\u0641\u0627\u0639 \u0633\u0639\u0631\u0643 \u0628\u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629",
  "To do": "\u0627\u0644\u0645\u0647\u0627\u0645",
  "Next 4 weeks": "\u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0627\u0644\u0623\u0631\u0628\u0639\u0629 \u0627\u0644\u0642\u0627\u062F\u0645\u0629",
  "Sold or waiting on you": "\u0645\u0628\u0627\u0639\u0629 \u0623\u0648 \u0628\u0627\u0646\u062A\u0638\u0627\u0631\u0643",
  "{sold} sold \xB7 {waiting} waiting for your decision \xB7 {open} still on sale": "{sold} \u0645\u0628\u0627\u0639\u0629 \xB7 {waiting} \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0642\u0631\u0627\u0631\u0643 \xB7 {open} \u0645\u0627 \u0632\u0627\u0644\u062A \u0645\u0639\u0631\u0648\u0636\u0629",
  " \xB7 {n} unsold": " \xB7 {n} \u0644\u0645 \u062A\u064F\u0628\u0639",
  "Nothing listed for the next 4 weeks.": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u0639\u0631\u0648\u0636 \u0644\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0627\u0644\u0623\u0631\u0628\u0639\u0629 \u0627\u0644\u0642\u0627\u062F\u0645\u0629.",
  "Requests you accepted (90 days)": "\u0627\u0644\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u062A\u064A \u0642\u0628\u0644\u062A\u0647\u0627 (90 \u064A\u0648\u0645\u064B\u0627)",
  "{accepted} accepted \xB7 {declined} declined \xB7 typical reply {time}": "{accepted} \u0645\u0642\u0628\u0648\u0644\u0629 \xB7 {declined} \u0645\u0631\u0641\u0648\u0636\u0629 \xB7 \u0645\u062A\u0648\u0633\u0637 \u0627\u0644\u0631\u062F {time}",
  "No decisions yet.": "\u0644\u0627 \u0642\u0631\u0627\u0631\u0627\u062A \u0628\u0639\u062F.",
  "Best-selling placements (last 90 days)": "\u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u0623\u0643\u062B\u0631 \u0645\u0628\u064A\u0639\u064B\u0627 (\u0622\u062E\u0631 90 \u064A\u0648\u0645\u064B\u0627)",
  "No paid bookings yet.": "\u0644\u0627 \u062D\u062C\u0648\u0632\u0627\u062A \u0645\u062F\u0641\u0648\u0639\u0629 \u0628\u0639\u062F.",
  "{n} sold": "{n} \u0645\u0628\u0627\u0639\u0629",
  "Top buyers (last 90 days)": "\u0623\u0628\u0631\u0632 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646 (\u0622\u062E\u0631 90 \u064A\u0648\u0645\u064B\u0627)",
  "No buyers yet.": "\u0644\u0627 \u0645\u0634\u062A\u0631\u064A\u0646 \u0628\u0639\u062F.",
  "Coming up on air": "\u0642\u0631\u064A\u0628\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0647\u0648\u0627\u0621",
  "No booked slots coming up.": "\u0644\u0627 \u0645\u0633\u0627\u062D\u0627\u062A \u0645\u062D\u062C\u0648\u0632\u0629 \u0642\u0627\u062F\u0645\u0629.",
  "Everything waiting on you, soonest deadline first.": "\u0643\u0644 \u0645\u0627 \u064A\u0646\u062A\u0638\u0631\u0643\u060C \u0627\u0644\u0623\u0642\u0631\u0628 \u0645\u0648\u0639\u062F\u064B\u0627 \u0623\u0648\u0644\u064B\u0627.",
  // Deals and a deal
  "Every sale from acceptance to proof and payout.": "\u0643\u0644 \u0639\u0645\u0644\u064A\u0629 \u0628\u064A\u0639 \u0645\u0646 \u0627\u0644\u0642\u0628\u0648\u0644 \u0625\u0644\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0648\u0627\u0644\u062A\u062D\u0648\u064A\u0644.",
  "Filter": "\u062A\u0635\u0641\u064A\u0629",
  "No deals here.": "\u0644\u0627 \u0635\u0641\u0642\u0627\u062A \u0647\u0646\u0627.",
  "You receive": "\u0635\u0627\u0641\u064A \u0645\u0627 \u062A\u0633\u062A\u0644\u0645\u0647",
  "The buyer's rating": "\u062A\u0642\u064A\u064A\u0645 \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "Your VAT on the media": "\u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629 \u0639\u0644\u0649 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  "Nashr commission ({pct})": "\u0639\u0645\u0648\u0644\u0629 \u0646\u0634\u0631 ({pct})",
  "This is below your reserve price. You can still accept it.": "\u0647\u0630\u0627 \u0623\u0642\u0644 \u0645\u0646 \u0633\u0639\u0631\u0643 \u0627\u0644\u0623\u062F\u0646\u0649. \u064A\u0645\u0643\u0646\u0643 \u0642\u0628\u0648\u0644\u0647 \u0645\u0639 \u0630\u0644\u0643.",
  "Decide by {when} or the request expires.": "\u0642\u0631\u0651\u0631 \u0642\u0628\u0644 {when} \u0648\u0625\u0644\u0627 \u0627\u0646\u062A\u0647\u062A \u0635\u0644\u0627\u062D\u064A\u0629 \u0627\u0644\u0637\u0644\u0628.",
  "Accepted. The buyer has been asked to pay.": "\u0642\u064F\u0628\u0644 \u0627\u0644\u0637\u0644\u0628. \u0637\u064F\u0644\u0628 \u0645\u0646 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0627\u0644\u062F\u0641\u0639.",
  "Accept": "\u0642\u0628\u0648\u0644",
  "Decline": "\u0631\u0641\u0636",
  "Reason (the buyer sees it)": "\u0627\u0644\u0633\u0628\u0628 (\u064A\u0631\u0627\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u064A)",
  "Declined.": "\u0631\u064F\u0641\u0636 \u0627\u0644\u0637\u0644\u0628.",
  "Payment pending: the buyer's card was declined and they've been asked to update it. The booking lapses at {when} if they don't pay.": "\u0627\u0644\u062F\u0641\u0639\u0629 \u0645\u0639\u0644\u0651\u0642\u0629: \u0631\u064F\u0641\u0636\u062A \u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0648\u0637\u064F\u0644\u0628 \u0645\u0646\u0647 \u062A\u062D\u062F\u064A\u062B\u0647\u0627. \u064A\u0633\u0642\u0637 \u0627\u0644\u062D\u062C\u0632 \u0641\u064A {when} \u0625\u0646 \u0644\u0645 \u064A\u062F\u0641\u0639.",
  "Payment pending: the buyer's card was declined and they've been asked to update it.": "\u0627\u0644\u062F\u0641\u0639\u0629 \u0645\u0639\u0644\u0651\u0642\u0629: \u0631\u064F\u0641\u0636\u062A \u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0648\u0637\u064F\u0644\u0628 \u0645\u0646\u0647 \u062A\u062D\u062F\u064A\u062B\u0647\u0627.",
  "Waiting for the buyer to pay (by {when}). They can send creative already.": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u062F\u0641\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A (\u0642\u0628\u0644 {when}). \u064A\u0645\u0643\u0646\u0647 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0645\u0646 \u0627\u0644\u0622\u0646.",
  "Waiting for the buyer to pay. They can send creative already.": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u062F\u0641\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A. \u064A\u0645\u0643\u0646\u0647 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0645\u0646 \u0627\u0644\u0622\u0646.",
  "You can choose another bid for this slot.": "\u064A\u0645\u0643\u0646\u0643 \u0627\u062E\u062A\u064A\u0627\u0631 \u0645\u0632\u0627\u064A\u062F\u0629 \u0623\u062E\u0631\u0649 \u0644\u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629.",
  "Advertiser": "\u0627\u0644\u0645\u0639\u0644\u0646",
  "The ad will say": "\u0645\u0636\u0645\u0648\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  "Language": "\u0627\u0644\u0644\u063A\u0629",
  "Landing page": "\u0635\u0641\u062D\u0629 \u0627\u0644\u0647\u0628\u0648\u0637",
  "Notes": "\u0645\u0644\u0627\u062D\u0638\u0627\u062A",
  "Industry is one of your sectors": "\u0627\u0644\u0642\u0637\u0627\u0639 \u0636\u0645\u0646 \u0642\u0637\u0627\u0639\u0627\u062A\u0643",
  "Industry isn't in your sectors": "\u0627\u0644\u0642\u0637\u0627\u0639 \u0644\u064A\u0633 \u0636\u0645\u0646 \u0642\u0637\u0627\u0639\u0627\u062A\u0643",
  "No landing page link yet": "\u0644\u0627 \u0631\u0627\u0628\u0637 \u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0647\u0628\u0648\u0637 \u0628\u0639\u062F",
  "These checks are for your information. The decision is yours.": "\u0647\u0630\u0647 \u0627\u0644\u0641\u062D\u0648\u0635 \u0644\u0644\u0639\u0644\u0645 \u0641\u0642\u0637. \u0627\u0644\u0642\u0631\u0627\u0631 \u0644\u0643.",
  "Due {when}. A technical problem with the file doesn't use one of the buyer's change rounds.": "\u062A\u0633\u062A\u062D\u0642 \u0641\u064A {when}. \u0627\u0644\u0645\u0634\u0643\u0644\u0629 \u0627\u0644\u0641\u0646\u064A\u0629 \u0641\u064A \u0627\u0644\u0645\u0644\u0641 \u0644\u0627 \u062A\u064F\u062D\u062A\u0633\u0628 \u0645\u0646 \u062C\u0648\u0644\u0627\u062A \u0627\u0644\u062A\u0639\u062F\u064A\u0644 \u0627\u0644\u0645\u062A\u0627\u062D\u0629 \u0644\u0644\u0645\u0634\u062A\u0631\u064A.",
  "Not received yet.": "\u0644\u0645 \u062A\u0635\u0644 \u0628\u0639\u062F.",
  "Creative approved.": "\u0627\u0639\u062A\u064F\u0645\u062F\u062A \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "Approve": "\u0627\u0639\u062A\u0645\u0627\u062F",
  "Ask for changes or reject": "\u0627\u0637\u0644\u0628 \u062A\u0639\u062F\u064A\u0644\u0627\u062A \u0623\u0648 \u0627\u0631\u0641\u0636",
  "Decision": "\u0627\u0644\u0642\u0631\u0627\u0631",
  "Ask for changes (uses a change round)": "\u0627\u0637\u0644\u0628 \u062A\u0639\u062F\u064A\u0644\u0627\u062A (\u062A\u064F\u062D\u062A\u0633\u0628 \u062C\u0648\u0644\u0629 \u062A\u0639\u062F\u064A\u0644)",
  "Technical problem with the file (free)": "\u0645\u0634\u0643\u0644\u0629 \u0641\u0646\u064A\u0629 \u0641\u064A \u0627\u0644\u0645\u0644\u0641 (\u062F\u0648\u0646 \u0627\u062D\u062A\u0633\u0627\u0628)",
  "Reject": "\u0631\u0641\u0636",
  "Reason": "\u0627\u0644\u0633\u0628\u0628",
  "What needs to change": "\u0645\u0627 \u0627\u0644\u0630\u064A \u064A\u062C\u0628 \u062A\u0639\u062F\u064A\u0644\u0647",
  "Sent to the buyer.": "\u0623\u064F\u0631\u0633\u0644 \u0625\u0644\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u064A.",
  "Send": "\u0625\u0631\u0633\u0627\u0644",
  "The material deadline has passed without approved creative.": "\u0627\u0646\u0642\u0636\u0649 \u0645\u0648\u0639\u062F \u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0645\u0627\u062F\u0629 \u062F\u0648\u0646 \u0645\u0627\u062F\u0629 \u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0645\u0639\u062A\u0645\u062F\u0629.",
  "You will run a placeholder.": "\u0633\u062A\u0628\u062B \u0645\u0627\u062F\u0629 \u0628\u062F\u064A\u0644\u0629.",
  "Run a placeholder": "\u0628\u062B\u0651 \u0645\u0627\u062F\u0629 \u0628\u062F\u064A\u0644\u0629",
  "The booking is released to you.": "\u062D\u064F\u0631\u0651\u0631 \u0627\u0644\u062D\u062C\u0632 \u0644\u0635\u0627\u0644\u062D\u0643.",
  "Release the slot (you are paid)": "\u062D\u0631\u0651\u0631 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 (\u062A\u062D\u0635\u0644 \u0639\u0644\u0649 \u0627\u0644\u0645\u0628\u0644\u063A)",
  "Confirm the slot is scheduled and you have the final creative.": "\u0623\u0643\u0651\u062F \u0623\u0646 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0645\u062C\u062F\u0648\u0644\u0629 \u0648\u0623\u0646 \u0644\u062F\u064A\u0643 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0627\u0644\u0646\u0647\u0627\u0626\u064A\u0629.",
  "Pre-run check confirmed.": "\u062A\u0645 \u062A\u0623\u0643\u064A\u062F \u0641\u062D\u0635 \u0645\u0627 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B.",
  "You can send proof once the ad has run. You'll need: {list}.": "\u064A\u0645\u0643\u0646\u0643 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0628\u0639\u062F \u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646. \u0633\u062A\u062D\u062A\u0627\u062C \u0625\u0644\u0649: {list}.",
  "Proof sent. The buyer has the review window to approve.": "\u0623\u064F\u0631\u0633\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A. \u0623\u0645\u0627\u0645 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0645\u0647\u0644\u0629 \u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629 \u0644\u0644\u0645\u0648\u0627\u0641\u0642\u0629.",
  "Respond before the deadline ({when}), or it goes to Nashr to decide.": "\u0631\u062F\u0651 \u0642\u0628\u0644 \u0627\u0644\u0645\u0648\u0639\u062F ({when})\u060C \u0648\u0625\u0644\u0627 \u0623\u064F\u062D\u064A\u0644\u062A \u0625\u0644\u0649 \u0646\u0634\u0631 \u0644\u062A\u0642\u0631\u0631.",
  "Respond before the deadline, or it goes to Nashr to decide.": "\u0631\u062F\u0651 \u0642\u0628\u0644 \u0627\u0644\u0645\u0648\u0639\u062F\u060C \u0648\u0625\u0644\u0627 \u0623\u064F\u062D\u064A\u0644\u062A \u0625\u0644\u0649 \u0646\u0634\u0631 \u0644\u062A\u0642\u0631\u0631.",
  "Offer a fix": "\u0627\u0639\u0631\u0636 \u062D\u0644\u064B\u0627",
  "Offer": "\u0627\u0644\u0639\u0631\u0636",
  "Partial refund": "\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u062C\u0632\u0626\u064A",
  "Make-good (run it again)": "\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0628\u062B (\u0628\u062B\u0651\u0647 \u0645\u0631\u0629 \u0623\u062E\u0631\u0649)",
  "Refund to the buyer (AED, incl. VAT)": "\u0627\u0644\u0645\u0628\u0644\u063A \u0627\u0644\u0645\u0633\u062A\u0631\u062F \u0644\u0644\u0645\u0634\u062A\u0631\u064A (\u062F\u0631\u0647\u0645\u060C \u0634\u0627\u0645\u0644 \u0627\u0644\u0636\u0631\u064A\u0628\u0629)",
  "New air date and time (Dubai)": "\u062A\u0627\u0631\u064A\u062E \u0648\u0648\u0642\u062A \u0627\u0644\u0628\u062B \u0627\u0644\u062C\u062F\u064A\u062F (\u062F\u0628\u064A)",
  "Offer sent to the buyer.": "\u0623\u064F\u0631\u0633\u0644 \u0627\u0644\u0639\u0631\u0636 \u0625\u0644\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u064A.",
  "Send offer": "\u0623\u0631\u0633\u0644 \u0627\u0644\u0639\u0631\u0636",
  "Your offer is with the buyer.": "\u0639\u0631\u0636\u0643 \u0644\u062F\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u064A.",
  "Nashr's team is deciding this one.": "\u0641\u0631\u064A\u0642 \u0646\u0634\u0631 \u064A\u062F\u0631\u0633 \u0647\u0630\u0647 \u0627\u0644\u062D\u0627\u0644\u0629.",
  "Your tax invoice": "\u0641\u0627\u062A\u0648\u0631\u062A\u0643 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629",
  "You chose to issue your own invoices. Upload it for the buyer; Nashr keeps it with the booking.": "\u0627\u062E\u062A\u0631\u062A \u0625\u0635\u062F\u0627\u0631 \u0641\u0648\u0627\u062A\u064A\u0631\u0643 \u0628\u0646\u0641\u0633\u0643. \u0627\u0631\u0641\u0639\u0647\u0627 \u0644\u0644\u0645\u0634\u062A\u0631\u064A\u060C \u0648\u062A\u062D\u0641\u0638\u0647\u0627 \u0646\u0634\u0631 \u0645\u0639 \u0627\u0644\u062D\u062C\u0632.",
  "Invoice number": "\u0631\u0642\u0645 \u0627\u0644\u0641\u0627\u062A\u0648\u0631\u0629",
  "Invoice file (PDF)": "\u0645\u0644\u0641 \u0627\u0644\u0641\u0627\u062A\u0648\u0631\u0629 (PDF)",
  "Invoice sent to the buyer.": "\u0623\u064F\u0631\u0633\u0644\u062A \u0627\u0644\u0641\u0627\u062A\u0648\u0631\u0629 \u0625\u0644\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u064A.",
  "Cancel this booking": "\u0625\u0644\u063A\u0627\u0621 \u0647\u0630\u0627 \u0627\u0644\u062D\u062C\u0632",
  "Cancelling refunds the buyer in full and the card costs are deducted from your next payout.": "\u0627\u0644\u0625\u0644\u063A\u0627\u0621 \u064A\u0631\u062F\u0651 \u0644\u0644\u0645\u0634\u062A\u0631\u064A \u0627\u0644\u0645\u0628\u0644\u063A \u0643\u0627\u0645\u0644\u064B\u0627\u060C \u0648\u062A\u064F\u062E\u0635\u0645 \u0631\u0633\u0648\u0645 \u0627\u0644\u0628\u0637\u0627\u0642\u0629 \u0645\u0646 \u062A\u062D\u0648\u064A\u0644\u0643 \u0627\u0644\u0642\u0627\u062F\u0645.",
  "Booking cancelled.": "\u0623\u064F\u0644\u063A\u064A \u0627\u0644\u062D\u062C\u0632.",
  "Cancel booking": "\u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u062D\u062C\u0632",
  "Documents": "\u0627\u0644\u0645\u0633\u062A\u0646\u062F\u0627\u062A",
  "e.g. 07:16": "\u0645\u062B\u0627\u0644: 07:16",
  "Uploaded": "\u062A\u0645 \u0627\u0644\u0631\u0641\u0639",
  "Note (optional)": "\u0645\u0644\u0627\u062D\u0638\u0629 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A\u0629)",
  // Earnings
  "Money is held while a booking runs and released to you when the buyer approves proof.": "\u064A\u064F\u062D\u062A\u062C\u0632 \u0627\u0644\u0645\u0628\u0644\u063A \u0623\u062B\u0646\u0627\u0621 \u062A\u0646\u0641\u064A\u0630 \u0627\u0644\u062D\u062C\u0632 \u0648\u064A\u064F\u062D\u0631\u064E\u0651\u0631 \u0644\u0643 \u0639\u0646\u062F \u0645\u0648\u0627\u0641\u0642\u0629 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0639\u0644\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A.",
  "Released, to be paid out": "\u0645\u062D\u0631\u0651\u0631\u0629\u060C \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u062A\u062D\u0648\u064A\u0644",
  "Owed (deducted from next payout)": "\u0645\u0633\u062A\u062D\u0642\u0629 (\u062A\u064F\u062E\u0635\u0645 \u0645\u0646 \u0627\u0644\u062A\u062D\u0648\u064A\u0644 \u0627\u0644\u0642\u0627\u062F\u0645)",
  "Monthly statement": "\u0643\u0634\u0641 \u0634\u0647\u0631\u064A",
  "Download CSV": "\u062A\u0646\u0632\u064A\u0644 CSV",
  "Your VAT": "\u0636\u0631\u064A\u0628\u062A\u0643",
  "Commission": "\u0627\u0644\u0639\u0645\u0648\u0644\u0629",
  "No payouts yet. Released money is transferred to your payout account automatically.": "\u0644\u0627 \u062A\u062D\u0648\u064A\u0644\u0627\u062A \u0628\u0639\u062F. \u062A\u064F\u062D\u0648\u064E\u0651\u0644 \u0627\u0644\u0645\u0628\u0627\u0644\u063A \u0627\u0644\u0645\u062D\u0631\u0651\u0631\u0629 \u0625\u0644\u0649 \u062D\u0633\u0627\u0628\u0643 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627.",
  // Listings and a new placement
  "What you sell repeatedly. Each airing becomes slots on the calendar.": "\u0645\u0627 \u062A\u0628\u064A\u0639\u0647 \u0628\u0634\u0643\u0644 \u0645\u062A\u0643\u0631\u0631. \u0643\u0644 \u0628\u062B \u064A\u0635\u0628\u062D \u0645\u0633\u0627\u062D\u0627\u062A \u0639\u0644\u0649 \u0627\u0644\u062A\u0642\u0648\u064A\u0645.",
  "Add placement": "\u0625\u0636\u0627\u0641\u0629 \u0645\u0633\u0627\u062D\u0629 \u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Slots go on sale once your payout account is verified.": "\u062A\u064F\u0639\u0631\u0636 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0644\u0644\u0628\u064A\u0639 \u0628\u0639\u062F \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0633\u0627\u0628 \u0627\u0633\u062A\u0644\u0627\u0645 \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A.",
  "Connect it": "\u0627\u0631\u0628\u0637\u0647",
  "No placements yet.": "\u0644\u0627 \u0645\u0633\u0627\u062D\u0627\u062A \u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0628\u0639\u062F.",
  "Listed until": "\u0645\u0639\u0631\u0648\u0636\u0629 \u062D\u062A\u0649",
  "reserve {price}": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u062F\u0646\u0649 {price}",
  "{n} new slots listed from {from}.": "\u0639\u064F\u0631\u0636\u062A {n} \u0645\u0633\u0627\u062D\u0627\u062A \u062C\u062F\u064A\u062F\u0629 \u0627\u0628\u062A\u062F\u0627\u0621\u064B \u0645\u0646 {from}.",
  "List 4 more weeks": "\u0627\u0639\u0631\u0636 4 \u0623\u0633\u0627\u0628\u064A\u0639 \u0625\u0636\u0627\u0641\u064A\u0629",
  "Restored.": "\u0627\u0633\u062A\u064F\u0639\u064A\u062F\u062A.",
  "Archived. Slots already on sale stay on sale.": "\u0623\u064F\u0631\u0634\u0641\u062A. \u062A\u0628\u0642\u0649 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u0645\u0639\u0631\u0648\u0636\u0629 \u062D\u0627\u0644\u064A\u064B\u0627 \u0645\u0639\u0631\u0648\u0636\u0629.",
  "Restore": "\u0627\u0633\u062A\u0639\u0627\u062F\u0629",
  "Archive": "\u0623\u0631\u0634\u0641\u0629",
  "Placement saved": "\u062D\u064F\u0641\u0638\u062A \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Check the times if that's not intended.": "\u0631\u0627\u062C\u0639 \u0627\u0644\u0623\u0648\u0642\u0627\u062A \u0625\u0646 \u0644\u0645 \u064A\u0643\u0646 \u0630\u0644\u0643 \u0645\u0642\u0635\u0648\u062F\u064B\u0627.",
  "Go to listings": "\u0627\u0644\u0630\u0647\u0627\u0628 \u0625\u0644\u0649 \u0627\u0644\u0639\u0631\u0648\u0636",
  "Add your outlet first.": "\u0623\u0636\u0641 \u0645\u0646\u0635\u062A\u0643 \u0623\u0648\u0644\u064B\u0627.",
  "Outlet profile": "\u0645\u0644\u0641 \u0627\u0644\u0645\u0646\u0635\u0629",
  "Full page": "\u0635\u0641\u062D\u0629 \u0643\u0627\u0645\u0644\u0629",
  "Morning show": "\u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C \u0627\u0644\u0635\u0628\u0627\u062D\u064A",
  "Auction (buyers bid; you accept the winner)": "\u0645\u0632\u0627\u062F (\u064A\u0632\u0627\u064A\u062F \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0648\u062A\u0642\u0628\u0644 \u0627\u0644\u0641\u0627\u0626\u0632)",
  "Quick sale (fixed price; you pick a buyer)": "\u0628\u064A\u0639 \u0633\u0631\u064A\u0639 (\u0633\u0639\u0631 \u062B\u0627\u0628\u062A \u0648\u062A\u062E\u062A\u0627\u0631 \u0627\u0644\u0645\u0634\u062A\u0631\u064A)",
  "Days": "\u0627\u0644\u0623\u064A\u0627\u0645",
  "Starts (Dubai time, empty for all day; overnight like 23:00\u201302:00 works)": "\u0627\u0644\u0628\u062F\u0627\u064A\u0629 (\u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A\u060C \u0627\u062A\u0631\u0643\u0647 \u0641\u0627\u0631\u063A\u064B\u0627 \u0644\u0637\u0648\u0627\u0644 \u0627\u0644\u064A\u0648\u0645\u061B \u064A\u0645\u0643\u0646 \u062A\u062C\u0627\u0648\u0632 \u0645\u0646\u062A\u0635\u0641 \u0627\u0644\u0644\u064A\u0644 \u0645\u062B\u0644 \u206623:00\u201302:00\u2069)",
  "Ends": "\u0627\u0644\u0646\u0647\u0627\u064A\u0629",
  "Positions (each one is sold on its own; leave empty to sell the whole slot)": "\u0627\u0644\u0645\u0648\u0627\u0636\u0639 (\u064A\u064F\u0628\u0627\u0639 \u0643\u0644 \u0645\u0646\u0647\u0627 \u0645\u0646\u0641\u0631\u062F\u064B\u0627\u061B \u0627\u062A\u0631\u0643\u0647\u0627 \u0641\u0627\u0631\u063A\u0629 \u0644\u0628\u064A\u0639 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0643\u0627\u0645\u0644\u0629)",
  "Breaks (each one is sold on its own; leave empty to sell the whole slot)": "\u0627\u0644\u0641\u0648\u0627\u0635\u0644 (\u064A\u064F\u0628\u0627\u0639 \u0643\u0644 \u0645\u0646\u0647\u0627 \u0645\u0646\u0641\u0631\u062F\u064B\u0627\u061B \u0627\u062A\u0631\u0643\u0647\u0627 \u0641\u0627\u0631\u063A\u0629 \u0644\u0628\u064A\u0639 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0643\u0627\u0645\u0644\u0629)",
  "Label": "\u0627\u0644\u0627\u0633\u0645",
  "Time": "\u0627\u0644\u0648\u0642\u062A",
  "Seconds": "\u0627\u0644\u062B\u0648\u0627\u0646\u064A",
  "break": "\u0641\u0627\u0635\u0644",
  "Add position": "\u0623\u0636\u0641 \u0645\u0648\u0636\u0639\u064B\u0627",
  "Add break": "\u0623\u0636\u0641 \u0641\u0627\u0635\u0644\u064B\u0627",
  "Prices (AED, excl. VAT)": "\u0627\u0644\u0623\u0633\u0639\u0627\u0631 (\u062F\u0631\u0647\u0645\u060C \u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629)",
  "Starting price per break": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0627\u0628\u062A\u062F\u0627\u0626\u064A \u0644\u0643\u0644 \u0641\u0627\u0635\u0644",
  "Price per break": "\u0627\u0644\u0633\u0639\u0631 \u0644\u0643\u0644 \u0641\u0627\u0635\u0644",
  "\u201CAny break\u201D price (optional)": "\u0633\u0639\u0631 \u201C\u0623\u064A \u0641\u0627\u0635\u0644\u201D (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "All {n} breaks, package (optional)": "\u0628\u0627\u0642\u0629 \u0627\u0644\u0641\u0648\u0627\u0635\u0644 \u0627\u0644\u0640{n} \u0643\u0644\u0647\u0627 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Buy-now price (optional)": "\u0633\u0639\u0631 \u0627\u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0641\u0648\u0631\u064A (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Reserve (optional, hidden from buyers)": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u062F\u0646\u0649 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A\u060C \u0645\u062E\u0641\u064A \u0639\u0646 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646)",
  "Deadlines": "\u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F \u0627\u0644\u0646\u0647\u0627\u0626\u064A\u0629",
  "Creative due (hours before air)": "\u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 (\u0633\u0627\u0639\u0627\u062A \u0642\u0628\u0644 \u0627\u0644\u0628\u062B)",
  "Bidding closes (days before air)": "\u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 (\u0623\u064A\u0627\u0645 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B)",
  "Bidding must close early enough for you to decide (24h), the buyer to pay (48h) and the creative to arrive.": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u064F\u063A\u0644\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0645\u0628\u0643\u0631\u064B\u0627 \u0628\u0645\u0627 \u064A\u0643\u0641\u064A \u0644\u062A\u0642\u0631\u0631 (24 \u0633\u0627\u0639\u0629) \u0648\u064A\u062F\u0641\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A (48 \u0633\u0627\u0639\u0629) \u0648\u062A\u0635\u0644 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "List on the calendar for (days from today)": "\u0627\u0644\u0639\u0631\u0636 \u0639\u0644\u0649 \u0627\u0644\u062A\u0642\u0648\u064A\u0645 \u0644\u0645\u062F\u0629 (\u0623\u064A\u0627\u0645 \u0645\u0646 \u0627\u0644\u064A\u0648\u0645)",
  "Save placement": "\u062D\u0641\u0638 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  // Profile and cover photo
  "Your payout account, tax details and outlet as buyers see it.": "\u062D\u0633\u0627\u0628 \u0627\u0633\u062A\u0644\u0627\u0645 \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A \u0648\u0628\u064A\u0627\u0646\u0627\u062A\u0643 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629 \u0648\u0645\u0646\u0635\u062A\u0643 \u0643\u0645\u0627 \u064A\u0631\u0627\u0647\u0627 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646.",
  "Payout account": "\u062D\u0633\u0627\u0628 \u0627\u0633\u062A\u0644\u0627\u0645 \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A",
  "\u25CF Verified. Released money is transferred to it automatically.": "\u25CF \u062A\u0645 \u0627\u0644\u062A\u062D\u0642\u0642. \u062A\u064F\u062D\u0648\u064E\u0651\u0644 \u0625\u0644\u064A\u0647 \u0627\u0644\u0645\u0628\u0627\u0644\u063A \u0627\u0644\u0645\u062D\u0631\u0651\u0631\u0629 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627.",
  "Connect the bank account Nashr pays you into. Verification is done by the payment provider; Nashr never sees your bank login.": "\u0627\u0631\u0628\u0637 \u0627\u0644\u062D\u0633\u0627\u0628 \u0627\u0644\u0628\u0646\u0643\u064A \u0627\u0644\u0630\u064A \u062A\u062D\u0648\u0651\u0644 \u0625\u0644\u064A\u0647 \u0646\u0634\u0631 \u0645\u0633\u062A\u062D\u0642\u0627\u062A\u0643. \u064A\u062A\u0648\u0644\u0649 \u0645\u0632\u0648\u0651\u062F \u0627\u0644\u062F\u0641\u0639 \u0627\u0644\u062A\u062D\u0642\u0642\u060C \u0648\u0644\u0627 \u062A\u0631\u0649 \u0646\u0634\u0631 \u0628\u064A\u0627\u0646\u0627\u062A \u062F\u062E\u0648\u0644\u0643 \u0627\u0644\u0645\u0635\u0631\u0641\u064A\u0629 \u0623\u0628\u062F\u064B\u0627.",
  "Payout account verified.": "\u062A\u0645 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0633\u0627\u0628 \u0627\u0633\u062A\u0644\u0627\u0645 \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A.",
  "Connect payout account": "\u0631\u0628\u0637 \u062D\u0633\u0627\u0628 \u0627\u0633\u062A\u0644\u0627\u0645 \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A",
  "Tax and invoices": "\u0627\u0644\u0636\u0631\u064A\u0628\u0629 \u0648\u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631",
  " We are VAT-registered (5% VAT is added for buyers)": " \u0646\u062D\u0646 \u0645\u0633\u062C\u0644\u0648\u0646 \u0641\u064A \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629 (\u062A\u064F\u0636\u0627\u0641 5% \u0644\u0644\u0645\u0634\u062A\u0631\u064A\u0646)",
  "TRN (15 digits)": "\u0627\u0644\u0631\u0642\u0645 \u0627\u0644\u0636\u0631\u064A\u0628\u064A (15 \u0631\u0642\u0645\u064B\u0627)",
  "Tax invoices to buyers": "\u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629 \u0644\u0644\u0645\u0634\u062A\u0631\u064A\u0646",
  "Nashr issues them in our name and TRN": "\u062A\u0635\u062F\u0631\u0647\u0627 \u0646\u0634\u0631 \u0628\u0627\u0633\u0645\u0646\u0627 \u0648\u0631\u0642\u0645\u0646\u0627 \u0627\u0644\u0636\u0631\u064A\u0628\u064A",
  "We upload our own": "\u0646\u0631\u0641\u0639 \u0641\u0648\u0627\u062A\u064A\u0631\u0646\u0627 \u0628\u0623\u0646\u0641\u0633\u0646\u0627",
  "Tax details saved.": "\u062D\u064F\u0641\u0638\u062A \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629.",
  "{name} saved.": "\u062D\u064F\u0641\u0638\u062A {name}.",
  "Outlet added.": "\u0623\u064F\u0636\u064A\u0641\u062A \u0627\u0644\u0645\u0646\u0635\u0629.",
  "Add another outlet": "\u0623\u0636\u0641 \u0645\u0646\u0635\u0629 \u0623\u062E\u0631\u0649",
  "New outlet": "\u0645\u0646\u0635\u0629 \u062C\u062F\u064A\u062F\u0629",
  "Name in Arabic": "\u0627\u0644\u0627\u0633\u0645 \u0628\u0627\u0644\u0639\u0631\u0628\u064A\u0629",
  "Sectors you accept (comma-separated; add your own)": "\u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u0642\u0628\u0644\u0647\u0627 (\u0627\u0641\u0635\u0644 \u0628\u064A\u0646\u0647\u0627 \u0628\u0641\u0648\u0627\u0635\u0644\u061B \u0623\u0636\u0641 \u0645\u0627 \u062A\u0634\u0627\u0621)",
  "Banking, Retail, Real estate": "Banking, Retail, Real estate",
  "Audience": "\u0627\u0644\u062C\u0645\u0647\u0648\u0631",
  "Business commuters, 25-45": "\u0645\u0648\u0638\u0641\u0648\u0646 \u0641\u064A \u0637\u0631\u064A\u0642\u0647\u0645 \u0625\u0644\u0649 \u0627\u0644\u0639\u0645\u0644\u060C 25-45",
  "Buyers see this in the directory. Emails and phone numbers are not allowed.": "\u064A\u0631\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0647\u0630\u0627 \u0641\u064A \u0627\u0644\u062F\u0644\u064A\u0644. \u0644\u0627 \u064A\u064F\u0633\u0645\u062D \u0628\u0639\u0646\u0627\u0648\u064A\u0646 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0648 \u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0647\u0648\u0627\u062A\u0641.",
  "Use a JPEG or PNG photo.": "\u0627\u0633\u062A\u062E\u062F\u0645 \u0635\u0648\u0631\u0629 JPEG \u0623\u0648 PNG.",
  "This photo is {w} pixels wide. Use one at least {min} pixels wide so it stays sharp.": "\u0639\u0631\u0636 \u0647\u0630\u0647 \u0627\u0644\u0635\u0648\u0631\u0629 {w} \u0628\u0643\u0633\u0644. \u0627\u0633\u062A\u062E\u062F\u0645 \u0635\u0648\u0631\u0629 \u0628\u0639\u0631\u0636 {min} \u0628\u0643\u0633\u0644 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644 \u0644\u062A\u0628\u0642\u0649 \u0648\u0627\u0636\u062D\u0629.",
  "The photo could not be uploaded.": "\u062A\u0639\u0630\u0651\u0631 \u0631\u0641\u0639 \u0627\u0644\u0635\u0648\u0631\u0629.",
  "Cover photo saved. Buyers see it now.": "\u062D\u064F\u0641\u0638\u062A \u0635\u0648\u0631\u0629 \u0627\u0644\u063A\u0644\u0627\u0641. \u064A\u0631\u0627\u0647\u0627 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0627\u0644\u0622\u0646.",
  "This photo could not be read. Try another JPEG or PNG.": "\u062A\u0639\u0630\u0651\u0631\u062A \u0642\u0631\u0627\u0621\u0629 \u0647\u0630\u0647 \u0627\u0644\u0635\u0648\u0631\u0629. \u062C\u0631\u0651\u0628 \u0635\u0648\u0631\u0629 JPEG \u0623\u0648 PNG \u0623\u062E\u0631\u0649.",
  "The photo could not be removed.": "\u062A\u0639\u0630\u0651\u0631\u062A \u0625\u0632\u0627\u0644\u0629 \u0627\u0644\u0635\u0648\u0631\u0629.",
  "Cover photo removed. The {channel} photo shows instead.": "\u0623\u064F\u0632\u064A\u0644\u062A \u0635\u0648\u0631\u0629 \u0627\u0644\u063A\u0644\u0627\u0641. \u062A\u0638\u0647\u0631 \u0635\u0648\u0631\u0629 {channel} \u0628\u062F\u0644\u064B\u0627 \u0645\u0646\u0647\u0627.",
  "Default {channel} photo": "\u0635\u0648\u0631\u0629 {channel} \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A\u0629",
  "Saving\u2026": "\u062C\u0627\u0631\u064D \u0627\u0644\u062D\u0641\u0638\u2026",
  "Replace cover photo": "\u0627\u0633\u062A\u0628\u062F\u0627\u0644 \u0635\u0648\u0631\u0629 \u0627\u0644\u063A\u0644\u0627\u0641",
  "Upload a cover photo": "\u0631\u0641\u0639 \u0635\u0648\u0631\u0629 \u063A\u0644\u0627\u0641",
  "A wide photo of the outlet's studio, team or publication, at least {min} pixels wide. It is cropped to a 16:5 strip.": "\u0635\u0648\u0631\u0629 \u0639\u0631\u064A\u0636\u0629 \u0644\u0627\u0633\u062A\u0648\u062F\u064A\u0648 \u0627\u0644\u0645\u0646\u0635\u0629 \u0623\u0648 \u0641\u0631\u064A\u0642\u0647\u0627 \u0623\u0648 \u0645\u0637\u0628\u0648\u0639\u062A\u0647\u0627\u060C \u0628\u0639\u0631\u0636 {min} \u0628\u0643\u0633\u0644 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644. \u062A\u064F\u0642\u0635\u0651 \u0625\u0644\u0649 \u0634\u0631\u064A\u0637 \u0628\u0646\u0633\u0628\u0629 16:5.",
  // Calendar (publisher)
  "Your slots by week, with bids, bookings and what is still on sale. Dubai time.": "\u0645\u0633\u0627\u062D\u0627\u062A\u0643 \u0623\u0633\u0628\u0648\u0639\u064A\u064B\u0627\u060C \u0645\u0639 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0627\u062A \u0648\u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0648\u0645\u0627 \u0632\u0627\u0644 \u0645\u0639\u0631\u0648\u0636\u064B\u0627. \u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A.",
  "Previous week": "\u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u0627\u0644\u0633\u0627\u0628\u0642",
  "Next week": "\u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u0627\u0644\u062A\u0627\u0644\u064A",
  "Nothing listed this week.": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u0639\u0631\u0648\u0636 \u0647\u0630\u0627 \u0627\u0644\u0623\u0633\u0628\u0648\u0639.",
  "List slots": "\u0627\u0639\u0631\u0636 \u0645\u0633\u0627\u062D\u0627\u062A",
  "bidding closes {when}": "\u062A\u064F\u063A\u0644\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 {when}",
  "The winner did not go ahead. Choose another bid by {when}, or let it relist as a quick sale.": "\u0644\u0645 \u064A\u064F\u0643\u0645\u0644 \u0627\u0644\u0641\u0627\u0626\u0632. \u0627\u062E\u062A\u0631 \u0645\u0632\u0627\u064A\u062F\u0629 \u0623\u062E\u0631\u0649 \u0642\u0628\u0644 {when}\u060C \u0623\u0648 \u062F\u0639\u0647\u0627 \u062A\u064F\u0639\u0631\u0636 \u0645\u0646 \u062C\u062F\u064A\u062F \u0628\u064A\u0639\u064B\u0627 \u0633\u0631\u064A\u0639\u064B\u0627.",
  "The winner did not go ahead. Choose another bid, or let it relist as a quick sale.": "\u0644\u0645 \u064A\u064F\u0643\u0645\u0644 \u0627\u0644\u0641\u0627\u0626\u0632. \u0627\u062E\u062A\u0631 \u0645\u0632\u0627\u064A\u062F\u0629 \u0623\u062E\u0631\u0649\u060C \u0623\u0648 \u062F\u0639\u0647\u0627 \u062A\u064F\u0639\u0631\u0636 \u0645\u0646 \u062C\u062F\u064A\u062F \u0628\u064A\u0639\u064B\u0627 \u0633\u0631\u064A\u0639\u064B\u0627.",
  "Reserve (buyers don't see it)": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u062F\u0646\u0649 (\u0644\u0627 \u064A\u0631\u0627\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646)",
  "Creative due": "\u0645\u0648\u0639\u062F \u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0645\u0627\u062F\u0629",
  "Bids and requests": "\u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0627\u062A \u0648\u0627\u0644\u0637\u0644\u0628\u0627\u062A",
  "None yet.": "\u0644\u0627 \u0634\u064A\u0621 \u0628\u0639\u062F.",
  "Choose": "\u0627\u062E\u062A\u064A\u0627\u0631",
  "Take off sale": "\u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u0628\u064A\u0639",
  "Put back on sale": "\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0639\u0631\u0636 \u0644\u0644\u0628\u064A\u0639",
  "What you are accepting": "\u0645\u0627 \u0627\u0644\u0630\u064A \u062A\u0648\u0627\u0641\u0642 \u0639\u0644\u064A\u0647",
  "The creative": "\u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "No creative was attached to this bid (sent before creatives were required).": "\u0644\u0645 \u062A\u064F\u0631\u0641\u0642 \u0645\u0627\u062F\u0629 \u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0628\u0647\u0630\u0627 \u0627\u0644\u0639\u0631\u0636 (\u0623\u064F\u0631\u0633\u0644 \u0642\u0628\u0644 \u0623\u0646 \u062A\u0635\u0628\u062D \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0645\u0637\u0644\u0648\u0628\u0629).",
  "No creative attached": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0627\u062F\u0629 \u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0645\u0631\u0641\u0642\u0629"
};

// web/src/i18n-ar-admin.ts
var AR_ADMIN = {
  // Overview
  "Access requests to review": "\u0637\u0644\u0628\u0627\u062A \u0627\u0646\u0636\u0645\u0627\u0645 \u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629",
  "Disputes to decide": "\u0646\u0632\u0627\u0639\u0627\u062A \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0642\u0631\u0627\u0631",
  "Issues waiting on publishers": "\u0645\u0634\u0643\u0644\u0627\u062A \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646",
  "Failed payouts or refunds": "\u062A\u062D\u0648\u064A\u0644\u0627\u062A \u0623\u0648 \u0645\u0628\u0627\u0644\u063A \u0645\u0633\u062A\u0631\u062F\u0629 \u0641\u0634\u0644\u062A",
  "Quote requests": "\u0637\u0644\u0628\u0627\u062A \u0639\u0631\u0648\u0636 \u0627\u0644\u0623\u0633\u0639\u0627\u0631",
  "Ledger reconciles with the payment provider.": "\u0627\u0644\u062F\u0641\u062A\u0631 \u0645\u0637\u0627\u0628\u0642 \u0644\u0631\u0635\u064A\u062F \u0645\u0632\u0648\u0651\u062F \u0627\u0644\u062F\u0641\u0639.",
  "Ledger cash {ledger} does not match the payment provider ({provider}).": "\u0627\u0644\u0646\u0642\u062F \u0641\u064A \u0627\u0644\u062F\u0641\u062A\u0631 {ledger} \u0644\u0627 \u064A\u0637\u0627\u0628\u0642 \u0631\u0635\u064A\u062F \u0645\u0632\u0648\u0651\u062F \u0627\u0644\u062F\u0641\u0639 ({provider}).",
  "Open Funds": "\u0627\u0641\u062A\u062D \u0627\u0644\u0623\u0645\u0648\u0627\u0644",
  "All deals": "\u0643\u0644 \u0627\u0644\u0635\u0641\u0642\u0627\u062A",
  "Booked value, last 30 days": "\u0642\u064A\u0645\u0629 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A\u060C \u0622\u062E\u0631 30 \u064A\u0648\u0645\u064B\u0627",
  "Price of bookings paid, excluding VAT.": "\u0633\u0639\u0631 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0629\u060C \u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629.",
  "Commission earned (30 days)": "\u0627\u0644\u0639\u0645\u0648\u0644\u0629 \u0627\u0644\u0645\u0643\u062A\u0633\u0628\u0629 (30 \u064A\u0648\u0645\u064B\u0627)",
  "Take rate (90 days)": "\u0646\u0633\u0628\u0629 \u0627\u0644\u0639\u0645\u0648\u0644\u0629 \u0627\u0644\u0641\u0639\u0644\u064A\u0629 (90 \u064A\u0648\u0645\u064B\u0627)",
  "Publishers live": "\u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0627\u0644\u0646\u0634\u0637\u0648\u0646",
  "Buyer companies": "\u0634\u0631\u0643\u0627\u062A \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646",
  "Booked value by week (excluding VAT)": "\u0642\u064A\u0645\u0629 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0623\u0633\u0628\u0648\u0639\u064A\u064B\u0627 (\u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629)",
  "Booked value": "\u0642\u064A\u0645\u0629 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A",
  "Commission, last 30 days": "\u0627\u0644\u0639\u0645\u0648\u0644\u0629\u060C \u0622\u062E\u0631 30 \u064A\u0648\u0645\u064B\u0627",
  "Held for bookings": "\u0645\u062D\u062A\u062C\u0632\u0629 \u0644\u0644\u062D\u062C\u0648\u0632\u0627\u062A",
  "Paid by buyers, not yet released": "\u062F\u0641\u0639\u0647\u0627 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0648\u0644\u0645 \u062A\u064F\u062D\u0631\u064E\u0651\u0631 \u0628\u0639\u062F",
  "Open slots with bids": "\u0645\u0633\u0627\u062D\u0627\u062A \u0645\u0639\u0631\u0648\u0636\u0629 \u0639\u0644\u064A\u0647\u0627 \u0645\u0632\u0627\u064A\u062F\u0627\u062A",
  "{n} of {total}": "{n} \u0645\u0646 {total}",
  "{n} bids this week": "{n} \u0645\u0632\u0627\u064A\u062F\u0627\u062A \u0647\u0630\u0627 \u0627\u0644\u0623\u0633\u0628\u0648\u0639",
  "Active buyers": "\u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0627\u0644\u0646\u0634\u0637\u0648\u0646",
  "bid in the last 30 days": "\u0632\u0627\u064A\u062F\u0648\u0627 \u0641\u064A \u0622\u062E\u0631 30 \u064A\u0648\u0645\u064B\u0627",
  "Requested or won": "\u0637\u064F\u0644\u0628\u062A \u0623\u0648 \u0631\u0633\u062A",
  "Accepted by publisher": "\u0642\u0628\u0644\u0647\u0627 \u0627\u0644\u0646\u0627\u0634\u0631",
  "Needs attention": "\u064A\u062D\u062A\u0627\u062C \u0625\u0644\u0649 \u0645\u062A\u0627\u0628\u0639\u0629",
  "Bookings opened in the last 30 days": "\u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u0645\u0641\u062A\u0648\u062D\u0629 \u0641\u064A \u0622\u062E\u0631 30 \u064A\u0648\u0645\u064B\u0627",
  "Money position": "\u0627\u0644\u0648\u0636\u0639 \u0627\u0644\u0645\u0627\u0644\u064A",
  "Owed to publishers": "\u0645\u0633\u062A\u062D\u0642\u0629 \u0644\u0644\u0646\u0627\u0634\u0631\u064A\u0646",
  "VAT on commission": "\u0627\u0644\u0636\u0631\u064A\u0628\u0629 \u0639\u0644\u0649 \u0627\u0644\u0639\u0645\u0648\u0644\u0629",
  "Card processing fees": "\u0631\u0633\u0648\u0645 \u0645\u0639\u0627\u0644\u062C\u0629 \u0627\u0644\u0628\u0637\u0627\u0642\u0627\u062A",
  "Commission earned (all time)": "\u0627\u0644\u0639\u0645\u0648\u0644\u0629 \u0627\u0644\u0645\u0643\u062A\u0633\u0628\u0629 (\u0645\u0646\u0630 \u0627\u0644\u0628\u062F\u0627\u064A\u0629)",
  "Booked value by channel (90 days)": "\u0642\u064A\u0645\u0629 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u062D\u0633\u0628 \u0627\u0644\u0642\u0646\u0627\u0629 (90 \u064A\u0648\u0645\u064B\u0627)",
  "Top publishers (90 days)": "\u0623\u0628\u0631\u0632 \u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646 (90 \u064A\u0648\u0645\u064B\u0627)",
  "Top buyers (90 days)": "\u0623\u0628\u0631\u0632 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646 (90 \u064A\u0648\u0645\u064B\u0627)",
  "All deals by status": "\u0643\u0644 \u0627\u0644\u0635\u0641\u0642\u0627\u062A \u062D\u0633\u0628 \u0627\u0644\u062D\u0627\u0644\u0629",
  "No deals yet.": "\u0644\u0627 \u0635\u0641\u0642\u0627\u062A \u0628\u0639\u062F.",
  // Access requests
  "Access requests": "\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645",
  "Nashr is invite-only. Approving creates the company and an invite link (valid 7 days).": "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0646\u0634\u0631 \u0628\u0627\u0644\u062F\u0639\u0648\u0629 \u0641\u0642\u0637. \u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 \u062A\u0646\u0634\u0626 \u0627\u0644\u0634\u0631\u0643\u0629 \u0648\u0631\u0627\u0628\u0637 \u062F\u0639\u0648\u0629 (\u0635\u0627\u0644\u062D 7 \u0623\u064A\u0627\u0645).",
  "No requests.": "\u0644\u0627 \u0637\u0644\u0628\u0627\u062A.",
  "Person": "\u0627\u0644\u0634\u062E\u0635",
  "Received": "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0627\u0633\u062A\u0644\u0627\u0645",
  "Invite link (send it to {email}):": "\u0631\u0627\u0628\u0637 \u0627\u0644\u062F\u0639\u0648\u0629 (\u0623\u0631\u0633\u0644\u0647 \u0625\u0644\u0649 {email}):",
  "{name} approved.": "\u062A\u0645\u062A \u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 \u0639\u0644\u0649 {name}.",
  "Reason for {name}": "\u0627\u0644\u0633\u0628\u0628 \u0644\u0640{name}",
  "Reason (for reject or more info)": "\u0627\u0644\u0633\u0628\u0628 (\u0644\u0644\u0631\u0641\u0636 \u0623\u0648 \u0644\u0637\u0644\u0628 \u0645\u0639\u0644\u0648\u0645\u0627\u062A)",
  "Asked for more information.": "\u0637\u064F\u0644\u0628\u062A \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0625\u0636\u0627\u0641\u064A\u0629.",
  "Ask for info": "\u0627\u0637\u0644\u0628 \u0645\u0639\u0644\u0648\u0645\u0627\u062A",
  "Rejected.": "\u0631\u064F\u0641\u0636 \u0627\u0644\u0637\u0644\u0628.",
  "More information asked": "\u0637\u064F\u0644\u0628\u062A \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0625\u0636\u0627\u0641\u064A\u0629",
  "Brand": "\u0639\u0644\u0627\u0645\u0629 \u062A\u062C\u0627\u0631\u064A\u0629",
  "Agency": "\u0648\u0643\u0627\u0644\u0629",
  "Media outlet": "\u0645\u0646\u0635\u0629 \u0625\u0639\u0644\u0627\u0645\u064A\u0629",
  // Accounts
  "Every buyer and publisher company on Nashr, with their people, outlets and bookings.": "\u0643\u0644 \u0634\u0631\u0643\u0627\u062A \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u0648\u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646 \u0639\u0644\u0649 \u0646\u0634\u0631\u060C \u0645\u0639 \u0623\u0641\u0631\u0627\u062F\u0647\u0627 \u0648\u0645\u0646\u0635\u0627\u062A\u0647\u0627 \u0648\u062D\u062C\u0648\u0632\u0627\u062A\u0647\u0627.",
  "Search companies": "\u0627\u0628\u062D\u062B \u0641\u064A \u0627\u0644\u0634\u0631\u0643\u0627\u062A",
  "Type": "\u0627\u0644\u0646\u0648\u0639",
  "Buyers": "\u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646",
  "Publishers": "\u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646",
  "Users": "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u0648\u0646",
  "VAT": "\u0627\u0644\u0636\u0631\u064A\u0628\u0629",
  "Joined": "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645",
  "{n} suspended": "{n} \u0645\u0648\u0642\u0648\u0641",
  "Verified": "\u062A\u0645 \u0627\u0644\u062A\u062D\u0642\u0642",
  "Not verified": "\u0644\u0645 \u064A\u064F\u062A\u062D\u0642\u0642",
  "Registered": "\u0645\u0633\u062C\u0651\u0644",
  "no TRN": "\u062F\u0648\u0646 \u0631\u0642\u0645 \u0636\u0631\u064A\u0628\u064A",
  "Not registered": "\u063A\u064A\u0631 \u0645\u0633\u062C\u0651\u0644",
  "{pct} (own)": "{pct} (\u062E\u0627\u0635\u0629)",
  "Default": "\u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A\u0629",
  "joined {date}": "\u0627\u0646\u0636\u0645 \u0641\u064A {date}",
  "View as this account (read only)": "\u0627\u0644\u0639\u0631\u0636 \u0628\u0635\u0641\u0629 \u0647\u0630\u0627 \u0627\u0644\u062D\u0633\u0627\u0628 (\u0644\u0644\u0642\u0631\u0627\u0621\u0629 \u0641\u0642\u0637)",
  "TRN {trn}": "\u0627\u0644\u0631\u0642\u0645 \u0627\u0644\u0636\u0631\u064A\u0628\u064A {trn}",
  "missing": "\u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F",
  "Tax invoices": "\u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629",
  "Nashr issues them on their behalf": "\u062A\u0635\u062F\u0631\u0647\u0627 \u0646\u0634\u0631 \u0646\u064A\u0627\u0628\u0629 \u0639\u0646\u0647\u0645",
  "They upload their own": "\u064A\u0631\u0641\u0639\u0648\u0646 \u0641\u0648\u0627\u062A\u064A\u0631\u0647\u0645 \u0628\u0623\u0646\u0641\u0633\u0647\u0645",
  "Released, not yet paid out": "\u0645\u062D\u0631\u0651\u0631\u0629\u060C \u0644\u0645 \u062A\u064F\u062D\u0648\u064E\u0651\u0644 \u0628\u0639\u062F",
  "Owed to Nashr": "\u0645\u0633\u062A\u062D\u0642\u0629 \u0644\u0646\u0634\u0631",
  "{pct} (own rate)": "{pct} (\u0646\u0633\u0628\u0629 \u062E\u0627\u0635\u0629)",
  "Default rate": "\u0627\u0644\u0646\u0633\u0628\u0629 \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A\u0629",
  "{pct} from {date}": "{pct} \u0627\u0628\u062A\u062F\u0627\u0621\u064B \u0645\u0646 {date}",
  "Commission %": "\u0646\u0633\u0628\u0629 \u0627\u0644\u0639\u0645\u0648\u0644\u0629 %",
  "e.g. 10": "\u0645\u062B\u0627\u0644: 10",
  "Commission saved. It applies to deals accepted from now on.": "\u062D\u064F\u0641\u0638\u062A \u0627\u0644\u0639\u0645\u0648\u0644\u0629. \u062A\u064F\u0637\u0628\u064E\u0651\u0642 \u0639\u0644\u0649 \u0627\u0644\u0635\u0641\u0642\u0627\u062A \u0627\u0644\u0645\u0642\u0628\u0648\u0644\u0629 \u0645\u0646 \u0627\u0644\u0622\u0646.",
  "Set founding commission": "\u062D\u062F\u0651\u062F \u0639\u0645\u0648\u0644\u0629 \u0627\u0644\u062A\u0623\u0633\u064A\u0633",
  "Founder only. Deals already accepted keep their rate.": "\u0644\u0644\u0645\u0624\u0633\u0633 \u0641\u0642\u0637. \u062A\u062D\u062A\u0641\u0638 \u0627\u0644\u0635\u0641\u0642\u0627\u062A \u0627\u0644\u0645\u0642\u0628\u0648\u0644\u0629 \u0628\u0646\u0633\u0628\u062A\u0647\u0627.",
  "Suspend {name}? They are signed out at once.": "\u0625\u064A\u0642\u0627\u0641 {name}\u061F \u0633\u064A\u064F\u0633\u062C\u064E\u0651\u0644 \u062E\u0631\u0648\u062C\u0647 \u0641\u0648\u0631\u064B\u0627.",
  "{name} suspended.": "\u0623\u064F\u0648\u0642\u0641 {name}.",
  "Suspend": "\u0625\u064A\u0642\u0627\u0641",
  "{name} restored.": "\u0623\u064F\u0639\u064A\u062F \u062A\u0641\u0639\u064A\u0644 {name}.",
  "Outlets": "\u0627\u0644\u0645\u0646\u0635\u0627\u062A",
  "Recent deals": "\u0623\u062D\u062F\u062B \u0627\u0644\u0635\u0641\u0642\u0627\u062A",
  "admin": "\u0645\u0634\u0631\u0641",
  "founder": "\u0645\u0624\u0633\u0633",
  "buyer": "\u0645\u0634\u062A\u0631\u064D",
  "seller": "\u0646\u0627\u0634\u0631",
  "suspended": "\u0645\u0648\u0642\u0648\u0641",
  "invited": "\u0645\u062F\u0639\u0648",
  "tv": "\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646",
  // Deals and a deal
  "Every booking on the platform, from request to release.": "\u0643\u0644 \u062D\u062C\u0632 \u0639\u0644\u0649 \u0627\u0644\u0645\u0646\u0635\u0629\u060C \u0645\u0646 \u0627\u0644\u0637\u0644\u0628 \u062D\u062A\u0649 \u0627\u0644\u062A\u062D\u0631\u064A\u0631.",
  "Order number, buyer or publisher": "\u0631\u0642\u0645 \u0627\u0644\u0637\u0644\u0628 \u0623\u0648 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0623\u0648 \u0627\u0644\u0646\u0627\u0634\u0631",
  "All statuses": "\u0643\u0644 \u0627\u0644\u062D\u0627\u0644\u0627\u062A",
  "No deals match.": "\u0644\u0627 \u0635\u0641\u0642\u0627\u062A \u0645\u0637\u0627\u0628\u0642\u0629.",
  "Next deadline": "\u0627\u0644\u0645\u0648\u0639\u062F \u0627\u0644\u062A\u0627\u0644\u064A",
  "Release to the publisher": "\u0627\u0644\u062A\u062D\u0631\u064A\u0631 \u0644\u0644\u0646\u0627\u0634\u0631",
  "Refund the buyer in full": "\u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0627\u0644\u0643\u0627\u0645\u0644 \u0644\u0644\u0645\u0634\u062A\u0631\u064A",
  "Creative and proof": "\u0627\u0644\u0645\u0627\u062F\u0629 \u0648\u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "buys from": "\u064A\u0634\u062A\u0631\u064A \u0645\u0646",
  "Buyer's rating (hidden from the outlet page)": "\u062A\u0642\u064A\u064A\u0645 \u0627\u0644\u0645\u0634\u062A\u0631\u064A (\u0645\u062E\u0641\u064A \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0646\u0635\u0629)",
  "Buyer's rating": "\u062A\u0642\u064A\u064A\u0645 \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "Rating shown again.": "\u0623\u064F\u0639\u064A\u062F \u0625\u0638\u0647\u0627\u0631 \u0627\u0644\u062A\u0642\u064A\u064A\u0645.",
  "Rating hidden.": "\u0623\u064F\u062E\u0641\u064A \u0627\u0644\u062A\u0642\u064A\u064A\u0645.",
  "Show on the outlet page": "\u0623\u0638\u0647\u0631\u0647 \u0641\u064A \u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0646\u0635\u0629",
  "Hide from the outlet page": "\u0623\u062E\u0641\u0650\u0647 \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0646\u0635\u0629",
  "Decide this dispute": "\u0642\u0631\u0651\u0631 \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u0646\u0632\u0627\u0639",
  "publisher offered a refund of {amount}": "\u0639\u0631\u0636 \u0627\u0644\u0646\u0627\u0634\u0631 \u0627\u0633\u062A\u0631\u062F\u0627\u062F {amount}",
  "publisher offered: {offer}": "\u0639\u0631\u0636 \u0627\u0644\u0646\u0627\u0634\u0631: {offer}",
  "Outcome": "\u0627\u0644\u0646\u062A\u064A\u062C\u0629",
  "Refunds at the publisher's fault: the card costs are deducted from their next payout. Both sides are told. The decision is final, except that within 10 working days either side can point to a clear mistake of fact and Nashr looks again.": "\u0641\u064A \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u062A\u064A \u064A\u062A\u062D\u0645\u0644 \u0627\u0644\u0646\u0627\u0634\u0631 \u0645\u0633\u0624\u0648\u0644\u064A\u062A\u0647\u0627: \u062A\u064F\u062E\u0635\u0645 \u062A\u0643\u0627\u0644\u064A\u0641 \u0627\u0644\u0628\u0637\u0627\u0642\u0629 \u0645\u0646 \u062F\u0641\u0639\u062A\u0647 \u0627\u0644\u062A\u0627\u0644\u064A\u0629. \u0648\u064A\u064F\u0628\u0644\u064E\u0651\u063A \u0627\u0644\u0637\u0631\u0641\u0627\u0646. \u0627\u0644\u0642\u0631\u0627\u0631 \u0646\u0647\u0627\u0626\u064A\u060C \u0625\u0644\u0627 \u0623\u0646\u0647 \u062E\u0644\u0627\u0644 10 \u0623\u064A\u0627\u0645 \u0639\u0645\u0644 \u064A\u0645\u0643\u0646 \u0644\u0623\u064A \u0637\u0631\u0641 \u0627\u0644\u0625\u0634\u0627\u0631\u0629 \u0625\u0644\u0649 \u062E\u0637\u0623 \u0648\u0627\u0636\u062D \u0641\u064A \u0627\u0644\u0648\u0642\u0627\u0626\u0639 \u0641\u062A\u0639\u064A\u062F \u0646\u0634\u0631 \u0627\u0644\u0646\u0638\u0631 \u0641\u064A\u0647.",
  "Apply this outcome? Money moves at once.": "\u062A\u0637\u0628\u064A\u0642 \u0647\u0630\u0647 \u0627\u0644\u0646\u062A\u064A\u062C\u0629\u061F \u062A\u062A\u062D\u0631\u0643 \u0627\u0644\u0623\u0645\u0648\u0627\u0644 \u0641\u0648\u0631\u064B\u0627.",
  "Decision applied.": "\u0637\u064F\u0628\u0651\u0642 \u0627\u0644\u0642\u0631\u0627\u0631.",
  "Apply decision": "\u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0642\u0631\u0627\u0631",
  "Commission ({pct})": "\u0627\u0644\u0639\u0645\u0648\u0644\u0629 ({pct})",
  "Commission (not frozen yet)": "\u0627\u0644\u0639\u0645\u0648\u0644\u0629 (\u0644\u0645 \u062A\u064F\u062B\u0628\u064E\u0651\u062A \u0628\u0639\u062F)",
  "earned \xB7 {amount} at full price": "\u0645\u0643\u062A\u0633\u0628\u0629 \xB7 {amount} \u0628\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0643\u0627\u0645\u0644",
  "earned": "\u0645\u0643\u062A\u0633\u0628\u0629",
  "when released": "\u0639\u0646\u062F \u0627\u0644\u062A\u062D\u0631\u064A\u0631",
  "Held now": "\u0645\u062D\u062A\u062C\u0632\u0629 \u0627\u0644\u0622\u0646",
  "{amount} refund being sent": "\u0627\u0633\u062A\u0631\u062F\u0627\u062F {amount} \u0642\u064A\u062F \u0627\u0644\u0625\u0631\u0633\u0627\u0644",
  "Event": "\u0627\u0644\u062D\u062F\u062B",
  "Who": "\u0645\u0646",
  "Note": "\u0645\u0644\u0627\u062D\u0638\u0629",
  "From (credit)": "\u0645\u0646 (\u062F\u0627\u0626\u0646)",
  "To (debit)": "\u0625\u0644\u0649 (\u0645\u062F\u064A\u0646)",
  "Reference": "\u0627\u0644\u0645\u0631\u062C\u0639",
  "Payments, refunds and transfers": "\u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A \u0648\u0627\u0644\u0645\u0628\u0627\u0644\u063A \u0627\u0644\u0645\u0633\u062A\u0631\u062F\u0629 \u0648\u0627\u0644\u062A\u062D\u0648\u064A\u0644\u0627\u062A",
  "Due {when} \xB7 extra change rounds allowed: {n}": "\u062A\u0633\u062A\u062D\u0642 {when} \xB7 \u062C\u0648\u0644\u0627\u062A \u0627\u0644\u062A\u0639\u062F\u064A\u0644 \u0627\u0644\u0625\u0636\u0627\u0641\u064A\u0629 \u0627\u0644\u0645\u0633\u0645\u0648\u062D\u0629: {n}",
  "One more change round allowed.": "\u0633\u064F\u0645\u062D \u0628\u062C\u0648\u0644\u0629 \u062A\u0639\u062F\u064A\u0644 \u0625\u0636\u0627\u0641\u064A\u0629.",
  "Allow one more change round": "\u0627\u0633\u0645\u062D \u0628\u062C\u0648\u0644\u0629 \u062A\u0639\u062F\u064A\u0644 \u0625\u0636\u0627\u0641\u064A\u0629",
  "Proof and issues": "\u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0648\u0627\u0644\u0645\u0634\u0643\u0644\u0627\u062A",
  "Proof sent {when}": "\u0623\u064F\u0631\u0633\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A {when}",
  "Issue opened {when}": "\u0641\u064F\u062A\u062D\u062A \u0627\u0644\u0645\u0634\u0643\u0644\u0629 {when}",
  "No documents yet.": "\u0644\u0627 \u0645\u0633\u062A\u0646\u062F\u0627\u062A \u0628\u0639\u062F.",
  "Disputed deals wait for Nashr's decision. Open issues are still with the publisher until their deadline.": "\u0627\u0644\u0635\u0641\u0642\u0627\u062A \u0645\u062D\u0644 \u0627\u0644\u0646\u0632\u0627\u0639 \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0642\u0631\u0627\u0631 \u0646\u0634\u0631. \u0627\u0644\u0645\u0634\u0643\u0644\u0627\u062A \u0627\u0644\u0645\u0641\u062A\u0648\u062D\u0629 \u0645\u0627 \u0632\u0627\u0644\u062A \u0644\u062F\u0649 \u0627\u0644\u0646\u0627\u0634\u0631 \u062D\u062A\u0649 \u0645\u0648\u0639\u062F\u0647\u0627 \u0627\u0644\u0646\u0647\u0627\u0626\u064A.",
  "No disputes or open issues.": "\u0644\u0627 \u0646\u0632\u0627\u0639\u0627\u062A \u0648\u0644\u0627 \u0645\u0634\u0643\u0644\u0627\u062A \u0645\u0641\u062A\u0648\u062D\u0629.",
  "Buyer \xB7 publisher": "\u0627\u0644\u0645\u0634\u062A\u0631\u064A \xB7 \u0627\u0644\u0646\u0627\u0634\u0631",
  "Publisher's offer": "\u0639\u0631\u0636 \u0627\u0644\u0646\u0627\u0634\u0631",
  "Deadline": "\u0627\u0644\u0645\u0648\u0639\u062F \u0627\u0644\u0646\u0647\u0627\u0626\u064A",
  "Refund {amount}": "\u0627\u0633\u062A\u0631\u062F\u0627\u062F {amount}",
  "Nashr to decide": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0642\u0631\u0627\u0631 \u0646\u0634\u0631",
  // Timeline events, money operations, creative and issue states as the server names them
  "opened": "\u0641\u064F\u062A\u062D \u0627\u0644\u0637\u0644\u0628",
  "accept": "\u0642\u0628\u0648\u0644",
  "decline": "\u0631\u0641\u0636",
  "expire": "\u0627\u0646\u062A\u0647\u0627\u0621 \u0627\u0644\u0645\u0647\u0644\u0629",
  "supersede": "\u0627\u0633\u062A\u064F\u0628\u062F\u0644 \u0628\u0637\u0644\u0628 \u0622\u062E\u0631",
  "pay": "\u062F\u0641\u0639",
  "lapse": "\u0633\u0642\u0648\u0637",
  "submit proof": "\u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "approve": "\u0645\u0648\u0627\u0641\u0642\u0629",
  "auto release": "\u062A\u062D\u0631\u064A\u0631 \u062A\u0644\u0642\u0627\u0626\u064A",
  "report issue": "\u0625\u0628\u0644\u0627\u063A \u0639\u0646 \u0645\u0634\u0643\u0644\u0629",
  "resolve": "\u062D\u0644\u0651",
  "make good": "\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0628\u062B",
  "partial refund": "\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u062C\u0632\u0626\u064A",
  "escalate": "\u0625\u062D\u0627\u0644\u0629 \u0625\u0644\u0649 \u0646\u0634\u0631",
  "release": "\u062A\u062D\u0631\u064A\u0631",
  "refund": "\u0627\u0633\u062A\u0631\u062F\u0627\u062F",
  "paid out": "\u062A\u062D\u0648\u064A\u0644 \u0644\u0644\u0646\u0627\u0634\u0631",
  "cancel by buyer": "\u0625\u0644\u063A\u0627\u0621 \u0645\u0646 \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "cancel by seller": "\u0625\u0644\u063A\u0627\u0621 \u0645\u0646 \u0627\u0644\u0646\u0627\u0634\u0631",
  "creative missed": "\u0644\u0645 \u062A\u0635\u0644 \u0627\u0644\u0645\u0627\u062F\u0629",
  "proof missed": "\u0644\u0645 \u064A\u064F\u0631\u0633\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "charge": "\u062A\u062D\u0635\u064A\u0644",
  "transfer": "\u062A\u062D\u0648\u064A\u0644",
  "failed": "\u0641\u0634\u0644",
  "pending": "\u0642\u064A\u062F \u0627\u0644\u0627\u0646\u062A\u0638\u0627\u0631",
  "succeeded": "\u062A\u0645",
  "open": "\u0645\u0641\u062A\u0648\u062D",
  "answered": "\u062A\u0645 \u0627\u0644\u0631\u062F",
  "resolved": "\u0645\u062D\u0644\u0648\u0644\u0629",
  "escalated": "\u0645\u062D\u0627\u0644\u0629",
  "closed": "\u0645\u063A\u0644\u0642\u0629",
  "approved": "\u0645\u0639\u062A\u0645\u062F\u0629",
  "changes requested": "\u0637\u064F\u0644\u0628\u062A \u062A\u0639\u062F\u064A\u0644\u0627\u062A",
  "technical issue": "\u0645\u0634\u0643\u0644\u0629 \u0641\u0646\u064A\u0629",
  "rejected": "\u0645\u0631\u0641\u0648\u0636\u0629",
  "brief mismatch": "\u0644\u0627 \u062A\u0637\u0627\u0628\u0642 \u0627\u0644\u0645\u0644\u062E\u0635",
  "content standards": "\u062A\u062E\u0627\u0644\u0641 \u0645\u0639\u0627\u064A\u064A\u0631 \u0627\u0644\u0645\u062D\u062A\u0648\u0649",
  "wrong specs": "\u0645\u0648\u0627\u0635\u0641\u0627\u062A \u062E\u0627\u0637\u0626\u0629",
  "other": "\u0623\u062E\u0631\u0649",
  "did not run": "\u0644\u0645 \u064A\u064F\u0628\u062B",
  "wrong time": "\u0648\u0642\u062A \u062E\u0627\u0637\u0626",
  "wrong position": "\u0645\u0648\u0636\u0639 \u062E\u0627\u0637\u0626",
  "creative altered": "\u0639\u064F\u062F\u0651\u0644\u062A \u0627\u0644\u0645\u0627\u062F\u0629",
  "quality": "\u0627\u0644\u062C\u0648\u062F\u0629",
  // Funds, payouts, reports
  "Double-entry ledger. Every movement is recorded once and never changed.": "\u062F\u0641\u062A\u0631 \u0642\u064A\u062F \u0645\u0632\u062F\u0648\u062C. \u062A\u064F\u0633\u062C\u064E\u0651\u0644 \u0643\u0644 \u062D\u0631\u0643\u0629 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \u0648\u0644\u0627 \u062A\u064F\u0639\u062F\u064E\u0651\u0644 \u0623\u0628\u062F\u064B\u0627.",
  "Reconciled: ledger cash {ledger}, payment provider {provider}.": "\u0645\u0637\u0627\u0628\u0642: \u0627\u0644\u0646\u0642\u062F \u0641\u064A \u0627\u0644\u062F\u0641\u062A\u0631 {ledger}\u060C \u0648\u0644\u062F\u0649 \u0645\u0632\u0648\u0651\u062F \u0627\u0644\u062F\u0641\u0639 {provider}.",
  "Does not reconcile: ledger cash {ledger}, payment provider {provider}.": "\u063A\u064A\u0631 \u0645\u0637\u0627\u0628\u0642: \u0627\u0644\u0646\u0642\u062F \u0641\u064A \u0627\u0644\u062F\u0641\u062A\u0631 {ledger}\u060C \u0648\u0644\u062F\u0649 \u0645\u0632\u0648\u0651\u062F \u0627\u0644\u062F\u0641\u0639 {provider}.",
  "Cash at the payment provider": "\u0627\u0644\u0646\u0642\u062F \u0644\u062F\u0649 \u0645\u0632\u0648\u0651\u062F \u0627\u0644\u062F\u0641\u0639",
  "Everything paid in, less refunds and payouts": "\u0643\u0644 \u0645\u0627 \u062F\u064F\u0641\u0639\u060C \u0645\u0637\u0631\u0648\u062D\u064B\u0627 \u0645\u0646\u0647 \u0627\u0644\u0645\u0628\u0627\u0644\u063A \u0627\u0644\u0645\u0633\u062A\u0631\u062F\u0629 \u0648\u0627\u0644\u062A\u062D\u0648\u064A\u0644\u0627\u062A",
  "Paid by buyers, not yet released or refunded": "\u062F\u0641\u0639\u0647\u0627 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0648\u0644\u0645 \u062A\u064F\u062D\u0631\u064E\u0651\u0631 \u0623\u0648 \u062A\u064F\u0633\u062A\u0631\u062F \u0628\u0639\u062F",
  "Released, waiting for transfer": "\u0645\u062D\u0631\u0651\u0631\u0629\u060C \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u062A\u062D\u0648\u064A\u0644",
  "Owed by publishers": "\u0645\u0633\u062A\u062D\u0642\u0629 \u0639\u0644\u0649 \u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646",
  "Refund costs at their fault, deducted from next payout": "\u062A\u0643\u0627\u0644\u064A\u0641 \u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0628\u062E\u0637\u0626\u0647\u0645\u060C \u062A\u064F\u062E\u0635\u0645 \u0645\u0646 \u0627\u0644\u062A\u062D\u0648\u064A\u0644 \u0627\u0644\u0642\u0627\u062F\u0645",
  "Nashr commission": "\u0639\u0645\u0648\u0644\u0629 \u0646\u0634\u0631",
  "Earned on released bookings": "\u0645\u0643\u062A\u0633\u0628\u0629 \u0645\u0646 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u0645\u062D\u0631\u0651\u0631\u0629",
  "Only while Nashr is VAT-registered": "\u0641\u0642\u0637 \u062D\u064A\u0646 \u062A\u0643\u0648\u0646 \u0646\u0634\u0631 \u0645\u0633\u062C\u0644\u0629 \u0641\u064A \u0627\u0644\u0636\u0631\u064A\u0628\u0629",
  "Refund card costs": "\u0631\u0633\u0648\u0645 \u0627\u0644\u0628\u0637\u0627\u0642\u0629 \u0639\u0644\u0649 \u0627\u0644\u0645\u0628\u0627\u0644\u063A \u0627\u0644\u0645\u0633\u062A\u0631\u062F\u0629",
  "Positive: still to recover \xB7 negative: recovered": "\u0645\u0648\u062C\u0628: \u0644\u0645 \u062A\u064F\u0633\u062A\u0631\u062F\u0651 \u0628\u0639\u062F \xB7 \u0633\u0627\u0644\u0628: \u0627\u0633\u062A\u064F\u0631\u062F\u0651\u062A",
  "Latest movements": "\u0623\u062D\u062F\u062B \u0627\u0644\u062D\u0631\u0643\u0627\u062A",
  "Payouts and refunds": "\u0627\u0644\u062A\u062D\u0648\u064A\u0644\u0627\u062A \u0648\u0627\u0644\u0645\u0628\u0627\u0644\u063A \u0627\u0644\u0645\u0633\u062A\u0631\u062F\u0629",
  "Sent every minute by the money job. A retry reuses the same key, so nothing is paid twice.": "\u062A\u064F\u0631\u0633\u0644 \u0643\u0644 \u062F\u0642\u064A\u0642\u0629 \u0628\u0648\u0627\u0633\u0637\u0629 \u0645\u0647\u0645\u0629 \u0627\u0644\u0623\u0645\u0648\u0627\u0644. \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u062A\u0633\u062A\u062E\u062F\u0645 \u0627\u0644\u0645\u0641\u062A\u0627\u062D \u0646\u0641\u0633\u0647\u060C \u0641\u0644\u0627 \u064A\u064F\u062F\u0641\u0639 \u0634\u064A\u0621 \u0645\u0631\u062A\u064A\u0646.",
  "Failed": "\u0641\u0634\u0644\u062A",
  "Sent": "\u0623\u064F\u0631\u0633\u0644\u062A",
  "Nothing here.": "\u0644\u0627 \u0634\u064A\u0621 \u0647\u0646\u0627.",
  "Updated": "\u0622\u062E\u0631 \u062A\u062D\u062F\u064A\u062B",
  "Payout": "\u062A\u062D\u0648\u064A\u0644 \u0644\u0644\u0646\u0627\u0634\u0631",
  "Refund": "\u0627\u0633\u062A\u0631\u062F\u0627\u062F",
  "Payout account not verified": "\u062D\u0633\u0627\u0628 \u0627\u0644\u0627\u0633\u062A\u0644\u0627\u0645 \u0644\u0645 \u064A\u064F\u062A\u062D\u0642\u0642 \u0645\u0646\u0647",
  "Buyer card": "\u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "{ref} queued again.": "\u0623\u064F\u0639\u064A\u062F \u0625\u062F\u0631\u0627\u062C {ref}.",
  "Retry": "\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629",
  "No paid bookings in this period.": "\u0644\u0627 \u062D\u062C\u0648\u0632\u0627\u062A \u0645\u062F\u0641\u0648\u0639\u0629 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0641\u062A\u0631\u0629.",
  "Take rate": "\u0646\u0633\u0628\u0629 \u0627\u0644\u0639\u0645\u0648\u0644\u0629 \u0627\u0644\u0641\u0639\u0644\u064A\u0629",
  "Paid bookings, by the date they were booked (Dubai). Values excl. VAT.": "\u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0629 \u062D\u0633\u0628 \u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062D\u062C\u0632 (\u062F\u0628\u064A). \u0627\u0644\u0642\u064A\u0645 \u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629.",
  "By month": "\u062D\u0633\u0628 \u0627\u0644\u0634\u0647\u0631",
  "By channel": "\u062D\u0633\u0628 \u0627\u0644\u0642\u0646\u0627\u0629",
  "By how it sold": "\u062D\u0633\u0628 \u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u0628\u064A\u0639",
  "Top outlets": "\u0623\u0628\u0631\u0632 \u0627\u0644\u0645\u0646\u0635\u0627\u062A",
  "Next bid chosen": "\u0627\u062E\u062A\u064A\u0627\u0631 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629",
  "Refund losses": "\u062E\u0633\u0627\u0626\u0631 \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F",
  "Refunds sent": "\u0627\u0644\u0645\u0628\u0627\u0644\u063A \u0627\u0644\u0645\u0633\u062A\u0631\u062F\u0629 \u0627\u0644\u0645\u0631\u0633\u0644\u0629",
  "Card costs kept from buyer cancellations": "\u0631\u0633\u0648\u0645 \u0628\u0637\u0627\u0642\u0627\u062A \u0645\u064F\u0642\u062A\u0637\u0639\u0629 \u0645\u0646 \u0625\u0644\u063A\u0627\u0621\u0627\u062A \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646",
  "Card costs charged to publishers": "\u0631\u0633\u0648\u0645 \u0628\u0637\u0627\u0642\u0627\u062A \u0645\u062D\u0645\u0651\u0644\u0629 \u0639\u0644\u0649 \u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646",
  "Recovered from publisher payouts": "\u0645\u0633\u062A\u0631\u062F\u0629 \u0645\u0646 \u062A\u062D\u0648\u064A\u0644\u0627\u062A \u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646",
  "Publishers still owe (all time)": "\u0645\u0627 \u0632\u0627\u0644 \u0645\u0633\u062A\u062D\u0642\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646 (\u0645\u0646\u0630 \u0627\u0644\u0628\u062F\u0627\u064A\u0629)",
  "Card costs are Nashr's estimate until the payment provider's own refund fees are recorded (Stripe, B5).": "\u0631\u0633\u0648\u0645 \u0627\u0644\u0628\u0637\u0627\u0642\u0627\u062A \u062A\u0642\u062F\u064A\u0631 \u0645\u0646 \u0646\u0634\u0631 \u0625\u0644\u0649 \u0623\u0646 \u062A\u064F\u0633\u062C\u064E\u0651\u0644 \u0631\u0633\u0648\u0645 \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0627\u0644\u0641\u0639\u0644\u064A\u0629 \u0644\u062F\u0649 \u0645\u0632\u0648\u0651\u062F \u0627\u0644\u062F\u0641\u0639 (Stripe\u060C B5).",
  "Period {from} to {to}.": "\u0627\u0644\u0641\u062A\u0631\u0629 \u0645\u0646 {from} \u0625\u0644\u0649 {to}.",
  // Settings and team
  "Changes take effect immediately and are kept with their history. Financial settings are the founder's.": "\u062A\u0633\u0631\u064A \u0627\u0644\u062A\u063A\u064A\u064A\u0631\u0627\u062A \u0641\u0648\u0631\u064B\u0627 \u0648\u062A\u064F\u062D\u0641\u0638 \u0645\u0639 \u0633\u062C\u0644\u0647\u0627. \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0645\u0627\u0644\u064A\u0629 \u0645\u0646 \u0635\u0644\u0627\u062D\u064A\u0629 \u0627\u0644\u0645\u0624\u0633\u0633.",
  "Setting": "\u0627\u0644\u0625\u0639\u062F\u0627\u062F",
  "Changed": "\u0622\u062E\u0631 \u062A\u063A\u064A\u064A\u0631",
  "founder only": "\u0644\u0644\u0645\u0624\u0633\u0633 \u0641\u0642\u0637",
  "New value for {name}": "\u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u062C\u062F\u064A\u062F\u0629 \u0644\u0640{name}",
  "Initial value": "\u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0623\u0648\u0644\u064A\u0629",
  "History ({n})": "\u0627\u0644\u0633\u062C\u0644 ({n})",
  "Only the founder can change this": "\u064A\u063A\u064A\u0651\u0631\u0647 \u0627\u0644\u0645\u0624\u0633\u0633 \u0641\u0642\u0637",
  "Change": "\u062A\u063A\u064A\u064A\u0631",
  "by {name}": "\u0628\u0648\u0627\u0633\u0637\u0629 {name}",
  "{name} saved. It applies from now on; the old value stays in the history.": "\u062D\u064F\u0641\u0638 {name}. \u064A\u0633\u0631\u064A \u0645\u0646 \u0627\u0644\u0622\u0646\u060C \u0648\u062A\u0628\u0642\u0649 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0642\u062F\u064A\u0645\u0629 \u0641\u064A \u0627\u0644\u0633\u062C\u0644.",
  "Default commission": "\u0627\u0644\u0639\u0645\u0648\u0644\u0629 \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A\u0629",
  "basis points: 1200 = 12%": "\u0646\u0642\u0627\u0637 \u0623\u0633\u0627\u0633: 1200 = 12%",
  "VAT on media": "\u0627\u0644\u0636\u0631\u064A\u0628\u0629 \u0639\u0644\u0649 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  "basis points": "\u0646\u0642\u0627\u0637 \u0623\u0633\u0627\u0633",
  "Nashr is VAT-registered": "\u0646\u0634\u0631 \u0645\u0633\u062C\u0644\u0629 \u0641\u064A \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629",
  "true / false": "true / false",
  "VAT on Nashr commission": "\u0627\u0644\u0636\u0631\u064A\u0628\u0629 \u0639\u0644\u0649 \u0639\u0645\u0648\u0644\u0629 \u0646\u0634\u0631",
  "Nashr legal name on documents": "\u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0642\u0627\u0646\u0648\u0646\u064A \u0644\u0646\u0634\u0631 \u0641\u064A \u0627\u0644\u0645\u0633\u062A\u0646\u062F\u0627\u062A",
  "Nashr's TRN": "\u0627\u0644\u0631\u0642\u0645 \u0627\u0644\u0636\u0631\u064A\u0628\u064A \u0644\u0646\u0634\u0631",
  "null until registered": "null \u062D\u062A\u0649 \u0627\u0644\u062A\u0633\u062C\u064A\u0644",
  "Publisher decision window": "\u0645\u0647\u0644\u0629 \u0642\u0631\u0627\u0631 \u0627\u0644\u0646\u0627\u0634\u0631",
  "hours": "\u0633\u0627\u0639\u0627\u062A",
  "Payment window": "\u0645\u0647\u0644\u0629 \u0627\u0644\u062F\u0641\u0639",
  "hours, capped by the creative deadline": "\u0633\u0627\u0639\u0627\u062A\u060C \u0628\u062D\u062F \u0623\u0642\u0635\u0649 \u0645\u0648\u0639\u062F \u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0645\u0627\u062F\u0629",
  "Minimum bid step": "\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u062F\u0646\u0649 \u0644\u0632\u064A\u0627\u062F\u0629 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629",
  "basis points: 300 = 3%": "\u0646\u0642\u0627\u0637 \u0623\u0633\u0627\u0633: 300 = 3%",
  "Next-bid choices before relisting": "\u0645\u0631\u0627\u062A \u0627\u062E\u062A\u064A\u0627\u0631 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629 \u0642\u0628\u0644 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0639\u0631\u0636",
  "Buyer proof review": "\u0645\u0631\u0627\u062C\u0639\u0629 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0644\u0644\u0625\u062B\u0628\u0627\u062A",
  "working days": "\u0623\u064A\u0627\u0645 \u0639\u0645\u0644",
  "Proof due after the run": "\u0645\u0648\u0639\u062F \u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0628\u0639\u062F \u0627\u0644\u0628\u062B",
  "Creative change rounds": "\u062C\u0648\u0644\u0627\u062A \u062A\u0639\u062F\u064A\u0644 \u0627\u0644\u0645\u0627\u062F\u0629",
  "Publisher response to an issue": "\u0645\u0647\u0644\u0629 \u0631\u062F \u0627\u0644\u0646\u0627\u0634\u0631 \u0639\u0644\u0649 \u0645\u0634\u0643\u0644\u0629",
  "Pre-run check before air": "\u0641\u062D\u0635 \u0645\u0627 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B",
  "Free cancellation after payment": "\u0627\u0644\u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u0645\u062C\u0627\u0646\u064A \u0628\u0639\u062F \u0627\u0644\u062F\u0641\u0639",
  "Publisher keeps on late cancellation": "\u0645\u0627 \u064A\u062D\u062A\u0641\u0638 \u0628\u0647 \u0627\u0644\u0646\u0627\u0634\u0631 \u0639\u0646\u062F \u0627\u0644\u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u0645\u062A\u0623\u062E\u0631",
  "Card processing estimate": "\u062A\u0642\u062F\u064A\u0631 \u0631\u0633\u0648\u0645 \u0645\u0639\u0627\u0644\u062C\u0629 \u0627\u0644\u0628\u0637\u0627\u0642\u0627\u062A",
  "Card processing fixed part": "\u0627\u0644\u062C\u0632\u0621 \u0627\u0644\u062B\u0627\u0628\u062A \u0645\u0646 \u0631\u0633\u0648\u0645 \u0627\u0644\u0628\u0637\u0627\u0642\u0627\u062A",
  "fils": "\u0641\u0644\u0633",
  "Media invoice issued at": "\u0648\u0642\u062A \u0625\u0635\u062F\u0627\u0631 \u0641\u0627\u062A\u0648\u0631\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  '"payment" or "run"': '"payment" \u0623\u0648 "run"',
  "UAE public holidays": "\u0627\u0644\u0639\u0637\u0644 \u0627\u0644\u0631\u0633\u0645\u064A\u0629 \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A",
  "list of dates, affects working days": "\u0642\u0627\u0626\u0645\u0629 \u062A\u0648\u0627\u0631\u064A\u062E\u060C \u062A\u0624\u062B\u0631 \u0641\u064A \u0623\u064A\u0627\u0645 \u0627\u0644\u0639\u0645\u0644",
  "Question extension": "\u0627\u0644\u062A\u0645\u062F\u064A\u062F \u0639\u0646\u062F \u0627\u0644\u0633\u0624\u0627\u0644",
  "Markets open for booking": "\u0627\u0644\u0623\u0633\u0648\u0627\u0642 \u0627\u0644\u0645\u062A\u0627\u062D\u0629 \u0644\u0644\u062D\u062C\u0632",
  "country codes": "\u0631\u0645\u0648\u0632 \u0627\u0644\u062F\u0648\u0644",
  "Nashr team": "\u0641\u0631\u064A\u0642 \u0646\u0634\u0631",
  "authenticator on": "\u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629 \u0645\u0641\u0639\u0651\u0644",
  "authenticator off (switched off for testing)": "\u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629 \u0645\u062A\u0648\u0642\u0641 (\u0623\u064F\u0648\u0642\u0641 \u0644\u0644\u0627\u062E\u062A\u0628\u0627\u0631)",
  "Invite a team member": "\u0627\u062F\u0639\u064F \u0639\u0636\u0648\u064B\u0627 \u0625\u0644\u0649 \u0627\u0644\u0641\u0631\u064A\u0642",
  "Role": "\u0627\u0644\u062F\u0648\u0631",
  "Work email": "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0644\u0644\u0639\u0645\u0644",
  "Admin (operations)": "\u0645\u0634\u0631\u0641 (\u0627\u0644\u0639\u0645\u0644\u064A\u0627\u062A)",
  "Founder (financial settings too)": "\u0645\u0624\u0633\u0633 (\u0648\u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0645\u0627\u0644\u064A\u0629 \u0623\u064A\u0636\u064B\u0627)",
  "They set a password and link an authenticator app from the invite link.": "\u064A\u0639\u064A\u0651\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0648\u064A\u0631\u0628\u0637 \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629 \u0645\u0646 \u0631\u0627\u0628\u0637 \u0627\u0644\u062F\u0639\u0648\u0629.",
  "Invite link": "\u0631\u0627\u0628\u0637 \u0627\u0644\u062F\u0639\u0648\u0629",
  "Invite created. Send them the link.": "\u0623\u064F\u0646\u0634\u0626\u062A \u0627\u0644\u062F\u0639\u0648\u0629. \u0623\u0631\u0633\u0644 \u0625\u0644\u064A\u0647 \u0627\u0644\u0631\u0627\u0628\u0637.",
  "Create invite": "\u0625\u0646\u0634\u0627\u0621 \u062F\u0639\u0648\u0629",
  // Audit and directory
  "Audit log": "\u0633\u062C\u0644 \u0627\u0644\u062A\u062F\u0642\u064A\u0642",
  "Append-only. Latest 500 entries; filter by record to see its whole history.": "\u0644\u0644\u0625\u0636\u0627\u0641\u0629 \u0641\u0642\u0637. \u0622\u062E\u0631 500 \u0642\u064A\u062F\u061B \u0635\u0641\u0650\u0651 \u062D\u0633\u0628 \u0627\u0644\u0633\u062C\u0644 \u0644\u062A\u0631\u0649 \u062A\u0627\u0631\u064A\u062E\u0647 \u0643\u0627\u0645\u0644\u064B\u0627.",
  "Filter by actor or action": "\u0635\u0641\u0650\u0651 \u062D\u0633\u0628 \u0627\u0644\u0645\u0646\u0641\u0651\u0630 \u0623\u0648 \u0627\u0644\u0625\u062C\u0631\u0627\u0621",
  "Record id": "\u0645\u0639\u0631\u0651\u0641 \u0627\u0644\u0633\u062C\u0644",
  "Record id (deal, company, user\u2026)": "\u0645\u0639\u0631\u0651\u0641 \u0627\u0644\u0633\u062C\u0644 (\u0635\u0641\u0642\u0629\u060C \u0634\u0631\u0643\u0629\u060C \u0645\u0633\u062A\u062E\u062F\u0645\u2026)",
  "Action": "\u0627\u0644\u0625\u062C\u0631\u0627\u0621",
  "Record": "\u0627\u0644\u0633\u062C\u0644",
  "Detail": "\u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644",
  "Added to the directory.": "\u0623\u064F\u0636\u064A\u0641\u062A \u0625\u0644\u0649 \u0627\u0644\u062F\u0644\u064A\u0644.",
  "Outlets not on Nashr show Nashr's estimate, marked \u201Cunconfirmed\u201D. Publishers on Nashr manage their own profile.": "\u062A\u0638\u0647\u0631 \u0644\u0644\u0645\u0646\u0635\u0627\u062A \u063A\u064A\u0631 \u0627\u0644\u0645\u0646\u0636\u0645\u0629 \u0625\u0644\u0649 \u0646\u0634\u0631 \u062A\u0642\u062F\u064A\u0631\u0627\u062A \u0646\u0634\u0631 \u0628\u0639\u0644\u0627\u0645\u0629 \u201C\u063A\u064A\u0631 \u0645\u0624\u0643\u062F\u201D. \u0648\u064A\u062F\u064A\u0631 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0639\u0644\u0649 \u0646\u0634\u0631 \u0645\u0644\u0641\u0627\u062A\u0647\u0645 \u0628\u0623\u0646\u0641\u0633\u0647\u0645.",
  "Marked answered.": "\u0639\u064F\u0644\u0651\u0645 \u0628\u0623\u0646\u0647 \u062A\u0645 \u0627\u0644\u0631\u062F.",
  "Mark answered": "\u0639\u0644\u0651\u0645\u0647 \u0628\u0623\u0646\u0647 \u062A\u0645 \u0627\u0644\u0631\u062F",
  "Reopened.": "\u0623\u064F\u0639\u064A\u062F \u0641\u062A\u062D\u0647.",
  "Estimate {low}\u2013{high}": "\u062A\u0642\u062F\u064A\u0631 {low}\u2013{high}",
  "No estimate": "\u0644\u0627 \u062A\u0642\u062F\u064A\u0631",
  "Edit {name}": "\u062A\u0639\u062F\u064A\u0644 {name}",
  "Add an outlet not on Nashr": "\u0623\u0636\u0641 \u0645\u0646\u0635\u0629 \u063A\u064A\u0631 \u0645\u0646\u0636\u0645\u0629 \u0625\u0644\u0649 \u0646\u0634\u0631",
  "Sectors (comma-separated)": "\u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A (\u0627\u0641\u0635\u0644 \u0628\u064A\u0646\u0647\u0627 \u0628\u0641\u0648\u0627\u0635\u0644)",
  "Tier": "\u0627\u0644\u0641\u0626\u0629",
  "Edit": "\u062A\u0639\u062F\u064A\u0644",
  "Estimate from (AED)": "\u0627\u0644\u062A\u0642\u062F\u064A\u0631 \u0645\u0646 (\u062F\u0631\u0647\u0645)",
  "Estimate to (AED)": "\u0627\u0644\u062A\u0642\u062F\u064A\u0631 \u0625\u0644\u0649 (\u062F\u0631\u0647\u0645)",
  "Nashr registered address on documents": "\u0639\u0646\u0648\u0627\u0646 \u0646\u0634\u0631 \u0627\u0644\u0645\u0633\u062C\u0651\u0644 \u0641\u064A \u0627\u0644\u0645\u0633\u062A\u0646\u062F\u0627\u062A",
  "as on the trade licence": "\u0643\u0645\u0627 \u0641\u064A \u0627\u0644\u0631\u062E\u0635\u0629 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629",
  "Two-step sign-in before paying or connecting payouts": "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646 \u0642\u0628\u0644 \u0627\u0644\u062F\u0641\u0639 \u0623\u0648 \u0631\u0628\u0637 \u062D\u0633\u0627\u0628 \u0627\u0644\u062A\u062D\u0648\u064A\u0644\u0627\u062A",
  "Yes": "\u0646\u0639\u0645",
  "No": "\u0644\u0627",
  "Cancel it (nothing has been paid)": "\u0623\u0644\u063A\u0650\u0647\u0627 (\u0644\u0645 \u064A\u064F\u062F\u0641\u0639 \u0634\u064A\u0621)",
  "Refund part, release the rest": "\u0627\u0633\u062A\u0631\u062F \u062C\u0632\u0621\u064B\u0627 \u0648\u062D\u0631\u0651\u0631 \u0627\u0644\u0628\u0627\u0642\u064A"
};

// web/src/i18n-ar-upgrade.ts
var AR_UPGRADE = {
  // Navigation and bell
  "Messages": "\u0627\u0644\u0631\u0633\u0627\u0626\u0644",
  "Your company": "\u0634\u0631\u0643\u062A\u0643",
  "{n} unread": "{n} \u063A\u064A\u0631 \u0645\u0642\u0631\u0648\u0621\u0629",
  "New message from the publisher.": "\u0631\u0633\u0627\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0645\u0646 \u0627\u0644\u0646\u0627\u0634\u0631.",
  "New message from the buyer.": "\u0631\u0633\u0627\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0645\u0646 \u0627\u0644\u0645\u0634\u062A\u0631\u064A.",
  // Conversation
  "Messages with {name}": "\u0627\u0644\u0631\u0633\u0627\u0626\u0644 \u0645\u0639 {name}",
  "Everything stays on Nashr. Emails and phone numbers can\u2019t be sent.": "\u0643\u0644 \u0634\u064A\u0621 \u064A\u0628\u0642\u0649 \u0639\u0644\u0649 \u0646\u0634\u0631. \u0644\u0627 \u064A\u0645\u0643\u0646 \u0625\u0631\u0633\u0627\u0644 \u0639\u0646\u0627\u0648\u064A\u0646 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0648 \u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0647\u0648\u0627\u062A\u0641.",
  "No messages yet. Ask about timing, the creative, or anything else about this booking.": "\u0644\u0627 \u0631\u0633\u0627\u0626\u0644 \u0628\u0639\u062F. \u0627\u0633\u0623\u0644 \u0639\u0646 \u0627\u0644\u062A\u0648\u0642\u064A\u062A \u0623\u0648 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0623\u0648 \u0623\u064A \u0634\u064A\u0621 \u0622\u062E\u0631 \u064A\u062E\u0635 \u0647\u0630\u0627 \u0627\u0644\u062D\u062C\u0632.",
  "Your message": "\u0631\u0633\u0627\u0644\u062A\u0643",
  "Write a message\u2026": "\u0627\u0643\u062A\u0628 \u0631\u0633\u0627\u0644\u0629\u2026",
  "{n} characters left": "\u062A\u0628\u0642\u0651\u0649 {n} \u062D\u0631\u0641\u064B\u0627",
  "Enter to send \xB7 Shift+Enter for a new line": "Enter \u0644\u0644\u0625\u0631\u0633\u0627\u0644 \xB7 Shift+Enter \u0644\u0633\u0637\u0631 \u062C\u062F\u064A\u062F",
  "This deal is finished, so the conversation is closed. It stays here as a record.": "\u0627\u0646\u062A\u0647\u062A \u0627\u0644\u0635\u0641\u0642\u0629\u060C \u0644\u0630\u0627 \u0623\u064F\u063A\u0644\u0642\u062A \u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0629. \u062A\u0628\u0642\u0649 \u0647\u0646\u0627 \u0644\u0644\u0631\u062C\u0648\u0639 \u0625\u0644\u064A\u0647\u0627.",
  "Messages with the publisher open once you have paid": "\u062A\u064F\u0641\u062A\u062D \u0627\u0644\u0631\u0633\u0627\u0626\u0644 \u0645\u0639 \u0627\u0644\u0646\u0627\u0634\u0631 \u0628\u0639\u062F \u0623\u0646 \u062A\u062F\u0641\u0639",
  "Messages with the buyer open once they have paid": "\u062A\u064F\u0641\u062A\u062D \u0627\u0644\u0631\u0633\u0627\u0626\u0644 \u0645\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0628\u0639\u062F \u0623\u0646 \u064A\u062F\u0641\u0639",
  "Until then, the booking brief carries everything the publisher needs. The conversation closes when the deal is finished.": "\u062D\u062A\u0649 \u0630\u0644\u0643 \u0627\u0644\u062D\u064A\u0646\u060C \u064A\u062A\u0636\u0645\u0646 \u0645\u0644\u062E\u0635 \u0627\u0644\u062D\u062C\u0632 \u0643\u0644 \u0645\u0627 \u064A\u062D\u062A\u0627\u062C\u0647 \u0627\u0644\u0646\u0627\u0634\u0631. \u0648\u062A\u064F\u063A\u0644\u0642 \u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0629 \u0639\u0646\u062F \u0627\u0646\u062A\u0647\u0627\u0621 \u0627\u0644\u0635\u0641\u0642\u0629.",
  "You": "\u0623\u0646\u062A",
  "Flagged: may be moving off Nashr": "\u0645\u064F\u0639\u0644\u064E\u0651\u0645\u0629: \u0642\u062F \u062A\u0646\u0642\u0644 \u0627\u0644\u062A\u0648\u0627\u0635\u0644 \u062E\u0627\u0631\u062C \u0646\u0634\u0631",
  // Messages page
  "Conversations with buyers about their bookings.": "\u0645\u062D\u0627\u062F\u062B\u0627\u062A\u0643 \u0645\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u062D\u0648\u0644 \u062D\u062C\u0648\u0632\u0627\u062A\u0647\u0645.",
  "Conversations with publishers about your bookings.": "\u0645\u062D\u0627\u062F\u062B\u0627\u062A\u0643 \u0645\u0639 \u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646 \u062D\u0648\u0644 \u062D\u062C\u0648\u0632\u0627\u062A\u0643.",
  "No conversations yet": "\u0644\u0627 \u0645\u062D\u0627\u062F\u062B\u0627\u062A \u0628\u0639\u062F",
  "Once a buyer has paid for a booking, you can talk about it here until the deal is finished. Open a paid deal to start.": "\u0628\u0639\u062F \u0623\u0646 \u064A\u062F\u0641\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u062B\u0645\u0646 \u0627\u0644\u062D\u062C\u0632\u060C \u064A\u0645\u0643\u0646\u0643\u0645\u0627 \u0627\u0644\u062A\u062D\u062F\u062B \u0639\u0646\u0647 \u0647\u0646\u0627 \u062D\u062A\u0649 \u0627\u0646\u062A\u0647\u0627\u0621 \u0627\u0644\u0635\u0641\u0642\u0629. \u0627\u0641\u062A\u062D \u0635\u0641\u0642\u0629 \u0645\u062F\u0641\u0648\u0639\u0629 \u0644\u0644\u0628\u062F\u0621.",
  "Each paid booking has its own conversation with the publisher, open until the deal is finished. Open a paid booking to ask about timing or the creative.": "\u0644\u0643\u0644 \u062D\u062C\u0632 \u0645\u062F\u0641\u0648\u0639 \u0645\u062D\u0627\u062F\u062B\u062A\u0647 \u0627\u0644\u062E\u0627\u0635\u0629 \u0645\u0639 \u0627\u0644\u0646\u0627\u0634\u0631\u060C \u0645\u0641\u062A\u0648\u062D\u0629 \u062D\u062A\u0649 \u0627\u0646\u062A\u0647\u0627\u0621 \u0627\u0644\u0635\u0641\u0642\u0629. \u0627\u0641\u062A\u062D \u062D\u062C\u0632\u064B\u0627 \u0645\u062F\u0641\u0648\u0639\u064B\u0627 \u0644\u062A\u0633\u0623\u0644 \u0639\u0646 \u0627\u0644\u062A\u0648\u0642\u064A\u062A \u0623\u0648 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "Go to deals": "\u0627\u0644\u0630\u0647\u0627\u0628 \u0625\u0644\u0649 \u0627\u0644\u0635\u0641\u0642\u0627\u062A",
  "Go to bookings": "\u0627\u0644\u0630\u0647\u0627\u0628 \u0625\u0644\u0649 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A",
  "Conversations": "\u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0627\u062A",
  "Search by company, outlet or order": "\u0627\u0628\u062D\u062B \u0628\u0627\u0644\u0634\u0631\u0643\u0629 \u0623\u0648 \u0627\u0644\u0645\u0646\u0635\u0629 \u0623\u0648 \u0631\u0642\u0645 \u0627\u0644\u0637\u0644\u0628",
  "Search conversations": "\u0627\u0628\u062D\u062B \u0641\u064A \u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0627\u062A",
  "No conversations match.": "\u0644\u0627 \u0645\u062D\u0627\u062F\u062B\u0627\u062A \u0645\u0637\u0627\u0628\u0642\u0629.",
  "You:": "\u0623\u0646\u062A:",
  "All conversations": "\u0643\u0644 \u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0627\u062A",
  "Open deal": "\u0641\u062A\u062D \u0627\u0644\u0635\u0641\u0642\u0629",
  "Open booking": "\u0641\u062A\u062D \u0627\u0644\u062D\u062C\u0632",
  "This conversation is not available.": "\u0647\u0630\u0647 \u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0629 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629.",
  "Choose a conversation.": "\u0627\u062E\u062A\u0631 \u0645\u062D\u0627\u062F\u062B\u0629.",
  // Admin: messages on a deal
  "{n} flagged: wording that suggests moving the conversation off Nashr. Emails and phone numbers are always refused.": "{n} \u0645\u064F\u0639\u0644\u064E\u0651\u0645\u0629: \u0635\u064A\u0627\u063A\u0629 \u062A\u0648\u062D\u064A \u0628\u0646\u0642\u0644 \u0627\u0644\u062A\u0648\u0627\u0635\u0644 \u062E\u0627\u0631\u062C \u0646\u0634\u0631. \u0623\u0645\u0627 \u0639\u0646\u0627\u0648\u064A\u0646 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0648\u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0647\u0648\u0627\u062A\u0641 \u0641\u062A\u064F\u0631\u0641\u0636 \u062F\u0627\u0626\u0645\u064B\u0627.",
  "No messages on this booking.": "\u0644\u0627 \u0631\u0633\u0627\u0626\u0644 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062D\u062C\u0632.",
  // Booking page
  "Withdraw request\u2026": "\u0633\u062D\u0628 \u0627\u0644\u0637\u0644\u0628\u2026",
  "Withdraw your buy-now request? The slot stays on sale, and you can bid or ask again.": "\u0633\u062D\u0628 \u0637\u0644\u0628 \u0627\u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0641\u0648\u0631\u064A\u061F \u062A\u0628\u0642\u0649 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0645\u0639\u0631\u0648\u0636\u0629 \u0644\u0644\u0628\u064A\u0639\u060C \u0648\u064A\u0645\u0643\u0646\u0643 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0623\u0648 \u0627\u0644\u0637\u0644\u0628 \u0645\u062C\u062F\u062F\u064B\u0627.",
  "Request withdrawn.": "\u0633\u064F\u062D\u0628 \u0627\u0644\u0637\u0644\u0628.",
  "Withdraw request": "\u0633\u062D\u0628 \u0627\u0644\u0637\u0644\u0628",
  "Keep the request": "\u0627\u0644\u0625\u0628\u0642\u0627\u0621 \u0639\u0644\u0649 \u0627\u0644\u0637\u0644\u0628",
  "View order {ref}": "\u0639\u0631\u0636 \u0627\u0644\u0637\u0644\u0628 {ref}",
  "Order, receipts and invoices": "\u0627\u0644\u0637\u0644\u0628 \u0648\u0627\u0644\u0625\u064A\u0635\u0627\u0644\u0627\u062A \u0648\u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631",
  // Company page
  "TRN saved. It appears on tax invoices from now on.": "\u062D\u064F\u0641\u0638 \u0627\u0644\u0631\u0642\u0645 \u0627\u0644\u0636\u0631\u064A\u0628\u064A. \u064A\u0638\u0647\u0631 \u0639\u0644\u0649 \u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629 \u0645\u0646 \u0627\u0644\u0622\u0646.",
  "TRN removed.": "\u0623\u064F\u0632\u064A\u0644 \u0627\u0644\u0631\u0642\u0645 \u0627\u0644\u0636\u0631\u064A\u0628\u064A.",
  "Your company on Nashr: tax details and the people who book.": "\u0634\u0631\u0643\u062A\u0643 \u0639\u0644\u0649 \u0646\u0634\u0631: \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629 \u0648\u0627\u0644\u0623\u0634\u062E\u0627\u0635 \u0627\u0644\u0630\u064A\u0646 \u064A\u062D\u062C\u0632\u0648\u0646.",
  "Tax details": "\u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629",
  "Publishers put your TRN on the tax invoices they send you, so you can reclaim the VAT. Leave it empty if your company is not VAT-registered.": "\u064A\u0636\u0639 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0631\u0642\u0645\u0643 \u0627\u0644\u0636\u0631\u064A\u0628\u064A \u0639\u0644\u0649 \u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629 \u0627\u0644\u062A\u064A \u064A\u0631\u0633\u0644\u0648\u0646\u0647\u0627 \u0625\u0644\u064A\u0643\u060C \u0644\u062A\u062A\u0645\u0643\u0646 \u0645\u0646 \u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0627\u0644\u0636\u0631\u064A\u0628\u0629. \u0627\u062A\u0631\u0643\u0647 \u0641\u0627\u0631\u063A\u064B\u0627 \u0625\u0646 \u0644\u0645 \u062A\u0643\u0646 \u0634\u0631\u0643\u062A\u0643 \u0645\u0633\u062C\u0644\u0629 \u0641\u064A \u0627\u0644\u0636\u0631\u064A\u0628\u0629.",
  "{n} of 15 digits": "{n} \u0645\u0646 15 \u0631\u0642\u0645\u064B\u0627",
  "A TRN has 15 digits.": "\u0627\u0644\u0631\u0642\u0645 \u0627\u0644\u0636\u0631\u064A\u0628\u064A \u0645\u0646 15 \u0631\u0642\u0645\u064B\u0627.",
  "Undo": "\u062A\u0631\u0627\u062C\u0639",
  "Your team": "\u0641\u0631\u064A\u0642\u0643",
  "since {date}": "\u0645\u0646\u0630 {date}",
  "To add a colleague, ask Nashr: everyone joins by invitation.": "\u0644\u0625\u0636\u0627\u0641\u0629 \u0632\u0645\u064A\u0644\u060C \u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0646\u0634\u0631: \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0628\u0627\u0644\u062F\u0639\u0648\u0629 \u0641\u0642\u0637.",
  // Bid panel
  "Your current maximum: {amount}": "\u062D\u062F\u0651\u0643 \u0627\u0644\u0623\u0642\u0635\u0649 \u0627\u0644\u062D\u0627\u0644\u064A: {amount}",
  "{amount} left": "\u0645\u062A\u0628\u0642\u064D {amount}",
  "If everything you lead or requested goes through": "\u0625\u0630\u0627 \u062A\u0645\u0651 \u0643\u0644 \u0645\u0627 \u062A\u062A\u0635\u062F\u0631\u0647 \u0623\u0648 \u0637\u0644\u0628\u062A\u0647",
  "Nothing else you lead or requested yet": "\u0644\u0627 \u0634\u064A\u0621 \u0622\u062E\u0631 \u062A\u062A\u0635\u062F\u0631\u0647 \u0623\u0648 \u0637\u0644\u0628\u062A\u0647 \u0628\u0639\u062F",
  "Now": "\u0627\u0644\u0622\u0646",
  "With this bid": "\u0645\u0639 \u0647\u0630\u0647 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629",
  "Excluding VAT. Bids are binding, so plan within your budget.": "\u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629. \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0627\u062A \u0645\u0644\u0632\u0645\u0629\u060C \u0641\u062E\u0637\u0651\u0637 \u0636\u0645\u0646 \u0645\u064A\u0632\u0627\u0646\u064A\u062A\u0643.",
  // Listings, editing, auto-accept
  "Accepts automatically at the reserve": "\u064A\u0642\u0628\u0644 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627 \u0639\u0646\u062F \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u062F\u0646\u0649",
  "Accept automatically at the reserve": "\u0627\u0644\u0642\u0628\u0648\u0644 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A \u0639\u0646\u062F \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u062F\u0646\u0649",
  "When bidding closes at or above your reserve, the top bid is accepted for you and the buyer is asked to pay. Below the reserve, you still decide.": "\u0639\u0646\u062F \u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0639\u0646\u062F \u0633\u0639\u0631\u0643 \u0627\u0644\u0623\u062F\u0646\u0649 \u0623\u0648 \u0623\u0639\u0644\u0649 \u0645\u0646\u0647\u060C \u062A\u064F\u0642\u0628\u0644 \u0623\u0639\u0644\u0649 \u0645\u0632\u0627\u064A\u062F\u0629 \u0646\u064A\u0627\u0628\u0629 \u0639\u0646\u0643 \u0648\u064A\u064F\u0637\u0644\u0628 \u0645\u0646 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0627\u0644\u062F\u0641\u0639. \u0648\u062A\u062D\u062A \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u062F\u0646\u0649 \u064A\u0628\u0642\u0649 \u0627\u0644\u0642\u0631\u0627\u0631 \u0644\u0643.",
  "Set a reserve price first.": "\u062D\u062F\u0651\u062F \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u062F\u0646\u0649 \u0623\u0648\u0644\u064B\u0627.",
  "Give the placement a name.": "\u0623\u0639\u0637\u0650 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0627\u0633\u0645\u064B\u0627.",
  "Set a price.": "\u062D\u062F\u0651\u062F \u0633\u0639\u0631\u064B\u0627.",
  "The reserve cannot be above the buy-now price.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0623\u0646 \u064A\u062A\u062C\u0627\u0648\u0632 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u062F\u0646\u0649 \u0633\u0639\u0631 \u0627\u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0641\u0648\u0631\u064A.",
  "Changes reach every future slot nobody has bid on, straight away. Slots with bids keep the terms their buyers bid on. To change days, times or breaks, add a new placement and archive this one.": "\u062A\u0633\u0631\u064A \u0627\u0644\u062A\u063A\u064A\u064A\u0631\u0627\u062A \u0641\u0648\u0631\u064B\u0627 \u0639\u0644\u0649 \u0643\u0644 \u0645\u0633\u0627\u062D\u0629 \u0642\u0627\u062F\u0645\u0629 \u0644\u0645 \u064A\u0632\u0627\u064A\u062F \u0639\u0644\u064A\u0647\u0627 \u0623\u062D\u062F. \u0648\u062A\u062D\u062A\u0641\u0638 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u062A\u064A \u0639\u0644\u064A\u0647\u0627 \u0645\u0632\u0627\u064A\u062F\u0627\u062A \u0628\u0627\u0644\u0634\u0631\u0648\u0637 \u0627\u0644\u062A\u064A \u0632\u0627\u064A\u062F \u0639\u0644\u064A\u0647\u0627 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646. \u0644\u062A\u063A\u064A\u064A\u0631 \u0627\u0644\u0623\u064A\u0627\u0645 \u0623\u0648 \u0627\u0644\u0623\u0648\u0642\u0627\u062A \u0623\u0648 \u0627\u0644\u0641\u0648\u0627\u0635\u0644\u060C \u0623\u0636\u0641 \u0645\u0633\u0627\u062D\u0629 \u062C\u062F\u064A\u062F\u0629 \u0648\u0623\u0631\u0634\u0641 \u0647\u0630\u0647.",
  "Saved. 1 future slot now has the new terms.": "\u062D\u064F\u0641\u0638. \u0645\u0633\u0627\u062D\u0629 \u0642\u0627\u062F\u0645\u0629 \u0648\u0627\u062D\u062F\u0629 \u0635\u0627\u0631\u062A \u0628\u0627\u0644\u0634\u0631\u0648\u0637 \u0627\u0644\u062C\u062F\u064A\u062F\u0629.",
  "Saved. {n} future slots now have the new terms.": "\u062D\u064F\u0641\u0638. {n} \u0645\u0633\u0627\u062D\u0627\u062A \u0642\u0627\u062F\u0645\u0629 \u0635\u0627\u0631\u062A \u0628\u0627\u0644\u0634\u0631\u0648\u0637 \u0627\u0644\u062C\u062F\u064A\u062F\u0629.",
  "Back to listings": "\u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u0627\u0644\u0639\u0631\u0648\u0636",
  "Save changes": "\u062D\u0641\u0638 \u0627\u0644\u062A\u063A\u064A\u064A\u0631\u0627\u062A",
  // Logo and rate card
  "Use a JPEG or PNG image.": "\u0627\u0633\u062A\u062E\u062F\u0645 \u0635\u0648\u0631\u0629 JPEG \u0623\u0648 PNG.",
  "This image is {w}\xD7{h} pixels. Use one at least {min} pixels on each side.": "\u0623\u0628\u0639\u0627\u062F \u0647\u0630\u0647 \u0627\u0644\u0635\u0648\u0631\u0629 {w}\xD7{h} \u0628\u0643\u0633\u0644. \u0627\u0633\u062A\u062E\u062F\u0645 \u0635\u0648\u0631\u0629 \u0644\u0627 \u064A\u0642\u0644 \u0643\u0644 \u0636\u0644\u0639 \u0641\u064A\u0647\u0627 \u0639\u0646 {min} \u0628\u0643\u0633\u0644.",
  "The logo could not be uploaded.": "\u062A\u0639\u0630\u0651\u0631 \u0631\u0641\u0639 \u0627\u0644\u0634\u0639\u0627\u0631.",
  "Logo saved. Buyers see it now.": "\u062D\u064F\u0641\u0638 \u0627\u0644\u0634\u0639\u0627\u0631. \u064A\u0631\u0627\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0627\u0644\u0622\u0646.",
  "This image could not be read. Try another JPEG or PNG.": "\u062A\u0639\u0630\u0651\u0631\u062A \u0642\u0631\u0627\u0621\u0629 \u0647\u0630\u0647 \u0627\u0644\u0635\u0648\u0631\u0629. \u062C\u0631\u0651\u0628 \u0635\u0648\u0631\u0629 JPEG \u0623\u0648 PNG \u0623\u062E\u0631\u0649.",
  "The logo could not be removed.": "\u062A\u0639\u0630\u0651\u0631\u062A \u0625\u0632\u0627\u0644\u0629 \u0627\u0644\u0634\u0639\u0627\u0631.",
  "Logo removed. Your initials show instead.": "\u0623\u064F\u0632\u064A\u0644 \u0627\u0644\u0634\u0639\u0627\u0631. \u062A\u0638\u0647\u0631 \u0627\u0644\u0623\u062D\u0631\u0641 \u0627\u0644\u0623\u0648\u0644\u0649 \u0628\u062F\u0644\u064B\u0627 \u0645\u0646\u0647.",
  "Logo": "\u0627\u0644\u0634\u0639\u0627\u0631",
  "A square PNG or JPEG, at least {min} pixels. Transparent backgrounds stay transparent.": "\u0635\u0648\u0631\u0629 \u0645\u0631\u0628\u0639\u0629 PNG \u0623\u0648 JPEG\u060C \u0628\u062D\u062F \u0623\u062F\u0646\u0649 {min} \u0628\u0643\u0633\u0644. \u062A\u0628\u0642\u0649 \u0627\u0644\u062E\u0644\u0641\u064A\u0627\u062A \u0627\u0644\u0634\u0641\u0627\u0641\u0629 \u0634\u0641\u0627\u0641\u0629.",
  "Replace logo": "\u0627\u0633\u062A\u0628\u062F\u0627\u0644 \u0627\u0644\u0634\u0639\u0627\u0631",
  "Upload a logo": "\u0631\u0641\u0639 \u0634\u0639\u0627\u0631",
  "Rate card": "\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0623\u0633\u0639\u0627\u0631",
  "Not shared yet": "\u0644\u0645 \u062A\u064F\u0634\u0627\u0631\u064E\u0643 \u0628\u0639\u062F",
  "Rate card saved. Nashr uses it to set up your placements.": "\u062D\u064F\u0641\u0638\u062A \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0623\u0633\u0639\u0627\u0631. \u062A\u0633\u062A\u062E\u062F\u0645\u0647\u0627 \u0646\u0634\u0631 \u0644\u0625\u0639\u062F\u0627\u062F \u0645\u0633\u0627\u062D\u0627\u062A\u0643 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "Rate card removed.": "\u0623\u064F\u0632\u064A\u0644\u062A \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0623\u0633\u0639\u0627\u0631.",
  "Share your current rate card so Nashr can help set up your placements and prices. Only Nashr sees it.": "\u0634\u0627\u0631\u0643 \u0642\u0627\u0626\u0645\u0629 \u0623\u0633\u0639\u0627\u0631\u0643 \u0627\u0644\u062D\u0627\u0644\u064A\u0629 \u0644\u062A\u0633\u0627\u0639\u062F\u0643 \u0646\u0634\u0631 \u0641\u064A \u0625\u0639\u062F\u0627\u062F \u0645\u0633\u0627\u062D\u0627\u062A\u0643 \u0648\u0623\u0633\u0639\u0627\u0631\u0643. \u0644\u0627 \u064A\u0631\u0627\u0647\u0627 \u0625\u0644\u0627 \u0641\u0631\u064A\u0642 \u0646\u0634\u0631.",
  "Replace": "\u0627\u0633\u062A\u0628\u062F\u0627\u0644",
  "Uploading\u2026": "\u062C\u0627\u0631\u064D \u0627\u0644\u0631\u0641\u0639\u2026",
  "Upload your rate card": "\u0627\u0631\u0641\u0639 \u0642\u0627\u0626\u0645\u0629 \u0623\u0633\u0639\u0627\u0631\u0643",
  "PDF, spreadsheet or image": "PDF \u0623\u0648 \u062C\u062F\u0648\u0644 \u0628\u064A\u0627\u0646\u0627\u062A \u0623\u0648 \u0635\u0648\u0631\u0629",
  "You withdrew the request": "\u0633\u062D\u0628\u062A \u0627\u0644\u0637\u0644\u0628",
  "The buyer withdrew the request": "\u0633\u062D\u0628 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0627\u0644\u0637\u0644\u0628",
  "withdraw": "\u0633\u062D\u0628 \u0627\u0644\u0637\u0644\u0628",
  // Week calendar
  "Programme": "\u0627\u0644\u0628\u0631\u0627\u0645\u062C",
  "All day and packages": "\u0637\u0648\u0627\u0644 \u0627\u0644\u064A\u0648\u0645 \u0648\u0627\u0644\u0628\u0627\u0642\u0627\u062A",
  // Earnings and the payout statement
  "View statement": "\u0639\u0631\u0636 \u0627\u0644\u0643\u0634\u0641",
  "Back to earnings": "\u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u0627\u0644\u0623\u0631\u0628\u0627\u062D",
  "Previous month": "\u0627\u0644\u0634\u0647\u0631 \u0627\u0644\u0633\u0627\u0628\u0642",
  "Next month": "\u0627\u0644\u0634\u0647\u0631 \u0627\u0644\u062A\u0627\u0644\u064A",
  "Payout statement": "\u0643\u0634\u0641 \u0627\u0644\u062A\u062D\u0648\u064A\u0644\u0627\u062A",
  "From {name}": "\u0645\u0646 {name}",
  "Summary": "\u0627\u0644\u0645\u0644\u062E\u0635",
  "Balance at the start": "\u0627\u0644\u0631\u0635\u064A\u062F \u0641\u064A \u0627\u0644\u0628\u062F\u0627\u064A\u0629",
  "Released to you": "\u062D\u064F\u0631\u0651\u0631\u062A \u0644\u0643",
  "Balance at the end": "\u0627\u0644\u0631\u0635\u064A\u062F \u0641\u064A \u0627\u0644\u0646\u0647\u0627\u064A\u0629",
  "Movements": "\u0627\u0644\u062D\u0631\u0643\u0627\u062A",
  "Nothing moved this month.": "\u0644\u0627 \u062D\u0631\u0643\u0627\u062A \u0647\u0630\u0627 \u0627\u0644\u0634\u0647\u0631.",
  "What": "\u0627\u0644\u0628\u064A\u0627\u0646",
  "Change this month": "\u0627\u0644\u062A\u063A\u064A\u0651\u0631 \u0647\u0630\u0627 \u0627\u0644\u0634\u0647\u0631",
  "Deducted (refund costs)": "\u0645\u062E\u0635\u0648\u0645\u0629 (\u062A\u0643\u0627\u0644\u064A\u0641 \u0627\u0633\u062A\u0631\u062F\u0627\u062F)",
  "Deducted this month: {amount}. These are card costs of refunds that were your responsibility.": "\u0627\u0644\u0645\u062E\u0635\u0648\u0645 \u0647\u0630\u0627 \u0627\u0644\u0634\u0647\u0631: {amount}. \u0648\u0647\u064A \u0631\u0633\u0648\u0645 \u0628\u0637\u0627\u0642\u0627\u062A \u0644\u0645\u0628\u0627\u0644\u063A \u0645\u0633\u062A\u0631\u062F\u0629 \u0643\u0627\u0646\u062A \u0645\u0646 \u0645\u0633\u0624\u0648\u0644\u064A\u062A\u0643.",
  "Amounts released are your price plus VAT, less Nashr\u2019s commission. Nashr\u2019s commission invoices and the tax invoices to buyers are separate documents. This statement is not a tax document.": "\u0627\u0644\u0645\u0628\u0627\u0644\u063A \u0627\u0644\u0645\u062D\u0631\u0651\u0631\u0629 \u0647\u064A \u0633\u0639\u0631\u0643 \u0645\u0636\u0627\u0641\u064B\u0627 \u0625\u0644\u064A\u0647 \u0627\u0644\u0636\u0631\u064A\u0628\u0629\u060C \u0645\u062E\u0635\u0648\u0645\u064B\u0627 \u0645\u0646\u0647 \u0639\u0645\u0648\u0644\u0629 \u0646\u0634\u0631. \u0641\u0648\u0627\u062A\u064A\u0631 \u0639\u0645\u0648\u0644\u0629 \u0646\u0634\u0631 \u0648\u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629 \u0644\u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u0645\u0633\u062A\u0646\u062F\u0627\u062A \u0645\u0646\u0641\u0635\u0644\u0629. \u0647\u0630\u0627 \u0627\u0644\u0643\u0634\u0641 \u0644\u064A\u0633 \u0645\u0633\u062A\u0646\u062F\u064B\u0627 \u0636\u0631\u064A\u0628\u064A\u064B\u0627."
};

// web/src/i18n-ar-calendar.ts
var AR_CALENDAR = {
  "By outlet": "\u062D\u0633\u0628 \u0627\u0644\u0645\u0646\u0635\u0629",
  "Air time": "\u0648\u0642\u062A \u0627\u0644\u0628\u062B",
  "Closing soonest": "\u0627\u0644\u0623\u0642\u0631\u0628 \u0625\u063A\u0644\u0627\u0642\u064B\u0627",
  "Price: low to high": "\u0627\u0644\u0633\u0639\u0631: \u0645\u0646 \u0627\u0644\u0623\u0642\u0644 \u0625\u0644\u0649 \u0627\u0644\u0623\u0639\u0644\u0649",
  "Price: high to low": "\u0627\u0644\u0633\u0639\u0631: \u0645\u0646 \u0627\u0644\u0623\u0639\u0644\u0649 \u0625\u0644\u0649 \u0627\u0644\u0623\u0642\u0644",
  "Most bids": "\u0627\u0644\u0623\u0643\u062B\u0631 \u0645\u0632\u0627\u064A\u062F\u0627\u062A",
  "You bid": "\u0632\u0627\u064A\u062F\u062A",
  "{from} \u2013 {to}": "{from} \u2013 {to}",
  "open to book": "\u0645\u062A\u0627\u062D\u0629 \u0644\u0644\u062D\u062C\u0632",
  "Dates": "\u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E",
  "Today (T)": "\u0627\u0644\u064A\u0648\u0645 (T)",
  "Previous (\u2190)": "\u0627\u0644\u0633\u0627\u0628\u0642 (\u2192)",
  "Next (\u2192)": "\u0627\u0644\u062A\u0627\u0644\u064A (\u2190)",
  "Go to a date": "\u0627\u0644\u0627\u0646\u062A\u0642\u0627\u0644 \u0625\u0644\u0649 \u062A\u0627\u0631\u064A\u062E",
  "Go to date": "\u0627\u0646\u062A\u0642\u0644 \u0625\u0644\u0649 \u062A\u0627\u0631\u064A\u062E",
  "Search outlets, programmes, audiences": "\u0627\u0628\u062D\u062B \u0641\u064A \u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0648\u0627\u0644\u0628\u0631\u0627\u0645\u062C \u0648\u0627\u0644\u062C\u0645\u0627\u0647\u064A\u0631",
  "Filters ({n})": "\u0639\u0648\u0627\u0645\u0644 \u0627\u0644\u062A\u0635\u0641\u064A\u0629 ({n})",
  "Show {n} slots": "\u0639\u0631\u0636 {n} \u0645\u0633\u0627\u062D\u0629",
  "Show slots": "\u0639\u0631\u0636 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A",
  "Clear all": "\u0645\u0633\u062D \u0627\u0644\u0643\u0644",
  "Nothing matches these filters in this period.": "\u0644\u0627 \u0634\u064A\u0621 \u064A\u0637\u0627\u0628\u0642 \u0639\u0648\u0627\u0645\u0644 \u0627\u0644\u062A\u0635\u0641\u064A\u0629 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0641\u062A\u0631\u0629.",
  "Nothing open to book in this period.": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u062A\u0627\u062D \u0644\u0644\u062D\u062C\u0632 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0641\u062A\u0631\u0629.",
  "Bidding closes a few days before air, so the nearest days are often already closed.": "\u062A\u064F\u063A\u0644\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B \u0628\u0628\u0636\u0639\u0629 \u0623\u064A\u0627\u0645\u060C \u0644\u0630\u0627 \u062A\u0643\u0648\u0646 \u0627\u0644\u0623\u064A\u0627\u0645 \u0627\u0644\u0623\u0642\u0631\u0628 \u0645\u063A\u0644\u0642\u0629 \u063A\u0627\u0644\u0628\u064B\u0627.",
  "Jump to {date}": "\u0627\u0646\u062A\u0642\u0644 \u0625\u0644\u0649 {date}",
  "Dubai time. Prices exclude VAT. You pay only once the publisher accepts, and the money is held until the ad has run.": "\u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A. \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629. \u062A\u062F\u0641\u0639 \u0641\u0642\u0637 \u0628\u0639\u062F \u0645\u0648\u0627\u0641\u0642\u0629 \u0627\u0644\u0646\u0627\u0634\u0631\u060C \u0648\u064A\u064F\u062D\u062A\u062C\u0632 \u0627\u0644\u0645\u0628\u0644\u063A \u062D\u062A\u0649 \u064A\u064F\u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646.",
  "Shortcuts: \u2190 \u2192 move \xB7 T today \xB7 L D W M O views \xB7 / search": "\u0627\u0644\u0627\u062E\u062A\u0635\u0627\u0631\u0627\u062A: \u2190 \u2192 \u0644\u0644\u062A\u0646\u0642\u0644 \xB7 T \u0627\u0644\u064A\u0648\u0645 \xB7 L D W M O \u0637\u0631\u0642 \u0627\u0644\u0639\u0631\u0636 \xB7 / \u0627\u0644\u0628\u062D\u062B",
  "Only slots I bid on": "\u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u062A\u064A \u0632\u0627\u064A\u062F\u062A \u0639\u0644\u064A\u0647\u0627 \u0641\u0642\u0637",
  "Show taken and closed slots": "\u0625\u0638\u0647\u0627\u0631 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u0645\u062D\u062C\u0648\u0632\u0629 \u0648\u0627\u0644\u0645\u063A\u0644\u0642\u0629",
  "More filters": "\u0645\u0632\u064A\u062F \u0645\u0646 \u0639\u0648\u0627\u0645\u0644 \u0627\u0644\u062A\u0635\u0641\u064A\u0629",
  "Clear all ({n})": "\u0645\u0633\u062D \u0627\u0644\u0643\u0644 ({n})",
  "Slots": "\u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A",
  "Showing {n} of {total}": "\u0639\u0631\u0636 {n} \u0645\u0646 {total}",
  "Sort by": "\u0627\u0644\u062A\u0631\u062A\u064A\u0628 \u062D\u0633\u0628",
  "Sale": "\u0627\u0644\u0628\u064A\u0639",
  "Bids": "\u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0627\u062A",
  "top bid": "\u0623\u0639\u0644\u0649 \u0645\u0632\u0627\u064A\u062F\u0629",
  "Make an offer": "\u0642\u062F\u0651\u0645 \u0639\u0631\u0636\u064B\u0627",
  "Show {n} more": "\u0639\u0631\u0636 {n} \u0623\u062E\u0631\u0649",
  "{n} programmes": "{n} \u0628\u0631\u0627\u0645\u062C",
  "Open this day": "\u0627\u0641\u062A\u062D \u0647\u0630\u0627 \u0627\u0644\u064A\u0648\u0645",
  "+{n} more from {price}": "+{n} \u0623\u062E\u0631\u0649 \u0627\u0628\u062A\u062F\u0627\u0621\u064B \u0645\u0646 {price}",
  "programmes": "\u0628\u0631\u0627\u0645\u062C",
  "{n} slots": "{n} \u0645\u0633\u0627\u062D\u0627\u062A",
  "{n} outlets with slots this week": "{n} \u0645\u0646\u0635\u0627\u062A \u0644\u062F\u064A\u0647\u0627 \u0645\u0633\u0627\u062D\u0627\u062A \u0647\u0630\u0627 \u0627\u0644\u0623\u0633\u0628\u0648\u0639",
  "Lowest price": "\u0623\u0642\u0644 \u0633\u0639\u0631",
  "Most slots": "\u0627\u0644\u0623\u0643\u062B\u0631 \u0645\u0633\u0627\u062D\u0627\u062A",
  "Pages": "\u0627\u0644\u0635\u0641\u062D\u0627\u062A",
  "Page {n} of {total}": "\u0627\u0644\u0635\u0641\u062D\u0629 {n} \u0645\u0646 {total}",
  "Nothing here any more.": "\u0644\u0645 \u064A\u0639\u062F \u0647\u0646\u0627 \u0634\u064A\u0621.",
  // Publisher and Nashr calendars
  "Every slot on Nashr, from every publisher, in every status.": "\u0643\u0644 \u0645\u0633\u0627\u062D\u0629 \u0639\u0644\u0649 \u0646\u0634\u0631\u060C \u0645\u0646 \u0643\u0644 \u0646\u0627\u0634\u0631\u060C \u0628\u0643\u0644 \u062D\u0627\u0644\u0627\u062A\u0647\u0627.",
  "Search outlets, programmes, publishers": "\u0627\u0628\u062D\u062B \u0641\u064A \u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0648\u0627\u0644\u0628\u0631\u0627\u0645\u062C \u0648\u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646",
  "Dubai time. Prices exclude VAT. A booked or decided slot opens its deal.": "\u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A. \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629. \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0645\u062D\u062C\u0648\u0632\u0629 \u0623\u0648 \u0627\u0644\u062A\u064A \u0628\u064F\u062A\u0651 \u0641\u064A\u0647\u0627 \u062A\u0641\u062A\u062D \u0635\u0641\u0642\u062A\u0647\u0627.",
  "No slots match.": "\u0644\u0627 \u0645\u0633\u0627\u062D\u0627\u062A \u0645\u0637\u0627\u0628\u0642\u0629.",
  "Reserve": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u062F\u0646\u0649",
  "Bidding closes": "\u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629",
  "Your slots, bids and bookings. Dubai time.": "\u0645\u0633\u0627\u062D\u0627\u062A\u0643 \u0648\u0645\u0632\u0627\u064A\u062F\u0627\u062A\u0647\u0627 \u0648\u062D\u062C\u0648\u0632\u0627\u062A\u0647\u0627. \u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A.",
  "Search outlets and programmes": "\u0627\u0628\u062D\u062B \u0641\u064A \u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0648\u0627\u0644\u0628\u0631\u0627\u0645\u062C",
  "All outlets": "\u0643\u0644 \u0627\u0644\u0645\u0646\u0635\u0627\u062A",
  "Dubai time. Prices exclude VAT.": "\u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A. \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629.",
  "slot": "\u0645\u0633\u0627\u062D\u0629",
  "slots": "\u0645\u0633\u0627\u062D\u0627\u062A",
  // Getting started: invites and the first outlet
  "The passwords do not match.": "\u0643\u0644\u0645\u062A\u0627 \u0627\u0644\u0645\u0631\u0648\u0631 \u063A\u064A\u0631 \u0645\u062A\u0637\u0627\u0628\u0642\u062A\u064A\u0646.",
  "Not signed up yet.": "\u0644\u0645 \u064A\u064F\u0643\u0645\u0644 \u0627\u0644\u062A\u0633\u062C\u064A\u0644 \u0628\u0639\u062F.",
  "New invite link": "\u0631\u0627\u0628\u0637 \u062F\u0639\u0648\u0629 \u062C\u062F\u064A\u062F",
  "New invite link for {email}. The old link no longer works.": "\u0631\u0627\u0628\u0637 \u062F\u0639\u0648\u0629 \u062C\u062F\u064A\u062F \u0644\u0640 {email}. \u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0642\u062F\u064A\u0645 \u0644\u0645 \u064A\u0639\u062F \u064A\u0639\u0645\u0644.",
  "Your outlet": "\u0645\u0646\u0635\u062A\u0643",
  "The station, channel, publication or show buyers book with. You can add more later.": "\u0627\u0644\u0645\u062D\u0637\u0629 \u0623\u0648 \u0627\u0644\u0642\u0646\u0627\u0629 \u0623\u0648 \u0627\u0644\u0645\u0637\u0628\u0648\u0639\u0629 \u0623\u0648 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C \u0627\u0644\u0630\u064A \u064A\u062D\u062C\u0632 \u0641\u064A\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646. \u064A\u0645\u0643\u0646\u0643 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0645\u0632\u064A\u062F \u0644\u0627\u062D\u0642\u064B\u0627.",
  // Quick-sale interest: the publisher accepts one buyer
  "Interest sent": "\u0623\u064F\u0631\u0633\u0644 \u0627\u0644\u0627\u0647\u062A\u0645\u0627\u0645",
  "Interest sent. The publisher accepts one buyer before bidding closes; you will be told either way, and pay only if accepted.": "\u0623\u064F\u0631\u0633\u0644 \u0627\u0644\u0627\u0647\u062A\u0645\u0627\u0645. \u064A\u0642\u0628\u0644 \u0627\u0644\u0646\u0627\u0634\u0631 \u0645\u0634\u062A\u0631\u064A\u064B\u0627 \u0648\u0627\u062D\u062F\u064B\u0627 \u0642\u0628\u0644 \u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629\u060C \u0648\u0633\u062A\u064F\u0628\u0644\u064E\u0651\u063A \u0641\u064A \u0627\u0644\u062D\u0627\u0644\u062A\u064A\u0646\u060C \u0648\u0644\u0627 \u062A\u062F\u0641\u0639 \u0625\u0644\u0627 \u0625\u0630\u0627 \u0642\u064F\u0628\u0644\u062A.",
  "Buyer interested": "\u0645\u0634\u062A\u0631\u064D \u0645\u0647\u062A\u0645",
  "{n} buyers interested": "{n} \u0645\u0634\u062A\u0631\u064A\u0646 \u0645\u0647\u062A\u0645\u064A\u0646",
  "Accept one buyer by {when} to book it. The others are told the slot has gone. Unanswered interest lapses then.": "\u0627\u0642\u0628\u0644 \u0645\u0634\u062A\u0631\u064A\u064B\u0627 \u0648\u0627\u062D\u062F\u064B\u0627 \u0642\u0628\u0644 {when} \u0644\u062D\u062C\u0632\u0647\u0627. \u064A\u064F\u0628\u0644\u064E\u0651\u063A \u0627\u0644\u0622\u062E\u0631\u0648\u0646 \u0628\u0623\u0646 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u062D\u064F\u062C\u0632\u062A. \u0648\u064A\u0646\u062A\u0647\u064A \u0627\u0644\u0627\u0647\u062A\u0645\u0627\u0645 \u0627\u0644\u0630\u064A \u0644\u0645 \u064A\u064F\u0631\u062F \u0639\u0644\u064A\u0647 \u0639\u0646\u062F\u0647\u0627.",
  "A buyer is interested in {slot}. Accept to book it.": "\u0645\u0634\u062A\u0631\u064D \u0645\u0647\u062A\u0645 \u0628\u0640 {slot}. \u0627\u0642\u0628\u0644 \u0644\u062D\u062C\u0632\u0647\u0627.",
  "The publisher booked {slot} with another buyer.": "\u062D\u062C\u0632 \u0627\u0644\u0646\u0627\u0634\u0631 {slot} \u0644\u0645\u0634\u062A\u0631\u064D \u0622\u062E\u0631.",
  "The publisher did not take up your interest in {slot} before it closed.": "\u0644\u0645 \u064A\u0642\u0628\u0644 \u0627\u0644\u0646\u0627\u0634\u0631 \u0627\u0647\u062A\u0645\u0627\u0645\u0643 \u0628\u0640 {slot} \u0642\u0628\u0644 \u0627\u0644\u0625\u063A\u0644\u0627\u0642.",
  "Waiting for a decision": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0642\u0631\u0627\u0631",
  "Publisher deciding": "\u0627\u0644\u0646\u0627\u0634\u0631 \u064A\u0642\u0631\u0631",
  "Publisher choosing next bid": "\u0627\u0644\u0646\u0627\u0634\u0631 \u064A\u062E\u062A\u0627\u0631 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629",
  "AED {n}": "{n} \u062F\u0631\u0647\u0645",
  "My bids ({n})": "\u0639\u0631\u0648\u0636\u064A ({n})",
  "My bids": "\u0639\u0631\u0648\u0636\u064A",
  "Waiting for seller": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0646\u0627\u0634\u0631",
  "Accepted, pay now": "\u0645\u0642\u0628\u0648\u0644\u060C \u0627\u062F\u0641\u0639 \u0627\u0644\u0622\u0646",
  "Bid again": "\u0632\u0627\u064A\u062F \u0645\u062C\u062F\u062F\u064B\u0627",
  "Pay now": "\u0627\u062F\u0641\u0639 \u0627\u0644\u0622\u0646",
  "Ending now": "\u064A\u0646\u062A\u0647\u064A \u0627\u0644\u0622\u0646",
  "{d}d {h}h left": "\u0645\u062A\u0628\u0642\u064D\u0651 {d} \u064A {h} \u0633",
  "{h}h {m}m left": "\u0645\u062A\u0628\u0642\u064D\u0651 {h} \u0633 {m} \u062F",
  "{m}m left": "\u0645\u062A\u0628\u0642\u064D\u0651 {m} \u062F",
  "No bids in play. Click a price on the calendar to bid or book.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0639\u0631\u0648\u0636 \u062C\u0627\u0631\u064A\u0629. \u0627\u0646\u0642\u0631 \u0639\u0644\u0649 \u0623\u064A \u0633\u0639\u0631 \u0641\u064A \u0627\u0644\u062A\u0642\u0648\u064A\u0645 \u0644\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0623\u0648 \u0627\u0644\u062D\u062C\u0632.",
  "Closed": "\u0645\u063A\u0644\u0642",
  "1 bid": "\u0639\u0631\u0636 \u0648\u0627\u062D\u062F",
  "1 outlet": "\u0645\u0646\u0641\u0630 \u0648\u0627\u062D\u062F",
  "{n} outlets": "{n} \u0645\u0646\u0627\u0641\u0630",
  "1 product": "\u0645\u0646\u062A\u062C \u0648\u0627\u062D\u062F",
  "{n} products": "{n} \u0645\u0646\u062A\u062C\u0627\u062A",
  "Month": "\u0634\u0647\u0631",
  "Sectors": "\u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A",
  "Any sector": "\u0623\u064A \u0642\u0637\u0627\u0639",
  "Search outlets, programmes, sectors": "\u0627\u0628\u062D\u062B \u0639\u0646 \u0627\u0644\u0645\u0646\u0627\u0641\u0630 \u0648\u0627\u0644\u0628\u0631\u0627\u0645\u062C \u0648\u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A",
  "Shortcuts: arrow keys move \xB7 T today \xB7 D W M views \xB7 / search": "\u0627\u062E\u062A\u0635\u0627\u0631\u0627\u062A: \u0645\u0641\u0627\u062A\u064A\u062D \u0627\u0644\u0623\u0633\u0647\u0645 \u0644\u0644\u062A\u0646\u0642\u0644 \xB7 T \u0627\u0644\u064A\u0648\u0645 \xB7 D W M \u0637\u0631\u0642 \u0627\u0644\u0639\u0631\u0636 \xB7 / \u0628\u062D\u062B",
  "Nothing here in this period.": "\u0644\u0627 \u0634\u064A\u0621 \u0647\u0646\u0627 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0641\u062A\u0631\u0629.",
  "Prices in AED, before VAT": "\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0628\u0627\u0644\u062F\u0631\u0647\u0645\u060C \u0642\u0628\u0644 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629"
};

// web/src/i18n-ar-flow.ts
var AR_FLOW = {
  // Auto-bid
  "Your auto-bid maximum of {max} on {slot} was passed. Raise it to get back in front.": "\u062A\u062C\u0627\u0648\u0632 \u0623\u062D\u062F\u0647\u0645 \u0627\u0644\u062D\u062F \u0627\u0644\u0623\u0642\u0635\u0649 \u0644\u0645\u0632\u0627\u064A\u062F\u062A\u0643 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A\u0629 {max} \u0639\u0644\u0649 {slot}. \u0627\u0631\u0641\u0639\u0647 \u0644\u062A\u0639\u0648\u062F \u0625\u0644\u0649 \u0627\u0644\u0635\u062F\u0627\u0631\u0629.",
  "Auto-bid kept you in front on {slot}: you lead at {amount} (maximum {max}).": "\u0623\u0628\u0642\u062A\u0643 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A\u0629 \u0641\u064A \u0627\u0644\u0635\u062F\u0627\u0631\u0629 \u0639\u0644\u0649 {slot}: \u0623\u0646\u062A \u0627\u0644\u0623\u0639\u0644\u0649 \u0628\u0640{amount} (\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u0642\u0635\u0649 {max}).",
  "Auto-bid reached your maximum of {max} on {slot}. You still lead; raise it in case someone bids again.": "\u0628\u0644\u063A\u062A \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A\u0629 \u062D\u062F\u0643 \u0627\u0644\u0623\u0642\u0635\u0649 {max} \u0639\u0644\u0649 {slot}. \u0645\u0627 \u0632\u0644\u062A \u0641\u064A \u0627\u0644\u0635\u062F\u0627\u0631\u0629\u061B \u0627\u0631\u0641\u0639\u0647 \u062A\u062D\u0633\u0628\u064B\u0627 \u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u062C\u062F\u064A\u062F\u0629.",
  "Your bid is in, but another buyer's auto-bid is higher, so you are not leading. The top bid is now {top}. Bid at least {min}, or set a higher maximum.": "\u0633\u064F\u062C\u0651\u0644\u062A \u0645\u0632\u0627\u064A\u062F\u062A\u0643\u060C \u0644\u0643\u0646 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A\u0629 \u0644\u0645\u0634\u062A\u0631\u064D \u0622\u062E\u0631 \u0623\u0639\u0644\u0649\u060C \u0641\u0644\u0633\u062A \u0641\u064A \u0627\u0644\u0635\u062F\u0627\u0631\u0629. \u0623\u0639\u0644\u0649 \u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u0622\u0646 {top}. \u0632\u0627\u064A\u062F \u0628\u0640{min} \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644\u060C \u0623\u0648 \u062D\u062F\u0651\u062F \u062D\u062F\u064B\u0627 \u0623\u0642\u0635\u0649 \u0623\u0639\u0644\u0649.",
  "How to bid": "\u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629",
  "Single bid": "\u0645\u0632\u0627\u064A\u062F\u0629 \u0648\u0627\u062D\u062F\u0629",
  "New maximum (excl. VAT)": "\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u0642\u0635\u0649 \u0627\u0644\u062C\u062F\u064A\u062F (\u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629)",
  "Your maximum (excl. VAT)": "\u062D\u062F\u0643 \u0627\u0644\u0623\u0642\u0635\u0649 (\u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629)",
  "Raise your maximum": "\u0627\u0631\u0641\u0639 \u062D\u062F\u0643 \u0627\u0644\u0623\u0642\u0635\u0649",
  "You lead at {top}. Raising your maximum does not raise your bid; we only bid more when someone challenges you.": "\u0623\u0646\u062A \u0641\u064A \u0627\u0644\u0635\u062F\u0627\u0631\u0629 \u0628\u0640{top}. \u0631\u0641\u0639 \u062D\u062F\u0643 \u0627\u0644\u0623\u0642\u0635\u0649 \u0644\u0627 \u064A\u0631\u0641\u0639 \u0645\u0632\u0627\u064A\u062F\u062A\u0643\u061B \u0646\u0632\u0627\u064A\u062F \u0623\u0643\u062B\u0631 \u0641\u0642\u0637 \u0639\u0646\u062F\u0645\u0627 \u064A\u0646\u0627\u0641\u0633\u0643 \u0623\u062D\u062F.",
  "We bid {min} for you now, then only what it takes to stay ahead, in 3% steps, up to your maximum. Other buyers never see it. If you win, you pay the final bid, not your maximum.": "\u0646\u0632\u0627\u064A\u062F \u0639\u0646\u0643 \u0627\u0644\u0622\u0646 \u0628\u0640{min}\u060C \u062B\u0645 \u0628\u0645\u0627 \u064A\u0643\u0641\u064A \u0641\u0642\u0637 \u0644\u062A\u0628\u0642\u0649 \u0641\u064A \u0627\u0644\u0635\u062F\u0627\u0631\u0629\u060C \u0628\u062E\u0637\u0648\u0627\u062A 3%\u060C \u062D\u062A\u0649 \u062D\u062F\u0643 \u0627\u0644\u0623\u0642\u0635\u0649. \u0644\u0627 \u064A\u0631\u0627\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0627\u0644\u0622\u062E\u0631\u0648\u0646. \u0625\u0630\u0627 \u0641\u0632\u062A \u062A\u062F\u0641\u0639 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u0623\u062E\u064A\u0631\u0629\u060C \u0644\u0627 \u062D\u062F\u0643 \u0627\u0644\u0623\u0642\u0635\u0649.",
  "Auto-bid is on. You lead at {top}; we bid for you up to {max}.": "\u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A\u0629 \u0645\u0641\u0639\u0651\u0644\u0629. \u0623\u0646\u062A \u0641\u064A \u0627\u0644\u0635\u062F\u0627\u0631\u0629 \u0628\u0640{top}\u061B \u0646\u0632\u0627\u064A\u062F \u0639\u0646\u0643 \u062D\u062A\u0649 {max}.",
  "Raise maximum to {amount}": "\u0627\u0631\u0641\u0639 \u0627\u0644\u062D\u062F \u0627\u0644\u0623\u0642\u0635\u0649 \u0625\u0644\u0649 {amount}",
  "Start auto-bid up to {amount}": "\u0627\u0628\u062F\u0623 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A\u0629 \u062D\u062A\u0649 {amount}",
  "Your bid is in. You lead at {top}.": "\u0633\u064F\u062C\u0651\u0644\u062A \u0645\u0632\u0627\u064A\u062F\u062A\u0643. \u0623\u0646\u062A \u0641\u064A \u0627\u0644\u0635\u062F\u0627\u0631\u0629 \u0628\u0640{top}.",
  "You lead at {top}": "\u0623\u0646\u062A \u0641\u064A \u0627\u0644\u0635\u062F\u0627\u0631\u0629 \u0628\u0640{top}",
  "Auto-bid is on, up to {max}.": "\u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A\u0629 \u0645\u0641\u0639\u0651\u0644\u0629 \u062D\u062A\u0649 {max}.",
  "Your maximum is reached. Raise it to stay ahead if someone bids.": "\u0628\u0644\u063A\u062A \u062D\u062F\u0643 \u0627\u0644\u0623\u0642\u0635\u0649. \u0627\u0631\u0641\u0639\u0647 \u0644\u062A\u0628\u0642\u0649 \u0641\u064A \u0627\u0644\u0635\u062F\u0627\u0631\u0629 \u0625\u0646 \u0632\u0627\u064A\u062F \u0623\u062D\u062F.",
  "Turn on auto-bid to stay ahead without watching.": "\u0641\u0639\u0651\u0644 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A\u0629 \u0644\u062A\u0628\u0642\u0649 \u0641\u064A \u0627\u0644\u0635\u062F\u0627\u0631\u0629 \u062F\u0648\u0646 \u0645\u062A\u0627\u0628\u0639\u0629.",
  "Outbid: the top bid is {top}": "\u062A\u062C\u0627\u0648\u0632\u0643 \u0623\u062D\u062F\u0647\u0645: \u0623\u0639\u0644\u0649 \u0645\u0632\u0627\u064A\u062F\u0629 {top}",
  "Your maximum of {max} was passed. Set a higher one to get back in front.": "\u062A\u062C\u0627\u0648\u0632 \u0623\u062D\u062F\u0647\u0645 \u062D\u062F\u0643 \u0627\u0644\u0623\u0642\u0635\u0649 {max}. \u062D\u062F\u0651\u062F \u062D\u062F\u064B\u0627 \u0623\u0639\u0644\u0649 \u0644\u062A\u0639\u0648\u062F \u0625\u0644\u0649 \u0627\u0644\u0635\u062F\u0627\u0631\u0629.",
  "Bid again, or let auto-bid do it up to a maximum.": "\u0632\u0627\u064A\u062F \u0645\u062C\u062F\u062F\u064B\u0627\u060C \u0623\u0648 \u062F\u0639 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A\u0629 \u062A\u0641\u0639\u0644 \u0630\u0644\u0643 \u062D\u062A\u0649 \u062D\u062F \u0623\u0642\u0635\u0649.",
  // Add placement
  "What you get": "\u0645\u0627 \u062A\u062D\u0635\u0644 \u0639\u0644\u064A\u0647",
  "Creative specs": "\u0645\u0648\u0627\u0635\u0641\u0627\u062A \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Ad language": "\u0644\u063A\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  "Competitive separation: another {industry} advertiser is already booked with this outlet on the same day. You can still accept it.": "\u0627\u0644\u0641\u0635\u0644 \u0628\u064A\u0646 \u0627\u0644\u0645\u0646\u0627\u0641\u0633\u064A\u0646: \u0645\u0639\u0644\u0646 \u0622\u062E\u0631 \u0645\u0646 \u0642\u0637\u0627\u0639 {industry} \u0645\u062D\u062C\u0648\u0632 \u0644\u062F\u0649 \u0647\u0630\u0647 \u0627\u0644\u0645\u0646\u0635\u0629 \u0641\u064A \u0627\u0644\u064A\u0648\u0645 \u0646\u0641\u0633\u0647. \u0644\u0627 \u064A\u0632\u0627\u0644 \u0628\u0625\u0645\u0643\u0627\u0646\u0643 \u0627\u0644\u0642\u0628\u0648\u0644.",
  "Import a rate card file": "\u0627\u0633\u062A\u064A\u0631\u0627\u062F \u0645\u0644\u0641 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0623\u0633\u0639\u0627\u0631",
  "A whole week from {day}": "\u0623\u0633\u0628\u0648\u0639 \u0643\u0627\u0645\u0644 \u0645\u0646 {day}",
  "Kept {n} weeks ahead": "\u0645\u0639\u0631\u0648\u0636\u0629 {n} \u0623\u0633\u0627\u0628\u064A\u0639 \u0645\u0642\u062F\u0645\u064B\u0627",
  "Duplicate": "\u0646\u0633\u062E",
  "What the buyer gets": "\u0645\u0627 \u064A\u062D\u0635\u0644 \u0639\u0644\u064A\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "Listing": "\u0627\u0644\u0639\u0631\u0636",
  "How long it stays on sale": "\u0645\u062F\u0629 \u0628\u0642\u0627\u0626\u0647\u0627 \u0645\u0639\u0631\u0648\u0636\u0629 \u0644\u0644\u0628\u064A\u0639",
  "Keep it on sale": "\u0623\u0628\u0642\u0650\u0647\u0627 \u0645\u0639\u0631\u0648\u0636\u0629",
  "I list weeks myself": "\u0623\u0639\u0631\u0636 \u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0628\u0646\u0641\u0633\u064A",
  "Weeks ahead": "\u0639\u062F\u062F \u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0645\u0642\u062F\u0645\u064B\u0627",
  "{n} weeks": "{n} \u0623\u0633\u0627\u0628\u064A\u0639",
  "Competitive separation": "\u0627\u0644\u0641\u0635\u0644 \u0628\u064A\u0646 \u0627\u0644\u0645\u0646\u0627\u0641\u0633\u064A\u0646",
  "Warn me before I accept a booking when an advertiser in the same industry is already booked on that day.": "\u0646\u0628\u0651\u0647\u0646\u064A \u0642\u0628\u0644 \u0642\u0628\u0648\u0644 \u062D\u062C\u0632 \u0625\u0630\u0627 \u0643\u0627\u0646 \u0645\u0639\u0644\u0646 \u0645\u0646 \u0627\u0644\u0642\u0637\u0627\u0639 \u0646\u0641\u0633\u0647 \u0645\u062D\u062C\u0648\u0632\u064B\u0627 \u0641\u064A \u0630\u0644\u0643 \u0627\u0644\u064A\u0648\u0645.",
  "Spots in a programme": "\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u062F\u0627\u062E\u0644 \u0628\u0631\u0646\u0627\u0645\u062C",
  "Morning Drive": "\u0628\u0631\u0646\u0627\u0645\u062C \u0627\u0644\u0635\u0628\u0627\u062D",
  "30-second spots in the ad breaks of a programme": "\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0645\u062F\u062A\u0647\u0627 30 \u062B\u0627\u0646\u064A\u0629 \u0641\u064A \u0641\u0648\u0627\u0635\u0644 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C",
  "A 30-second spot in one ad break of the programme.": "\u0625\u0639\u0644\u0627\u0646 \u0645\u062F\u062A\u0647 30 \u062B\u0627\u0646\u064A\u0629 \u0641\u064A \u0623\u062D\u062F \u0641\u0648\u0627\u0635\u0644 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C.",
  "MP3 or WAV, 30 seconds, broadcast-ready.": "MP3 \u0623\u0648 WAV\u060C \u0645\u062F\u062A\u0647 30 \u062B\u0627\u0646\u064A\u0629\u060C \u062C\u0627\u0647\u0632 \u0644\u0644\u0628\u062B.",
  "Programme sponsorship": "\u0631\u0639\u0627\u064A\u0629 \u0628\u0631\u0646\u0627\u0645\u062C",
  "Your brand presents the whole programme": "\u0639\u0644\u0627\u0645\u062A\u0643 \u062A\u0642\u062F\u0651\u0645 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C \u0643\u0627\u0645\u0644\u064B\u0627",
  "Opening and closing credits naming your brand, plus two mentions during the programme.": "\u0630\u0643\u0631 \u0639\u0644\u0627\u0645\u062A\u0643 \u0641\u064A \u0628\u062F\u0627\u064A\u0629 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C \u0648\u0646\u0647\u0627\u064A\u062A\u0647\u060C \u0625\u0636\u0627\u0641\u0629 \u0625\u0644\u0649 \u0625\u0634\u0627\u0631\u062A\u064A\u0646 \u062E\u0644\u0627\u0644\u0647.",
  "Brand name and a tag line of up to 10 seconds, as text or audio.": "\u0627\u0633\u0645 \u0627\u0644\u0639\u0644\u0627\u0645\u0629 \u0648\u0634\u0639\u0627\u0631 \u0644\u0627 \u064A\u062A\u062C\u0627\u0648\u0632 10 \u062B\u0648\u0627\u0646\u064D\u060C \u0646\u0635\u064B\u0627 \u0623\u0648 \u0635\u0648\u062A\u064B\u0627.",
  "Live read": "\u0642\u0631\u0627\u0621\u0629 \u0645\u0628\u0627\u0634\u0631\u0629",
  "The presenter reads your message live": "\u064A\u0642\u0631\u0623 \u0627\u0644\u0645\u0630\u064A\u0639 \u0631\u0633\u0627\u0644\u062A\u0643 \u0639\u0644\u0649 \u0627\u0644\u0647\u0648\u0627\u0621",
  "The presenter reads your message live, about 60 seconds.": "\u064A\u0642\u0631\u0623 \u0627\u0644\u0645\u0630\u064A\u0639 \u0631\u0633\u0627\u0644\u062A\u0643 \u0639\u0644\u0649 \u0627\u0644\u0647\u0648\u0627\u0621\u060C \u0646\u062D\u0648 60 \u062B\u0627\u0646\u064A\u0629.",
  "Script of up to 150 words in the ad language.": "\u0646\u0635 \u0644\u0627 \u064A\u062A\u062C\u0627\u0648\u0632 150 \u0643\u0644\u0645\u0629 \u0628\u0644\u063A\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646.",
  "Prime time": "\u0648\u0642\u062A \u0627\u0644\u0630\u0631\u0648\u0629",
  "MP4 (H.264), 1920 \xD7 1080, 30 seconds, loudness \u221223 LUFS.": "MP4 (H.264)\u060C 1920 \xD7 1080\u060C \u0645\u062F\u062A\u0647 30 \u062B\u0627\u0646\u064A\u0629\u060C \u0645\u0633\u062A\u0648\u0649 \u0627\u0644\u0635\u0648\u062A \u221223 LUFS.",
  "Billboards at the start and end of each episode": "\u0644\u0648\u062D\u0629 \u0631\u0639\u0627\u064A\u0629 \u0641\u064A \u0628\u062F\u0627\u064A\u0629 \u0643\u0644 \u062D\u0644\u0642\u0629 \u0648\u0646\u0647\u0627\u064A\u062A\u0647\u0627",
  "A 5-second billboard before and after the episode, and your logo on screen during it.": "\u0644\u0648\u062D\u0629 \u0631\u0639\u0627\u064A\u0629 \u0645\u062F\u062A\u0647\u0627 5 \u062B\u0648\u0627\u0646\u064D \u0642\u0628\u0644 \u0627\u0644\u062D\u0644\u0642\u0629 \u0648\u0628\u0639\u062F\u0647\u0627\u060C \u0648\u0634\u0639\u0627\u0631\u0643 \u0639\u0644\u0649 \u0627\u0644\u0634\u0627\u0634\u0629 \u062E\u0644\u0627\u0644\u0647\u0627.",
  "5-second billboard, MP4 1920 \xD7 1080, and a logo as PNG.": "\u0644\u0648\u062D\u0629 \u0631\u0639\u0627\u064A\u0629 \u0645\u062F\u062A\u0647\u0627 5 \u062B\u0648\u0627\u0646\u064D \u0628\u0635\u064A\u063A\u0629 MP4 \u0628\u062F\u0642\u0629 1920 \xD7 1080\u060C \u0648\u0634\u0639\u0627\u0631 \u0628\u0635\u064A\u063A\u0629 PNG.",
  "A full page in one edition": "\u0635\u0641\u062D\u0629 \u0643\u0627\u0645\u0644\u0629 \u0641\u064A \u0639\u062F\u062F \u0648\u0627\u062D\u062F",
  "A full page in one edition.": "\u0635\u0641\u062D\u0629 \u0643\u0627\u0645\u0644\u0629 \u0641\u064A \u0639\u062F\u062F \u0648\u0627\u062D\u062F.",
  "26 \xD7 36 cm, PDF/X-1a, 300 dpi.": "26 \xD7 36 \u0633\u0645\u060C PDF/X-1a\u060C \u0628\u062F\u0642\u0629 300 \u0646\u0642\u0637\u0629.",
  "Half page": "\u0646\u0635\u0641 \u0635\u0641\u062D\u0629",
  "A horizontal half page in one edition": "\u0646\u0635\u0641 \u0635\u0641\u062D\u0629 \u0623\u0641\u0642\u064A \u0641\u064A \u0639\u062F\u062F \u0648\u0627\u062D\u062F",
  "A horizontal half page in one edition.": "\u0646\u0635\u0641 \u0635\u0641\u062D\u0629 \u0623\u0641\u0642\u064A \u0641\u064A \u0639\u062F\u062F \u0648\u0627\u062D\u062F.",
  "26 \xD7 17 cm, PDF/X-1a, 300 dpi.": "26 \xD7 17 \u0633\u0645\u060C PDF/X-1a\u060C \u0628\u062F\u0642\u0629 300 \u0646\u0642\u0637\u0629.",
  "Front-page strip": "\u0634\u0631\u064A\u0637 \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0623\u0648\u0644\u0649",
  "The strip across the bottom of the front page": "\u0627\u0644\u0634\u0631\u064A\u0637 \u0623\u0633\u0641\u0644 \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0623\u0648\u0644\u0649",
  "The strip across the bottom of the front page, one edition.": "\u0627\u0644\u0634\u0631\u064A\u0637 \u0623\u0633\u0641\u0644 \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0623\u0648\u0644\u0649\u060C \u0641\u064A \u0639\u062F\u062F \u0648\u0627\u062D\u062F.",
  "25 cm \xD7 5 columns, PDF/X-1a, 300 dpi.": "25 \u0633\u0645 \xD7 5 \u0623\u0639\u0645\u062F\u0629\u060C PDF/X-1a\u060C \u0628\u062F\u0642\u0629 300 \u0646\u0642\u0637\u0629.",
  "Magazine page": "\u0635\u0641\u062D\u0629 \u0645\u062C\u0644\u0629",
  "A page in a weekly issue, sold by the week": "\u0635\u0641\u062D\u0629 \u0641\u064A \u0639\u062F\u062F \u0623\u0633\u0628\u0648\u0639\u064A\u060C \u062A\u064F\u0628\u0627\u0639 \u0628\u0627\u0644\u0623\u0633\u0628\u0648\u0639",
  "A full page in one weekly issue.": "\u0635\u0641\u062D\u0629 \u0643\u0627\u0645\u0644\u0629 \u0641\u064A \u0639\u062F\u062F \u0623\u0633\u0628\u0648\u0639\u064A \u0648\u0627\u062D\u062F.",
  "21 \xD7 28 cm with 3 mm bleed, PDF/X-1a, 300 dpi.": "21 \xD7 28 \u0633\u0645 \u0645\u0639 \u0647\u0627\u0645\u0634 \u0642\u0635 3 \u0645\u0645\u060C PDF/X-1a\u060C \u0628\u062F\u0642\u0629 300 \u0646\u0642\u0637\u0629.",
  "Homepage takeover": "\u0627\u0644\u0627\u0633\u062A\u062D\u0648\u0627\u0630 \u0639\u0644\u0649 \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629",
  "The whole homepage for 24 hours": "\u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629 \u0643\u0627\u0645\u0644\u0629 \u0644\u0645\u062F\u0629 24 \u0633\u0627\u0639\u0629",
  "Your brand on the homepage skin and the main banner for 24 hours.": "\u0639\u0644\u0627\u0645\u062A\u0643 \u0639\u0644\u0649 \u062E\u0644\u0641\u064A\u0629 \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629 \u0648\u0627\u0644\u0628\u0627\u0646\u0631 \u0627\u0644\u0631\u0626\u064A\u0633\u064A \u0644\u0645\u062F\u0629 24 \u0633\u0627\u0639\u0629.",
  "Skin 1920 \xD7 1080 and MPU 300 \xD7 250, HTML5 or JPG, up to 150 KB.": "\u062E\u0644\u0641\u064A\u0629 1920 \xD7 1080 \u0648\u0625\u0639\u0644\u0627\u0646 MPU \u0628\u062D\u062C\u0645 300 \xD7 250\u060C HTML5 \u0623\u0648 JPG\u060C \u062D\u062A\u0649 150 \u0643\u064A\u0644\u0648\u0628\u0627\u064A\u062A.",
  "Banner for a week": "\u0628\u0627\u0646\u0631 \u0644\u0645\u062F\u0629 \u0623\u0633\u0628\u0648\u0639",
  "Run-of-site banners, Monday to Sunday": "\u0628\u0627\u0646\u0631\u0627\u062A \u0641\u064A \u0623\u0646\u062D\u0627\u0621 \u0627\u0644\u0645\u0648\u0642\u0639\u060C \u0645\u0646 \u0627\u0644\u0627\u062B\u0646\u064A\u0646 \u0625\u0644\u0649 \u0627\u0644\u0623\u062D\u062F",
  "Your banners across the site for seven days.": "\u0628\u0627\u0646\u0631\u0627\u062A\u0643 \u0641\u064A \u0623\u0646\u062D\u0627\u0621 \u0627\u0644\u0645\u0648\u0642\u0639 \u0644\u0645\u062F\u0629 \u0633\u0628\u0639\u0629 \u0623\u064A\u0627\u0645.",
  "MPU 300 \xD7 250 and leaderboard 728 \xD7 90, JPG, PNG or HTML5, up to 150 KB.": "MPU \u0628\u062D\u062C\u0645 300 \xD7 250 \u0648\u0628\u0627\u0646\u0631 \u0639\u0644\u0648\u064A 728 \xD7 90\u060C JPG \u0623\u0648 PNG \u0623\u0648 HTML5\u060C \u062D\u062A\u0649 150 \u0643\u064A\u0644\u0648\u0628\u0627\u064A\u062A.",
  "Newsletter sponsorship": "\u0631\u0639\u0627\u064A\u0629 \u0627\u0644\u0646\u0634\u0631\u0629 \u0627\u0644\u0628\u0631\u064A\u062F\u064A\u0629",
  "A featured block in one newsletter send": "\u0645\u0633\u0627\u062D\u0629 \u0645\u0645\u064A\u0632\u0629 \u0641\u064A \u0625\u0631\u0633\u0627\u0644 \u0648\u0627\u062D\u062F \u0644\u0644\u0646\u0634\u0631\u0629",
  "A featured block in one send to the newsletter list.": "\u0645\u0633\u0627\u062D\u0629 \u0645\u0645\u064A\u0632\u0629 \u0641\u064A \u0625\u0631\u0633\u0627\u0644 \u0648\u0627\u062D\u062F \u0625\u0644\u0649 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0646\u0634\u0631\u0629.",
  "Logo 600 \xD7 200 PNG, 40 words of text and a link.": "\u0634\u0639\u0627\u0631 PNG \u0628\u062D\u062C\u0645 600 \xD7 200\u060C \u0648\u0646\u0635 \u0645\u0646 40 \u0643\u0644\u0645\u0629 \u0648\u0631\u0627\u0628\u0637.",
  "Sponsored article": "\u0645\u0642\u0627\u0644 \u0628\u0631\u0639\u0627\u064A\u0629",
  "A labelled article that stays published": "\u0645\u0642\u0627\u0644 \u0645\u0648\u0633\u0648\u0645 \u064A\u0628\u0642\u0649 \u0645\u0646\u0634\u0648\u0631\u064B\u0627",
  'An article labelled "Sponsored", published on the day and shared once on social media.': '\u0645\u0642\u0627\u0644 \u0645\u0648\u0633\u0648\u0645 \u0628\u0640"\u0628\u0631\u0639\u0627\u064A\u0629"\u060C \u064A\u064F\u0646\u0634\u0631 \u0641\u064A \u0627\u0644\u064A\u0648\u0645 \u0627\u0644\u0645\u062D\u062F\u062F \u0648\u064A\u064F\u0634\u0627\u0631\u0643 \u0645\u0631\u0629 \u0639\u0644\u0649 \u0648\u0633\u0627\u0626\u0644 \u0627\u0644\u062A\u0648\u0627\u0635\u0644.',
  "600\u2013800 words and 3 images (JPG, 1600 px wide).": "600\u2013800 \u0643\u0644\u0645\u0629 \u06483 \u0635\u0648\u0631 (JPG \u0628\u0639\u0631\u0636 1600 \u0628\u0643\u0633\u0644).",
  "Sponsored contest": "\u0645\u0633\u0627\u0628\u0642\u0629 \u0628\u0631\u0639\u0627\u064A\u0629",
  "A contest page for seven days": "\u0635\u0641\u062D\u0629 \u0645\u0633\u0627\u0628\u0642\u0629 \u0644\u0645\u062F\u0629 \u0633\u0628\u0639\u0629 \u0623\u064A\u0627\u0645",
  "A contest page with your prize for seven days, promoted twice.": "\u0635\u0641\u062D\u0629 \u0645\u0633\u0627\u0628\u0642\u0629 \u0628\u062C\u0627\u0626\u0632\u062A\u0643 \u0644\u0645\u062F\u0629 \u0633\u0628\u0639\u0629 \u0623\u064A\u0627\u0645\u060C \u0645\u0639 \u062A\u0631\u0648\u064A\u062C \u0645\u0631\u062A\u064A\u0646.",
  "Prize text (100 words), hero image 1200 \xD7 630 and a link to the terms.": "\u0646\u0635 \u0627\u0644\u062C\u0627\u0626\u0632\u0629 (100 \u0643\u0644\u0645\u0629)\u060C \u0648\u0635\u0648\u0631\u0629 \u0631\u0626\u064A\u0633\u064A\u0629 1200 \xD7 630\u060C \u0648\u0631\u0627\u0628\u0637 \u0644\u0644\u0634\u0631\u0648\u0637.",
  "Ad positions in an episode": "\u0645\u0648\u0627\u0636\u0639 \u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0641\u064A \u0627\u0644\u062D\u0644\u0642\u0629",
  "Pre-roll, mid-roll and post-roll, each sold on its own": "\u0642\u0628\u0644 \u0627\u0644\u062D\u0644\u0642\u0629 \u0648\u0648\u0633\u0637\u0647\u0627 \u0648\u0628\u0639\u062F\u0647\u0627\u060C \u0643\u0644 \u0645\u0648\u0636\u0639 \u064A\u064F\u0628\u0627\u0639 \u0648\u062D\u062F\u0647",
  "Pre-roll": "\u0642\u0628\u0644 \u0627\u0644\u062D\u0644\u0642\u0629",
  "Mid-roll": "\u0648\u0633\u0637 \u0627\u0644\u062D\u0644\u0642\u0629",
  "Post-roll": "\u0628\u0639\u062F \u0627\u0644\u062D\u0644\u0642\u0629",
  "A host-read or produced ad in one position of the episode.": "\u0625\u0639\u0644\u0627\u0646 \u064A\u0642\u0631\u0624\u0647 \u0627\u0644\u0645\u0642\u062F\u0651\u0645 \u0623\u0648 \u0625\u0639\u0644\u0627\u0646 \u062C\u0627\u0647\u0632 \u0641\u064A \u0645\u0648\u0636\u0639 \u0648\u0627\u062D\u062F \u0645\u0646 \u0627\u0644\u062D\u0644\u0642\u0629.",
  "MP3, 48 kHz, or a script for the host to read.": "MP3 \u0628\u062A\u0631\u062F\u062F 48 \u0643\u064A\u0644\u0648\u0647\u0631\u062A\u0632\u060C \u0623\u0648 \u0646\u0635 \u064A\u0642\u0631\u0624\u0647 \u0627\u0644\u0645\u0642\u062F\u0651\u0645.",
  "Episode sponsorship": "\u0631\u0639\u0627\u064A\u0629 \u062D\u0644\u0642\u0629",
  "Your brand presents a whole episode": "\u0639\u0644\u0627\u0645\u062A\u0643 \u062A\u0642\u062F\u0651\u0645 \u062D\u0644\u0642\u0629 \u0643\u0627\u0645\u0644\u0629",
  "The episode is presented by your brand, with a mention at the start and end.": "\u062A\u064F\u0642\u062F\u064E\u0651\u0645 \u0627\u0644\u062D\u0644\u0642\u0629 \u0628\u0631\u0639\u0627\u064A\u0629 \u0639\u0644\u0627\u0645\u062A\u0643\u060C \u0645\u0639 \u0630\u0643\u0631\u0647\u0627 \u0641\u064A \u0627\u0644\u0628\u062F\u0627\u064A\u0629 \u0648\u0627\u0644\u0646\u0647\u0627\u064A\u0629.",
  "Brand name and a 30-second message as a script.": "\u0627\u0633\u0645 \u0627\u0644\u0639\u0644\u0627\u0645\u0629 \u0648\u0631\u0633\u0627\u0644\u0629 \u0645\u062F\u062A\u0647\u0627 30 \u062B\u0627\u0646\u064A\u0629 \u0646\u0635\u064B\u0627.",
  "{name} (copy)": "{name} (\u0646\u0633\u062E\u0629)",
  "{name} is saved": "\u062D\u064F\u0641\u0638\u062A {name}",
  "{n} slots are on sale, the first on {date}.": "{n} \u0645\u0633\u0627\u062D\u0629 \u0645\u0639\u0631\u0648\u0636\u0629 \u0644\u0644\u0628\u064A\u0639\u060C \u0623\u0648\u0644\u0647\u0627 \u0641\u064A {date}.",
  "Nothing is on sale yet. List weeks from Listings when you are ready.": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u0639\u0631\u0648\u0636 \u0644\u0644\u0628\u064A\u0639 \u0628\u0639\u062F. \u0627\u0639\u0631\u0636 \u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u0639\u0631\u0648\u0636 \u0639\u0646\u062F\u0645\u0627 \u062A\u0643\u0648\u0646 \u062C\u0627\u0647\u0632\u064B\u0627.",
  "See it on the calendar": "\u0627\u0639\u0631\u0636\u0647\u0627 \u0641\u064A \u0627\u0644\u062A\u0642\u0648\u064A\u0645",
  "Add another": "\u0623\u0636\u0641 \u0623\u062E\u0631\u0649",
  "Choose the days it runs.": "\u0627\u062E\u062A\u0631 \u0623\u064A\u0627\u0645 \u0627\u0644\u0628\u062B.",
  "The buy-now price must be above the starting price.": "\u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0633\u0639\u0631 \u0627\u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0641\u0648\u0631\u064A \u0623\u0639\u0644\u0649 \u0645\u0646 \u0633\u0639\u0631 \u0627\u0644\u0628\u062F\u0627\u064A\u0629.",
  "Set the deadlines in days.": "\u062D\u062F\u0651\u062F \u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F \u0628\u0627\u0644\u0623\u064A\u0627\u0645.",
  "With these settings, bidding must close at least {n} days before air.": "\u0628\u0647\u0630\u0647 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A\u060C \u064A\u062C\u0628 \u0623\u0646 \u062A\u064F\u063A\u0644\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B \u0628\u0640{n} \u0623\u064A\u0627\u0645 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
  "The end time must be after the start time.": "\u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0648\u0642\u062A \u0627\u0644\u0627\u0646\u062A\u0647\u0627\u0621 \u0628\u0639\u062F \u0648\u0642\u062A \u0627\u0644\u0628\u062F\u0621.",
  "position": "\u0645\u0648\u0636\u0639",
  "What you're selling": "\u0645\u0627 \u062A\u0628\u064A\u0639\u0647",
  "Format": "\u0627\u0644\u0635\u064A\u063A\u0629",
  "Start from a blank form": "\u0627\u0628\u062F\u0623 \u0628\u0646\u0645\u0648\u0630\u062C \u0641\u0627\u0631\u063A",
  "Name buyers see": "\u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0630\u064A \u064A\u0631\u0627\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646",
  "Buyers read this before they bid. Emails and phone numbers are not allowed.": "\u064A\u0642\u0631\u0623 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0647\u0630\u0627 \u0642\u0628\u0644 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629. \u0644\u0627 \u064A\u064F\u0633\u0645\u062D \u0628\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0648\u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0647\u0627\u062A\u0641.",
  "When it runs": "\u0645\u0648\u0639\u062F \u0627\u0644\u0628\u062B",
  "Sold by": "\u064A\u064F\u0628\u0627\u0639 \u062D\u0633\u0628",
  "Each edition": "\u0643\u0644 \u0639\u062F\u062F",
  "Each day": "\u0643\u0644 \u064A\u0648\u0645",
  "A whole week": "\u0623\u0633\u0628\u0648\u0639 \u0643\u0627\u0645\u0644",
  "The week starts on": "\u064A\u0628\u062F\u0623 \u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u064A\u0648\u0645",
  "Mon\u2013Fri": "\u0627\u0644\u0625\u062B\u0646\u064A\u0646\u2013\u0627\u0644\u062C\u0645\u0639\u0629",
  "Every day": "\u0643\u0644 \u064A\u0648\u0645",
  "Weekend": "\u0639\u0637\u0644\u0629 \u0646\u0647\u0627\u064A\u0629 \u0627\u0644\u0623\u0633\u0628\u0648\u0639",
  "Edition time (optional)": "\u0648\u0642\u062A \u0635\u062F\u0648\u0631 \u0627\u0644\u0639\u062F\u062F (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Goes live at (optional)": "\u064A\u064F\u0646\u0634\u0631 \u0641\u064A (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Programme starts": "\u064A\u0628\u062F\u0623 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C",
  "Dubai time. Leave empty for the whole day. Overnight like 23:00\u201302:00 works.": "\u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A. \u0627\u062A\u0631\u0643\u0647 \u0641\u0627\u0631\u063A\u064B\u0627 \u0644\u0644\u064A\u0648\u0645 \u0643\u0627\u0645\u0644\u064B\u0627. \u0627\u0644\u0641\u062A\u0631\u0627\u062A \u0627\u0644\u0644\u064A\u0644\u064A\u0629 \u0645\u062B\u0644 23:00\u201302:00 \u0645\u0642\u0628\u0648\u0644\u0629.",
  "Positions: each one is sold on its own. Leave none to sell the whole episode.": "\u0627\u0644\u0645\u0648\u0627\u0636\u0639: \u0643\u0644 \u0645\u0648\u0636\u0639 \u064A\u064F\u0628\u0627\u0639 \u0648\u062D\u062F\u0647. \u0644\u0627 \u062A\u0636\u0641 \u0634\u064A\u0626\u064B\u0627 \u0644\u0628\u064A\u0639 \u0627\u0644\u062D\u0644\u0642\u0629 \u0643\u0627\u0645\u0644\u0629.",
  "Ad breaks: each one is sold on its own. Leave none to sell the whole slot.": "\u0627\u0644\u0641\u0648\u0627\u0635\u0644 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629: \u0643\u0644 \u0641\u0627\u0635\u0644 \u064A\u064F\u0628\u0627\u0639 \u0648\u062D\u062F\u0647. \u0644\u0627 \u062A\u0636\u0641 \u0634\u064A\u0626\u064B\u0627 \u0644\u0628\u064A\u0639 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0643\u0627\u0645\u0644\u0629.",
  "How it is sold": "\u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u0628\u064A\u0639",
  "Buyers bid until bidding closes. You accept the top bid, or it is accepted for you at your reserve.": "\u064A\u0632\u0627\u064A\u062F \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u062D\u062A\u0649 \u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629. \u062A\u0642\u0628\u0644 \u0623\u0639\u0644\u0649 \u0645\u0632\u0627\u064A\u062F\u0629\u060C \u0623\u0648 \u062A\u064F\u0642\u0628\u0644 \u0639\u0646\u0643 \u0639\u0646\u062F \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u062F\u0646\u0649.",
  "A fixed price. Buyers show interest and you accept one of them.": "\u0633\u0639\u0631 \u062B\u0627\u0628\u062A. \u064A\u0628\u062F\u064A \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0627\u0647\u062A\u0645\u0627\u0645\u0647\u0645 \u0648\u062A\u0642\u0628\u0644 \u0623\u062D\u062F\u0647\u0645.",
  "Starting price per {thing}": "\u0633\u0639\u0631 \u0627\u0644\u0628\u062F\u0627\u064A\u0629 \u0644\u0643\u0644 {thing}",
  "Price per {thing}": "\u0627\u0644\u0633\u0639\u0631 \u0644\u0643\u0644 {thing}",
  "More pricing options": "\u062E\u064A\u0627\u0631\u0627\u062A \u062A\u0633\u0639\u064A\u0631 \u0625\u0636\u0627\u0641\u064A\u0629",
  "\u201CAny position\u201D price (optional)": "\u0633\u0639\u0631 \xAB\u0623\u064A \u0645\u0648\u0636\u0639\xBB (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "All {n} as a package (optional)": "\u0627\u0644\u0640{n} \u0643\u0644\u0647\u0627 \u0643\u0628\u0627\u0642\u0629 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Deadlines and listing": "\u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F \u0648\u0627\u0644\u0639\u0631\u0636",
  "Creative due (days before air)": "\u0645\u0648\u0639\u062F \u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0645\u0627\u062F\u0629 (\u0623\u064A\u0627\u0645 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B)",
  "Sale closes (days before air)": "\u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u0628\u064A\u0639 (\u0623\u064A\u0627\u0645 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B)",
  "At least {n} days: {a}h for you to decide, {b}h for the buyer to pay, then the creative deadline.": "{n} \u0623\u064A\u0627\u0645 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644: {a} \u0633\u0627\u0639\u0629 \u0644\u0642\u0631\u0627\u0631\u0643\u060C \u0648{b} \u0633\u0627\u0639\u0629 \u0644\u062F\u0641\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u060C \u062B\u0645 \u0645\u0648\u0639\u062F \u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0645\u0627\u062F\u0629.",
  "Always open a set number of weeks ahead. New dates are added every day.": "\u0645\u0639\u0631\u0648\u0636\u0629 \u062F\u0627\u0626\u0645\u064B\u0627 \u0644\u0639\u062F\u062F \u0645\u062D\u062F\u062F \u0645\u0646 \u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0645\u0642\u062F\u0645\u064B\u0627. \u062A\u064F\u0636\u0627\u0641 \u062A\u0648\u0627\u0631\u064A\u062E \u062C\u062F\u064A\u062F\u0629 \u0643\u0644 \u064A\u0648\u0645.",
  "List some weeks now and add more from Listings when you choose.": "\u0627\u0639\u0631\u0636 \u0628\u0639\u0636 \u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0627\u0644\u0622\u0646 \u0648\u0623\u0636\u0641 \u0627\u0644\u0645\u0632\u064A\u062F \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u0639\u0631\u0648\u0636 \u0645\u062A\u0649 \u0634\u0626\u062A.",
  "List now": "\u0627\u0639\u0631\u0636 \u0627\u0644\u0622\u0646",
  "Nothing yet": "\u0644\u0627 \u0634\u064A\u0621 \u0628\u0639\u062F",
  "The next {n} weeks": "\u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0627\u0644\u0640{n} \u0627\u0644\u0642\u0627\u062F\u0645\u0629",
  "Preview": "\u0645\u0639\u0627\u064A\u0646\u0629",
  "How buyers see it": "\u0643\u0645\u0627 \u064A\u0631\u0627\u0647\u0627 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646",
  "When you save": "\u0639\u0646\u062F \u0627\u0644\u062D\u0641\u0638",
  "Nothing goes on sale until your payout account is verified.": "\u0644\u0627 \u064A\u064F\u0639\u0631\u0636 \u0634\u064A\u0621 \u0644\u0644\u0628\u064A\u0639 \u062D\u062A\u0649 \u064A\u062A\u0645 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0633\u0627\u0628 \u0627\u0644\u062F\u0641\u0639\u0627\u062A.",
  "{n} weeks are on sale at all times, topped up every day.": "{n} \u0623\u0633\u0627\u0628\u064A\u0639 \u0645\u0639\u0631\u0648\u0636\u0629 \u062F\u0627\u0626\u0645\u064B\u0627\u060C \u0648\u062A\u064F\u0633\u062A\u0643\u0645\u0644 \u0643\u0644 \u064A\u0648\u0645.",
  "The next {n} weeks go on sale now.": "\u062A\u064F\u0639\u0631\u0636 \u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0627\u0644\u0640{n} \u0627\u0644\u0642\u0627\u062F\u0645\u0629 \u0627\u0644\u0622\u0646.",
  "Nothing goes on sale yet.": "\u0644\u0627 \u064A\u064F\u0639\u0631\u0636 \u0634\u064A\u0621 \u0644\u0644\u0628\u064A\u0639 \u0628\u0639\u062F.",
  "1 slot a week.": "\u0645\u0633\u0627\u062D\u0629 \u0648\u0627\u062D\u062F\u0629 \u0641\u064A \u0627\u0644\u0623\u0633\u0628\u0648\u0639.",
  "{n} slots a week.": "{n} \u0645\u0633\u0627\u062D\u0629 \u0641\u064A \u0627\u0644\u0623\u0633\u0628\u0648\u0639.",
  "First date buyers can book: {date}.": "\u0623\u0648\u0644 \u062A\u0627\u0631\u064A\u062E \u064A\u0645\u0643\u0646 \u0644\u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u062D\u062C\u0632\u0647: {date}.",
  "Bidding closes {n} days before each airing; creative is due {m} days before.": "\u062A\u064F\u063A\u0644\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0642\u0628\u0644 \u0643\u0644 \u0628\u062B \u0628\u0640{n} \u0623\u064A\u0627\u0645\u061B \u0648\u062A\u064F\u0633\u0644\u064E\u0651\u0645 \u0627\u0644\u0645\u0627\u062F\u0629 \u0642\u0628\u0644\u0647 \u0628\u0640{m} \u0623\u064A\u0627\u0645.",
  "The sale closes {n} days before each airing; creative is due {m} days before.": "\u064A\u064F\u063A\u0644\u0642 \u0627\u0644\u0628\u064A\u0639 \u0642\u0628\u0644 \u0643\u0644 \u0628\u062B \u0628\u0640{n} \u0623\u064A\u0627\u0645\u061B \u0648\u062A\u064F\u0633\u0644\u064E\u0651\u0645 \u0627\u0644\u0645\u0627\u062F\u0629 \u0642\u0628\u0644\u0647 \u0628\u0640{m} \u0623\u064A\u0627\u0645.",
  'Outlet "{name}" is not one of yours.': '\u0627\u0644\u0645\u0646\u0635\u0629 "{name}" \u0644\u064A\u0633\u062A \u0645\u0646 \u0645\u0646\u0635\u0627\u062A\u0643.',
  "Name is missing.": "\u0627\u0644\u0627\u0633\u0645 \u0645\u0641\u0642\u0648\u062F.",
  "Sold as must be auction or quick sale.": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u0628\u064A\u0639 \u0645\u0632\u0627\u062F \u0623\u0648 \u0628\u064A\u0639 \u0633\u0631\u064A\u0639.",
  "Days are not readable (use Mon-Fri or Mon;Wed).": "\u0627\u0644\u0623\u064A\u0627\u0645 \u063A\u064A\u0631 \u0645\u0641\u0647\u0648\u0645\u0629 (\u0627\u0633\u062A\u062E\u062F\u0645 Mon-Fri \u0623\u0648 Mon;Wed).",
  "Price is missing.": "\u0627\u0644\u0633\u0639\u0631 \u0645\u0641\u0642\u0648\u062F.",
  "Times must look like 07:30.": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0627\u0644\u0623\u0648\u0642\u0627\u062A \u0628\u0635\u064A\u063A\u0629 07:30.",
  "Added, {n} slots on sale.": "\u0623\u064F\u0636\u064A\u0641\u062A\u060C {n} \u0645\u0633\u0627\u062D\u0629 \u0645\u0639\u0631\u0648\u0636\u0629 \u0644\u0644\u0628\u064A\u0639.",
  "Add many placements at once from a spreadsheet saved as CSV. Each row becomes a placement kept on sale 8 weeks ahead; you can edit any of them afterwards.": "\u0623\u0636\u0641 \u0645\u0633\u0627\u062D\u0627\u062A \u0643\u062B\u064A\u0631\u0629 \u062F\u0641\u0639\u0629 \u0648\u0627\u062D\u062F\u0629 \u0645\u0646 \u062C\u062F\u0648\u0644 \u0645\u062D\u0641\u0648\u0638 \u0628\u0635\u064A\u063A\u0629 CSV. \u0643\u0644 \u0635\u0641 \u064A\u0635\u0628\u062D \u0645\u0633\u0627\u062D\u0629 \u0645\u0639\u0631\u0648\u0636\u0629 8 \u0623\u0633\u0627\u0628\u064A\u0639 \u0645\u0642\u062F\u0645\u064B\u0627\u060C \u0648\u064A\u0645\u0643\u0646\u0643 \u062A\u0639\u062F\u064A\u0644 \u0623\u064A \u0645\u0646\u0647\u0627 \u0644\u0627\u062D\u0642\u064B\u0627.",
  "Download the template": "\u0646\u0632\u0651\u0644 \u0627\u0644\u0646\u0645\u0648\u0630\u062C",
  "Choose a CSV file": "\u0627\u062E\u062A\u0631 \u0645\u0644\u0641 CSV",
  "Columns: {cols}. Days like Mon-Fri or Sat;Sun. Break times separated by semicolons. Prices in AED excluding VAT.": "\u0627\u0644\u0623\u0639\u0645\u062F\u0629: {cols}. \u0627\u0644\u0623\u064A\u0627\u0645 \u0645\u062B\u0644 Mon-Fri \u0623\u0648 Sat;Sun. \u0623\u0648\u0642\u0627\u062A \u0627\u0644\u0641\u0648\u0627\u0635\u0644 \u0645\u0641\u0635\u0648\u0644\u0629 \u0628\u0641\u0627\u0635\u0644\u0629 \u0645\u0646\u0642\u0648\u0637\u0629. \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0628\u0627\u0644\u062F\u0631\u0647\u0645 \u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629.",
  "Row": "\u0627\u0644\u0635\u0641",
  "Ready": "\u062C\u0627\u0647\u0632",
  "Importing\u2026": "\u062C\u0627\u0631\u064D \u0627\u0644\u0627\u0633\u062A\u064A\u0631\u0627\u062F\u2026",
  "Import 1 placement": "\u0627\u0633\u062A\u064A\u0631\u0627\u062F \u0645\u0633\u0627\u062D\u0629 \u0648\u0627\u062D\u062F\u0629",
  "Import {n} placements": "\u0627\u0633\u062A\u064A\u0631\u0627\u062F {n} \u0645\u0633\u0627\u062D\u0627\u062A",
  // Review fixes
  "Your bid on {slot} was not selected. The slot has gone to another buyer or is no longer on sale.": "\u0644\u0645 \u062A\u064F\u062E\u062A\u0631 \u0645\u0632\u0627\u064A\u062F\u062A\u0643 \u0639\u0644\u0649 {slot}. \u0630\u0647\u0628\u062A \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0625\u0644\u0649 \u0645\u0634\u062A\u0631\u064D \u0622\u062E\u0631 \u0623\u0648 \u0644\u0645 \u062A\u0639\u062F \u0645\u0639\u0631\u0648\u0636\u0629 \u0644\u0644\u0628\u064A\u0639.",
  // Fixed price and business profiles
  "on Nashr since {date}": "\u0639\u0644\u0649 \u0646\u0634\u0631 \u0645\u0646\u0630 {date}",
  "1 booking completed": "\u062D\u062C\u0632 \u0648\u0627\u062D\u062F \u0645\u0643\u062A\u0645\u0644",
  "{n} bookings completed": "{n} \u062D\u062C\u0648\u0632\u0627\u062A \u0645\u0643\u062A\u0645\u0644\u0629",
  "pays {n}% of accepted bookings": "\u064A\u062F\u0641\u0639 {n}% \u0645\u0646 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u0645\u0642\u0628\u0648\u0644\u0629",
  "accepts {n}% of requests": "\u064A\u0642\u0628\u0644 {n}% \u0645\u0646 \u0627\u0644\u0637\u0644\u0628\u0627\u062A",
  "rated {score} by {n} buyers": "\u062A\u0642\u064A\u064A\u0645\u0647 {score} \u0645\u0646 {n} \u0645\u0634\u062A\u0631\u064A\u0646",
  "Verified by Nashr": "\u0645\u0648\u062B\u0651\u0642 \u0645\u0646 \u0646\u0634\u0631",
  "On Nashr since": "\u0639\u0644\u0649 \u0646\u0634\u0631 \u0645\u0646\u0630",
  "Bookings completed": "\u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u0645\u0643\u062A\u0645\u0644\u0629",
  "Pays accepted bookings": "\u064A\u062F\u0641\u0639 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u0645\u0642\u0628\u0648\u0644\u0629",
  "Accepts requests": "\u064A\u0642\u0628\u0644 \u0627\u0644\u0637\u0644\u0628\u0627\u062A",
  "Buyer rating": "\u062A\u0642\u064A\u064A\u0645 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646",
  "Tax": "\u0627\u0644\u0636\u0631\u064A\u0628\u0629",
  "VAT registered": "\u0645\u0633\u062C\u0651\u0644 \u0641\u064A \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629",
  "TRN on file": "\u0627\u0644\u0631\u0642\u0645 \u0627\u0644\u0636\u0631\u064A\u0628\u064A \u0645\u0633\u062C\u0651\u0644",
  "No TRN on file": "\u0644\u0627 \u0631\u0642\u0645 \u0636\u0631\u064A\u0628\u064A \u0645\u0633\u062C\u0651\u0644",
  "Contact details are shared inside the booking once it is paid.": "\u062A\u064F\u0634\u0627\u0631\u0643 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062A\u0648\u0627\u0635\u0644 \u062F\u0627\u062E\u0644 \u0627\u0644\u062D\u062C\u0632 \u0628\u0639\u062F \u0627\u0644\u062F\u0641\u0639.",
  "Profile saved.": "\u062D\u064F\u0641\u0638 \u0627\u0644\u0645\u0644\u0641.",
  "Business profile": "\u0645\u0644\u0641 \u0627\u0644\u0634\u0631\u0643\u0629",
  "Publishers see this when you bid or book, before they decide. Contact details are never shown.": "\u064A\u0631\u0649 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0647\u0630\u0627 \u0639\u0646\u062F \u0645\u0632\u0627\u064A\u062F\u062A\u0643 \u0623\u0648 \u062D\u062C\u0632\u0643\u060C \u0642\u0628\u0644 \u0623\u0646 \u064A\u0642\u0631\u0631\u0648\u0627. \u0644\u0627 \u062A\u0638\u0647\u0631 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062A\u0648\u0627\u0635\u0644 \u0623\u0628\u062F\u064B\u0627.",
  "Buyers see this when they look at your slots, before they book. Contact details are never shown.": "\u064A\u0631\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0647\u0630\u0627 \u0639\u0646\u062F \u062A\u0635\u0641\u062D \u0645\u0633\u0627\u062D\u0627\u062A\u0643\u060C \u0642\u0628\u0644 \u0627\u0644\u062D\u062C\u0632. \u0644\u0627 \u062A\u0638\u0647\u0631 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062A\u0648\u0627\u0635\u0644 \u0623\u0628\u062F\u064B\u0627.",
  "About the company": "\u0639\u0646 \u0627\u0644\u0634\u0631\u0643\u0629",
  "How publishers see you": "\u0643\u0645\u0627 \u064A\u0631\u0627\u0643 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646",
  "How buyers see you": "\u0643\u0645\u0627 \u064A\u0631\u0627\u0643 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646",
  "A fixed price: the first buyer to book takes the slot. The publisher confirms within 24 hours, and you pay only then.": "\u0633\u0639\u0631 \u062B\u0627\u0628\u062A: \u0623\u0648\u0644 \u0645\u0634\u062A\u0631\u064D \u064A\u062D\u062C\u0632 \u064A\u062D\u0635\u0644 \u0639\u0644\u0649 \u0627\u0644\u0645\u0633\u0627\u062D\u0629. \u064A\u0624\u0643\u062F \u0627\u0644\u0646\u0627\u0634\u0631 \u062E\u0644\u0627\u0644 24 \u0633\u0627\u0639\u0629\u060C \u0648\u0644\u0627 \u062A\u062F\u0641\u0639 \u0625\u0644\u0627 \u0628\u0639\u062F\u0647\u0627.",
  "Booked and confirmed. Pay from Bookings to secure it.": "\u062A\u0645 \u0627\u0644\u062D\u062C\u0632 \u0648\u0627\u0644\u062A\u0623\u0643\u064A\u062F. \u0627\u062F\u0641\u0639 \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0644\u062A\u0623\u0645\u064A\u0646\u0647.",
  "Booked. The publisher confirms within 24 hours; you pay only then.": "\u062A\u0645 \u0627\u0644\u062D\u062C\u0632. \u064A\u0624\u0643\u062F \u0627\u0644\u0646\u0627\u0634\u0631 \u062E\u0644\u0627\u0644 24 \u0633\u0627\u0639\u0629\u060C \u0648\u0644\u0627 \u062A\u062F\u0641\u0639 \u0625\u0644\u0627 \u0628\u0639\u062F\u0647\u0627.",
  "Book for {price}": "\u0627\u062D\u062C\u0632 \u0628\u0640{price}",
  "Fixed price": "\u0633\u0639\u0631 \u062B\u0627\u0628\u062A",
  "Book now": "\u0627\u062D\u062C\u0632 \u0627\u0644\u0622\u0646",
  "The buyer": "\u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "Confirm bookings automatically": "\u0623\u0643\u0651\u062F \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627",
  "A booking at your price is confirmed at once and the buyer is asked to pay. Off: you confirm each one within 24 hours.": "\u064A\u064F\u0624\u0643\u064E\u0651\u062F \u0627\u0644\u062D\u062C\u0632 \u0628\u0633\u0639\u0631\u0643 \u0641\u0648\u0631\u064B\u0627 \u0648\u064A\u064F\u0637\u0644\u0628 \u0645\u0646 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0627\u0644\u062F\u0641\u0639. \u0639\u0646\u062F \u0627\u0644\u0625\u064A\u0642\u0627\u0641: \u062A\u0624\u0643\u062F \u0643\u0644 \u062D\u062C\u0632 \u062E\u0644\u0627\u0644 24 \u0633\u0627\u0639\u0629.",
  "Book now at your price. The first buyer to book takes it; you confirm within 24 hours, or automatically.": "\u0627\u062D\u062C\u0632 \u0627\u0644\u0622\u0646 \u0628\u0633\u0639\u0631\u0643. \u0623\u0648\u0644 \u0645\u0634\u062A\u0631\u064D \u064A\u062D\u062C\u0632 \u064A\u062D\u0635\u0644 \u0639\u0644\u064A\u0647\u0627\u061B \u0648\u062A\u0624\u0643\u062F \u062E\u0644\u0627\u0644 24 \u0633\u0627\u0639\u0629 \u0623\u0648 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627.",
  "A price buyers can offer on or above. Buyers show interest and you choose one of them.": "\u0633\u0639\u0631 \u064A\u0645\u0643\u0646 \u0644\u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u062A\u0642\u062F\u064A\u0645 \u0639\u0631\u0648\u0636 \u0639\u0646\u062F\u0647 \u0623\u0648 \u0623\u0639\u0644\u0649. \u064A\u0628\u062F\u064A \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0627\u0647\u062A\u0645\u0627\u0645\u0647\u0645 \u0648\u062A\u062E\u062A\u0627\u0631 \u0623\u062D\u062F\u0647\u0645.",
  "Sold as must be auction, fixed price or quick sale.": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u0628\u064A\u0639 \u0645\u0632\u0627\u062F\u064B\u0627 \u0623\u0648 \u0633\u0639\u0631\u064B\u0627 \u062B\u0627\u0628\u062A\u064B\u0627 \u0623\u0648 \u0628\u064A\u0639\u064B\u0627 \u0633\u0631\u064A\u0639\u064B\u0627.",
  "Booked at your fixed price": "\u062D\u064F\u062C\u0632\u062A \u0628\u0633\u0639\u0631\u0643 \u0627\u0644\u062B\u0627\u0628\u062A",
  // Audiences, public pages, results, insights, brand safety
  "Sell your airtime on Nashr": "\u0628\u0650\u0639 \u0645\u0633\u0627\u062D\u0627\u062A\u0643 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0639\u0644\u0649 \u0646\u0634\u0631",
  "Book UAE media on Nashr": "\u0627\u062D\u062C\u0632 \u0648\u0633\u0627\u0626\u0644 \u0627\u0644\u0625\u0639\u0644\u0627\u0645 \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A\u064A\u0629 \u0639\u0644\u0649 \u0646\u0634\u0631",
  "List your breaks, pages and placements, choose how each one sells, and get paid once the buyer approves proof. Onboarding happens on a short call.": "\u0627\u0639\u0631\u0636 \u0641\u0648\u0627\u0635\u0644\u0643 \u0648\u0635\u0641\u062D\u0627\u062A\u0643 \u0648\u0645\u0633\u0627\u062D\u0627\u062A\u0643\u060C \u0648\u0627\u062E\u062A\u0631 \u0637\u0631\u064A\u0642\u0629 \u0628\u064A\u0639 \u0643\u0644 \u0645\u0646\u0647\u0627\u060C \u0648\u0627\u062D\u0635\u0644 \u0639\u0644\u0649 \u0623\u0645\u0648\u0627\u0644\u0643 \u0628\u0639\u062F \u0645\u0648\u0627\u0641\u0642\u0629 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0639\u0644\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A. \u064A\u062A\u0645 \u0627\u0644\u062A\u0633\u062C\u064A\u0644 \u0639\u0628\u0631 \u0645\u0643\u0627\u0644\u0645\u0629 \u0642\u0635\u064A\u0631\u0629.",
  "Bid on and book radio, TV, print, digital and podcast slots from UAE publishers. You pay only once a publisher accepts, and the money is held until the ad runs.": "\u0632\u0627\u064A\u062F \u0648\u0627\u062D\u062C\u0632 \u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0645\u0637\u0628\u0648\u0639\u0627\u062A \u0648\u0627\u0644\u0631\u0642\u0645\u064A \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A \u0645\u0646 \u0646\u0627\u0634\u0631\u064A\u0646 \u0625\u0645\u0627\u0631\u0627\u062A\u064A\u064A\u0646. \u0644\u0627 \u062A\u062F\u0641\u0639 \u0625\u0644\u0627 \u0628\u0639\u062F \u0642\u0628\u0648\u0644 \u0627\u0644\u0646\u0627\u0634\u0631\u060C \u0648\u064A\u064F\u062D\u062A\u062C\u0632 \u0627\u0644\u0645\u0628\u0644\u063A \u062D\u062A\u0649 \u064A\u064F\u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646.",
  "I want to advertise": "\u0623\u0631\u064A\u062F \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  "A brand or an agency booking media": "\u0639\u0644\u0627\u0645\u0629 \u062A\u062C\u0627\u0631\u064A\u0629 \u0623\u0648 \u0648\u0643\u0627\u0644\u0629 \u062A\u062D\u062C\u0632 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A",
  "I sell airtime or ad space": "\u0623\u0628\u064A\u0639 \u0623\u0648\u0642\u0627\u062A \u0628\u062B \u0623\u0648 \u0645\u0633\u0627\u062D\u0627\u062A \u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "A radio or TV station, publication, website or podcast": "\u0645\u062D\u0637\u0629 \u0625\u0630\u0627\u0639\u064A\u0629 \u0623\u0648 \u062A\u0644\u0641\u0632\u064A\u0648\u0646\u064A\u0629\u060C \u0623\u0648 \u0645\u0637\u0628\u0648\u0639\u0629\u060C \u0623\u0648 \u0645\u0648\u0642\u0639\u060C \u0623\u0648 \u0628\u0648\u062F\u0643\u0627\u0633\u062A",
  "I want to advertise instead": "\u0623\u0631\u064A\u062F \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0628\u062F\u0644\u064B\u0627 \u0645\u0646 \u0630\u0644\u0643",
  "I sell airtime instead": "\u0623\u0628\u064A\u0639 \u0623\u0648\u0642\u0627\u062A \u0627\u0644\u0628\u062B \u0628\u062F\u0644\u064B\u0627 \u0645\u0646 \u0630\u0644\u0643",
  "Audiences": "\u0627\u0644\u062C\u0645\u0627\u0647\u064A\u0631",
  "Results": "\u0627\u0644\u0646\u062A\u0627\u0626\u062C",
  "Start from who you want to reach.": "\u0627\u0628\u062F\u0623 \u0628\u0645\u0646 \u062A\u0631\u064A\u062F \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u064A\u0647.",
  "Pick an audience and see every slot that reaches it, on every channel, from every publisher.": "\u0627\u062E\u062A\u0631 \u062C\u0645\u0647\u0648\u0631\u064B\u0627 \u0648\u0634\u0627\u0647\u062F \u0643\u0644 \u0645\u0633\u0627\u062D\u0629 \u062A\u0635\u0644 \u0625\u0644\u064A\u0647\u060C \u0641\u064A \u0643\u0644 \u0642\u0646\u0627\u0629 \u0648\u0645\u0646 \u0643\u0644 \u0646\u0627\u0634\u0631.",
  "All audiences": "\u0643\u0644 \u0627\u0644\u062C\u0645\u0627\u0647\u064A\u0631",
  "Or by industry:": "\u0623\u0648 \u062D\u0633\u0628 \u0627\u0644\u0642\u0637\u0627\u0639:",
  "Insights": "\u0631\u0624\u0649",
  "slots open to book in the next 30 days": "\u0645\u0633\u0627\u062D\u0629 \u0645\u062A\u0627\u062D\u0629 \u0644\u0644\u062D\u062C\u0632 \u062E\u0644\u0627\u0644 30 \u064A\u0648\u0645\u064B\u0627",
  "outlets you can book today": "\u0645\u0646\u0635\u0629 \u064A\u0645\u0643\u0646\u0643 \u0627\u0644\u062D\u062C\u0632 \u0641\u064A\u0647\u0627 \u0627\u0644\u064A\u0648\u0645",
  "verified UAE publishers": "\u0646\u0627\u0634\u0631\u0648\u0646 \u0625\u0645\u0627\u0631\u0627\u062A\u064A\u0648\u0646 \u0645\u0648\u062B\u0651\u0642\u0648\u0646",
  "channels: radio, TV, print, digital, podcast": "\u0642\u0646\u0648\u0627\u062A: \u0625\u0630\u0627\u0639\u0629\u060C \u062A\u0644\u0641\u0632\u064A\u0648\u0646\u060C \u0645\u0637\u0628\u0648\u0639\u0627\u062A\u060C \u0631\u0642\u0645\u064A\u060C \u0628\u0648\u062F\u0643\u0627\u0633\u062A",
  "bookings completed, paid only after proof": "\u062D\u062C\u0648\u0632\u0627\u062A \u0645\u0643\u062A\u0645\u0644\u0629\u060C \u062F\u064F\u0641\u0639\u062A \u0628\u0639\u062F \u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0641\u0642\u0637",
  "Nashr in numbers": "\u0646\u0634\u0631 \u0628\u0627\u0644\u0623\u0631\u0642\u0627\u0645",
  "booked through Nashr, held until the ad ran": "\u062D\u064F\u062C\u0632\u062A \u0639\u0628\u0631 \u0646\u0634\u0631\u060C \u0648\u0627\u062D\u062A\u064F\u062C\u0632\u062A \u062D\u062A\u0649 \u0628\u064F\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  "Does not accept": "\u0644\u0627 \u064A\u0642\u0628\u0644",
  "Required disclaimer or licence number (regulated advertisers, optional)": "\u0625\u062E\u0644\u0627\u0621 \u0645\u0633\u0624\u0648\u0644\u064A\u0629 \u0623\u0648 \u0631\u0642\u0645 \u062A\u0631\u062E\u064A\u0635 \u0625\u0644\u0632\u0627\u0645\u064A (\u0644\u0644\u0645\u0639\u0644\u0646\u064A\u0646 \u0627\u0644\u062E\u0627\u0636\u0639\u064A\u0646 \u0644\u0644\u062A\u0646\u0638\u064A\u0645\u060C \u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "e.g. Licensed by the Central Bank of the UAE": "\u0645\u062B\u0627\u0644: \u0645\u0631\u062E\u0651\u0635 \u0645\u0646 \u0645\u0635\u0631\u0641 \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A \u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0627\u0644\u0645\u062A\u062D\u062F\u0629 \u0627\u0644\u0645\u0631\u0643\u0632\u064A",
  "The publisher must include it and confirm it in their proof.": "\u064A\u062C\u0628 \u0639\u0644\u0649 \u0627\u0644\u0646\u0627\u0634\u0631 \u062A\u0636\u0645\u064A\u0646\u0647 \u0648\u062A\u0623\u0643\u064A\u062F\u0647 \u0641\u064A \u0627\u0644\u0625\u062B\u0628\u0627\u062A.",
  "What your bookings delivered: spend, airings, proof and the reach publishers report.": "\u0645\u0627 \u062D\u0642\u0642\u062A\u0647 \u062D\u062C\u0648\u0632\u0627\u062A\u0643: \u0627\u0644\u0625\u0646\u0641\u0627\u0642 \u0648\u0627\u0644\u0628\u062B \u0648\u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0648\u0627\u0644\u0648\u0635\u0648\u0644 \u0627\u0644\u0630\u064A \u064A\u0639\u0644\u0646\u0647 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646.",
  "All campaigns": "\u0643\u0644 \u0627\u0644\u062D\u0645\u0644\u0627\u062A",
  "Results appear here once a booking is paid. Each airing, its proof and its reach are added as it runs.": "\u062A\u0638\u0647\u0631 \u0627\u0644\u0646\u062A\u0627\u0626\u062C \u0647\u0646\u0627 \u0628\u0639\u062F \u062F\u0641\u0639 \u0627\u0644\u062D\u062C\u0632. \u064A\u064F\u0636\u0627\u0641 \u0643\u0644 \u0628\u062B \u0648\u0625\u062B\u0628\u0627\u062A\u0647 \u0648\u0648\u0635\u0648\u0644\u0647 \u0639\u0646\u062F \u062D\u062F\u0648\u062B\u0647.",
  "Spend (excl. VAT)": "\u0627\u0644\u0625\u0646\u0641\u0627\u0642 (\u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629)",
  "{n} with proof": "{n} \u0645\u0639 \u0625\u062B\u0628\u0627\u062A",
  "Reach": "\u0627\u0644\u0648\u0635\u0648\u0644",
  "Publishers' estimates per airing": "\u062A\u0642\u062F\u064A\u0631\u0627\u062A \u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646 \u0644\u0643\u0644 \u0628\u062B",
  "Cost per 1,000 reached": "\u0627\u0644\u062A\u0643\u0644\u0641\u0629 \u0644\u0643\u0644 1,000 \u0634\u062E\u0635",
  "Over airings with a reach figure": "\u0644\u0644\u0628\u062B \u0627\u0644\u0630\u064A \u0644\u0647 \u0631\u0642\u0645 \u0648\u0635\u0648\u0644",
  "Due": "\u0645\u0633\u062A\u062D\u0642",
  "After airing": "\u0628\u0639\u062F \u0627\u0644\u0628\u062B",
  "Sales insights": "\u0631\u0624\u0649 \u0627\u0644\u0645\u0628\u064A\u0639\u0627\u062A",
  "last 90 days, slots whose sale has closed": "\u0622\u062E\u0631 90 \u064A\u0648\u0645\u064B\u0627\u060C \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u062A\u064A \u0623\u064F\u063A\u0644\u0642 \u0628\u064A\u0639\u0647\u0627",
  "Sell-through": "\u0646\u0633\u0628\u0629 \u0627\u0644\u0628\u064A\u0639",
  "{sold} of {slots} slots sold": "\u0628\u064A\u0639\u062A {sold} \u0645\u0646 {slots} \u0645\u0633\u0627\u062D\u0629",
  "Sold": "\u0627\u0644\u0645\u0628\u064A\u0639\u0627\u062A",
  "excl. VAT, before commission": "\u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629\u060C \u0642\u0628\u0644 \u0627\u0644\u0639\u0645\u0648\u0644\u0629",
  "Above starting price": "\u0641\u0648\u0642 \u0633\u0639\u0631 \u0627\u0644\u0628\u062F\u0627\u064A\u0629",
  "What bidding added on average": "\u0645\u0627 \u0623\u0636\u0627\u0641\u062A\u0647 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0641\u064A \u0627\u0644\u0645\u062A\u0648\u0633\u0637",
  "Unsold airtime": "\u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u063A\u064A\u0631 \u0627\u0644\u0645\u0628\u0627\u0639\u0629",
  "worth {value} at starting prices": "\u0642\u064A\u0645\u062A\u0647\u0627 {value} \u0628\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0628\u062F\u0627\u064A\u0629",
  "Average price": "\u0645\u062A\u0648\u0633\u0637 \u0627\u0644\u0633\u0639\u0631",
  "Insights: buying and selling UAE media | Nashr": "\u0631\u0624\u0649: \u0634\u0631\u0627\u0621 \u0648\u0628\u064A\u0639 \u0627\u0644\u0625\u0639\u0644\u0627\u0645 \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A\u064A | \u0646\u0634\u0631",
  "Practical guides to booking radio, TV, print, digital and podcast advertising in the UAE.": "\u0623\u062F\u0644\u0629 \u0639\u0645\u0644\u064A\u0629 \u0644\u062D\u062C\u0632 \u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0627\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0645\u0637\u0628\u0648\u0639\u0627\u062A \u0648\u0627\u0644\u0631\u0642\u0645\u064A \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A.",
  "Practical guides to buying and selling UAE media, from the Nashr team.": "\u0623\u062F\u0644\u0629 \u0639\u0645\u0644\u064A\u0629 \u0644\u0634\u0631\u0627\u0621 \u0648\u0628\u064A\u0639 \u0627\u0644\u0625\u0639\u0644\u0627\u0645 \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A\u064A \u0645\u0646 \u0641\u0631\u064A\u0642 \u0646\u0634\u0631.",
  "{n} min read": "\u0642\u0631\u0627\u0621\u0629 {n} \u062F\u0642\u0627\u0626\u0642",
  "More insights": "\u0645\u0632\u064A\u062F \u0645\u0646 \u0627\u0644\u0631\u0624\u0649",
  "Nothing open for this yet.": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u062A\u0627\u062D \u0644\u0647\u0630\u0627 \u0628\u0639\u062F.",
  "Publishers add new dates every day. Save a search on the calendar and Nashr tells you when something matches.": "\u064A\u0636\u064A\u0641 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u062A\u0648\u0627\u0631\u064A\u062E \u062C\u062F\u064A\u062F\u0629 \u0643\u0644 \u064A\u0648\u0645. \u0627\u062D\u0641\u0638 \u0628\u062D\u062B\u064B\u0627 \u0641\u064A \u0627\u0644\u062A\u0642\u0648\u064A\u0645 \u0648\u0633\u064A\u0628\u0644\u063A\u0643 \u0646\u0634\u0631 \u0639\u0646\u062F \u0648\u062C\u0648\u062F \u0645\u0627 \u064A\u0637\u0627\u0628\u0642\u0647.",
  "Open the calendar": "\u0627\u0641\u062A\u062D \u0627\u0644\u062A\u0642\u0648\u064A\u0645",
  "{n} slots open in the next 8 weeks across {m} outlets.": "{n} \u0645\u0633\u0627\u062D\u0629 \u0645\u062A\u0627\u062D\u0629 \u062E\u0644\u0627\u0644 \u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0627\u0644\u062B\u0645\u0627\u0646\u064A\u0629 \u0627\u0644\u0642\u0627\u062F\u0645\u0629 \u0639\u0628\u0631 {m} \u0645\u0646\u0635\u0629.",
  "1 slot open": "\u0645\u0633\u0627\u062D\u0629 \u0648\u0627\u062D\u062F\u0629 \u0645\u062A\u0627\u062D\u0629",
  "{n} slots open": "{n} \u0645\u0633\u0627\u062D\u0627\u062A \u0645\u062A\u0627\u062D\u0629",
  "See every open slot on the calendar": "\u0627\u0639\u0631\u0636 \u0643\u0644 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u0645\u062A\u0627\u062D\u0629 \u0641\u064A \u0627\u0644\u062A\u0642\u0648\u064A\u0645",
  "Request access to book": "\u0627\u0637\u0644\u0628 \u0627\u0644\u0648\u0635\u0648\u0644 \u0644\u0644\u062D\u062C\u0632",
  "Other audiences": "\u062C\u0645\u0627\u0647\u064A\u0631 \u0623\u062E\u0631\u0649",
  "Other industries": "\u0642\u0637\u0627\u0639\u0627\u062A \u0623\u062E\u0631\u0649",
  "Audiences you can reach in the UAE | Nashr": "\u0627\u0644\u062C\u0645\u0627\u0647\u064A\u0631 \u0627\u0644\u062A\u064A \u064A\u0645\u0643\u0646\u0643 \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u064A\u0647\u0627 \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A | \u0646\u0634\u0631",
  "Pick who you want to reach and see every radio, TV, print, digital and podcast slot that reaches them.": "\u0627\u062E\u062A\u0631 \u0645\u0646 \u062A\u0631\u064A\u062F \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u064A\u0647 \u0648\u0634\u0627\u0647\u062F \u0643\u0644 \u0645\u0633\u0627\u062D\u0629 \u0625\u0630\u0627\u0639\u064A\u0629 \u0648\u062A\u0644\u0641\u0632\u064A\u0648\u0646\u064A\u0629 \u0648\u0645\u0637\u0628\u0648\u0639\u0629 \u0648\u0631\u0642\u0645\u064A\u0629 \u0648\u0628\u0648\u062F\u0643\u0627\u0633\u062A \u062A\u0635\u0644 \u0625\u0644\u064A\u0647.",
  "Who do you want to reach?": "\u0645\u0646 \u062A\u0631\u064A\u062F \u0623\u0646 \u062A\u0635\u0644 \u0625\u0644\u064A\u0647\u061F",
  "Pick an audience and see every slot that reaches it, across radio, TV, print, digital and podcasts, from every publisher on Nashr.": "\u0627\u062E\u062A\u0631 \u062C\u0645\u0647\u0648\u0631\u064B\u0627 \u0648\u0634\u0627\u0647\u062F \u0643\u0644 \u0645\u0633\u0627\u062D\u0629 \u062A\u0635\u0644 \u0625\u0644\u064A\u0647 \u0641\u064A \u0627\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0645\u0637\u0628\u0648\u0639\u0627\u062A \u0648\u0627\u0644\u0631\u0642\u0645\u064A \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A\u060C \u0645\u0646 \u0643\u0644 \u0646\u0627\u0634\u0631 \u0639\u0644\u0649 \u0646\u0634\u0631.",
  "Advertise to {who} in the UAE | Nashr": "\u0623\u0639\u0644\u0646 \u0644\u0640{who} \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A | \u0646\u0634\u0631",
  "Reach {who}": "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639: {who}",
  "{industry} advertising in the UAE | Nashr": "\u0625\u0639\u0644\u0627\u0646\u0627\u062A {industry} \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A | \u0646\u0634\u0631",
  "Industries": "\u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A",
  "{industry} advertising in the UAE": "\u0625\u0639\u0644\u0627\u0646\u0627\u062A {industry} \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A",
  "Required disclaimer": "\u0625\u062E\u0644\u0627\u0621 \u0627\u0644\u0645\u0633\u0624\u0648\u0644\u064A\u0629 \u0627\u0644\u0625\u0644\u0632\u0627\u0645\u064A",
  "Include it in the ad and confirm it when you send proof.": "\u0636\u0645\u0651\u0646\u0647 \u0641\u064A \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0648\u0623\u0643\u0651\u062F\u0647 \u0639\u0646\u062F \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A.",
  "Who it reaches (optional: leave empty to use the outlet's audiences)": "\u0645\u0646 \u062A\u0635\u0644 \u0625\u0644\u064A\u0647 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A: \u0627\u062A\u0631\u0643\u0647 \u0641\u0627\u0631\u063A\u064B\u0627 \u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u062C\u0645\u0627\u0647\u064A\u0631 \u0627\u0644\u0645\u0646\u0635\u0629)",
  "Who it reaches (buyers filter by these)": "\u0645\u0646 \u062A\u0635\u0644 \u0625\u0644\u064A\u0647 (\u064A\u0635\u0641\u0651\u064A \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0628\u0647\u0627)",
  "People reached per airing or edition (your estimate, optional)": "\u0639\u062F\u062F \u0627\u0644\u0623\u0634\u062E\u0627\u0635 \u0627\u0644\u0630\u064A\u0646 \u062A\u0635\u0644 \u0625\u0644\u064A\u0647\u0645 \u0641\u064A \u0643\u0644 \u0628\u062B \u0623\u0648 \u0639\u062F\u062F (\u062A\u0642\u062F\u064A\u0631\u0643\u060C \u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Brand safety": "\u0633\u0644\u0627\u0645\u0629 \u0627\u0644\u0639\u0644\u0627\u0645\u0629 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629",
  "Buyers in these industries can't bid on or book this outlet. They see it before they try.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0644\u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0639\u0644\u0649 \u0647\u0630\u0647 \u0627\u0644\u0645\u0646\u0635\u0629 \u0623\u0648 \u062D\u062C\u0632\u0647\u0627\u060C \u0648\u064A\u0631\u0648\u0646 \u0630\u0644\u0643 \u0642\u0628\u0644 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629.",
  "Industries you do not accept": "\u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A \u0627\u0644\u062A\u064A \u0644\u0627 \u062A\u0642\u0628\u0644\u0647\u0627",
  "Advertisers you will not run (comma-separated, e.g. competitors)": "\u0645\u0639\u0644\u0646\u0648\u0646 \u0644\u0646 \u062A\u0646\u0634\u0631 \u0644\u0647\u0645 (\u0627\u0641\u0635\u0644 \u0628\u0641\u0627\u0635\u0644\u0629\u060C \u0645\u062B\u0644 \u0627\u0644\u0645\u0646\u0627\u0641\u0633\u064A\u0646)",
  "Crypto & trading": "\u0627\u0644\u0639\u0645\u0644\u0627\u062A \u0627\u0644\u0631\u0642\u0645\u064A\u0629 \u0648\u0627\u0644\u062A\u062F\u0627\u0648\u0644",
  "Alcohol & nightlife": "\u0627\u0644\u0643\u062D\u0648\u0644 \u0648\u0627\u0644\u062D\u064A\u0627\u0629 \u0627\u0644\u0644\u064A\u0644\u064A\u0629",
  "Lottery & gaming": "\u0627\u0644\u064A\u0627\u0646\u0635\u064A\u0628 \u0648\u0627\u0644\u0623\u0644\u0639\u0627\u0628",
  "fixed price": "\u0633\u0639\u0631 \u062B\u0627\u0628\u062A",
  "Booking": "\u062D\u062C\u0632",
  "Full week": "\u0623\u0633\u0628\u0648\u0639 \u0643\u0627\u0645\u0644",
  "Business owners and executives": "\u0623\u0635\u062D\u0627\u0628 \u0627\u0644\u0623\u0639\u0645\u0627\u0644 \u0648\u0627\u0644\u062A\u0646\u0641\u064A\u0630\u064A\u0648\u0646",
  "Founders, C-suite and decision makers across the UAE.": "\u0627\u0644\u0645\u0624\u0633\u0633\u0648\u0646 \u0648\u0643\u0628\u0627\u0631 \u0627\u0644\u062A\u0646\u0641\u064A\u0630\u064A\u064A\u0646 \u0648\u0635\u0646\u0627\u0639 \u0627\u0644\u0642\u0631\u0627\u0631 \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A.",
  "Affluent expats": "\u0627\u0644\u0645\u063A\u062A\u0631\u0628\u0648\u0646 \u0627\u0644\u0645\u064A\u0633\u0648\u0631\u0648\u0646",
  "High-income expatriate professionals and families.": "\u0645\u0647\u0646\u064A\u0648\u0646 \u0648\u0639\u0627\u0626\u0644\u0627\u062A \u0645\u063A\u062A\u0631\u0628\u0629 \u0630\u0627\u062A \u062F\u062E\u0644 \u0645\u0631\u062A\u0641\u0639.",
  "Arabic-speaking families": "\u0627\u0644\u0639\u0627\u0626\u0644\u0627\u062A \u0627\u0644\u0646\u0627\u0637\u0642\u0629 \u0628\u0627\u0644\u0639\u0631\u0628\u064A\u0629",
  "Emirati and Arab households, Arabic-first media.": "\u0627\u0644\u0623\u0633\u0631 \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A\u064A\u0629 \u0648\u0627\u0644\u0639\u0631\u0628\u064A\u0629\u060C \u0648\u0627\u0644\u0625\u0639\u0644\u0627\u0645 \u0627\u0644\u0646\u0627\u0637\u0642 \u0628\u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0623\u0648\u0644\u064B\u0627.",
  "Drive-time commuters": "\u0627\u0644\u0645\u062A\u0646\u0642\u0644\u0648\u0646 \u0641\u064A \u0623\u0648\u0642\u0627\u062A \u0627\u0644\u0630\u0631\u0648\u0629",
  "People on the road in the morning and evening rush.": "\u0645\u0646 \u0647\u0645 \u0639\u0644\u0649 \u0627\u0644\u0637\u0631\u064A\u0642 \u0641\u064A \u0632\u062D\u0645\u0629 \u0627\u0644\u0635\u0628\u0627\u062D \u0648\u0627\u0644\u0645\u0633\u0627\u0621.",
  "Property investors": "\u0627\u0644\u0645\u0633\u062A\u062B\u0645\u0631\u0648\u0646 \u0627\u0644\u0639\u0642\u0627\u0631\u064A\u0648\u0646",
  "Buyers and investors following UAE real estate.": "\u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0648\u0627\u0644\u0645\u0633\u062A\u062B\u0645\u0631\u0648\u0646 \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0648\u0646 \u0644\u0639\u0642\u0627\u0631\u0627\u062A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A.",
  "Young professionals": "\u0627\u0644\u0645\u0647\u0646\u064A\u0648\u0646 \u0627\u0644\u0634\u0628\u0627\u0628",
  "Working adults aged 22 to 35 building their careers.": "\u0627\u0644\u0639\u0627\u0645\u0644\u0648\u0646 \u0628\u064A\u0646 22 \u064835 \u0639\u0627\u0645\u064B\u0627 \u0627\u0644\u0630\u064A\u0646 \u064A\u0628\u0646\u0648\u0646 \u0645\u0633\u064A\u0631\u062A\u0647\u0645 \u0627\u0644\u0645\u0647\u0646\u064A\u0629.",
  "Students": "\u0627\u0644\u0637\u0644\u0627\u0628",
  "University and college students.": "\u0637\u0644\u0627\u0628 \u0627\u0644\u062C\u0627\u0645\u0639\u0627\u062A \u0648\u0627\u0644\u0643\u0644\u064A\u0627\u062A.",
  "Parents": "\u0627\u0644\u0622\u0628\u0627\u0621 \u0648\u0627\u0644\u0623\u0645\u0647\u0627\u062A",
  "Mothers and fathers making family decisions.": "\u0627\u0644\u0623\u0645\u0647\u0627\u062A \u0648\u0627\u0644\u0622\u0628\u0627\u0621 \u0627\u0644\u0630\u064A\u0646 \u064A\u062A\u062E\u0630\u0648\u0646 \u0642\u0631\u0627\u0631\u0627\u062A \u0627\u0644\u0623\u0633\u0631\u0629.",
  "Tech early adopters": "\u0623\u0648\u0627\u0626\u0644 \u0645\u062A\u0628\u0646\u064A \u0627\u0644\u062A\u0642\u0646\u064A\u0629",
  "People who buy new gadgets, apps and services first.": "\u0645\u0646 \u064A\u0634\u062A\u0631\u0648\u0646 \u0627\u0644\u0623\u062C\u0647\u0632\u0629 \u0648\u0627\u0644\u062A\u0637\u0628\u064A\u0642\u0627\u062A \u0648\u0627\u0644\u062E\u062F\u0645\u0627\u062A \u0627\u0644\u062C\u062F\u064A\u062F\u0629 \u0623\u0648\u0644\u064B\u0627.",
  "Luxury shoppers": "\u0645\u062A\u0633\u0648\u0642\u0648 \u0627\u0644\u0641\u062E\u0627\u0645\u0629",
  "High spenders on fashion, cars, jewellery and travel.": "\u0643\u0628\u0627\u0631 \u0627\u0644\u0645\u0646\u0641\u0642\u064A\u0646 \u0639\u0644\u0649 \u0627\u0644\u0623\u0632\u064A\u0627\u0621 \u0648\u0627\u0644\u0633\u064A\u0627\u0631\u0627\u062A \u0648\u0627\u0644\u0645\u062C\u0648\u0647\u0631\u0627\u062A \u0648\u0627\u0644\u0633\u0641\u0631.",
  "South Asian community": "\u0645\u062C\u062A\u0645\u0639 \u062C\u0646\u0648\u0628 \u0622\u0633\u064A\u0627",
  "Hindi, Urdu and Malayalam-speaking residents.": "\u0627\u0644\u0645\u0642\u064A\u0645\u0648\u0646 \u0627\u0644\u0646\u0627\u0637\u0642\u0648\u0646 \u0628\u0627\u0644\u0647\u0646\u062F\u064A\u0629 \u0648\u0627\u0644\u0623\u0631\u062F\u064A\u0629 \u0648\u0627\u0644\u0645\u0627\u0644\u0627\u064A\u0627\u0644\u0627\u0645\u064A\u0629.",
  "Sports fans": "\u0639\u0634\u0627\u0642 \u0627\u0644\u0631\u064A\u0627\u0636\u0629",
  "Followers of football, cricket and motorsport.": "\u0645\u062A\u0627\u0628\u0639\u0648 \u0643\u0631\u0629 \u0627\u0644\u0642\u062F\u0645 \u0648\u0627\u0644\u0643\u0631\u064A\u0643\u064A\u062A \u0648\u0631\u064A\u0627\u0636\u0629 \u0627\u0644\u0633\u064A\u0627\u0631\u0627\u062A.",
  "Banking and finance": "\u0627\u0644\u0628\u0646\u0648\u0643 \u0648\u0627\u0644\u062A\u0645\u0648\u064A\u0644",
  "Reach the people choosing a bank, a card or a business account.": "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0645\u0646 \u064A\u062E\u062A\u0627\u0631\u0648\u0646 \u0628\u0646\u0643\u064B\u0627 \u0623\u0648 \u0628\u0637\u0627\u0642\u0629 \u0623\u0648 \u062D\u0633\u0627\u0628\u064B\u0627 \u062A\u062C\u0627\u0631\u064A\u064B\u0627.",
  "Reach buyers, tenants and investors following the UAE property market.": "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u0648\u0627\u0644\u0645\u0633\u062A\u0623\u062C\u0631\u064A\u0646 \u0648\u0627\u0644\u0645\u0633\u062A\u062B\u0645\u0631\u064A\u0646 \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u064A\u0646 \u0644\u0633\u0648\u0642 \u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A\u064A.",
  "Reach shoppers before the weekend, the sale and the season.": "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0627\u0644\u0645\u062A\u0633\u0648\u0642\u064A\u0646 \u0642\u0628\u0644 \u0639\u0637\u0644\u0629 \u0646\u0647\u0627\u064A\u0629 \u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u0648\u0627\u0644\u062A\u062E\u0641\u064A\u0636\u0627\u062A \u0648\u0627\u0644\u0645\u0648\u0627\u0633\u0645.",
  "Reach drivers on their commute and families choosing their next car.": "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0627\u0644\u0633\u0627\u0626\u0642\u064A\u0646 \u0623\u062B\u0646\u0627\u0621 \u062A\u0646\u0642\u0644\u0647\u0645 \u0648\u0627\u0644\u0639\u0627\u0626\u0644\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u062E\u062A\u0627\u0631 \u0633\u064A\u0627\u0631\u062A\u0647\u0627 \u0627\u0644\u0642\u0627\u062F\u0645\u0629.",
  "Reach early adopters and the teams buying software and devices.": "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0623\u0648\u0627\u0626\u0644 \u0627\u0644\u0645\u062A\u0628\u0646\u064A\u0646 \u0648\u0627\u0644\u0641\u0631\u0642 \u0627\u0644\u062A\u064A \u062A\u0634\u062A\u0631\u064A \u0627\u0644\u0628\u0631\u0645\u062C\u064A\u0627\u062A \u0648\u0627\u0644\u0623\u062C\u0647\u0632\u0629.",
  "Hospitality and travel": "\u0627\u0644\u0636\u064A\u0627\u0641\u0629 \u0648\u0627\u0644\u0633\u0641\u0631",
  "Reach residents and visitors planning where to stay, eat and go.": "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0627\u0644\u0645\u0642\u064A\u0645\u064A\u0646 \u0648\u0627\u0644\u0632\u0648\u0627\u0631 \u0627\u0644\u0630\u064A\u0646 \u064A\u062E\u0637\u0637\u0648\u0646 \u0623\u064A\u0646 \u064A\u0642\u064A\u0645\u0648\u0646 \u0648\u064A\u0623\u0643\u0644\u0648\u0646 \u0648\u064A\u0630\u0647\u0628\u0648\u0646.",
  "Reach families and professionals making health decisions.": "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0627\u0644\u0639\u0627\u0626\u0644\u0627\u062A \u0648\u0627\u0644\u0645\u0647\u0646\u064A\u064A\u0646 \u0627\u0644\u0630\u064A\u0646 \u064A\u062A\u062E\u0630\u0648\u0646 \u0642\u0631\u0627\u0631\u0627\u062A \u0635\u062D\u064A\u0629.",
  "Reach parents, students and professionals choosing what to learn next.": "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0627\u0644\u0622\u0628\u0627\u0621 \u0648\u0627\u0644\u0637\u0644\u0627\u0628 \u0648\u0627\u0644\u0645\u0647\u0646\u064A\u064A\u0646 \u0627\u0644\u0630\u064A\u0646 \u064A\u062E\u062A\u0627\u0631\u0648\u0646 \u0645\u0627 \u064A\u062A\u0639\u0644\u0645\u0648\u0646\u0647 \u0628\u0639\u062F \u0630\u0644\u0643.",
  // Account self-service, Nashr stepping in, live updates
  "Check your email": "\u062A\u062D\u0642\u0642 \u0645\u0646 \u0628\u0631\u064A\u062F\u0643 \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
  "Reset your password": "\u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
  "If an account uses {email}, Nashr's team will send it a reset link shortly. The link works for 24 hours.": "\u0625\u0630\u0627 \u0643\u0627\u0646 \u0647\u0646\u0627\u0643 \u062D\u0633\u0627\u0628 \u064A\u0633\u062A\u062E\u062F\u0645 {email}\u060C \u0641\u0633\u064A\u0631\u0633\u0644 \u0644\u0647 \u0641\u0631\u064A\u0642 \u0646\u0634\u0631 \u0631\u0627\u0628\u0637 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062A\u0639\u064A\u064A\u0646 \u0642\u0631\u064A\u0628\u064B\u0627. \u064A\u0639\u0645\u0644 \u0627\u0644\u0631\u0627\u0628\u0637 \u0644\u0645\u062F\u0629 24 \u0633\u0627\u0639\u0629.",
  "Enter your work email. We will send a link to choose a new password.": "\u0623\u062F\u062E\u0644 \u0628\u0631\u064A\u062F \u0627\u0644\u0639\u0645\u0644 \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A. \u0633\u0646\u0631\u0633\u0644 \u0631\u0627\u0628\u0637\u064B\u0627 \u0644\u0627\u062E\u062A\u064A\u0627\u0631 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u062C\u062F\u064A\u062F\u0629.",
  "Send me a reset link": "\u0623\u0631\u0633\u0644 \u0644\u064A \u0631\u0627\u0628\u0637 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062A\u0639\u064A\u064A\u0646",
  "Back to sign in": "\u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644",
  "Password changed": "\u062A\u0645 \u062A\u063A\u064A\u064A\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
  "Choose a new password": "\u0627\u062E\u062A\u0631 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u062C\u062F\u064A\u062F\u0629",
  "Sign in with your new password. You have been signed out everywhere else.": "\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062C\u062F\u064A\u062F\u0629. \u062A\u0645 \u062A\u0633\u062C\u064A\u0644 \u062E\u0631\u0648\u062C\u0643 \u0645\u0646 \u0643\u0644 \u0627\u0644\u0623\u062C\u0647\u0632\u0629 \u0627\u0644\u0623\u062E\u0631\u0649.",
  "Use at least 12 characters.": "\u0627\u0633\u062A\u062E\u062F\u0645 12 \u062D\u0631\u0641\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
  "New password": "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062C\u062F\u064A\u062F\u0629",
  "Save new password": "\u062D\u0641\u0638 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062C\u062F\u064A\u062F\u0629",
  "Password changed. You have been signed out everywhere else.": "\u062A\u0645 \u062A\u063A\u064A\u064A\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631. \u062A\u0645 \u062A\u0633\u062C\u064A\u0644 \u062E\u0631\u0648\u062C\u0643 \u0645\u0646 \u0643\u0644 \u0627\u0644\u0623\u062C\u0647\u0632\u0629 \u0627\u0644\u0623\u062E\u0631\u0649.",
  "Outbid, auto-bid at its maximum, a request accepted or declined.": "\u062A\u062C\u0627\u0648\u0632 \u0639\u0631\u0636\u0643\u060C \u0623\u0648 \u0628\u0644\u0648\u063A \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A\u0629 \u062D\u062F\u0647\u0627 \u0627\u0644\u0623\u0642\u0635\u0649\u060C \u0623\u0648 \u0642\u0628\u0648\u0644 \u0637\u0644\u0628 \u0623\u0648 \u0631\u0641\u0636\u0647.",
  "Saved-search alerts": "\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0639\u0645\u0644\u064A\u0627\u062A \u0627\u0644\u0628\u062D\u062B \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629",
  "New slots that match a search you saved.": "\u0645\u0633\u0627\u062D\u0627\u062A \u062C\u062F\u064A\u062F\u0629 \u062A\u0637\u0627\u0628\u0642 \u0628\u062D\u062B\u064B\u0627 \u062D\u0641\u0638\u062A\u0647.",
  "A new message on one of your bookings.": "\u0631\u0633\u0627\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0641\u064A \u0623\u062D\u062F \u062D\u062C\u0648\u0632\u0627\u062A\u0643.",
  "News from Nashr": "\u0623\u062E\u0628\u0627\u0631 \u0645\u0646 \u0646\u0634\u0631",
  "New features and guides, at most once a month.": "\u0645\u064A\u0632\u0627\u062A \u0648\u0623\u062F\u0644\u0629 \u062C\u062F\u064A\u062F\u0629\u060C \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \u0641\u064A \u0627\u0644\u0634\u0647\u0631 \u0639\u0644\u0649 \u0627\u0644\u0623\u0643\u062B\u0631.",
  "Your account": "\u062D\u0633\u0627\u0628\u0643",
  "Your name": "\u0627\u0633\u0645\u0643",
  "Current password": "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062D\u0627\u0644\u064A\u0629",
  "At least 12 characters. Changing it signs you out on every other device.": "12 \u062D\u0631\u0641\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644. \u062A\u063A\u064A\u064A\u0631\u0647\u0627 \u064A\u0633\u062C\u0651\u0644 \u062E\u0631\u0648\u062C\u0643 \u0645\u0646 \u0643\u0644 \u0627\u0644\u0623\u062C\u0647\u0632\u0629 \u0627\u0644\u0623\u062E\u0631\u0649.",
  "Change password": "\u062A\u063A\u064A\u064A\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
  "Emails": "\u0631\u0633\u0627\u0626\u0644 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
  "Emails about payments, bookings you must act on and deadlines always go, so nothing is missed.": "\u0631\u0633\u0627\u0626\u0644 \u0627\u0644\u062F\u0641\u0639\u0627\u062A \u0648\u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u062A\u0637\u0644\u0628 \u0625\u062C\u0631\u0627\u0621\u064B \u0645\u0646\u0643 \u0648\u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F \u0627\u0644\u0646\u0647\u0627\u0626\u064A\u0629 \u062A\u064F\u0631\u0633\u0644 \u062F\u0627\u0626\u0645\u064B\u0627\u060C \u062D\u062A\u0649 \u0644\u0627 \u064A\u0641\u0648\u062A\u0643 \u0634\u064A\u0621.",
  "Email choices saved.": "\u062A\u0645 \u062D\u0641\u0638 \u0627\u062E\u062A\u064A\u0627\u0631\u0627\u062A \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A.",
  "Someone asked to reset their password. Send them a link from their account page.": "\u0637\u0644\u0628 \u0623\u062D\u062F\u0647\u0645 \u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631. \u0623\u0631\u0633\u0644 \u0644\u0647 \u0631\u0627\u0628\u0637\u064B\u0627 \u0645\u0646 \u0635\u0641\u062D\u0629 \u062D\u0633\u0627\u0628\u0647.",
  "Nashr cancelled this booking.": "\u0623\u0644\u063A\u062A \u0646\u0634\u0631 \u0647\u0630\u0627 \u0627\u0644\u062D\u062C\u0632.",
  "Nashr refunded this booking in full.": "\u0631\u062F\u0651\u062A \u0646\u0634\u0631 \u0645\u0628\u0644\u063A \u0647\u0630\u0627 \u0627\u0644\u062D\u062C\u0632 \u0628\u0627\u0644\u0643\u0627\u0645\u0644.",
  "Nashr refunded part of this booking and released the rest.": "\u0631\u062F\u0651\u062A \u0646\u0634\u0631 \u062C\u0632\u0621\u064B\u0627 \u0645\u0646 \u0645\u0628\u0644\u063A \u0647\u0630\u0627 \u0627\u0644\u062D\u062C\u0632 \u0648\u062D\u0631\u0651\u0631\u062A \u0627\u0644\u0628\u0627\u0642\u064A.",
  "Nashr released the payment to the publisher.": "\u062D\u0631\u0651\u0631\u062A \u0646\u0634\u0631 \u0627\u0644\u062F\u0641\u0639\u0629 \u0644\u0644\u0646\u0627\u0634\u0631.",
  "Nashr voided your bid on {slot}. Reason: {reason}": "\u0623\u0644\u063A\u062A \u0646\u0634\u0631 \u0639\u0631\u0636\u0643 \u0639\u0644\u0649 {slot}. \u0627\u0644\u0633\u0628\u0628: {reason}",
  "A buyer's bank disputed a payment that was already released. Recover it from the publisher.": "\u0627\u0639\u062A\u0631\u0636 \u0628\u0646\u0643 \u0623\u062D\u062F \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u0639\u0644\u0649 \u062F\u0641\u0639\u0629 \u062A\u0645 \u062A\u062D\u0631\u064A\u0631\u0647\u0627 \u0628\u0627\u0644\u0641\u0639\u0644. \u0627\u0633\u062A\u0631\u062F\u0651\u0647\u0627 \u0645\u0646 \u0627\u0644\u0646\u0627\u0634\u0631.",
  "A buyer's bank disputed a payment. The booking is now a dispute for Nashr.": "\u0627\u0639\u062A\u0631\u0636 \u0628\u0646\u0643 \u0623\u062D\u062F \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u0639\u0644\u0649 \u062F\u0641\u0639\u0629. \u0623\u0635\u0628\u062D \u0627\u0644\u062D\u062C\u0632 \u0627\u0644\u0622\u0646 \u0646\u0632\u0627\u0639\u064B\u0627 \u0644\u062F\u0649 \u0646\u0634\u0631.",
  "Forgot your password?": "\u0646\u0633\u064A\u062A \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631\u061F",
  "Asked for a password reset": "\u0637\u0644\u0628 \u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
  "Reset link (valid 24 hours, send it to {email}):": "\u0631\u0627\u0628\u0637 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062A\u0639\u064A\u064A\u0646 (\u0635\u0627\u0644\u062D 24 \u0633\u0627\u0639\u0629\u060C \u0623\u0631\u0633\u0644\u0647 \u0625\u0644\u0649 {email}):",
  "Reset link ready for {name}. Older links no longer work.": "\u0631\u0627\u0628\u0637 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062A\u0639\u064A\u064A\u0646 \u062C\u0627\u0647\u0632 \u0644\u0640 {name}. \u0627\u0644\u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u0623\u0642\u062F\u0645 \u0644\u0645 \u062A\u0639\u062F \u062A\u0639\u0645\u0644.",
  "Password reset link": "\u0631\u0627\u0628\u0637 \u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
  "Order number, buyer, publisher or outlet": "\u0631\u0642\u0645 \u0627\u0644\u0637\u0644\u0628 \u0623\u0648 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0623\u0648 \u0627\u0644\u0646\u0627\u0634\u0631 \u0623\u0648 \u0627\u0644\u0645\u0646\u0635\u0629",
  "Any way of selling": "\u0623\u064A \u0637\u0631\u064A\u0642\u0629 \u0628\u064A\u0639",
  "Airs from": "\u064A\u064F\u0639\u0631\u0636 \u0645\u0646",
  "to": "\u0625\u0644\u0649",
  "{n} deals, {value} in total (excl. VAT)": "{n} \u0635\u0641\u0642\u0629\u060C \u0628\u0625\u062C\u0645\u0627\u0644\u064A {value} (\u063A\u064A\u0631 \u0634\u0627\u0645\u0644 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629)",
  "Open the slot and every bid on it": "\u0627\u0641\u062A\u062D \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0648\u0643\u0644 \u0627\u0644\u0639\u0631\u0648\u0636 \u0639\u0644\u064A\u0647\u0627",
  "No files attached.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0644\u0641\u0627\u062A \u0645\u0631\u0641\u0642\u0629.",
  "File {n}": "\u0645\u0644\u0641 {n}",
  "The buyer, {name}": "\u0627\u0644\u0645\u0634\u062A\u0631\u064A\u060C {name}",
  "Reported {when}": "\u0623\u064F\u0628\u0644\u063A \u0639\u0646\u0647 {when}",
  "No issue on record (a chargeback or a direct escalation).": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0634\u0643\u0644\u0629 \u0645\u0633\u062C\u0644\u0629 (\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0645\u0646 \u0627\u0644\u0628\u0646\u0643 \u0623\u0648 \u062A\u0635\u0639\u064A\u062F \u0645\u0628\u0627\u0634\u0631).",
  "The publisher, {name}": "\u0627\u0644\u0646\u0627\u0634\u0631\u060C {name}",
  "No proof sent.": "\u0644\u0645 \u064A\u064F\u0631\u0633\u0644 \u0625\u062B\u0628\u0627\u062A.",
  "Offered a refund of {amount}": "\u0639\u0631\u0636 \u0627\u0633\u062A\u0631\u062F\u0627\u062F {amount}",
  "Offered to run it again on {when}": "\u0639\u0631\u0636 \u0625\u0639\u0627\u062F\u0629 \u0639\u0631\u0636\u0647 \u0641\u064A {when}",
  "Sent corrected proof": "\u0623\u0631\u0633\u0644 \u0625\u062B\u0628\u0627\u062A\u064B\u0627 \u0645\u0635\u062D\u062D\u064B\u0627",
  "the buyer turned it down": "\u0631\u0641\u0636\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "The brief both sides agreed to": "\u0627\u0644\u0645\u0648\u062C\u0632 \u0627\u0644\u0630\u064A \u0627\u062A\u0641\u0642 \u0639\u0644\u064A\u0647 \u0627\u0644\u0637\u0631\u0641\u0627\u0646",
  "Reason (both sides receive it)": "\u0627\u0644\u0633\u0628\u0628 (\u064A\u0635\u0644 \u0625\u0644\u0649 \u0627\u0644\u0637\u0631\u0641\u064A\u0646)",
  "Step in on this deal": "\u0627\u0644\u062A\u062F\u062E\u0644 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u0642\u0629",
  "For what the normal flow cannot fix: a publisher off air, a mistake, a request from both sides. Every step is on the record.": "\u0644\u0645\u0627 \u0644\u0627 \u064A\u0633\u062A\u0637\u064A\u0639 \u0627\u0644\u0645\u0633\u0627\u0631 \u0627\u0644\u0639\u0627\u062F\u064A \u0625\u0635\u0644\u0627\u062D\u0647: \u0646\u0627\u0634\u0631 \u0645\u062A\u0648\u0642\u0641 \u0639\u0646 \u0627\u0644\u0628\u062B\u060C \u0623\u0648 \u062E\u0637\u0623\u060C \u0623\u0648 \u0637\u0644\u0628 \u0645\u0646 \u0627\u0644\u0637\u0631\u0641\u064A\u0646. \u0643\u0644 \u062E\u0637\u0648\u0629 \u0645\u0633\u062C\u0644\u0629.",
  "What to do": "\u0627\u0644\u0625\u062C\u0631\u0627\u0621 \u0627\u0644\u0645\u0637\u0644\u0648\u0628",
  "Who bears the card cost": "\u0645\u0646 \u064A\u062A\u062D\u0645\u0644 \u062A\u0643\u0644\u0641\u0629 \u0627\u0644\u0628\u0637\u0627\u0642\u0629",
  "Nashr": "\u0646\u0634\u0631",
  "The publisher (from their next payout)": "\u0627\u0644\u0646\u0627\u0634\u0631 (\u0645\u0646 \u062F\u0641\u0639\u062A\u0647 \u0627\u0644\u062A\u0627\u0644\u064A\u0629)",
  "The buyer (kept from the refund)": "\u0627\u0644\u0645\u0634\u062A\u0631\u064A (\u062A\u064F\u062E\u0635\u0645 \u0645\u0646 \u0627\u0644\u0645\u0628\u0644\u063A \u0627\u0644\u0645\u0633\u062A\u0631\u062F)",
  "Apply this now? Money moves at once and both sides are told.": "\u062A\u0637\u0628\u064A\u0642 \u0647\u0630\u0627 \u0627\u0644\u0622\u0646\u061F \u062A\u062A\u062D\u0631\u0643 \u0627\u0644\u0623\u0645\u0648\u0627\u0644 \u0641\u0648\u0631\u064B\u0627 \u0648\u064A\u064F\u0628\u0644\u064E\u0651\u063A \u0627\u0644\u0637\u0631\u0641\u0627\u0646.",
  "Done. Both sides have been told.": "\u062A\u0645. \u0623\u064F\u0628\u0644\u063A \u0627\u0644\u0637\u0631\u0641\u0627\u0646.",
  "Apply": "\u062A\u0637\u0628\u064A\u0642",
  "Top bid": "\u0623\u0639\u0644\u0649 \u0639\u0631\u0636",
  "auto-bid up to {max}": "\u0645\u0632\u0627\u064A\u062F\u0629 \u062A\u0644\u0642\u0627\u0626\u064A\u0629 \u062D\u062A\u0649 {max}",
  "Maximum": "\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u0642\u0635\u0649",
  "Reason the buyer will see": "\u0627\u0644\u0633\u0628\u0628 \u0627\u0644\u0630\u064A \u0633\u064A\u0631\u0627\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "Bid voided. The auction has been worked out again.": "\u0623\u064F\u0644\u063A\u064A \u0627\u0644\u0639\u0631\u0636. \u0623\u064F\u0639\u064A\u062F \u0627\u062D\u062A\u0633\u0627\u0628 \u0627\u0644\u0645\u0632\u0627\u062F.",
  "Void bid": "\u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u0639\u0631\u0636",
  "Void": "\u0625\u0644\u063A\u0627\u0621",
  "Voiding removes all of that buyer's bids on this slot. The highest remaining maximum leads, one step above the next.": "\u0627\u0644\u0625\u0644\u063A\u0627\u0621 \u064A\u0632\u064A\u0644 \u0643\u0644 \u0639\u0631\u0648\u0636 \u0647\u0630\u0627 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0639\u0644\u0649 \u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629. \u064A\u062A\u0635\u062F\u0631 \u0623\u0639\u0644\u0649 \u062D\u062F \u0623\u0642\u0635\u0649 \u0645\u062A\u0628\u0642\u064D\u060C \u0628\u062E\u0637\u0648\u0629 \u0648\u0627\u062D\u062F\u0629 \u0641\u0648\u0642 \u0627\u0644\u062A\u0627\u0644\u064A.",
  "Password resets to send": "\u0631\u0648\u0627\u0628\u0637 \u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0627\u062A \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u0645\u0637\u0644\u0648\u0628 \u0625\u0631\u0633\u0627\u0644\u0647\u0627",
  "Payments held over 60 days: release or refund them": "\u062F\u0641\u0639\u0627\u062A \u0645\u062D\u062A\u062C\u0632\u0629 \u0644\u0623\u0643\u062B\u0631 \u0645\u0646 60 \u064A\u0648\u0645\u064B\u0627: \u062D\u0631\u0651\u0631\u0647\u0627 \u0623\u0648 \u0631\u062F\u0651\u0647\u0627",
  "Append-only. Filter by who, what, when or one record to see its whole history; the CSV holds every match.": "\u0625\u0636\u0627\u0641\u0629 \u0641\u0642\u0637. \u0635\u0641\u0650\u0651 \u062D\u0633\u0628 \u0645\u0646 \u0623\u0648 \u0645\u0627\u0630\u0627 \u0623\u0648 \u0645\u062A\u0649 \u0623\u0648 \u0633\u062C\u0644 \u0648\u0627\u062D\u062F \u0644\u0631\u0624\u064A\u0629 \u062A\u0627\u0631\u064A\u062E\u0647 \u0643\u0627\u0645\u0644\u064B\u0627\u061B \u0648\u064A\u062D\u0648\u064A \u0645\u0644\u0641 CSV \u0643\u0644 \u0627\u0644\u0646\u062A\u0627\u0626\u062C.",
  "Who (e.g. admin:, seller:, system)": "\u0645\u0646 (\u0645\u062B\u0644 admin: \u0623\u0648 seller: \u0623\u0648 system)",
  "Action (e.g. deal., password.)": "\u0627\u0644\u0625\u062C\u0631\u0627\u0621 (\u0645\u062B\u0644 deal. \u0623\u0648 password.)",
  "Nothing matches.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0646\u062A\u0627\u0626\u062C \u0645\u0637\u0627\u0628\u0642\u0629.",
  "Bidding closes in {time}": "\u062A\u064F\u063A\u0644\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u062E\u0644\u0627\u0644 {time}",
  // Sign in as, pilot scorecard, auction close
  "{staff}, you are signed in as {user} of {company} until {time}. Every change is logged under your name.": "{staff}\u060C \u0623\u0646\u062A \u0645\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0627\u0633\u0645 {user} \u0645\u0646 {company} \u062D\u062A\u0649 {time}. \u0643\u0644 \u062A\u063A\u064A\u064A\u0631 \u064A\u064F\u0633\u062C\u064E\u0651\u0644 \u0628\u0627\u0633\u0645\u0643.",
  "Back to Nashr": "\u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u0646\u0634\u0631",
  "Nashr's team signed in to your account as {user} to help. Reason: {reason}": "\u0633\u062C\u0651\u0644 \u0641\u0631\u064A\u0642 \u0646\u0634\u0631 \u0627\u0644\u062F\u062E\u0648\u0644 \u0625\u0644\u0649 \u062D\u0633\u0627\u0628\u0643 \u0628\u0627\u0633\u0645 {user} \u0644\u0644\u0645\u0633\u0627\u0639\u062F\u0629. \u0627\u0644\u0633\u0628\u0628: {reason}",
  "You won {slot} at {amount}. The publisher confirms next, then you pay.": "\u0641\u0632\u062A \u0628\u0640 {slot} \u0628\u0645\u0628\u0644\u063A {amount}. \u064A\u0624\u0643\u062F \u0627\u0644\u0646\u0627\u0634\u0631 \u0623\u0648\u0644\u064B\u0627\u060C \u062B\u0645 \u062A\u062F\u0641\u0639.",
  "Bidding closed on {slot}. Another bid was higher; if the publisher passes on it, you may be offered the slot.": "\u0623\u064F\u063A\u0644\u0642\u062A \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0639\u0644\u0649 {slot}. \u0643\u0627\u0646 \u0647\u0646\u0627\u0643 \u0639\u0631\u0636 \u0623\u0639\u0644\u0649\u061B \u0648\u0625\u0630\u0627 \u0644\u0645 \u064A\u0642\u0628\u0644\u0647 \u0627\u0644\u0646\u0627\u0634\u0631\u060C \u0641\u0642\u062F \u062A\u064F\u0639\u0631\u0636 \u0639\u0644\u064A\u0643 \u0627\u0644\u0645\u0633\u0627\u062D\u0629.",
  "Sign in as {name}": "\u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0627\u0633\u0645 {name}",
  "Why are you signing in as {name}? They see this on their bell.": "\u0644\u0645\u0627\u0630\u0627 \u062A\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0627\u0633\u0645 {name}\u061F \u0633\u064A\u0631\u0649 \u0630\u0644\u0643 \u0641\u064A \u0625\u0634\u0639\u0627\u0631\u0627\u062A\u0647.",
  "For one hour you act as this person. Every change is logged under your name. Their password, email choices, card payments and bank details stay theirs.": "\u0644\u0645\u062F\u0629 \u0633\u0627\u0639\u0629 \u062A\u062A\u0635\u0631\u0641 \u0628\u0635\u0641\u0629 \u0647\u0630\u0627 \u0627\u0644\u0634\u062E\u0635. \u0643\u0644 \u062A\u063A\u064A\u064A\u0631 \u064A\u064F\u0633\u062C\u064E\u0651\u0644 \u0628\u0627\u0633\u0645\u0643. \u062A\u0628\u0642\u0649 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0648\u0627\u062E\u062A\u064A\u0627\u0631\u0627\u062A \u0627\u0644\u0628\u0631\u064A\u062F \u0648\u062F\u0641\u0639\u0627\u062A \u0627\u0644\u0628\u0637\u0627\u0642\u0629 \u0648\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0628\u0646\u0643 \u062E\u0627\u0635\u0629 \u0628\u0647.",
  "Pilot scorecard": "\u0628\u0637\u0627\u0642\u0629 \u0623\u062F\u0627\u0621 \u0627\u0644\u062A\u062C\u0631\u0628\u0629",
  "The targets from the pilot plan, for deals booked in this period.": "\u0623\u0647\u062F\u0627\u0641 \u062E\u0637\u0629 \u0627\u0644\u062A\u062C\u0631\u0628\u0629\u060C \u0644\u0644\u0635\u0641\u0642\u0627\u062A \u0627\u0644\u0645\u062D\u062C\u0648\u0632\u0629 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0641\u062A\u0631\u0629.",
  "{done} of {of}": "{done} \u0645\u0646 {of}",
  "Nothing to count yet": "\u0644\u0627 \u0634\u064A\u0621 \u0644\u0627\u062D\u062A\u0633\u0627\u0628\u0647 \u0628\u0639\u062F",
  "Target {target}": "\u0627\u0644\u0647\u062F\u0641 {target}",
  "No data": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0628\u064A\u0627\u0646\u0627\u062A",
  "Met": "\u0645\u062A\u062D\u0642\u0642",
  "Not met": "\u063A\u064A\u0631 \u0645\u062A\u062D\u0642\u0642",
  "Paid bookings": "\u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0629",
  "Requests accepted within 24 hours": "\u0627\u0644\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u0645\u0642\u0628\u0648\u0644\u0629 \u062E\u0644\u0627\u0644 24 \u0633\u0627\u0639\u0629",
  "Payments completed within 48 hours of acceptance": "\u0627\u0644\u062F\u0641\u0639\u0627\u062A \u0627\u0644\u0645\u0643\u062A\u0645\u0644\u0629 \u062E\u0644\u0627\u0644 48 \u0633\u0627\u0639\u0629 \u0645\u0646 \u0627\u0644\u0642\u0628\u0648\u0644",
  "Proof sent on time": "\u0625\u062B\u0628\u0627\u062A \u0627\u0644\u0639\u0631\u0636 \u0627\u0644\u0645\u0631\u0633\u0644 \u0641\u064A \u0627\u0644\u0645\u0648\u0639\u062F",
  "Paid bookings that became disputes": "\u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0629 \u0627\u0644\u062A\u064A \u0623\u0635\u0628\u062D\u062A \u0646\u0632\u0627\u0639\u0627\u062A",
  "Payouts sent on the day of release": "\u0627\u0644\u062F\u0641\u0639\u0627\u062A \u0627\u0644\u0645\u0631\u0633\u0644\u0629 \u0644\u0644\u0646\u0627\u0634\u0631\u064A\u0646 \u064A\u0648\u0645 \u0627\u0644\u062A\u062D\u0631\u064A\u0631",
  // Help and support, invoice details, auction wins
  "Support": "\u0627\u0644\u062F\u0639\u0645",
  "Help": "\u0627\u0644\u0645\u0633\u0627\u0639\u062F\u0629",
  "New question from {company}.": "\u0633\u0624\u0627\u0644 \u062C\u062F\u064A\u062F \u0645\u0646 {company}.",
  "Nashr answered your question.": "\u0623\u062C\u0627\u0628\u062A \u0646\u0634\u0631 \u0639\u0646 \u0633\u0624\u0627\u0644\u0643.",
  "How do I book a slot?": "\u0643\u064A\u0641 \u0623\u062D\u062C\u0632 \u0645\u0633\u0627\u062D\u0629\u061F",
  "Each slot is sold one of three ways. Auction: the highest bid when bidding closes wins. Fixed price: book it now and it comes off sale at once. Quick sale: offer a price and the publisher picks one. In every case the publisher confirms within {h} hours.": "\u062A\u064F\u0628\u0627\u0639 \u0643\u0644 \u0645\u0633\u0627\u062D\u0629 \u0628\u0625\u062D\u062F\u0649 \u062B\u0644\u0627\u062B \u0637\u0631\u0642. \u0627\u0644\u0645\u0632\u0627\u062F: \u064A\u0641\u0648\u0632 \u0623\u0639\u0644\u0649 \u0639\u0631\u0636 \u0639\u0646\u062F \u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629. \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u062B\u0627\u0628\u062A: \u0627\u062D\u062C\u0632\u0647\u0627 \u0627\u0644\u0622\u0646 \u0641\u062A\u064F\u0633\u062D\u0628 \u0645\u0646 \u0627\u0644\u0628\u064A\u0639 \u0641\u0648\u0631\u064B\u0627. \u0627\u0644\u0628\u064A\u0639 \u0627\u0644\u0633\u0631\u064A\u0639: \u0627\u0639\u0631\u0636 \u0633\u0639\u0631\u064B\u0627 \u0648\u064A\u062E\u062A\u0627\u0631 \u0627\u0644\u0646\u0627\u0634\u0631 \u0623\u062D\u062F \u0627\u0644\u0639\u0631\u0648\u0636. \u0648\u0641\u064A \u0643\u0644 \u0627\u0644\u062D\u0627\u0644\u0627\u062A \u064A\u0624\u0643\u062F \u0627\u0644\u0646\u0627\u0634\u0631 \u062E\u0644\u0627\u0644 {h} \u0633\u0627\u0639\u0629.",
  "What is auto-bid?": "\u0645\u0627 \u0647\u064A \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A\u0629\u061F",
  "Set the most you will pay. Nashr bids for you, one step above anyone else, up to that maximum. If the publisher has a hidden minimum price and your maximum covers it, your bid rises to that minimum at once. Other buyers never see your maximum.": "\u062D\u062F\u0651\u062F \u0623\u0642\u0635\u0649 \u0645\u0627 \u0633\u062A\u062F\u0641\u0639\u0647. \u062A\u0632\u0627\u064A\u062F \u0646\u0634\u0631 \u0639\u0646\u0643 \u0628\u062E\u0637\u0648\u0629 \u0648\u0627\u062D\u062F\u0629 \u0641\u0648\u0642 \u0623\u064A \u0634\u062E\u0635 \u0622\u062E\u0631 \u062D\u062A\u0649 \u0647\u0630\u0627 \u0627\u0644\u062D\u062F. \u0648\u0625\u0630\u0627 \u0643\u0627\u0646 \u0644\u062F\u0649 \u0627\u0644\u0646\u0627\u0634\u0631 \u062D\u062F \u0623\u062F\u0646\u0649 \u0645\u062E\u0641\u064A \u0644\u0644\u0633\u0639\u0631 \u0648\u064A\u063A\u0637\u064A\u0647 \u062D\u062F\u0643 \u0627\u0644\u0623\u0642\u0635\u0649\u060C \u064A\u0631\u062A\u0641\u0639 \u0639\u0631\u0636\u0643 \u0625\u0644\u064A\u0647 \u0641\u0648\u0631\u064B\u0627. \u0644\u0627 \u064A\u0631\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0627\u0644\u0622\u062E\u0631\u0648\u0646 \u062D\u062F\u0643 \u0627\u0644\u0623\u0642\u0635\u0649 \u0623\u0628\u062F\u064B\u0627.",
  "When do I pay?": "\u0645\u062A\u0649 \u0623\u062F\u0641\u0639\u061F",
  "Only after the publisher accepts. You then have {h} hours to pay, or until the creative deadline if that comes sooner.": "\u0641\u0642\u0637 \u0628\u0639\u062F \u0642\u0628\u0648\u0644 \u0627\u0644\u0646\u0627\u0634\u0631. \u0644\u062F\u064A\u0643 \u0628\u0639\u062F\u0647\u0627 {h} \u0633\u0627\u0639\u0629 \u0644\u0644\u062F\u0641\u0639\u060C \u0623\u0648 \u062D\u062A\u0649 \u0645\u0648\u0639\u062F \u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0625\u0646 \u0643\u0627\u0646 \u0623\u0642\u0631\u0628.",
  "Where does my money go?": "\u0623\u064A\u0646 \u062A\u0630\u0647\u0628 \u0623\u0645\u0648\u0627\u0644\u064A\u061F",
  "Nashr holds it. The publisher is paid only after you approve proof that the ad ran. If you do not answer within {d} working days, it is released.": "\u062A\u062D\u062A\u0641\u0638 \u0628\u0647\u0627 \u0646\u0634\u0631. \u0644\u0627 \u064A\u064F\u062F\u0641\u0639 \u0644\u0644\u0646\u0627\u0634\u0631 \u0625\u0644\u0627 \u0628\u0639\u062F \u0645\u0648\u0627\u0641\u0642\u062A\u0643 \u0639\u0644\u0649 \u0625\u062B\u0628\u0627\u062A \u0639\u0631\u0636 \u0627\u0644\u0625\u0639\u0644\u0627\u0646. \u0648\u0625\u0630\u0627 \u0644\u0645 \u062A\u0631\u062F \u062E\u0644\u0627\u0644 {d} \u0623\u064A\u0627\u0645 \u0639\u0645\u0644\u060C \u062A\u064F\u062D\u0631\u064E\u0651\u0631 \u0627\u0644\u062F\u0641\u0639\u0629.",
  "What if the ad did not run as booked?": "\u0645\u0627\u0630\u0627 \u0644\u0648 \u0644\u0645 \u064A\u064F\u0639\u0631\u0636 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0643\u0645\u0627 \u062D\u064F\u062C\u0632\u061F",
  "Report an issue from the booking while you review the proof. The publisher has {h} hours to fix it, offer a make-good or refund. If you cannot agree, Nashr decides.": "\u0623\u0628\u0644\u063A \u0639\u0646 \u0645\u0634\u0643\u0644\u0629 \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u062D\u062C\u0632 \u0623\u062B\u0646\u0627\u0621 \u0645\u0631\u0627\u062C\u0639\u0629 \u0627\u0644\u0625\u062B\u0628\u0627\u062A. \u0644\u062F\u0649 \u0627\u0644\u0646\u0627\u0634\u0631 {h} \u0633\u0627\u0639\u0629 \u0644\u0625\u0635\u0644\u0627\u062D\u0647\u0627 \u0623\u0648 \u0639\u0631\u0636 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0628\u062B \u0623\u0648 \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F. \u0648\u0625\u0630\u0627 \u0644\u0645 \u062A\u062A\u0641\u0642\u0627\u060C \u062A\u0642\u0631\u0631 \u0646\u0634\u0631.",
  "Can I cancel?": "\u0647\u0644 \u064A\u0645\u0643\u0646\u0646\u064A \u0627\u0644\u0625\u0644\u063A\u0627\u0621\u061F",
  "Free within {h} hours of paying. After that the publisher keeps {pct}% of the price.": "\u0645\u062C\u0627\u0646\u064B\u0627 \u062E\u0644\u0627\u0644 {h} \u0633\u0627\u0639\u0629 \u0645\u0646 \u0627\u0644\u062F\u0641\u0639. \u0628\u0639\u062F \u0630\u0644\u0643 \u064A\u062D\u062A\u0641\u0638 \u0627\u0644\u0646\u0627\u0634\u0631 \u0628\u0646\u0633\u0628\u0629 {pct}% \u0645\u0646 \u0627\u0644\u0633\u0639\u0631.",
  "Where are my receipts and tax invoices?": "\u0623\u064A\u0646 \u0625\u064A\u0635\u0627\u0644\u0627\u062A\u064A \u0648\u0641\u0648\u0627\u062A\u064A\u0631\u064A \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629\u061F",
  "Under Bookings, Receipts and invoices: a receipt from Nashr when you pay, then the publisher's tax invoice. Add your TRN and registered address under Company so they appear on them.": "\u0641\u064A \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A\u060C \u0627\u0644\u0625\u064A\u0635\u0627\u0644\u0627\u062A \u0648\u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631: \u0625\u064A\u0635\u0627\u0644 \u0645\u0646 \u0646\u0634\u0631 \u0639\u0646\u062F \u0627\u0644\u062F\u0641\u0639\u060C \u062B\u0645 \u0627\u0644\u0641\u0627\u062A\u0648\u0631\u0629 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629 \u0645\u0646 \u0627\u0644\u0646\u0627\u0634\u0631. \u0623\u0636\u0641 \u0631\u0642\u0645\u0643 \u0627\u0644\u0636\u0631\u064A\u0628\u064A \u0648\u0639\u0646\u0648\u0627\u0646\u0643 \u0627\u0644\u0645\u0633\u062C\u0644 \u0641\u064A \u0635\u0641\u062D\u0629 \u0627\u0644\u0634\u0631\u0643\u0629 \u0644\u064A\u0638\u0647\u0631\u0627 \u0639\u0644\u064A\u0647\u0627.",
  "How do bookings reach me?": "\u0643\u064A\u0641 \u062A\u0635\u0644\u0646\u064A \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A\u061F",
  "In your Inbox. Accept or decline each one within {h} hours, or switch on auto-accept for a placement.": "\u0641\u064A \u0635\u0646\u062F\u0648\u0642 \u0627\u0644\u0648\u0627\u0631\u062F. \u0627\u0642\u0628\u0644 \u0643\u0644 \u062D\u062C\u0632 \u0623\u0648 \u0627\u0631\u0641\u0636\u0647 \u062E\u0644\u0627\u0644 {h} \u0633\u0627\u0639\u0629\u060C \u0623\u0648 \u0641\u0639\u0651\u0644 \u0627\u0644\u0642\u0628\u0648\u0644 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A \u0644\u0645\u0633\u0627\u062D\u0629 \u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "When am I paid?": "\u0645\u062A\u0649 \u0623\u062D\u0635\u0644 \u0639\u0644\u0649 \u0623\u0645\u0648\u0627\u0644\u064A\u061F",
  "After the buyer approves proof, or {d} working days after you send it if they do not answer. Nashr's commission is deducted and the rest goes to your verified bank account.": "\u0628\u0639\u062F \u0645\u0648\u0627\u0641\u0642\u0629 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0639\u0644\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A\u060C \u0623\u0648 \u0628\u0639\u062F {d} \u0623\u064A\u0627\u0645 \u0639\u0645\u0644 \u0645\u0646 \u0625\u0631\u0633\u0627\u0644\u0647 \u0625\u0646 \u0644\u0645 \u064A\u0631\u062F. \u062A\u064F\u062E\u0635\u0645 \u0639\u0645\u0648\u0644\u0629 \u0646\u0634\u0631 \u0648\u064A\u064F\u062D\u0648\u064E\u0651\u0644 \u0627\u0644\u0628\u0627\u0642\u064A \u0625\u0644\u0649 \u062D\u0633\u0627\u0628\u0643 \u0627\u0644\u0628\u0646\u0643\u064A \u0627\u0644\u0645\u0648\u062B\u0651\u0642.",
  "When is proof due?": "\u0645\u062A\u0649 \u064A\u062C\u0628 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A\u061F",
  "Within {d} working days after the ad runs. If it is missing, the buyer is refunded.": "\u062E\u0644\u0627\u0644 {d} \u0623\u064A\u0627\u0645 \u0639\u0645\u0644 \u0628\u0639\u062F \u0639\u0631\u0636 \u0627\u0644\u0625\u0639\u0644\u0627\u0646. \u0648\u0625\u0630\u0627 \u0644\u0645 \u064A\u064F\u0631\u0633\u0644\u060C \u064A\u064F\u0631\u062F \u0627\u0644\u0645\u0628\u0644\u063A \u0644\u0644\u0645\u0634\u062A\u0631\u064A.",
  "Can I ask for changes to the creative?": "\u0647\u0644 \u064A\u0645\u0643\u0646\u0646\u064A \u0637\u0644\u0628 \u062A\u0639\u062F\u064A\u0644\u0627\u062A \u0639\u0644\u0649 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u061F",
  "Yes, up to {n} rounds, before the creative deadline.": "\u0646\u0639\u0645\u060C \u062D\u062A\u0649 {n} \u062C\u0648\u0644\u0627\u062A\u060C \u0642\u0628\u0644 \u0645\u0648\u0639\u062F \u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0625\u0639\u0644\u0627\u0646.",
  "Who issues the tax invoices?": "\u0645\u0646 \u064A\u0635\u062F\u0631 \u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629\u061F",
  "Nashr issues them in your name and TRN, or you upload your own; choose under Profile. Nashr's commission invoice comes to you. All of them are under Earnings, Receipts and invoices.": "\u062A\u0635\u062F\u0631\u0647\u0627 \u0646\u0634\u0631 \u0628\u0627\u0633\u0645\u0643 \u0648\u0631\u0642\u0645\u0643 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u060C \u0623\u0648 \u062A\u0631\u0641\u0639 \u0641\u0648\u0627\u062A\u064A\u0631\u0643 \u0628\u0646\u0641\u0633\u0643\u061B \u0627\u062E\u062A\u0631 \u0630\u0644\u0643 \u0645\u0646 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u062A\u0639\u0631\u064A\u0641\u064A. \u0648\u062A\u0635\u0644\u0643 \u0641\u0627\u062A\u0648\u0631\u0629 \u0639\u0645\u0648\u0644\u0629 \u0646\u0634\u0631. \u062A\u062C\u062F\u0647\u0627 \u0643\u0644\u0647\u0627 \u0641\u064A \u0627\u0644\u0623\u0631\u0628\u0627\u062D\u060C \u0627\u0644\u0625\u064A\u0635\u0627\u0644\u0627\u062A \u0648\u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631.",
  "What if I cannot run a paid booking?": "\u0645\u0627\u0630\u0627 \u0644\u0648 \u0644\u0645 \u0623\u0633\u062A\u0637\u0639 \u062A\u0646\u0641\u064A\u0630 \u062D\u062C\u0632 \u0645\u062F\u0641\u0648\u0639\u061F",
  "Cancel it from the deal. The buyer is refunded in full, and the card costs come out of your next payout.": "\u0623\u0644\u063A\u0647 \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u0635\u0641\u0642\u0629. \u064A\u064F\u0631\u062F \u0627\u0644\u0645\u0628\u0644\u063A \u0643\u0627\u0645\u0644\u064B\u0627 \u0644\u0644\u0645\u0634\u062A\u0631\u064A\u060C \u0648\u062A\u064F\u062E\u0635\u0645 \u062A\u0643\u0627\u0644\u064A\u0641 \u0627\u0644\u0628\u0637\u0627\u0642\u0629 \u0645\u0646 \u062F\u0641\u0639\u062A\u0643 \u0627\u0644\u062A\u0627\u0644\u064A\u0629.",
  "I forgot my password": "\u0646\u0633\u064A\u062A \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
  'Use "Forgot your password?" on the sign-in page. Nashr sends you a link that works for 24 hours.': "\u0627\u0633\u062A\u062E\u062F\u0645 \xAB\u0646\u0633\u064A\u062A \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631\u061F\xBB \u0641\u064A \u0635\u0641\u062D\u0629 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644. \u062A\u0631\u0633\u0644 \u0644\u0643 \u0646\u0634\u0631 \u0631\u0627\u0628\u0637\u064B\u0627 \u064A\u0639\u0645\u0644 \u0644\u0645\u062F\u0629 24 \u0633\u0627\u0639\u0629.",
  "How do I add a colleague?": "\u0643\u064A\u0641 \u0623\u0636\u064A\u0641 \u0632\u0645\u064A\u0644\u064B\u0627\u061F",
  "Ask Nashr below: everyone joins by invitation.": "\u0627\u0637\u0644\u0628 \u0630\u0644\u0643 \u0645\u0646 \u0646\u0634\u0631 \u0623\u062F\u0646\u0627\u0647: \u064A\u0646\u0636\u0645 \u0627\u0644\u062C\u0645\u064A\u0639 \u0628\u062F\u0639\u0648\u0629.",
  "How Nashr works, and a direct line to the team.": "\u0643\u064A\u0641 \u062A\u0639\u0645\u0644 \u0646\u0634\u0631\u060C \u0648\u062E\u0637 \u0645\u0628\u0627\u0634\u0631 \u0645\u0639 \u0627\u0644\u0641\u0631\u064A\u0642.",
  "For advertisers": "\u0644\u0644\u0645\u0639\u0644\u0646\u064A\u0646",
  "Booking and paying": "\u0627\u0644\u062D\u062C\u0632 \u0648\u0627\u0644\u062F\u0641\u0639",
  "For publishers": "\u0644\u0644\u0646\u0627\u0634\u0631\u064A\u0646",
  "Selling and getting paid": "\u0627\u0644\u0628\u064A\u0639 \u0648\u0627\u0633\u062A\u0644\u0627\u0645 \u0627\u0644\u0623\u0645\u0648\u0627\u0644",
  "Contact Nashr": "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0646\u0634\u0631",
  "Sign in to send a question to the team and follow the answer here.": "\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0644\u0625\u0631\u0633\u0627\u0644 \u0633\u0624\u0627\u0644 \u0625\u0644\u0649 \u0627\u0644\u0641\u0631\u064A\u0642 \u0648\u0645\u062A\u0627\u0628\u0639\u0629 \u0627\u0644\u0625\u062C\u0627\u0628\u0629 \u0647\u0646\u0627.",
  "The team answers here and on your bell, usually within one working day.": "\u064A\u062C\u064A\u0628 \u0627\u0644\u0641\u0631\u064A\u0642 \u0647\u0646\u0627 \u0648\u0641\u064A \u0625\u0634\u0639\u0627\u0631\u0627\u062A\u0643\u060C \u0639\u0627\u062F\u0629\u064B \u062E\u0644\u0627\u0644 \u064A\u0648\u0645 \u0639\u0645\u0644 \u0648\u0627\u062D\u062F.",
  "What is it about?": "\u0628\u062E\u0635\u0648\u0635 \u0645\u0627\u0630\u0627\u061F",
  "About the booking you came from. Nashr sees it with your question.": "\u0628\u062E\u0635\u0648\u0635 \u0627\u0644\u062D\u062C\u0632 \u0627\u0644\u0630\u064A \u062C\u0626\u062A \u0645\u0646\u0647. \u062A\u0631\u0627\u0647 \u0646\u0634\u0631 \u0645\u0639 \u0633\u0624\u0627\u0644\u0643.",
  "Your question": "\u0633\u0624\u0627\u0644\u0643",
  "Send to Nashr": "\u0623\u0631\u0633\u0644 \u0625\u0644\u0649 \u0646\u0634\u0631",
  "Sent. You will see the answer below and on your bell.": "\u062A\u0645 \u0627\u0644\u0625\u0631\u0633\u0627\u0644. \u0633\u062A\u0631\u0649 \u0627\u0644\u0625\u062C\u0627\u0628\u0629 \u0623\u062F\u0646\u0627\u0647 \u0648\u0641\u064A \u0625\u0634\u0639\u0627\u0631\u0627\u062A\u0643.",
  "Your questions": "\u0623\u0633\u0626\u0644\u062A\u0643",
  "Waiting for Nashr": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0646\u0634\u0631",
  "Answered": "\u062A\u0645\u062A \u0627\u0644\u0625\u062C\u0627\u0628\u0629",
  "Nashr replied": "\u0631\u062F\u0651\u062A \u0646\u0634\u0631",
  "Questions from buyers and publishers": "\u0623\u0633\u0626\u0644\u0629 \u0645\u0646 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u0648\u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646",
  "Questions sent from the Help page. Your answer reaches them on their bell.": "\u0623\u0633\u0626\u0644\u0629 \u0645\u0631\u0633\u0644\u0629 \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0633\u0627\u0639\u062F\u0629. \u062A\u0635\u0644\u0647\u0645 \u0625\u062C\u0627\u0628\u062A\u0643 \u0641\u064A \u0625\u0634\u0639\u0627\u0631\u0627\u062A\u0647\u0645.",
  "Waiting": "\u0628\u0627\u0644\u0627\u0646\u062A\u0638\u0627\u0631",
  "No questions waiting.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0623\u0633\u0626\u0644\u0629 \u0628\u0627\u0644\u0627\u0646\u062A\u0638\u0627\u0631.",
  "Answer": "\u0627\u0644\u0625\u062C\u0627\u0628\u0629",
  "Your answer": "\u0625\u062C\u0627\u0628\u062A\u0643",
  "Answer sent.": "\u0623\u064F\u0631\u0633\u0644\u062A \u0627\u0644\u0625\u062C\u0627\u0628\u0629.",
  "Send answer": "\u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0625\u062C\u0627\u0628\u0629",
  "Answer sent and closed.": "\u0623\u064F\u0631\u0633\u0644\u062A \u0627\u0644\u0625\u062C\u0627\u0628\u0629 \u0648\u0623\u064F\u063A\u0644\u0642 \u0627\u0644\u0633\u0624\u0627\u0644.",
  "Send and close": "\u0625\u0631\u0633\u0627\u0644 \u0648\u0625\u063A\u0644\u0627\u0642",
  "Closed.": "\u0623\u064F\u063A\u0644\u0642.",
  "Close without answer": "\u0625\u063A\u0644\u0627\u0642 \u062F\u0648\u0646 \u0625\u062C\u0627\u0628\u0629",
  "Get help with this booking": "\u0627\u062D\u0635\u0644 \u0639\u0644\u0649 \u0645\u0633\u0627\u0639\u062F\u0629 \u0628\u0634\u0623\u0646 \u0647\u0630\u0627 \u0627\u0644\u062D\u062C\u0632",
  "Saved. New invoices and receipts carry these details.": "\u062A\u0645 \u0627\u0644\u062D\u0641\u0638. \u062A\u062D\u0645\u0644 \u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631 \u0648\u0627\u0644\u0625\u064A\u0635\u0627\u0644\u0627\u062A \u0627\u0644\u062C\u062F\u064A\u062F\u0629 \u0647\u0630\u0647 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A.",
  "Invoice details": "\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631",
  "Registered address": "\u0627\u0644\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u0633\u062C\u0644",
  "As on your trade licence. It is printed on the invoices and receipts you receive.": "\u0643\u0645\u0627 \u0641\u064A \u0631\u062E\u0635\u062A\u0643 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629. \u064A\u064F\u0637\u0628\u0639 \u0639\u0644\u0649 \u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631 \u0648\u0627\u0644\u0625\u064A\u0635\u0627\u0644\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u0635\u0644\u0643.",
  "Auctions you won": "\u0627\u0644\u0645\u0632\u0627\u062F\u0627\u062A \u0627\u0644\u062A\u064A \u0641\u0632\u062A \u0628\u0647\u0627",
  "You won {slot}": "\u0641\u0632\u062A \u0628\u0640 {slot}",
  "The publisher confirmed. Pay {amount} by {when} to secure it.": "\u0623\u0643\u062F \u0627\u0644\u0646\u0627\u0634\u0631. \u0627\u062F\u0641\u0639 {amount} \u0642\u0628\u0644 {when} \u0644\u062A\u0623\u0645\u064A\u0646\u0647\u0627.",
  "{amount} with VAT. The publisher confirms by {when}; you pay only then.": "{amount} \u0634\u0627\u0645\u0644\u0629 \u0627\u0644\u0636\u0631\u064A\u0628\u0629. \u064A\u0624\u0643\u062F \u0627\u0644\u0646\u0627\u0634\u0631 \u0642\u0628\u0644 {when}\u061B \u0648\u0644\u0627 \u062A\u062F\u0641\u0639 \u0625\u0644\u0627 \u0628\u0639\u062F \u0630\u0644\u0643.",
  "Pay now": "\u0627\u062F\u0641\u0639 \u0627\u0644\u0622\u0646",
  "View booking": "\u0639\u0631\u0636 \u0627\u0644\u062D\u062C\u0632",
  "You won this slot.": "\u0641\u0632\u062A \u0628\u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629.",
  "See it in Bookings": "\u0627\u0637\u0644\u0639 \u0639\u0644\u064A\u0647\u0627 \u0641\u064A \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A",
  "Orders, the tax invoices issued in your name, Nashr's commission invoices and credit notes.": "\u0627\u0644\u0637\u0644\u0628\u0627\u062A\u060C \u0648\u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629 \u0627\u0644\u0635\u0627\u062F\u0631\u0629 \u0628\u0627\u0633\u0645\u0643\u060C \u0648\u0641\u0648\u0627\u062A\u064A\u0631 \u0639\u0645\u0648\u0644\u0629 \u0646\u0634\u0631\u060C \u0648\u0627\u0644\u0625\u0634\u0639\u0627\u0631\u0627\u062A \u0627\u0644\u062F\u0627\u0626\u0646\u0629.",
  "Nothing yet. Each accepted booking adds an order, and each payment a tax invoice in your name.": "\u0644\u0627 \u0634\u064A\u0621 \u0628\u0639\u062F. \u064A\u0636\u064A\u0641 \u0643\u0644 \u062D\u062C\u0632 \u0645\u0642\u0628\u0648\u0644 \u0637\u0644\u0628\u064B\u0627\u060C \u0648\u0643\u0644 \u062F\u0641\u0639\u0629 \u0641\u0627\u062A\u0648\u0631\u0629 \u0636\u0631\u064A\u0628\u064A\u0629 \u0628\u0627\u0633\u0645\u0643.",
  "Document type": "\u0646\u0648\u0639 \u0627\u0644\u0645\u0633\u062A\u0646\u062F",
  "PDF": "PDF",
  "PDF of {number}": "\u0645\u0644\u0641 PDF \u0644\u0640 {number}",
  "Download PDF": "\u062A\u0646\u0632\u064A\u0644 PDF",
  "As on your trade licence. It is printed on the tax invoices issued in your name.": "\u0643\u0645\u0627 \u0641\u064A \u0631\u062E\u0635\u062A\u0643 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629. \u064A\u064F\u0637\u0628\u0639 \u0639\u0644\u0649 \u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629 \u0627\u0644\u0635\u0627\u062F\u0631\u0629 \u0628\u0627\u0633\u0645\u0643.",
  "A booking": "\u062D\u062C\u0632",
  "A payment or refund": "\u062F\u0641\u0639\u0629 \u0623\u0648 \u0627\u0633\u062A\u0631\u062F\u0627\u062F",
  "My listings": "\u0645\u0633\u0627\u062D\u0627\u062A\u064A \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "My account": "\u062D\u0633\u0627\u0628\u064A",
  // Two-step sign-in for everyone
  "connecting your payout account": "\u0631\u0628\u0637 \u062D\u0633\u0627\u0628 \u0627\u0644\u062A\u062D\u0648\u064A\u0644\u0627\u062A",
  "paying for a booking": "\u0627\u0644\u062F\u0641\u0639 \u0645\u0642\u0627\u0628\u0644 \u062D\u062C\u0632",
  "Two-step sign-in": "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646",
  "Your authenticator was set up when you joined Nashr.": "\u0623\u064F\u0639\u062F\u0651 \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629 \u0644\u062F\u064A\u0643 \u0639\u0646\u062F \u0627\u0646\u0636\u0645\u0627\u0645\u0643 \u0625\u0644\u0649 \u0646\u0634\u0631.",
  "On": "\u0645\u0641\u0639\u0651\u0644",
  "Signing in asks for a code from your authenticator app.": "\u064A\u0637\u0644\u0628 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0631\u0645\u0632\u064B\u0627 \u0645\u0646 \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629.",
  "Turn off": "\u0625\u064A\u0642\u0627\u0641",
  "Two-step sign-in is off.": "\u062A\u0645 \u0625\u064A\u0642\u0627\u0641 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646.",
  "Without it you cannot go on {what}.": "\u0645\u0646 \u062F\u0648\u0646\u0647 \u0644\u0627 \u064A\u0645\u0643\u0646\u0643 {what}.",
  "Turn off two-step sign-in": "\u0625\u064A\u0642\u0627\u0641 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646",
  "Keep it on": "\u0625\u0628\u0642\u0627\u0624\u0647 \u0645\u0641\u0639\u0651\u0644\u064B\u0627",
  "Protect your account with a code from an authenticator app (Google Authenticator, Microsoft Authenticator, 1Password and others) each time you sign in.": "\u0627\u062D\u0645\u0650 \u062D\u0633\u0627\u0628\u0643 \u0628\u0631\u0645\u0632 \u0645\u0646 \u062A\u0637\u0628\u064A\u0642 \u0645\u0635\u0627\u062F\u0642\u0629 (Google Authenticator \u0623\u0648 Microsoft Authenticator \u0623\u0648 1Password \u0648\u063A\u064A\u0631\u0647\u0627) \u0641\u064A \u0643\u0644 \u0645\u0631\u0629 \u062A\u0633\u062C\u0651\u0644 \u0641\u064A\u0647\u0627 \u0627\u0644\u062F\u062E\u0648\u0644.",
  "Nashr asks for it before {what}.": "\u062A\u0637\u0644\u0628\u0647 \u0646\u0634\u0631 \u0642\u0628\u0644 {what}.",
  "Turn on two-step sign-in": "\u062A\u0641\u0639\u064A\u0644 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646",
  "Two-step sign-in is on. Next time you sign in, have your authenticator app ready.": "\u062A\u0645 \u062A\u0641\u0639\u064A\u0644 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646. \u0623\u0628\u0642\u0650 \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629 \u062C\u0627\u0647\u0632\u064B\u0627 \u0639\u0646\u062F \u062A\u0633\u062C\u064A\u0644 \u062F\u062E\u0648\u0644\u0643 \u0627\u0644\u0642\u0627\u062F\u0645.",
  "In your authenticator app, add an account and type this key:": "\u0641\u064A \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629\u060C \u0623\u0636\u0641 \u062D\u0633\u0627\u0628\u064B\u0627 \u0648\u0627\u0643\u062A\u0628 \u0647\u0630\u0627 \u0627\u0644\u0645\u0641\u062A\u0627\u062D:",
  "On this phone? Open it in your authenticator app": "\u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0647\u0627\u062A\u0641\u061F \u0627\u0641\u062A\u062D\u0647 \u0641\u064A \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629",
  "Enter the 6-digit code the app shows:": "\u0623\u062F\u062E\u0644 \u0627\u0644\u0631\u0645\u0632 \u0627\u0644\u0645\u0643\u0648\u0651\u0646 \u0645\u0646 6 \u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0630\u064A \u064A\u0638\u0647\u0631\u0647 \u0627\u0644\u062A\u0637\u0628\u064A\u0642:",
  "Confirm and turn on": "\u062A\u0623\u0643\u064A\u062F \u0648\u062A\u0641\u0639\u064A\u0644",
  "Nashr turned off two-step sign-in for {user}. Reason: {reason}": "\u0623\u0648\u0642\u0641\u062A \u0646\u0634\u0631 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646 \u0644\u0640 {user}. \u0627\u0644\u0633\u0628\u0628: {reason}",
  "Two-step on": "\u0627\u0644\u062E\u0637\u0648\u062A\u0627\u0646 \u0645\u0641\u0639\u0651\u0644\u062A\u0627\u0646",
  "Why is two-step sign-in being turned off for {name}? (lost phone, identity checked\u2026) Their company sees this.": "\u0644\u0645\u0627\u0630\u0627 \u064A\u064F\u0648\u0642\u0641 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646 \u0644\u0640 {name}\u061F (\u0647\u0627\u062A\u0641 \u0645\u0641\u0642\u0648\u062F\u060C \u062A\u0645 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0647\u0648\u064A\u0629\u2026) \u0633\u062A\u0637\u0651\u0644\u0639 \u0634\u0631\u0643\u062A\u0647 \u0639\u0644\u0649 \u0630\u0644\u0643.",
  "Two-step sign-in is off for {name}. They have been signed out.": "\u0623\u064F\u0648\u0642\u0641 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646 \u0644\u0640 {name}. \u0648\u062A\u0645 \u062A\u0633\u062C\u064A\u0644 \u062E\u0631\u0648\u062C\u0647.",
  "Turn off two-step": "\u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u062E\u0637\u0648\u062A\u064A\u0646",
  "Before paying, turn on two-step sign-in to protect your account.": "\u0642\u0628\u0644 \u0627\u0644\u062F\u0641\u0639\u060C \u0641\u0639\u0651\u0644 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646 \u0644\u062D\u0645\u0627\u064A\u0629 \u062D\u0633\u0627\u0628\u0643.",
  "Turn it on": "\u0641\u0639\u0651\u0644\u0647 \u0627\u0644\u0622\u0646",
  "Before connecting where your money goes, turn on two-step sign-in to protect your account.": "\u0642\u0628\u0644 \u0631\u0628\u0637 \u0627\u0644\u062D\u0633\u0627\u0628 \u0627\u0644\u0630\u064A \u062A\u064F\u062D\u0648\u064E\u0651\u0644 \u0625\u0644\u064A\u0647 \u0623\u0645\u0648\u0627\u0644\u0643\u060C \u0641\u0639\u0651\u0644 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646 \u0644\u062D\u0645\u0627\u064A\u0629 \u062D\u0633\u0627\u0628\u0643.",
  // Review fixes: resets on request, chargebacks
  "Nashr issued a password reset link for {user}, who asked for one.": "\u0623\u0635\u062F\u0631\u062A \u0646\u0634\u0631 \u0631\u0627\u0628\u0637 \u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0644\u0640 {user} \u0628\u0646\u0627\u0621\u064B \u0639\u0644\u0649 \u0637\u0644\u0628\u0647.",
  "The bank decided a chargeback for Nashr. Decide the dispute now.": "\u062D\u0633\u0645 \u0627\u0644\u0628\u0646\u0643 \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0644\u0635\u0627\u0644\u062D \u0646\u0634\u0631. \u0642\u0631\u0651\u0631 \u0641\u064A \u0627\u0644\u0646\u0632\u0627\u0639 \u0627\u0644\u0622\u0646.",
  "The bank decided a chargeback for the buyer. The booking is closed as refunded.": "\u062D\u0633\u0645 \u0627\u0644\u0628\u0646\u0643 \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0644\u0635\u0627\u0644\u062D \u0627\u0644\u0645\u0634\u062A\u0631\u064A. \u0623\u064F\u063A\u0644\u0642 \u0627\u0644\u062D\u062C\u0632 \u0639\u0644\u0649 \u0623\u0646\u0647 \u0645\u064F\u0633\u062A\u0631\u062F.",
  // Disputes and terms, forgot password with a code, users and tracking
  "I accept the": "\u0623\u0648\u0627\u0641\u0642 \u0639\u0644\u0649",
  "the": "\u0648",
  "disputes and payment protection policy": "\u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u0646\u0632\u0627\u0639\u0627\u062A \u0648\u062D\u0645\u0627\u064A\u0629 \u0627\u0644\u062F\u0641\u0639",
  "for myself and the company I act for.": "\u0639\u0646 \u0646\u0641\u0633\u064A \u0648\u0639\u0646 \u0627\u0644\u0634\u0631\u0643\u0629 \u0627\u0644\u062A\u064A \u0623\u0645\u062B\u0644\u0647\u0627.",
  "Password changed. Sign in with your new password. You have been signed out everywhere else.": "\u062A\u0645 \u062A\u063A\u064A\u064A\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631. \u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062C\u062F\u064A\u062F\u0629. \u062A\u0645 \u062A\u0633\u062C\u064A\u0644 \u062E\u0631\u0648\u062C\u0643 \u0645\u0646 \u0643\u0644 \u0627\u0644\u0623\u062C\u0647\u0632\u0629 \u0627\u0644\u0623\u062E\u0631\u0649.",
  "Using two-step sign-in?": "\u062A\u0633\u062A\u062E\u062F\u0645 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646\u061F",
  "Reset now with a code from your authenticator app": "\u0623\u0639\u062F \u0627\u0644\u062A\u0639\u064A\u064A\u0646 \u0627\u0644\u0622\u0646 \u0628\u0631\u0645\u0632 \u0645\u0646 \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629",
  "Reset now with your authenticator app": "\u0623\u0639\u062F \u0627\u0644\u062A\u0639\u064A\u064A\u0646 \u0627\u0644\u0622\u0646 \u0628\u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629",
  "Nashr will decide this dispute by {date}. Add your side and any files from the booking.": "\u0633\u062A\u0628\u062A\u0651 \u0646\u0634\u0631 \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u0646\u0632\u0627\u0639 \u0628\u062D\u0644\u0648\u0644 {date}. \u0623\u0636\u0641 \u0631\u0648\u0627\u064A\u062A\u0643 \u0648\u0623\u064A \u0645\u0644\u0641\u0627\u062A \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u062D\u062C\u0632.",
  "The buyer added to the dispute case.": "\u0623\u0636\u0627\u0641 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0625\u0644\u0649 \u0645\u0644\u0641 \u0627\u0644\u0646\u0632\u0627\u0639.",
  "The publisher added to the dispute case.": "\u0623\u0636\u0627\u0641 \u0627\u0644\u0646\u0627\u0634\u0631 \u0625\u0644\u0649 \u0645\u0644\u0641 \u0627\u0644\u0646\u0632\u0627\u0639.",
  "The publisher answers: corrected proof, a make-good or a refund": "\u064A\u0631\u062F \u0627\u0644\u0646\u0627\u0634\u0631: \u0625\u062B\u0628\u0627\u062A \u0645\u0635\u062D\u062D \u0623\u0648 \u0625\u0639\u0627\u062F\u0629 \u0639\u0631\u0636 \u0623\u0648 \u0627\u0633\u062A\u0631\u062F\u0627\u062F",
  "The publisher": "\u0627\u0644\u0646\u0627\u0634\u0631",
  "The buyer accepts the answer, or asks Nashr to decide": "\u064A\u0642\u0628\u0644 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0627\u0644\u0631\u062F \u0623\u0648 \u064A\u0637\u0644\u0628 \u0645\u0646 \u0646\u0634\u0631 \u0623\u0646 \u062A\u0642\u0631\u0631",
  "Nashr decides on the evidence from both sides": "\u062A\u0642\u0631\u0631 \u0646\u0634\u0631 \u0628\u0646\u0627\u0621\u064B \u0639\u0644\u0649 \u0623\u062F\u0644\u0629 \u0627\u0644\u0637\u0631\u0641\u064A\u0646",
  "Added. Nashr and the other side can read it.": "\u062A\u0645\u062A \u0627\u0644\u0625\u0636\u0627\u0641\u0629. \u064A\u0645\u0643\u0646 \u0644\u0646\u0634\u0631 \u0648\u0644\u0644\u0637\u0631\u0641 \u0627\u0644\u0622\u062E\u0631 \u0642\u0631\u0627\u0621\u062A\u0647\u0627.",
  "How this was resolved": "\u0643\u064A\u0641 \u062D\u064F\u0644\u0651\u062A \u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0623\u0644\u0629",
  "How this is being resolved": "\u0643\u064A\u0641 \u062A\u064F\u062D\u0644 \u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0623\u0644\u0629",
  "Your payment of {amount} is held by Nashr. Nobody is paid until this is resolved.": "\u062F\u0641\u0639\u062A\u0643 \u0627\u0644\u0628\u0627\u0644\u063A\u0629 {amount} \u0645\u062D\u062A\u062C\u0632\u0629 \u0644\u062F\u0649 \u0646\u0634\u0631. \u0644\u0627 \u064A\u064F\u062F\u0641\u0639 \u0644\u0623\u062D\u062F \u062D\u062A\u0649 \u062A\u064F\u062D\u0644 \u0627\u0644\u0645\u0633\u0623\u0644\u0629.",
  "The payment of {amount} is held by Nashr until this is resolved. It is released to you if the outcome is in your favour.": "\u0627\u0644\u062F\u0641\u0639\u0629 \u0627\u0644\u0628\u0627\u0644\u063A\u0629 {amount} \u0645\u062D\u062A\u062C\u0632\u0629 \u0644\u062F\u0649 \u0646\u0634\u0631 \u062D\u062A\u0649 \u062A\u064F\u062D\u0644 \u0627\u0644\u0645\u0633\u0623\u0644\u0629. \u0648\u062A\u064F\u062D\u0631\u064E\u0651\u0631 \u0644\u0643 \u0625\u0646 \u062C\u0627\u0621\u062A \u0627\u0644\u0646\u062A\u064A\u062C\u0629 \u0644\u0635\u0627\u0644\u062D\u0643.",
  "Each side's case": "\u0631\u0648\u0627\u064A\u0629 \u0643\u0644 \u0637\u0631\u0641",
  "No statements yet. Explain what happened and attach anything that shows it: as-run logs, recordings, screenshots, emails.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0625\u0641\u0627\u062F\u0627\u062A \u0628\u0639\u062F. \u0627\u0634\u0631\u062D \u0645\u0627 \u062D\u062F\u062B \u0648\u0623\u0631\u0641\u0642 \u0645\u0627 \u064A\u062B\u0628\u062A\u0647: \u0633\u062C\u0644\u0627\u062A \u0627\u0644\u0628\u062B\u060C \u0623\u0648 \u0627\u0644\u062A\u0633\u062C\u064A\u0644\u0627\u062A\u060C \u0623\u0648 \u0644\u0642\u0637\u0627\u062A \u0627\u0644\u0634\u0627\u0634\u0629\u060C \u0623\u0648 \u0627\u0644\u0631\u0633\u0627\u0626\u0644.",
  "Your side": "\u0631\u0648\u0627\u064A\u062A\u0643",
  "Files (optional)": "\u0645\u0644\u0641\u0627\u062A (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Add to the case": "\u0623\u0636\u0641 \u0625\u0644\u0649 \u0627\u0644\u0645\u0644\u0641",
  "How disputes work, and what each outcome means": "\u0643\u064A\u0641 \u062A\u0639\u0645\u0644 \u0627\u0644\u0646\u0632\u0627\u0639\u0627\u062A\u060C \u0648\u0645\u0627 \u0645\u0639\u0646\u0649 \u0643\u0644 \u0646\u062A\u064A\u062C\u0629",
  "Our terms have been updated": "\u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0634\u0631\u0648\u0637\u0646\u0627",
  "Please read and accept them to carry on using Nashr. They cover how bookings, payments and refunds work, and how an issue between a buyer and a publisher is resolved while the payment is held.": "\u064A\u0631\u062C\u0649 \u0642\u0631\u0627\u0621\u062A\u0647\u0627 \u0648\u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 \u0639\u0644\u064A\u0647\u0627 \u0644\u0645\u0648\u0627\u0635\u0644\u0629 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0646\u0634\u0631. \u0648\u0647\u064A \u062A\u0634\u0631\u062D \u0643\u064A\u0641 \u062A\u0639\u0645\u0644 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0648\u0627\u0644\u062F\u0641\u0639\u0627\u062A \u0648\u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F\u0627\u062A\u060C \u0648\u0643\u064A\u0641 \u062A\u064F\u062D\u0644 \u0645\u0633\u0623\u0644\u0629 \u0628\u064A\u0646 \u0645\u0634\u062A\u0631\u064D \u0648\u0646\u0627\u0634\u0631 \u0628\u064A\u0646\u0645\u0627 \u062A\u0628\u0642\u0649 \u0627\u0644\u062F\u0641\u0639\u0629 \u0645\u062D\u062A\u062C\u0632\u0629.",
  "Terms of use": "\u0634\u0631\u0648\u0637 \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645",
  "Disputes and payment protection": "\u0627\u0644\u0646\u0632\u0627\u0639\u0627\u062A \u0648\u062D\u0645\u0627\u064A\u0629 \u0627\u0644\u062F\u0641\u0639",
  "Refunds and cancellations": "\u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0648\u0627\u0644\u0625\u0644\u063A\u0627\u0621",
  "Privacy policy": "\u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629",
  "I have read the terms and accept them for myself and the company I act for.": "\u0642\u0631\u0623\u062A \u0627\u0644\u0634\u0631\u0648\u0637 \u0648\u0623\u0648\u0627\u0641\u0642 \u0639\u0644\u064A\u0647\u0627 \u0639\u0646 \u0646\u0641\u0633\u064A \u0648\u0639\u0646 \u0627\u0644\u0634\u0631\u0643\u0629 \u0627\u0644\u062A\u064A \u0623\u0645\u062B\u0644\u0647\u0627.",
  "Version {v}": "\u0627\u0644\u0625\u0635\u062F\u0627\u0631 {v}",
  "Accept and continue": "\u0645\u0648\u0627\u0641\u0642\u0629 \u0648\u0645\u062A\u0627\u0628\u0639\u0629",
  "Add a colleague": "\u0625\u0636\u0627\u0641\u0629 \u0632\u0645\u064A\u0644",
  "Create and get the invite link": "\u0625\u0646\u0634\u0627\u0621 \u0648\u0627\u0644\u062D\u0635\u0648\u0644 \u0639\u0644\u0649 \u0631\u0627\u0628\u0637 \u0627\u0644\u062F\u0639\u0648\u0629",
  "Invite link (send it to them; it works once):": "\u0631\u0627\u0628\u0637 \u0627\u0644\u062F\u0639\u0648\u0629 (\u0623\u0631\u0633\u0644\u0647 \u0625\u0644\u064A\u0647\u061B \u064A\u0639\u0645\u0644 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629):",
  "With the bank (chargeback)": "\u0644\u062F\u0649 \u0627\u0644\u0628\u0646\u0643 (\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0628\u0646\u0643\u064A)",
  "Decide by {when}": "\u0627\u0644\u0642\u0631\u0627\u0631 \u0642\u0628\u0644 {when}",
  "{n} statements": "{n} \u0625\u0641\u0627\u062F\u0627\u062A",
  "The buyer's bank is deciding a chargeback on this payment. Refund and release wait for its decision.": "\u064A\u0628\u062A\u0651 \u0628\u0646\u0643 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0641\u064A \u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0639\u0644\u0649 \u0647\u0630\u0647 \u0627\u0644\u062F\u0641\u0639\u0629. \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0648\u0627\u0644\u062A\u062D\u0631\u064A\u0631 \u064A\u0646\u062A\u0638\u0631\u0627\u0646 \u0642\u0631\u0627\u0631\u0647.",
  "Disputes past Nashr's decision date": "\u0646\u0632\u0627\u0639\u0627\u062A \u062A\u062C\u0627\u0648\u0632\u062A \u0645\u0648\u0639\u062F \u0642\u0631\u0627\u0631 \u0646\u0634\u0631",
  "app": "\u062A\u0637\u0628\u064A\u0642",
  "Everyone on Nashr: who they are, where they are signed in, and what they did.": "\u0643\u0644 \u0645\u0646 \u0639\u0644\u0649 \u0646\u0634\u0631: \u0645\u0646 \u0647\u0645\u060C \u0648\u0623\u064A\u0646 \u0633\u062C\u0651\u0644\u0648\u0627 \u0627\u0644\u062F\u062E\u0648\u0644\u060C \u0648\u0645\u0627\u0630\u0627 \u0641\u0639\u0644\u0648\u0627.",
  "Signed in now": "\u0645\u0633\u062C\u0651\u0644\u0648\u0646 \u0627\u0644\u0622\u0646",
  "Sign-ins, last 24 hours": "\u062A\u0633\u062C\u064A\u0644\u0627\u062A \u0627\u0644\u062F\u062E\u0648\u0644\u060C \u0622\u062E\u0631 24 \u0633\u0627\u0639\u0629",
  "Failed sign-ins, last 24 hours": "\u0645\u062D\u0627\u0648\u0644\u0627\u062A \u062F\u062E\u0648\u0644 \u0641\u0627\u0634\u0644\u0629\u060C \u0622\u062E\u0631 24 \u0633\u0627\u0639\u0629",
  "Staff helping in an account now": "\u0645\u0648\u0638\u0641\u0648\u0646 \u064A\u0633\u0627\u0639\u062F\u0648\u0646 \u062F\u0627\u062E\u0644 \u062D\u0633\u0627\u0628 \u0627\u0644\u0622\u0646",
  "Buyers and publishers without two-step": "\u0645\u0634\u062A\u0631\u0648\u0646 \u0648\u0646\u0627\u0634\u0631\u0648\u0646 \u062F\u0648\u0646 \u062E\u0637\u0648\u062A\u064A\u0646",
  "Locked for 15 minutes after repeated failures:": "\u0645\u0642\u0641\u0644\u0629 \u0644\u0645\u062F\u0629 15 \u062F\u0642\u064A\u0642\u0629 \u0628\u0639\u062F \u0645\u062D\u0627\u0648\u0644\u0627\u062A \u0641\u0627\u0634\u0644\u0629 \u0645\u062A\u0643\u0631\u0631\u0629:",
  "Addresses trying several accounts:": "\u0639\u0646\u0627\u0648\u064A\u0646 \u062A\u062D\u0627\u0648\u0644 \u0639\u062F\u0629 \u062D\u0633\u0627\u0628\u0627\u062A:",
  "{n} accounts": "{n} \u062D\u0633\u0627\u0628\u0627\u062A",
  "Name, email or company": "\u0627\u0644\u0627\u0633\u0645 \u0623\u0648 \u0627\u0644\u0628\u0631\u064A\u062F \u0623\u0648 \u0627\u0644\u0634\u0631\u0643\u0629",
  "Search users": "\u0627\u0644\u0628\u062D\u062B \u0641\u064A \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u064A\u0646",
  "Every role": "\u0643\u0644 \u0627\u0644\u0623\u062F\u0648\u0627\u0631",
  "Any status": "\u0623\u064A \u062D\u0627\u0644\u0629",
  "Everyone": "\u0627\u0644\u062C\u0645\u064A\u0639",
  "Failed sign-ins in the last 24 hours": "\u0645\u062D\u0627\u0648\u0644\u0627\u062A \u062F\u062E\u0648\u0644 \u0641\u0627\u0634\u0644\u0629 \u0641\u064A \u0622\u062E\u0631 24 \u0633\u0627\u0639\u0629",
  "Never signed in": "\u0644\u0645 \u064A\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0642\u0637",
  "Has not accepted the current terms": "\u0644\u0645 \u064A\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u0627\u0644\u0634\u0631\u0648\u0637 \u0627\u0644\u062D\u0627\u0644\u064A\u0629",
  "{n} people": "{n} \u0623\u0634\u062E\u0627\u0635",
  "Two-step": "\u0627\u0644\u062E\u0637\u0648\u062A\u0627\u0646",
  "Last seen": "\u0622\u062E\u0631 \u0638\u0647\u0648\u0631",
  "Failed (24 h)": "\u0641\u0627\u0634\u0644\u0629 (24 \u0633\u0627\u0639\u0629)",
  "Off": "\u0645\u062A\u0648\u0642\u0641",
  "Never": "\u0623\u0628\u062F\u064B\u0627",
  "{n} sessions": "{n} \u062C\u0644\u0633\u0627\u062A",
  "{from}\u2013{to} of {n}": "{from}\u2013{to} \u0645\u0646 {n}",
  "Latest sign-in attempts": "\u0623\u062D\u062F\u062B \u0645\u062D\u0627\u0648\u0644\u0627\u062A \u0627\u0644\u062F\u062E\u0648\u0644",
  "Signed in": "\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644",
  "Link to send:": "\u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0645\u0637\u0644\u0648\u0628 \u0625\u0631\u0633\u0627\u0644\u0647:",
  "{staff} is signed in as this person until {when}. Reason: {reason}": "{staff} \u0645\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0627\u0633\u0645 \u0647\u0630\u0627 \u0627\u0644\u0634\u062E\u0635 \u062D\u062A\u0649 {when}. \u0627\u0644\u0633\u0628\u0628: {reason}",
  "Version {v}, accepted {when}": "\u0627\u0644\u0625\u0635\u062F\u0627\u0631 {v}\u060C \u062A\u0645\u062A \u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 {when}",
  "Not accepted yet": "\u0644\u0645 \u062A\u062A\u0645 \u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 \u0628\u0639\u062F",
  "not the current version": "\u0644\u064A\u0633 \u0627\u0644\u0625\u0635\u062F\u0627\u0631 \u0627\u0644\u062D\u0627\u0644\u064A",
  "Why sign {name} out everywhere? (lost laptop, left the company\u2026)": "\u0644\u0645\u0627\u0630\u0627 \u064A\u064F\u0633\u062C\u064E\u0651\u0644 \u062E\u0631\u0648\u062C {name} \u0645\u0646 \u0643\u0644 \u0645\u0643\u0627\u0646\u061F (\u062D\u0627\u0633\u0648\u0628 \u0645\u0641\u0642\u0648\u062F\u060C \u063A\u0627\u062F\u0631 \u0627\u0644\u0634\u0631\u0643\u0629\u2026)",
  "Signed out everywhere.": "\u062A\u0645 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062E\u0631\u0648\u062C \u0645\u0646 \u0643\u0644 \u0645\u0643\u0627\u0646.",
  "Sign out everywhere": "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062E\u0631\u0648\u062C \u0645\u0646 \u0643\u0644 \u0645\u0643\u0627\u0646",
  "Sign in as\u2026 (from the company page)": "\u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0627\u0633\u0645\u0647\u2026 (\u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u0634\u0631\u0643\u0629)",
  "Not signed in anywhere.": "\u063A\u064A\u0631 \u0645\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0641\u064A \u0623\u064A \u0645\u0643\u0627\u0646.",
  "Since": "\u0645\u0646\u0630",
  "Device": "\u0627\u0644\u062C\u0647\u0627\u0632",
  "Address": "\u0627\u0644\u0639\u0646\u0648\u0627\u0646",
  "acting as {name}": "\u064A\u0639\u0645\u0644 \u0628\u0627\u0633\u0645 {name}",
  "Sign-in history": "\u0633\u062C\u0644 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644",
  "No sign-ins yet.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u062A\u0633\u062C\u064A\u0644\u0627\u062A \u062F\u062E\u0648\u0644 \u0628\u0639\u062F.",
  "Activity": "\u0627\u0644\u0646\u0634\u0627\u0637",
  "What this person did, and what Nashr did to their account. The full record, with filters, is in the audit log.": "\u0645\u0627 \u0641\u0639\u0644\u0647 \u0647\u0630\u0627 \u0627\u0644\u0634\u062E\u0635\u060C \u0648\u0645\u0627 \u0641\u0639\u0644\u062A\u0647 \u0646\u0634\u0631 \u0628\u062D\u0633\u0627\u0628\u0647. \u0627\u0644\u0633\u062C\u0644 \u0627\u0644\u0643\u0627\u0645\u0644 \u0645\u0639 \u0639\u0648\u0627\u0645\u0644 \u0627\u0644\u062A\u0635\u0641\u064A\u0629 \u0641\u064A \u0633\u062C\u0644 \u0627\u0644\u062A\u062F\u0642\u064A\u0642.",
  "by Nashr": "\u0628\u0648\u0627\u0633\u0637\u0629 \u0646\u0634\u0631",
  "Nashr staff": "\u0641\u0631\u064A\u0642 \u0646\u0634\u0631",
  "Founder": "\u0627\u0644\u0645\u0624\u0633\u0633",
  "Wrong password": "\u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u062E\u0627\u0637\u0626\u0629",
  "Wrong code": "\u0631\u0645\u0632 \u062E\u0627\u0637\u0626",
  "Asked for the code": "\u0637\u064F\u0644\u0628 \u0627\u0644\u0631\u0645\u0632",
  "Locked: too many failures": "\u0645\u0642\u0641\u0644: \u0645\u062D\u0627\u0648\u0644\u0627\u062A \u0641\u0627\u0634\u0644\u0629 \u0643\u062B\u064A\u0631\u0629",
  "Joined Nashr": "\u0627\u0646\u0636\u0645 \u0625\u0644\u0649 \u0646\u0634\u0631",
  "Accepted the terms": "\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u0627\u0644\u0634\u0631\u0648\u0637",
  "Changed password": "\u063A\u064A\u0651\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
  "Reset password with a link": "\u0623\u0639\u0627\u062F \u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0628\u0631\u0627\u0628\u0637",
  "Reset password with the authenticator": "\u0623\u0639\u0627\u062F \u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0628\u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629",
  "Nashr issued a reset link": "\u0623\u0635\u062F\u0631\u062A \u0646\u0634\u0631 \u0631\u0627\u0628\u0637 \u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646",
  "Turned on two-step sign-in": "\u0641\u0639\u0651\u0644 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646",
  "Turned off two-step sign-in": "\u0623\u0648\u0642\u0641 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646",
  "Nashr turned off two-step sign-in": "\u0623\u0648\u0642\u0641\u062A \u0646\u0634\u0631 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646",
  "Nashr signed in as this person": "\u0633\u062C\u0651\u0644\u062A \u0646\u0634\u0631 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0627\u0633\u0645 \u0647\u0630\u0627 \u0627\u0644\u0634\u062E\u0635",
  "Nashr, signed in as this person, opened a page": "\u0641\u062A\u062D\u062A \u0646\u0634\u0631 \u0635\u0641\u062D\u0629 \u0648\u0647\u064A \u0645\u0633\u062C\u0651\u0644\u0629 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0627\u0633\u0645\u0647",
  "Nashr, signed in as this person, made a change": "\u0623\u062C\u0631\u062A \u0646\u0634\u0631 \u062A\u063A\u064A\u064A\u0631\u064B\u0627 \u0648\u0647\u064A \u0645\u0633\u062C\u0651\u0644\u0629 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0627\u0633\u0645\u0647",
  "Nashr signed back out": "\u062E\u0631\u062C\u062A \u0646\u0634\u0631 \u0645\u0646 \u062D\u0633\u0627\u0628\u0647",
  "Signed out everywhere by Nashr": "\u0633\u062C\u0651\u0644\u062A \u0646\u0634\u0631 \u062E\u0631\u0648\u062C\u0647 \u0645\u0646 \u0643\u0644 \u0645\u0643\u0627\u0646",
  "Status changed": "\u062A\u063A\u064A\u0651\u0631\u062A \u0627\u0644\u062D\u0627\u0644\u0629",
  "Updated their account": "\u062D\u062F\u0651\u062B \u062D\u0633\u0627\u0628\u0647",
  "Asked Nashr a question": "\u0633\u0623\u0644 \u0646\u0634\u0631 \u0633\u0624\u0627\u0644\u064B\u0627",
  "Invited by Nashr": "\u062F\u0639\u062A\u0647 \u0646\u0634\u0631",
  "Accept the terms to carry on.": "\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u0627\u0644\u0634\u0631\u0648\u0637 \u0644\u0644\u0645\u062A\u0627\u0628\u0639\u0629.",
  // Teams and email
  "If an account uses {email}, we have emailed it a reset link. The link works for 24 hours. Check your spam folder if it does not arrive.": "\u0625\u0630\u0627 \u0643\u0627\u0646 \u0647\u0646\u0627\u0643 \u062D\u0633\u0627\u0628 \u064A\u0633\u062A\u062E\u062F\u0645 {email}\u060C \u0641\u0642\u062F \u0623\u0631\u0633\u0644\u0646\u0627 \u0625\u0644\u064A\u0647 \u0631\u0627\u0628\u0637 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062A\u0639\u064A\u064A\u0646. \u064A\u0639\u0645\u0644 \u0627\u0644\u0631\u0627\u0628\u0637 \u0644\u0645\u062F\u0629 24 \u0633\u0627\u0639\u0629. \u062A\u062D\u0642\u0642 \u0645\u0646 \u0645\u062C\u0644\u062F \u0627\u0644\u0631\u0633\u0627\u0626\u0644 \u063A\u064A\u0631 \u0627\u0644\u0645\u0631\u063A\u0648\u0628 \u0641\u064A\u0647\u0627 \u0625\u0646 \u0644\u0645 \u064A\u0635\u0644.",
  "Can pay and cancel": "\u064A\u0645\u0643\u0646\u0647 \u0627\u0644\u062F\u0641\u0639 \u0648\u0627\u0644\u0625\u0644\u063A\u0627\u0621",
  "Can accept and decline bookings": "\u064A\u0645\u0643\u0646\u0647 \u0642\u0628\u0648\u0644 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0648\u0631\u0641\u0636\u0647\u0627",
  "Invite a colleague": "\u062F\u0639\u0648\u0629 \u0632\u0645\u064A\u0644",
  "Your company's team managers invite colleagues and choose what each may do.": "\u0645\u062F\u064A\u0631\u0648 \u0627\u0644\u0641\u0631\u064A\u0642 \u0641\u064A \u0634\u0631\u0643\u062A\u0643 \u064A\u062F\u0639\u0648\u0646 \u0627\u0644\u0632\u0645\u0644\u0627\u0621 \u0648\u064A\u062D\u062F\u062F\u0648\u0646 \u0635\u0644\u0627\u062D\u064A\u0627\u062A \u0643\u0644 \u0645\u0646\u0647\u0645.",
  "Invited. They get a link to set a password and accept the terms.": "\u062A\u0645\u062A \u0627\u0644\u062F\u0639\u0648\u0629. \u0633\u064A\u0635\u0644\u0647 \u0631\u0627\u0628\u0637 \u0644\u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u0648\u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 \u0639\u0644\u0649 \u0627\u0644\u0634\u0631\u0648\u0637.",
  "What they may do": "\u0635\u0644\u0627\u062D\u064A\u0627\u062A\u0647",
  "Can manage the team, company details and payouts": "\u064A\u0645\u0643\u0646\u0647 \u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u0641\u0631\u064A\u0642 \u0648\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0634\u0631\u0643\u0629 \u0648\u0627\u0644\u062A\u062D\u0648\u064A\u0644\u0627\u062A",
  "Everyone on the team can see bookings, send messages and book.": "\u064A\u0645\u0643\u0646 \u0644\u0643\u0644 \u0623\u0639\u0636\u0627\u0621 \u0627\u0644\u0641\u0631\u064A\u0642 \u0631\u0624\u064A\u0629 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0648\u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0631\u0633\u0627\u0626\u0644 \u0648\u0627\u0644\u062D\u062C\u0632.",
  "Send the invite": "\u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u062F\u0639\u0648\u0629",
  "Email is not set up yet, so send them this link yourself (it works once):": "\u0627\u0644\u0628\u0631\u064A\u062F \u063A\u064A\u0631 \u0645\u064F\u0639\u062F \u0628\u0639\u062F\u060C \u0644\u0630\u0627 \u0623\u0631\u0633\u0644 \u0647\u0630\u0627 \u0627\u0644\u0631\u0627\u0628\u0637 \u0628\u0646\u0641\u0633\u0643 (\u064A\u0639\u0645\u0644 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629):",
  "you": "\u0623\u0646\u062A",
  "invited, not joined yet": "\u0645\u062F\u0639\u0648\u060C \u0644\u0645 \u064A\u0646\u0636\u0645 \u0628\u0639\u062F",
  "removed": "\u0623\u064F\u0632\u064A\u0644",
  "Team manager": "\u0645\u062F\u064A\u0631 \u0627\u0644\u0641\u0631\u064A\u0642",
  "Can see and book": "\u064A\u0645\u0643\u0646\u0647 \u0627\u0644\u0627\u0637\u0644\u0627\u0639 \u0648\u0627\u0644\u062D\u062C\u0632",
  "A new invite is on its way. The old link no longer works.": "\u062F\u0639\u0648\u0629 \u062C\u062F\u064A\u062F\u0629 \u0641\u064A \u0637\u0631\u064A\u0642\u0647\u0627. \u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0642\u062F\u064A\u0645 \u0644\u0645 \u064A\u0639\u062F \u064A\u0639\u0645\u0644.",
  "New invite": "\u062F\u0639\u0648\u0629 \u062C\u062F\u064A\u062F\u0629",
  "Remove {name} from the team? They are signed out at once and cannot sign in again. Their past work stays with the company.": "\u0625\u0632\u0627\u0644\u0629 {name} \u0645\u0646 \u0627\u0644\u0641\u0631\u064A\u0642\u061F \u0633\u064A\u064F\u0633\u062C\u064E\u0651\u0644 \u062E\u0631\u0648\u062C\u0647 \u0641\u0648\u0631\u064B\u0627 \u0648\u0644\u0646 \u064A\u0633\u062A\u0637\u064A\u0639 \u0627\u0644\u062F\u062E\u0648\u0644 \u0645\u062C\u062F\u062F\u064B\u0627. \u064A\u0628\u0642\u0649 \u0639\u0645\u0644\u0647 \u0627\u0644\u0633\u0627\u0628\u0642 \u0644\u062F\u0649 \u0627\u0644\u0634\u0631\u0643\u0629.",
  "{name} was removed.": "\u062A\u0645\u062A \u0625\u0632\u0627\u0644\u0629 {name}.",
  "{name} is back on the team.": "\u0639\u0627\u062F {name} \u0625\u0644\u0649 \u0627\u0644\u0641\u0631\u064A\u0642.",
  "Everything Nashr emails: sent, waiting, failed, or held until email is set up.": "\u0643\u0644 \u0645\u0627 \u062A\u0631\u0633\u0644\u0647 \u0646\u0634\u0631 \u0628\u0627\u0644\u0628\u0631\u064A\u062F: \u0645\u064F\u0631\u0633\u0644\u060C \u0623\u0648 \u0628\u0627\u0644\u0627\u0646\u062A\u0638\u0627\u0631\u060C \u0623\u0648 \u0641\u0627\u0634\u0644\u060C \u0623\u0648 \u0645\u062D\u062A\u062C\u0632 \u062D\u062A\u0649 \u0625\u0639\u062F\u0627\u062F \u0627\u0644\u0628\u0631\u064A\u062F.",
  "Email is set up: {from} through {host}:{port}.": "\u0627\u0644\u0628\u0631\u064A\u062F \u0645\u064F\u0639\u062F: {from} \u0639\u0628\u0631 {host}:{port}.",
  "Email is not set up yet.": "\u0627\u0644\u0628\u0631\u064A\u062F \u063A\u064A\u0631 \u0645\u064F\u0639\u062F \u0628\u0639\u062F.",
  "Emails are kept here instead of being sent. Reset links and invites are handed out by Nashr's team meanwhile.": "\u062A\u064F\u062D\u0641\u0638 \u0627\u0644\u0631\u0633\u0627\u0626\u0644 \u0647\u0646\u0627 \u0628\u062F\u0644 \u0625\u0631\u0633\u0627\u0644\u0647\u0627. \u0648\u064A\u0633\u0644\u0651\u0645 \u0641\u0631\u064A\u0642 \u0646\u0634\u0631 \u0631\u0648\u0627\u0628\u0637 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062A\u0639\u064A\u064A\u0646 \u0648\u0627\u0644\u062F\u0639\u0648\u0627\u062A \u0641\u064A \u0627\u0644\u0623\u062B\u0646\u0627\u0621.",
  'To switch it on, add these to the server settings file (/etc/nashr.env) and redeploy: SMTP_HOST, SMTP_PORT (587, or 465 for TLS), SMTP_USER, SMTP_PASS, SMTP_FROM (for example "Nashr <noreply@your-domain>").': '\u0644\u062A\u0641\u0639\u064A\u0644\u0647\u060C \u0623\u0636\u0641 \u0647\u0630\u0647 \u0625\u0644\u0649 \u0645\u0644\u0641 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u062E\u0627\u062F\u0645 (/etc/nashr.env) \u062B\u0645 \u0623\u0639\u062F \u0627\u0644\u0646\u0634\u0631: SMTP_HOST \u0648SMTP_PORT (587\u060C \u0623\u0648 465 \u0644\u0640 TLS) \u0648SMTP_USER \u0648SMTP_PASS \u0648SMTP_FROM (\u0645\u062B\u0644 "Nashr <noreply@your-domain>").',
  "Test email sent to {to}.": "\u0623\u064F\u0631\u0633\u0644\u062A \u0631\u0633\u0627\u0644\u0629 \u062A\u062C\u0631\u064A\u0628\u064A\u0629 \u0625\u0644\u0649 {to}.",
  "Your email": "\u0628\u0631\u064A\u062F\u0643",
  "Send a test email to": "\u0625\u0631\u0633\u0627\u0644 \u0631\u0633\u0627\u0644\u0629 \u062A\u062C\u0631\u064A\u0628\u064A\u0629 \u0625\u0644\u0649",
  "Send a test email": "\u0625\u0631\u0633\u0627\u0644 \u0631\u0633\u0627\u0644\u0629 \u062A\u062C\u0631\u064A\u0628\u064A\u0629",
  "Recipient or subject": "\u0627\u0644\u0645\u0633\u062A\u0644\u0645 \u0623\u0648 \u0627\u0644\u0645\u0648\u0636\u0648\u0639",
  "Search emails": "\u0627\u0644\u0628\u062D\u062B \u0641\u064A \u0627\u0644\u0631\u0633\u0627\u0626\u0644",
  "No emails here.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0631\u0633\u0627\u0626\u0644 \u0647\u0646\u0627.",
  "Subject": "\u0627\u0644\u0645\u0648\u0636\u0648\u0639",
  "{n} tries": "{n} \u0645\u062D\u0627\u0648\u0644\u0627\u062A",
  "Read": "\u0642\u0631\u0627\u0621\u0629",
  "Queued to send again.": "\u0623\u064F\u062F\u0631\u062C\u062A \u0644\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0625\u0631\u0633\u0627\u0644.",
  "Send again": "\u0625\u0631\u0633\u0627\u0644 \u0645\u062C\u062F\u062F\u064B\u0627",
  "Waiting to send": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0625\u0631\u0633\u0627\u0644",
  "Held: email not set up": "\u0645\u062D\u062A\u062C\u0632\u0629: \u0627\u0644\u0628\u0631\u064A\u062F \u063A\u064A\u0631 \u0645\u064F\u0639\u062F",
  "You have a new notification on Nashr.": "\u0644\u062F\u064A\u0643 \u0625\u0634\u0639\u0627\u0631 \u062C\u062F\u064A\u062F \u0639\u0644\u0649 \u0646\u0634\u0631.",
  "Open in Nashr": "\u0627\u0641\u062A\u062D \u0641\u064A \u0646\u0634\u0631",
  "You get these emails because of your choices on Nashr. Change them under Your account.": "\u062A\u0635\u0644\u0643 \u0647\u0630\u0647 \u0627\u0644\u0631\u0633\u0627\u0626\u0644 \u0628\u062D\u0633\u0628 \u0627\u062E\u062A\u064A\u0627\u0631\u0627\u062A\u0643 \u0639\u0644\u0649 \u0646\u0634\u0631. \u063A\u064A\u0651\u0631\u0647\u0627 \u0645\u0646 \u0635\u0641\u062D\u0629 \u062D\u0633\u0627\u0628\u0643.",
  "Nashr sends this email about your bookings, payments or account. It cannot be switched off.": "\u062A\u0631\u0633\u0644 \u0646\u0634\u0631 \u0647\u0630\u0647 \u0627\u0644\u0631\u0633\u0627\u0644\u0629 \u0628\u0634\u0623\u0646 \u062D\u062C\u0648\u0632\u0627\u062A\u0643 \u0623\u0648 \u062F\u0641\u0639\u0627\u062A\u0643 \u0623\u0648 \u062D\u0633\u0627\u0628\u0643. \u0648\u0644\u0627 \u064A\u0645\u0643\u0646 \u0625\u064A\u0642\u0627\u0641\u0647\u0627.",
  "You are invited to Nashr": "\u0623\u0646\u062A \u0645\u062F\u0639\u0648 \u0625\u0644\u0649 \u0646\u0634\u0631",
  "Hello {name},": "\u0645\u0631\u062D\u0628\u064B\u0627 {name}\u060C",
  "{company} has invited you to Nashr, the marketplace for booking advertising across the UAE. Choose a password to join. The link works once.": "\u062F\u0639\u062A\u0643 {company} \u0625\u0644\u0649 \u0646\u0634\u0631\u060C \u0645\u0646\u0635\u0629 \u062D\u062C\u0632 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0641\u064A \u0623\u0646\u062D\u0627\u0621 \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A. \u0627\u062E\u062A\u0631 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u0644\u0644\u0627\u0646\u0636\u0645\u0627\u0645. \u064A\u0639\u0645\u0644 \u0627\u0644\u0631\u0627\u0628\u0637 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629.",
  "Join Nashr": "\u0627\u0646\u0636\u0645 \u0625\u0644\u0649 \u0646\u0634\u0631",
  "If you did not expect this, you can ignore it.": "\u0625\u0646 \u0644\u0645 \u062A\u0643\u0646 \u062A\u062A\u0648\u0642\u0639 \u0647\u0630\u0647 \u0627\u0644\u0631\u0633\u0627\u0644\u0629\u060C \u064A\u0645\u0643\u0646\u0643 \u062A\u062C\u0627\u0647\u0644\u0647\u0627.",
  "Someone asked to reset the password of your Nashr account. Use the link to choose a new one. It works once, for 24 hours.": "\u0637\u0644\u0628 \u0623\u062D\u062F\u0647\u0645 \u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u062D\u0633\u0627\u0628\u0643 \u0639\u0644\u0649 \u0646\u0634\u0631. \u0627\u0633\u062A\u062E\u062F\u0645 \u0627\u0644\u0631\u0627\u0628\u0637 \u0644\u0627\u062E\u062A\u064A\u0627\u0631 \u0643\u0644\u0645\u0629 \u062C\u062F\u064A\u062F\u0629. \u064A\u0639\u0645\u0644 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \u0644\u0645\u062F\u0629 24 \u0633\u0627\u0639\u0629.",
  "If you did not ask, ignore this email: your password stays the same.": "\u0625\u0646 \u0644\u0645 \u062A\u0637\u0644\u0628 \u0630\u0644\u0643\u060C \u062A\u062C\u0627\u0647\u0644 \u0647\u0630\u0647 \u0627\u0644\u0631\u0633\u0627\u0644\u0629: \u062A\u0628\u0642\u0649 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631\u0643 \u0643\u0645\u0627 \u0647\u064A.",
  "Alerts are blocked for Nashr in this browser. Allow them in the browser's site settings, then try again.": "\u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0645\u062D\u0638\u0648\u0631\u0629 \u0644\u0646\u0634\u0631 \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u0645\u062A\u0635\u0641\u062D. \u0627\u0633\u0645\u062D \u0628\u0647\u0627 \u0645\u0646 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0645\u0648\u0642\u0639 \u0641\u064A \u0627\u0644\u0645\u062A\u0635\u0641\u062D\u060C \u062B\u0645 \u062D\u0627\u0648\u0644 \u0645\u0631\u0629 \u0623\u062E\u0631\u0649.",
  "Alerts are on for this device.": "\u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0645\u0641\u0639\u0651\u0644\u0629 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632.",
  "Alerts are off for this device.": "\u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0645\u062A\u0648\u0642\u0641\u0629 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632.",
  "Phone and browser alerts": "\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0627\u0644\u0647\u0627\u062A\u0641 \u0648\u0627\u0644\u0645\u062A\u0635\u0641\u062D",
  "Get an alert on this device even when Nashr is closed: when you are outbid, a booking is accepted, a payment is due or an issue is reported. Your email choices above apply to alerts too.": "\u0627\u062D\u0635\u0644 \u0639\u0644\u0649 \u062A\u0646\u0628\u064A\u0647 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632 \u062D\u062A\u0649 \u0639\u0646\u062F\u0645\u0627 \u064A\u0643\u0648\u0646 \u0646\u0634\u0631 \u0645\u063A\u0644\u0642\u064B\u0627: \u0639\u0646\u062F\u0645\u0627 \u064A\u062A\u062C\u0627\u0648\u0632 \u0623\u062D\u062F \u0639\u0631\u0636\u0643\u060C \u0623\u0648 \u064A\u064F\u0642\u0628\u0644 \u062D\u062C\u0632\u060C \u0623\u0648 \u064A\u062D\u064A\u0646 \u0645\u0648\u0639\u062F \u062F\u0641\u0639\u060C \u0623\u0648 \u064A\u064F\u0628\u0644\u064E\u0651\u063A \u0639\u0646 \u0645\u0634\u0643\u0644\u0629. \u0627\u062E\u062A\u064A\u0627\u0631\u0627\u062A\u0643 \u0644\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0639\u0644\u0627\u0647 \u062A\u0646\u0637\u0628\u0642 \u0639\u0644\u0649 \u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0623\u064A\u0636\u064B\u0627.",
  "Nashr is installed on this device.": "\u0646\u0634\u0631 \u0645\u062B\u0628\u0651\u062A \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632.",
  "Install Nashr on this device": "\u062B\u0628\u0651\u062A \u0646\u0634\u0631 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632",
  'On iPhone and iPad: tap Share, then "Add to Home Screen". Open Nashr from the Home Screen to turn alerts on.': "\u0639\u0644\u0649 iPhone \u0648iPad: \u0627\u0636\u063A\u0637 \u0645\u0634\u0627\u0631\u0643\u0629\u060C \u062B\u0645 \xAB\u0625\u0636\u0627\u0641\u0629 \u0625\u0644\u0649 \u0627\u0644\u0634\u0627\u0634\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629\xBB. \u0627\u0641\u062A\u062D \u0646\u0634\u0631 \u0645\u0646 \u0627\u0644\u0634\u0627\u0634\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629 \u0644\u062A\u0641\u0639\u064A\u0644 \u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A.",
  "This browser cannot receive alerts.": "\u0644\u0627 \u064A\u0633\u062A\u0637\u064A\u0639 \u0647\u0630\u0627 \u0627\u0644\u0645\u062A\u0635\u0641\u062D \u0627\u0633\u062A\u0642\u0628\u0627\u0644 \u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A.",
  "On for this device": "\u0645\u0641\u0639\u0651\u0644\u0629 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632",
  "A test alert is on its way.": "\u062A\u0646\u0628\u064A\u0647 \u062A\u062C\u0631\u064A\u0628\u064A \u0641\u064A \u0627\u0644\u0637\u0631\u064A\u0642.",
  "The alert service did not accept the test. Turn alerts off and on again.": "\u0644\u0645 \u062A\u0642\u0628\u0644 \u062E\u062F\u0645\u0629 \u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0627\u0644\u062A\u062C\u0631\u0628\u0629. \u0623\u0648\u0642\u0641 \u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u062B\u0645 \u0641\u0639\u0651\u0644\u0647\u0627 \u0645\u0631\u0629 \u0623\u062E\u0631\u0649.",
  "Send a test alert": "\u0623\u0631\u0633\u0644 \u062A\u0646\u0628\u064A\u0647\u064B\u0627 \u062A\u062C\u0631\u064A\u0628\u064A\u064B\u0627",
  "Turn off on this device": "\u0623\u0648\u0642\u0641\u0647\u0627 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632",
  "Turn on alerts on this device": "\u0641\u0639\u0651\u0644 \u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632",
  "Alerts are on for {n} of your devices.": "\u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0645\u0641\u0639\u0651\u0644\u0629 \u0639\u0644\u0649 {n} \u0645\u0646 \u0623\u062C\u0647\u0632\u062A\u0643.",
  "Alerts are turned on by the person on their own device.": "\u064A\u0641\u0639\u0651\u0644 \u0643\u0644 \u0634\u062E\u0635 \u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0628\u0646\u0641\u0633\u0647 \u0639\u0644\u0649 \u062C\u0647\u0627\u0632\u0647.",
  "Turn on alerts on this device first.": "\u0641\u0639\u0651\u0644 \u0627\u0644\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632 \u0623\u0648\u0644\u064B\u0627.",
  "Clients": "\u0627\u0644\u0639\u0645\u0644\u0627\u0621",
  "Client": "\u0627\u0644\u0639\u0645\u064A\u0644",
  "All clients": "\u0643\u0644 \u0627\u0644\u0639\u0645\u0644\u0627\u0621",
  "For client": "\u0644\u0635\u0627\u0644\u062D \u0627\u0644\u0639\u0645\u064A\u0644",
  "No client": "\u0628\u0644\u0627 \u0639\u0645\u064A\u0644",
  "Open client": "\u0627\u0641\u062A\u062D \u0627\u0644\u0639\u0645\u064A\u0644",
  "Set by the campaign.": "\u062A\u062D\u062F\u062F\u0647 \u0627\u0644\u062D\u0645\u0644\u0629.",
  "Bids and bookings over this client's budget are refused.": "\u062A\u064F\u0631\u0641\u0636 \u0627\u0644\u0639\u0631\u0648\u0636 \u0648\u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u062A\u062C\u0627\u0648\u0632 \u0645\u064A\u0632\u0627\u0646\u064A\u0629 \u0647\u0630\u0627 \u0627\u0644\u0639\u0645\u064A\u0644.",
  "Everything booked in this campaign is for this client.": "\u0643\u0644 \u0645\u0627 \u064A\u064F\u062D\u062C\u0632 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u062D\u0645\u0644\u0629 \u0644\u0635\u0627\u0644\u062D \u0647\u0630\u0627 \u0627\u0644\u0639\u0645\u064A\u0644.",
  "Client name": "\u0627\u0633\u0645 \u0627\u0644\u0639\u0645\u064A\u0644",
  "Not set": "\u063A\u064A\u0631 \u0645\u062D\u062F\u062F",
  "TRN (optional)": "\u0627\u0644\u0631\u0642\u0645 \u0627\u0644\u0636\u0631\u064A\u0628\u064A (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Budget (AED, excl. VAT, optional)": "\u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629 (\u062F\u0631\u0647\u0645\u060C \u062F\u0648\u0646 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629\u060C \u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Address (optional)": "\u0627\u0644\u0639\u0646\u0648\u0627\u0646 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Stop bids and bookings that would go over this budget": "\u0623\u0648\u0642\u0641 \u0627\u0644\u0639\u0631\u0648\u0636 \u0648\u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u062A\u062C\u0627\u0648\u0632 \u0647\u0630\u0647 \u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629",
  "Outlets that do not accept the client's industry, or refuse its name, are blocked before you bid. The client's name and TRN appear on your orders, receipts and invoices for its bookings.": "\u0627\u0644\u0645\u0646\u0627\u0641\u0630 \u0627\u0644\u062A\u064A \u0644\u0627 \u062A\u0642\u0628\u0644 \u0642\u0637\u0627\u0639 \u0627\u0644\u0639\u0645\u064A\u0644 \u0623\u0648 \u062A\u0631\u0641\u0636 \u0627\u0633\u0645\u0647 \u062A\u064F\u062D\u062C\u0628 \u0642\u0628\u0644 \u0623\u0646 \u062A\u0642\u062F\u0651\u0645 \u0639\u0631\u0636\u0643. \u064A\u0638\u0647\u0631 \u0627\u0633\u0645 \u0627\u0644\u0639\u0645\u064A\u0644 \u0648\u0631\u0642\u0645\u0647 \u0627\u0644\u0636\u0631\u064A\u0628\u064A \u0639\u0644\u0649 \u0637\u0644\u0628\u0627\u062A\u0643 \u0648\u0625\u064A\u0635\u0627\u0644\u0627\u062A\u0643 \u0648\u0641\u0648\u0627\u062A\u064A\u0631\u0643 \u0644\u062D\u062C\u0648\u0632\u0627\u062A\u0647.",
  "For agencies: book for each client, keep to its budget, and send it its own receipts and report.": "\u0644\u0644\u0648\u0643\u0627\u0644\u0627\u062A: \u0627\u062D\u062C\u0632 \u0644\u0643\u0644 \u0639\u0645\u064A\u0644\u060C \u0648\u0627\u0644\u062A\u0632\u0645 \u0628\u0645\u064A\u0632\u0627\u0646\u064A\u062A\u0647\u060C \u0648\u0623\u0631\u0633\u0644 \u0644\u0647 \u0625\u064A\u0635\u0627\u0644\u0627\u062A\u0647 \u0648\u062A\u0642\u0631\u064A\u0631\u0647 \u0627\u0644\u062E\u0627\u0635.",
  "Add a client": "\u0623\u0636\u0641 \u0639\u0645\u064A\u0644\u064B\u0627",
  "Add client": "\u0623\u0636\u0641 \u0627\u0644\u0639\u0645\u064A\u0644",
  "No clients yet. Add one, then choose it when you bid or book, so its spend, receipts and report stay together.": "\u0644\u0627 \u0639\u0645\u0644\u0627\u0621 \u0628\u0639\u062F. \u0623\u0636\u0641 \u0639\u0645\u064A\u0644\u064B\u0627\u060C \u062B\u0645 \u0627\u062E\u062A\u0631\u0647 \u0639\u0646\u062F \u062A\u0642\u062F\u064A\u0645 \u0639\u0631\u0636 \u0623\u0648 \u062D\u062C\u0632\u060C \u0644\u064A\u0628\u0642\u0649 \u0625\u0646\u0641\u0627\u0642\u0647 \u0648\u0625\u064A\u0635\u0627\u0644\u0627\u062A\u0647 \u0648\u062A\u0642\u0631\u064A\u0631\u0647 \u0645\u0639\u064B\u0627.",
  "Archived": "\u0645\u0624\u0631\u0634\u0641",
  "No industry set": "\u0644\u0645 \u064A\u064F\u062D\u062F\u062F \u0627\u0644\u0642\u0637\u0627\u0639",
  "Report (CSV)": "\u0627\u0644\u062A\u0642\u0631\u064A\u0631 (CSV)",
  "Archived. Its bookings and documents stay.": "\u0623\u064F\u0631\u0634\u0641. \u062A\u0628\u0642\u0649 \u062D\u062C\u0648\u0632\u0627\u062A\u0647 \u0648\u0645\u0633\u062A\u0646\u062F\u0627\u062A\u0647.",
  "Active again.": "\u0646\u0634\u0637 \u0645\u062C\u062F\u062F\u064B\u0627.",
  "Make active": "\u0641\u0639\u0651\u0644\u0647",
  "Prices excl. VAT. Bids and bookings that would go over the budget are refused.": "\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u062F\u0648\u0646 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629. \u062A\u064F\u0631\u0641\u0636 \u0627\u0644\u0639\u0631\u0648\u0636 \u0648\u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u062A\u062C\u0627\u0648\u0632 \u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629.",
  "Prices excl. VAT. The budget is a guide: Nashr shows it when you bid but does not stop you.": "\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u062F\u0648\u0646 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629. \u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629 \u0625\u0631\u0634\u0627\u062F\u064A\u0629: \u062A\u0639\u0631\u0636\u0647\u0627 \u0646\u0634\u0631 \u0639\u0646\u062F \u062A\u0642\u062F\u064A\u0645 \u0627\u0644\u0639\u0631\u0636 \u0648\u0644\u0627 \u062A\u0645\u0646\u0639\u0643.",
  "Prices excl. VAT. Add a budget to track spend against it.": "\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u062F\u0648\u0646 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629. \u0623\u0636\u0641 \u0645\u064A\u0632\u0627\u0646\u064A\u0629 \u0644\u062A\u062A\u0627\u0628\u0639 \u0627\u0644\u0625\u0646\u0641\u0627\u0642 \u0645\u0642\u0627\u0628\u0644\u0647\u0627.",
  "Nothing booked for this client yet. Choose it in the bid panel when you bid or book.": "\u0644\u0627 \u062D\u062C\u0648\u0632\u0627\u062A \u0644\u0647\u0630\u0627 \u0627\u0644\u0639\u0645\u064A\u0644 \u0628\u0639\u062F. \u0627\u062E\u062A\u0631\u0647 \u0641\u064A \u0644\u0648\u062D\u0629 \u0627\u0644\u0639\u0631\u0636 \u0639\u0646\u062F \u062A\u0642\u062F\u064A\u0645 \u0639\u0631\u0636 \u0623\u0648 \u062D\u062C\u0632.",
  "Documents appear here once a booking for this client is accepted and paid.": "\u062A\u0638\u0647\u0631 \u0627\u0644\u0645\u0633\u062A\u0646\u062F\u0627\u062A \u0647\u0646\u0627 \u0628\u0639\u062F \u0642\u0628\u0648\u0644 \u062D\u062C\u0632 \u0644\u0647\u0630\u0627 \u0627\u0644\u0639\u0645\u064A\u0644 \u0648\u062F\u0641\u0639\u0647.",
  "For client: {name}": "\u0644\u0635\u0627\u0644\u062D \u0627\u0644\u0639\u0645\u064A\u0644: {name}",
  "passed": "\u0646\u062C\u062D",
  "not yet": "\u0644\u064A\u0633 \u0628\u0639\u062F",
  "{n} problems need a person": "{n} \u0645\u0634\u0643\u0644\u0627\u062A \u062A\u062D\u062A\u0627\u062C \u0625\u0644\u0649 \u0645\u062A\u0627\u0628\u0639\u0629",
  "All systems normal": "\u0643\u0644 \u0627\u0644\u0623\u0646\u0638\u0645\u0629 \u062A\u0639\u0645\u0644 \u0637\u0628\u064A\u0639\u064A\u064B\u0627",
  "Last backup": "\u0622\u062E\u0631 \u0646\u0633\u062E\u0629 \u0627\u062D\u062A\u064A\u0627\u0637\u064A\u0629",
  "Last restore drill": "\u0622\u062E\u0631 \u062A\u062C\u0631\u0628\u0629 \u0627\u0633\u062A\u0639\u0627\u062F\u0629",
  "Backups are not watched on this server (BACKUP_DIR is not set).": "\u0627\u0644\u0646\u0633\u062E \u0627\u0644\u0627\u062D\u062A\u064A\u0627\u0637\u064A\u0629 \u063A\u064A\u0631 \u0645\u0631\u0627\u0642\u0628\u0629 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062E\u0627\u062F\u0645 (\u0644\u0645 \u064A\u064F\u0636\u0628\u0637 BACKUP_DIR).",
  "Staff get a bell, email and phone alert when a problem starts and when it clears.": "\u064A\u062A\u0644\u0642\u0649 \u0627\u0644\u0641\u0631\u064A\u0642 \u062A\u0646\u0628\u064A\u0647\u064B\u0627 \u0641\u064A \u0627\u0644\u062C\u0631\u0633 \u0648\u0627\u0644\u0628\u0631\u064A\u062F \u0648\u0627\u0644\u0647\u0627\u062A\u0641 \u0639\u0646\u062F \u0628\u062F\u0621 \u0627\u0644\u0645\u0634\u0643\u0644\u0629 \u0648\u0639\u0646\u062F \u0632\u0648\u0627\u0644\u0647\u0627.",
  "Needs attention: {detail}": "\u064A\u062D\u062A\u0627\u062C \u0625\u0644\u0649 \u0645\u062A\u0627\u0628\u0639\u0629: {detail}",
  "Cleared: {detail}": "\u0632\u0627\u0644\u062A: {detail}",
  "One problem needs a person": "\u0645\u0634\u0643\u0644\u0629 \u0648\u0627\u062D\u062F\u0629 \u062A\u062D\u062A\u0627\u062C \u0625\u0644\u0649 \u0645\u062A\u0627\u0628\u0639\u0629",
  "The card form could not load. Check your connection and try again.": "\u062A\u0639\u0630\u0651\u0631 \u062A\u062D\u0645\u064A\u0644 \u0646\u0645\u0648\u0630\u062C \u0627\u0644\u0628\u0637\u0627\u0642\u0629. \u062A\u062D\u0642\u0651\u0642 \u0645\u0646 \u0627\u062A\u0635\u0627\u0644\u0643 \u0648\u062D\u0627\u0648\u0644 \u0645\u0631\u0629 \u0623\u062E\u0631\u0649.",
  "Confirmed by your bank. Securing the payment\u2026": "\u0623\u0643\u0651\u062F \u0628\u0646\u0643\u0643 \u0627\u0644\u062F\u0641\u0639. \u062C\u0627\u0631\u064D \u062A\u0623\u0645\u064A\u0646 \u0627\u0644\u062F\u0641\u0639\u0629\u2026",
  "Your bank confirmed the payment. It can take a minute to show here; refresh the page shortly.": "\u0623\u0643\u0651\u062F \u0628\u0646\u0643\u0643 \u0627\u0644\u062F\u0641\u0639. \u0642\u062F \u064A\u0633\u062A\u063A\u0631\u0642 \u0638\u0647\u0648\u0631\u0647 \u0647\u0646\u0627 \u062F\u0642\u064A\u0642\u0629\u061B \u062D\u062F\u0651\u062B \u0627\u0644\u0635\u0641\u062D\u0629 \u0628\u0639\u062F \u0642\u0644\u064A\u0644.",
  "Payment secured.": "\u062A\u0645 \u062A\u0623\u0645\u064A\u0646 \u0627\u0644\u062F\u0641\u0639\u0629.",
  "Check the card details.": "\u062A\u062D\u0642\u0651\u0642 \u0645\u0646 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0628\u0637\u0627\u0642\u0629.",
  "Card details go straight to Stripe, our payment provider. Nashr never sees the card number.": "\u062A\u0630\u0647\u0628 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0628\u0637\u0627\u0642\u0629 \u0645\u0628\u0627\u0634\u0631\u0629 \u0625\u0644\u0649 Stripe\u060C \u0645\u0632\u0648\u0651\u062F \u0627\u0644\u062F\u0641\u0639 \u0644\u062F\u064A\u0646\u0627. \u0644\u0627 \u062A\u0631\u0649 \u0646\u0634\u0631 \u0631\u0642\u0645 \u0627\u0644\u0628\u0637\u0627\u0642\u0629 \u0623\u0628\u062F\u064B\u0627.",
  "Test cards: payments are not connected yet, so no real money moves.": "\u0628\u0637\u0627\u0642\u0627\u062A \u062A\u062C\u0631\u064A\u0628\u064A\u0629: \u0644\u0645 \u064A\u064F\u0631\u0628\u0637 \u0627\u0644\u062F\u0641\u0639 \u0628\u0639\u062F\u060C \u0644\u0630\u0627 \u0644\u0627 \u062A\u064F\u0646\u0642\u0644 \u0623\u0645\u0648\u0627\u0644 \u062D\u0642\u064A\u0642\u064A\u0629.",
  "Paying\u2026": "\u062C\u0627\u0631\u064D \u0627\u0644\u062F\u0641\u0639\u2026",
  "The payout set-up link expired. Press Connect payout account to continue where you left off.": "\u0627\u0646\u062A\u0647\u062A \u0635\u0644\u0627\u062D\u064A\u0629 \u0631\u0627\u0628\u0637 \u0625\u0639\u062F\u0627\u062F \u0627\u0633\u062A\u0644\u0627\u0645 \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A. \u0627\u0636\u063A\u0637 \xAB\u0631\u0628\u0637 \u062D\u0633\u0627\u0628 \u0627\u0633\u062A\u0644\u0627\u0645 \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A\xBB \u0644\u062A\u0643\u0645\u0644 \u0645\u0646 \u062D\u064A\u062B \u062A\u0648\u0642\u0641\u062A.",
  "Thanks. Stripe is checking your details; this page updates once your payout account is verified.": "\u0634\u0643\u0631\u064B\u0627. \u062A\u0631\u0627\u062C\u0639 Stripe \u0628\u064A\u0627\u0646\u0627\u062A\u0643\u061B \u062A\u062A\u062D\u062F\u0651\u062B \u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u062D\u0629 \u0628\u0639\u062F \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0633\u0627\u0628 \u0627\u0633\u062A\u0644\u0627\u0645 \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A.",
  "Business and affluent": "\u0627\u0644\u0623\u0639\u0645\u0627\u0644 \u0648\u0623\u0635\u062D\u0627\u0628 \u0627\u0644\u062F\u062E\u0644 \u0627\u0644\u0645\u0631\u062A\u0641\u0639",
  "Decision makers, high earners and investors.": "\u0635\u0646\u0651\u0627\u0639 \u0627\u0644\u0642\u0631\u0627\u0631 \u0648\u0623\u0635\u062D\u0627\u0628 \u0627\u0644\u062F\u062E\u0644 \u0627\u0644\u0645\u0631\u062A\u0641\u0639 \u0648\u0627\u0644\u0645\u0633\u062A\u062B\u0645\u0631\u0648\u0646.",
  "Families and communities": "\u0627\u0644\u0639\u0627\u0626\u0644\u0627\u062A \u0648\u0627\u0644\u0645\u062C\u062A\u0645\u0639\u0627\u062A",
  "Households and the communities that make up the UAE.": "\u0627\u0644\u0623\u0633\u0631 \u0648\u0627\u0644\u0645\u062C\u062A\u0645\u0639\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u0634\u0643\u0651\u0644 \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A.",
  "Habits and interests": "\u0627\u0644\u0639\u0627\u062F\u0627\u062A \u0648\u0627\u0644\u0627\u0647\u062A\u0645\u0627\u0645\u0627\u062A",
  "People defined by what they do every day.": "\u0623\u0634\u062E\u0627\u0635 \u062A\u062C\u0645\u0639\u0647\u0645 \u0639\u0627\u062F\u0627\u062A\u0647\u0645 \u0627\u0644\u064A\u0648\u0645\u064A\u0629.",
  "How booking works": "\u0643\u064A\u0641 \u064A\u062A\u0645 \u0627\u0644\u062D\u062C\u0632",
  "Choose who to reach": "\u0627\u062E\u062A\u0631 \u0645\u0646 \u062A\u0631\u064A\u062F \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u064A\u0647",
  "See the radio, TV, print, digital and podcast slots that reach them, with real prices.": "\u0634\u0627\u0647\u062F \u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0645\u0637\u0628\u0648\u0639\u0627\u062A \u0648\u0627\u0644\u0631\u0642\u0645\u064A \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A \u0627\u0644\u062A\u064A \u062A\u0635\u0644 \u0625\u0644\u064A\u0647\u0645\u060C \u0628\u0623\u0633\u0639\u0627\u0631 \u062D\u0642\u064A\u0642\u064A\u0629.",
  "Bid or book": "\u0642\u062F\u0651\u0645 \u0639\u0631\u0636\u064B\u0627 \u0623\u0648 \u0627\u062D\u062C\u0632",
  "Bid in an auction, book at a fixed price, or ask for a quick sale. The publisher confirms.": "\u0642\u062F\u0651\u0645 \u0639\u0631\u0636\u064B\u0627 \u0641\u064A \u0645\u0632\u0627\u062F\u060C \u0623\u0648 \u0627\u062D\u062C\u0632 \u0628\u0633\u0639\u0631 \u062B\u0627\u0628\u062A\u060C \u0623\u0648 \u0627\u0637\u0644\u0628 \u0628\u064A\u0639\u064B\u0627 \u0633\u0631\u064A\u0639\u064B\u0627. \u0648\u064A\u0624\u0643\u062F \u0627\u0644\u0646\u0627\u0634\u0631.",
  "Pay safely": "\u0627\u062F\u0641\u0639 \u0628\u0623\u0645\u0627\u0646",
  "Your payment is held by Nashr and released to the publisher only after proof that your ad ran.": "\u062A\u062D\u062A\u0641\u0638 \u0646\u0634\u0631 \u0628\u062F\u0641\u0639\u062A\u0643 \u0648\u0644\u0627 \u062A\u064F\u062D\u0648\u064E\u0651\u0644 \u0625\u0644\u0649 \u0627\u0644\u0646\u0627\u0634\u0631 \u0625\u0644\u0627 \u0628\u0639\u062F \u0625\u062B\u0628\u0627\u062A \u0628\u062B \u0625\u0639\u0644\u0627\u0646\u0643.",
  "Help planning": "\u0645\u0633\u0627\u0639\u062F\u0629 \u0641\u064A \u0627\u0644\u062A\u062E\u0637\u064A\u0637",
  "Planning a campaign?": "\u062A\u062E\u0637\u0637 \u0644\u062D\u0645\u0644\u0629\u061F",
  "Get told about new slots.": "\u0627\u062D\u0635\u0644 \u0639\u0644\u0649 \u062A\u0646\u0628\u064A\u0647 \u0628\u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u062C\u062F\u064A\u062F\u0629.",
  "Open the calendar with this filter and save the search; Nashr sends an alert when something new matches.": "\u0627\u0641\u062A\u062D \u0627\u0644\u062A\u0642\u0648\u064A\u0645 \u0628\u0647\u0630\u0627 \u0627\u0644\u0641\u0644\u062A\u0631 \u0648\u0627\u062D\u0641\u0638 \u0627\u0644\u0628\u062D\u062B\u061B \u0648\u062A\u0631\u0633\u0644 \u0644\u0643 \u0646\u0634\u0631 \u062A\u0646\u0628\u064A\u0647\u064B\u0627 \u0639\u0646\u062F \u0638\u0647\u0648\u0631 \u0645\u0627 \u064A\u0637\u0627\u0628\u0642\u0647.",
  "Plan against a budget.": "\u062E\u0637\u0651\u0637 \u0636\u0645\u0646 \u0645\u064A\u0632\u0627\u0646\u064A\u0629.",
  "A campaign keeps your outlets, budget and bookings together, and makes a media plan PDF to share.": "\u062A\u062C\u0645\u0639 \u0627\u0644\u062D\u0645\u0644\u0629 \u0645\u0646\u0627\u0641\u0630\u0643 \u0648\u0645\u064A\u0632\u0627\u0646\u064A\u062A\u0643 \u0648\u062D\u062C\u0648\u0632\u0627\u062A\u0643 \u0645\u0639\u064B\u0627\u060C \u0648\u062A\u064F\u0639\u062F\u0651 \u062E\u0637\u0629 \u0625\u0639\u0644\u0627\u0645\u064A\u0629 \u0628\u0635\u064A\u063A\u0629 PDF \u0644\u0644\u0645\u0634\u0627\u0631\u0643\u0629.",
  "Not sure where to start?": "\u0644\u0633\u062A \u0645\u062A\u0623\u0643\u062F\u064B\u0627 \u0645\u0646 \u0623\u064A\u0646 \u062A\u0628\u062F\u0623\u061F",
  "Tell Nashr's team who you want to reach and your budget; we will suggest outlets and dates.": "\u0623\u062E\u0628\u0631 \u0641\u0631\u064A\u0642 \u0646\u0634\u0631 \u0628\u0645\u0646 \u062A\u0631\u064A\u062F \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u064A\u0647 \u0648\u0628\u0645\u064A\u0632\u0627\u0646\u064A\u062A\u0643\u061B \u0648\u0633\u0646\u0642\u062A\u0631\u062D \u0639\u0644\u064A\u0643 \u0627\u0644\u0645\u0646\u0627\u0641\u0630 \u0648\u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F.",
  "Ask Nashr": "\u0627\u0633\u0623\u0644 \u0646\u0634\u0631",
  "Open slots, next {n} weeks": "\u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u0645\u062A\u0627\u062D\u0629\u060C \u062E\u0644\u0627\u0644 {n} \u0623\u0633\u0627\u0628\u064A\u0639",
  "Starting from": "\u0627\u0628\u062A\u062F\u0627\u0621\u064B \u0645\u0646",
  "Nothing open for this right now": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0633\u0627\u062D\u0627\u062A \u0645\u062A\u0627\u062D\u0629 \u0644\u0647\u0630\u0627 \u062D\u0627\u0644\u064A\u064B\u0627",
  "Publishers add new dates every day. Save this search on the calendar and Nashr tells you as soon as something matches, or ask our team to find you options.": "\u064A\u0636\u064A\u0641 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0645\u0648\u0627\u0639\u064A\u062F \u062C\u062F\u064A\u062F\u0629 \u0643\u0644 \u064A\u0648\u0645. \u0627\u062D\u0641\u0638 \u0647\u0630\u0627 \u0627\u0644\u0628\u062D\u062B \u0641\u064A \u0627\u0644\u062A\u0642\u0648\u064A\u0645 \u0648\u0633\u062A\u062E\u0628\u0631\u0643 \u0646\u0634\u0631 \u0641\u0648\u0631 \u0638\u0647\u0648\u0631 \u0645\u0627 \u064A\u0637\u0627\u0628\u0642\u0647\u060C \u0623\u0648 \u0627\u0637\u0644\u0628 \u0645\u0646 \u0641\u0631\u064A\u0642\u0646\u0627 \u0623\u0646 \u064A\u062C\u062F \u0644\u0643 \u062E\u064A\u0627\u0631\u0627\u062A.",
  "Get alerts on the calendar": "\u0627\u062D\u0635\u0644 \u0639\u0644\u0649 \u062A\u0646\u0628\u064A\u0647\u0627\u062A \u0645\u0646 \u0627\u0644\u062A\u0642\u0648\u064A\u0645",
  "Where to reach them": "\u0623\u064A\u0646 \u062A\u0635\u0644 \u0625\u0644\u064A\u0647\u0645",
  "Publishers that reach them": "\u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0627\u0644\u0630\u064A\u0646 \u064A\u0635\u0644\u0648\u0646 \u0625\u0644\u064A\u0647\u0645",
  "Book soon: closing first": "\u0627\u062D\u062C\u0632 \u0642\u0631\u064A\u0628\u064B\u0627: \u0627\u0644\u0623\u0642\u0631\u0628 \u0625\u063A\u0644\u0627\u0642\u064B\u0627 \u0623\u0648\u0644\u064B\u0627",
  "Closes": "\u064A\u064F\u063A\u0644\u0642",
  "Price now": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0622\u0646",
  "See all {n} open slots on the calendar": "\u0634\u0627\u0647\u062F \u0643\u0644 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u0645\u062A\u0627\u062D\u0629 ({n}) \u0641\u064A \u0627\u0644\u062A\u0642\u0648\u064A\u0645",
  "Start from the people, not the media. Pick an audience to see every radio, TV, print, digital and podcast slot that reaches them, with real prices and dates.": "\u0627\u0628\u062F\u0623 \u0645\u0646 \u0627\u0644\u0646\u0627\u0633 \u0644\u0627 \u0645\u0646 \u0627\u0644\u0648\u0633\u064A\u0644\u0629. \u0627\u062E\u062A\u0631 \u062C\u0645\u0647\u0648\u0631\u064B\u0627 \u0644\u062A\u0631\u0649 \u0643\u0644 \u0645\u0633\u0627\u062D\u0629 \u0625\u0630\u0627\u0639\u064A\u0629 \u0648\u062A\u0644\u0641\u0632\u064A\u0648\u0646\u064A\u0629 \u0648\u0645\u0637\u0628\u0648\u0639\u0629 \u0648\u0631\u0642\u0645\u064A\u0629 \u0648\u0628\u0648\u062F\u0643\u0627\u0633\u062A \u062A\u0635\u0644 \u0625\u0644\u064A\u0647\u060C \u0628\u0623\u0633\u0639\u0627\u0631 \u0648\u0645\u0648\u0627\u0639\u064A\u062F \u062D\u0642\u064A\u0642\u064A\u0629.",
  "Show audiences reachable on": "\u0627\u0639\u0631\u0636 \u0627\u0644\u062C\u0645\u0627\u0647\u064A\u0631 \u0627\u0644\u062A\u064A \u064A\u0645\u0643\u0646 \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u064A\u0647\u0627 \u0639\u0628\u0631",
  "Any channel": "\u0623\u064A \u0642\u0646\u0627\u0629",
  "open slots": "\u0645\u0633\u0627\u062D\u0629 \u0645\u062A\u0627\u062D\u0629",
  "Nothing open right now. Get an alert when there is.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0633\u0627\u062D\u0627\u062A \u0645\u062A\u0627\u062D\u0629 \u062D\u0627\u0644\u064A\u064B\u0627. \u0627\u062D\u0635\u0644 \u0639\u0644\u0649 \u062A\u0646\u0628\u064A\u0647 \u0639\u0646\u062F \u062A\u0648\u0641\u0631\u0647\u0627.",
  "Not sure who to reach?": "\u0644\u0633\u062A \u0645\u062A\u0623\u0643\u062F\u064B\u0627 \u0645\u0645\u0646 \u062A\u0631\u064A\u062F \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u064A\u0647\u061F",
  "Tell Nashr's team what you sell, who buys it and your budget. We will suggest the audiences, outlets and dates that fit, at no cost.": "\u0623\u062E\u0628\u0631 \u0641\u0631\u064A\u0642 \u0646\u0634\u0631 \u0628\u0645\u0627 \u062A\u0628\u064A\u0639\u0647 \u0648\u0645\u0646 \u064A\u0634\u062A\u0631\u064A\u0647 \u0648\u0628\u0645\u064A\u0632\u0627\u0646\u064A\u062A\u0643. \u0648\u0633\u0646\u0642\u062A\u0631\u062D \u0639\u0644\u064A\u0643 \u0627\u0644\u062C\u0645\u0627\u0647\u064A\u0631 \u0648\u0627\u0644\u0645\u0646\u0627\u0641\u0630 \u0648\u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F \u0627\u0644\u0645\u0646\u0627\u0633\u0628\u0629\u060C \u062F\u0648\u0646 \u0623\u064A \u062A\u0643\u0644\u0641\u0629.",
  "1 open slot": "\u0645\u0633\u0627\u062D\u0629 \u0648\u0627\u062D\u062F\u0629 \u0645\u062A\u0627\u062D\u0629",
  "{n} open slots": "{n} \u0645\u0633\u0627\u062D\u0629 \u0645\u062A\u0627\u062D\u0629",
  "1 publisher": "\u0646\u0627\u0634\u0631 \u0648\u0627\u062D\u062F",
  "{n} publishers": "{n} \u0646\u0627\u0634\u0631\u064A\u0646",
  "Publishers": "\u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646",
  "Channels": "\u0627\u0644\u0642\u0646\u0648\u0627\u062A",
  "Browse the calendar": "\u062A\u0635\u0641\u0651\u062D \u0627\u0644\u062A\u0642\u0648\u064A\u0645",
  "Newspaper": "\u0635\u062D\u064A\u0641\u0629",
  "Magazine": "\u0645\u062C\u0644\u0629",
  "Newsletter": "\u0646\u0634\u0631\u0629 \u0628\u0631\u064A\u062F\u064A\u0629",
  "Website": "\u0645\u0648\u0642\u0639 \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
  "TV / Shows": "\u062A\u0644\u0641\u0632\u064A\u0648\u0646 / \u0628\u0631\u0627\u0645\u062C",
  "Social media": "\u0648\u0633\u0627\u0626\u0644 \u0627\u0644\u062A\u0648\u0627\u0635\u0644 \u0627\u0644\u0627\u062C\u062A\u0645\u0627\u0639\u064A",
  "Double-page spread": "\u0635\u0641\u062D\u062A\u0627\u0646 \u0645\u062A\u0642\u0627\u0628\u0644\u062A\u0627\u0646",
  "Two facing pages in one issue": "\u0635\u0641\u062D\u062A\u0627\u0646 \u0645\u062A\u0642\u0627\u0628\u0644\u062A\u0627\u0646 \u0641\u064A \u0639\u062F\u062F \u0648\u0627\u062D\u062F",
  "Two facing pages in one weekly issue.": "\u0635\u0641\u062D\u062A\u0627\u0646 \u0645\u062A\u0642\u0627\u0628\u0644\u062A\u0627\u0646 \u0641\u064A \u0639\u062F\u062F \u0623\u0633\u0628\u0648\u0639\u064A \u0648\u0627\u062D\u062F.",
  "42 \xD7 28 cm with 3 mm bleed, PDF/X-1a, 300 dpi.": "42 \xD7 28 \u0633\u0645 \u0645\u0639 \u0647\u0627\u0645\u0634 \u0646\u0632\u0641 3 \u0645\u0645\u060C PDF/X-1a\u060C \u0628\u062F\u0642\u0629 300 \u0646\u0642\u0637\u0629.",
  "Dedicated send": "\u0625\u0631\u0633\u0627\u0644 \u0645\u062E\u0635\u0635",
  "A whole email about your brand": "\u0631\u0633\u0627\u0644\u0629 \u0628\u0631\u064A\u062F \u0643\u0627\u0645\u0644\u0629 \u0639\u0646 \u0639\u0644\u0627\u0645\u062A\u0643",
  "One email to the whole list about your brand only.": "\u0631\u0633\u0627\u0644\u0629 \u0648\u0627\u062D\u062F\u0629 \u0644\u0643\u0627\u0645\u0644 \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0639\u0646 \u0639\u0644\u0627\u0645\u062A\u0643 \u0641\u0642\u0637.",
  "Subject line, 300 words, 2 images (1200 px wide) and a link.": "\u0633\u0637\u0631 \u0627\u0644\u0645\u0648\u0636\u0648\u0639\u060C \u0648300 \u0643\u0644\u0645\u0629\u060C \u0648\u0635\u0648\u0631\u062A\u0627\u0646 (\u0628\u0639\u0631\u0636 1200 \u0628\u0643\u0633\u0644) \u0648\u0631\u0627\u0628\u0637.",
  "Instagram post": "\u0645\u0646\u0634\u0648\u0631 \u0625\u0646\u0633\u062A\u063A\u0631\u0627\u0645",
  "A branded post in the feed": "\u0645\u0646\u0634\u0648\u0631 \u062A\u0631\u0648\u064A\u062C\u064A \u0641\u064A \u0627\u0644\u0635\u0641\u062D\u0629",
  "One branded feed post, labelled as a paid partnership.": "\u0645\u0646\u0634\u0648\u0631 \u062A\u0631\u0648\u064A\u062C\u064A \u0648\u0627\u062D\u062F \u064A\u062D\u0645\u0644 \u0648\u0633\u0645 \u0634\u0631\u0627\u0643\u0629 \u0645\u062F\u0641\u0648\u0639\u0629.",
  "Square or 4:5 image or carousel, caption of up to 150 words.": "\u0635\u0648\u0631\u0629 \u0645\u0631\u0628\u0639\u0629 \u0623\u0648 \u0628\u0646\u0633\u0628\u0629 4:5 \u0623\u0648 \u0645\u0646\u0634\u0648\u0631 \u0645\u062A\u0639\u062F\u062F \u0627\u0644\u0635\u0648\u0631\u060C \u0645\u0639 \u062A\u0639\u0644\u064A\u0642 \u062D\u062A\u0649 150 \u0643\u0644\u0645\u0629.",
  "Instagram Reel": "\u0631\u064A\u0644\u0632 \u0625\u0646\u0633\u062A\u063A\u0631\u0627\u0645",
  "A branded short video": "\u0641\u064A\u062F\u064A\u0648 \u0642\u0635\u064A\u0631 \u062A\u0631\u0648\u064A\u062C\u064A",
  "One branded Reel of up to 60 seconds, labelled as a paid partnership.": "\u0631\u064A\u0644\u0632 \u062A\u0631\u0648\u064A\u062C\u064A \u0648\u0627\u062D\u062F \u062D\u062A\u0649 60 \u062B\u0627\u0646\u064A\u0629 \u064A\u062D\u0645\u0644 \u0648\u0633\u0645 \u0634\u0631\u0627\u0643\u0629 \u0645\u062F\u0641\u0648\u0639\u0629.",
  "9:16 MP4, up to 60 seconds, or a brief for the outlet to film.": "MP4 \u0628\u0646\u0633\u0628\u0629 9:16 \u062D\u062A\u0649 60 \u062B\u0627\u0646\u064A\u0629\u060C \u0623\u0648 \u0645\u0648\u062C\u0632 \u0644\u064A\u0635\u0648\u0651\u0631\u0647 \u0627\u0644\u0645\u0646\u0641\u0630.",
  "Story set": "\u0645\u062C\u0645\u0648\u0639\u0629 \u0642\u0635\u0635",
  "Three stories with a link": "\u062B\u0644\u0627\u062B \u0642\u0635\u0635 \u0645\u0639 \u0631\u0627\u0628\u0637",
  "Three stories in a row with a link sticker to your page.": "\u062B\u0644\u0627\u062B \u0642\u0635\u0635 \u0645\u062A\u062A\u0627\u0644\u064A\u0629 \u0645\u0639 \u0645\u0644\u0635\u0642 \u0631\u0627\u0628\u0637 \u0625\u0644\u0649 \u0635\u0641\u062D\u062A\u0643.",
  "Three 9:16 images or videos, up to 15 seconds each, and a link.": "\u062B\u0644\u0627\u062B \u0635\u0648\u0631 \u0623\u0648 \u0645\u0642\u0627\u0637\u0639 \u0628\u0646\u0633\u0628\u0629 9:16\u060C \u062D\u062A\u0649 15 \u062B\u0627\u0646\u064A\u0629 \u0644\u0643\u0644 \u0645\u0646\u0647\u0627\u060C \u0648\u0631\u0627\u0628\u0637.",
  "TikTok video": "\u0641\u064A\u062F\u064A\u0648 \u062A\u064A\u0643 \u062A\u0648\u0643",
  "A branded TikTok": "\u062A\u064A\u0643 \u062A\u0648\u0643 \u062A\u0631\u0648\u064A\u062C\u064A",
  "One branded TikTok video, labelled as paid.": "\u0641\u064A\u062F\u064A\u0648 \u062A\u064A\u0643 \u062A\u0648\u0643 \u062A\u0631\u0648\u064A\u062C\u064A \u0648\u0627\u062D\u062F \u064A\u062D\u0645\u0644 \u0648\u0633\u0645 \u0625\u0639\u0644\u0627\u0646 \u0645\u062F\u0641\u0648\u0639.",
  "X post": "\u0645\u0646\u0634\u0648\u0631 \u0639\u0644\u0649 \u0625\u0643\u0633",
  "A post on X with a link": "\u0645\u0646\u0634\u0648\u0631 \u0639\u0644\u0649 \u0625\u0643\u0633 \u0645\u0639 \u0631\u0627\u0628\u0637",
  "One post on X with your message and link.": "\u0645\u0646\u0634\u0648\u0631 \u0648\u0627\u062D\u062F \u0639\u0644\u0649 \u0625\u0643\u0633 \u0628\u0631\u0633\u0627\u0644\u062A\u0643 \u0648\u0631\u0627\u0628\u0637\u0643.",
  "Up to 280 characters, one image (1600 \xD7 900) and a link.": "\u062D\u062A\u0649 280 \u062D\u0631\u0641\u064B\u0627\u060C \u0648\u0635\u0648\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 (1600 \xD7 900) \u0648\u0631\u0627\u0628\u0637.",
  "a screenshot of the sent email": "\u0644\u0642\u0637\u0629 \u0634\u0627\u0634\u0629 \u0644\u0644\u0631\u0633\u0627\u0644\u0629 \u0627\u0644\u0645\u0631\u0633\u0644\u0629",
  "the send time": "\u0648\u0642\u062A \u0627\u0644\u0625\u0631\u0633\u0627\u0644",
  "the link to the post": "\u0631\u0627\u0628\u0637 \u0627\u0644\u0645\u0646\u0634\u0648\u0631",
  "Products": "\u0627\u0644\u0645\u0646\u062A\u062C\u0627\u062A",
  "Requests": "\u0627\u0644\u0637\u0644\u0628\u0627\u062A",
  "Transactions": "\u0627\u0644\u0645\u0639\u0627\u0645\u0644\u0627\u062A",
  "Balances": "\u0627\u0644\u0623\u0631\u0635\u062F\u0629",
  "Net earnings over the period, added up: {amount}": "\u0635\u0627\u0641\u064A \u0627\u0644\u0623\u0631\u0628\u0627\u062D \u062E\u0644\u0627\u0644 \u0627\u0644\u0641\u062A\u0631\u0629\u060C \u062A\u0631\u0627\u0643\u0645\u064A\u064B\u0627: {amount}",
  "Net earnings by outlet": "\u0635\u0627\u0641\u064A \u0627\u0644\u0623\u0631\u0628\u0627\u062D \u062D\u0633\u0628 \u0627\u0644\u0645\u0646\u0641\u0630",
  "Net earnings": "\u0635\u0627\u0641\u064A \u0627\u0644\u0623\u0631\u0628\u0627\u062D",
  "No paid bookings in this period yet.": "\u0644\u0627 \u062D\u062C\u0648\u0632\u0627\u062A \u0645\u062F\u0641\u0648\u0639\u0629 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0641\u062A\u0631\u0629 \u0628\u0639\u062F.",
  "Accepted. The buyer is asked to pay.": "\u062A\u0645 \u0627\u0644\u0642\u0628\u0648\u0644. \u0637\u064F\u0644\u0628 \u0645\u0646 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0627\u0644\u062F\u0641\u0639.",
  "Your media inventory, bookings and earnings at a glance. Click any card for detail.": "\u0645\u062E\u0632\u0648\u0646\u0643 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A \u0648\u062D\u062C\u0648\u0632\u0627\u062A\u0643 \u0648\u0623\u0631\u0628\u0627\u062D\u0643 \u0641\u064A \u0644\u0645\u062D\u0629. \u0627\u0636\u063A\u0637 \u0623\u064A \u0628\u0637\u0627\u0642\u0629 \u0644\u0644\u062A\u0641\u0627\u0635\u064A\u0644.",
  "Period": "\u0627\u0644\u0641\u062A\u0631\u0629",
  "Finish setting up to start selling": "\u0623\u0643\u0645\u0644 \u0627\u0644\u0625\u0639\u062F\u0627\u062F \u0644\u062A\u0628\u062F\u0623 \u0627\u0644\u0628\u064A\u0639",
  "Gross sales": "\u0625\u062C\u0645\u0627\u0644\u064A \u0627\u0644\u0645\u0628\u064A\u0639\u0627\u062A",
  "Pending clearance": "\u0642\u064A\u062F \u0627\u0644\u062A\u0633\u0648\u064A\u0629",
  "1 booking until proof": "\u062D\u062C\u0632 \u0648\u0627\u062D\u062F \u062D\u062A\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "{n} bookings until proof": "{n} \u062D\u062C\u0648\u0632\u0627\u062A \u062D\u062A\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "Active products": "\u0627\u0644\u0645\u0646\u062A\u062C\u0627\u062A \u0627\u0644\u0646\u0634\u0637\u0629",
  "Awaiting your decision": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0642\u0631\u0627\u0631\u0643",
  "Review now": "\u0631\u0627\u062C\u0639 \u0627\u0644\u0622\u0646",
  "Earnings trend": "\u0627\u062A\u062C\u0627\u0647 \u0627\u0644\u0623\u0631\u0628\u0627\u062D",
  "Net, added up over the period": "\u0627\u0644\u0635\u0627\u0641\u064A\u060C \u062A\u0631\u0627\u0643\u0645\u064A\u064B\u0627 \u062E\u0644\u0627\u0644 \u0627\u0644\u0641\u062A\u0631\u0629",
  "Earnings by outlet": "\u0627\u0644\u0623\u0631\u0628\u0627\u062D \u062D\u0633\u0628 \u0627\u0644\u0645\u0646\u0641\u0630",
  "Needs your action": "\u064A\u062D\u062A\u0627\u062C \u0625\u0644\u0649 \u0625\u062C\u0631\u0627\u0621 \u0645\u0646\u0643",
  "All {n} items": "\u0643\u0644 \u0627\u0644\u0639\u0646\u0627\u0635\u0631 ({n})",
  "Nothing waiting on you. New bookings and requests appear here.": "\u0644\u0627 \u0634\u064A\u0621 \u0628\u0627\u0646\u062A\u0638\u0627\u0631\u0643. \u062A\u0638\u0647\u0631 \u0647\u0646\u0627 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0648\u0627\u0644\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u062C\u062F\u064A\u062F\u0629.",
  "You'd net {amount}": "\u0635\u0627\u0641\u064A \u0645\u0627 \u062A\u062D\u0635\u0644 \u0639\u0644\u064A\u0647 {amount}",
  "Due {date}": "\u0627\u0644\u0645\u0648\u0639\u062F {date}",
  "Recent transactions": "\u0623\u062D\u062F\u062B \u0627\u0644\u0645\u0639\u0627\u0645\u0644\u0627\u062A",
  "View all": "\u0639\u0631\u0636 \u0627\u0644\u0643\u0644",
  "No bookings yet.": "\u0644\u0627 \u062D\u062C\u0648\u0632\u0627\u062A \u0628\u0639\u062F.",
  "Gross sale": "\u0625\u062C\u0645\u0627\u0644\u064A \u0627\u0644\u0628\u064A\u0639",
  "Fee": "\u0627\u0644\u0631\u0633\u0648\u0645",
  "Net": "\u0627\u0644\u0635\u0627\u0641\u064A",
  "Earnings and statements": "\u0627\u0644\u0623\u0631\u0628\u0627\u062D \u0648\u0627\u0644\u0643\u0634\u0648\u0641",
  "Available now": "\u0645\u062A\u0627\u062D \u0627\u0644\u0622\u0646",
  "Transferred to your bank automatically": "\u064A\u064F\u062D\u0648\u064E\u0651\u0644 \u0625\u0644\u0649 \u062D\u0633\u0627\u0628\u0643 \u0627\u0644\u0628\u0646\u0643\u064A \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627",
  "Released when the buyer approves proof": "\u064A\u064F\u0635\u0631\u0641 \u0639\u0646\u062F \u0645\u0648\u0627\u0641\u0642\u0629 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0639\u0644\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "Released in this period": "\u0627\u0644\u0645\u0635\u0631\u0648\u0641 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0641\u062A\u0631\u0629",
  "After Nashr's commission": "\u0628\u0639\u062F \u0639\u0645\u0648\u0644\u0629 \u0646\u0634\u0631",
  "Awaiting you": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631\u0643",
  "Awaiting payment": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u062F\u0641\u0639",
  "Issue open": "\u0645\u0634\u0643\u0644\u0629 \u0645\u0641\u062A\u0648\u062D\u0629",
  "Paid": "\u0645\u062F\u0641\u0648\u0639",
  "Refunded": "\u0645\u0633\u062A\u0631\u062F",
  "Cancelled": "\u0645\u0644\u063A\u0649",
  "Disputed": "\u0645\u062A\u0646\u0627\u0632\u0639 \u0639\u0644\u064A\u0647",
  "Booking to decide": "\u062D\u062C\u0632 \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0642\u0631\u0627\u0631",
  "Bidding closed: choose the next bid": "\u0623\u064F\u063A\u0644\u0642 \u0627\u0644\u0645\u0632\u0627\u062F: \u0627\u062E\u062A\u0631 \u0627\u0644\u0639\u0631\u0636 \u0627\u0644\u062A\u0627\u0644\u064A",
  "Buyers interested": "\u0645\u0634\u062A\u0631\u0648\u0646 \u0645\u0647\u062A\u0645\u0648\u0646",
  "Creative to review": "\u062A\u0635\u0645\u064A\u0645 \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629",
  "Creative not received": "\u0644\u0645 \u064A\u0635\u0644 \u0627\u0644\u062A\u0635\u0645\u064A\u0645",
  "Proof needed": "\u0645\u0637\u0644\u0648\u0628 \u0625\u062B\u0628\u0627\u062A",
  "Issue reported": "\u062A\u0645 \u0627\u0644\u0625\u0628\u0644\u0627\u063A \u0639\u0646 \u0645\u0634\u0643\u0644\u0629",
  "Pre-run check": "\u062A\u062D\u0642\u0642 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B",
  "Invoice to upload": "\u0641\u0627\u062A\u0648\u0631\u0629 \u0644\u0644\u0631\u0641\u0639",
  "Accept": "\u0642\u0628\u0648\u0644",
  "Choose bid": "\u0627\u062E\u062A\u0631 \u0627\u0644\u0639\u0631\u0636",
  "Review": "\u0631\u0627\u062C\u0639",
  "Review creative": "\u0631\u0627\u062C\u0639 \u0627\u0644\u062A\u0635\u0645\u064A\u0645",
  "Decide": "\u0642\u0631\u0651\u0631",
  "Upload proof": "\u0627\u0631\u0641\u0639 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "Respond": "\u0631\u064F\u062F",
  "Confirm": "\u062A\u0623\u0643\u064A\u062F",
  "Upload invoice": "\u0627\u0631\u0641\u0639 \u0627\u0644\u0641\u0627\u062A\u0648\u0631\u0629",
  "Open": "\u0641\u062A\u062D",
  "Last 7 days": "\u0622\u062E\u0631 7 \u0623\u064A\u0627\u0645",
  "Last 30 days": "\u0622\u062E\u0631 30 \u064A\u0648\u0645\u064B\u0627",
  "Last 90 days": "\u0622\u062E\u0631 90 \u064A\u0648\u0645\u064B\u0627",
  "Last 12 months": "\u0622\u062E\u0631 12 \u0634\u0647\u0631\u064B\u0627",
  "All outlets": "\u0643\u0644 \u0627\u0644\u0645\u0646\u0627\u0641\u0630",
  "Add your first product": "\u0623\u0636\u0641 \u0645\u0646\u062A\u062C\u0643 \u0627\u0644\u0623\u0648\u0644",
  "Your business": "\u0646\u0634\u0627\u0637\u0643 \u0627\u0644\u062A\u062C\u0627\u0631\u064A",
  "Money": "\u0627\u0644\u0623\u0645\u0648\u0627\u0644",
  "Settings": "\u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A",
  "week": "\u0623\u0633\u0628\u0648\u0639",
  "edition": "\u0639\u062F\u062F",
  "send": "\u0625\u0631\u0633\u0627\u0644",
  "post": "\u0645\u0646\u0634\u0648\u0631",
  "day": "\u064A\u0648\u0645",
  "break": "\u0641\u0627\u0635\u0644",
  "{n} days": "{n} \u0623\u064A\u0627\u0645",
  "{n} hours": "{n} \u0633\u0627\u0639\u0627\u062A",
  "Package": "\u0627\u0644\u0628\u0627\u0642\u0629",
  "Who it reaches": "\u0645\u0646 \u064A\u0635\u0644 \u0625\u0644\u064A\u0647\u0645",
  "Not described yet": "\u0644\u0645 \u064A\u064F\u0648\u0635\u0641 \u0628\u0639\u062F",
  "None ticked": "\u0644\u0645 \u064A\u064F\u062D\u062F\u062F \u0623\u064A \u0645\u0646\u0647\u0627",
  "{n} per airing or edition": "{n} \u0644\u0643\u0644 \u0628\u062B \u0623\u0648 \u0639\u062F\u062F",
  "Every sector welcome": "\u0643\u0644 \u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A \u0645\u0631\u062D\u0651\u0628 \u0628\u0647\u0627",
  "Competitors refused: {names}": "\u0645\u0646\u0627\u0641\u0633\u0648\u0646 \u0645\u0631\u0641\u0648\u0636\u0648\u0646: {names}",
  "Creative deadline": "\u0645\u0648\u0639\u062F \u0627\u0644\u062A\u0635\u0645\u064A\u0645",
  "{time} before it runs": "\u0642\u0628\u0644 \u0627\u0644\u0628\u062B \u0628\u0640 {time}",
  "Runs": "\u064A\u064F\u0639\u0631\u0636",
  "Breaks": "\u0627\u0644\u0641\u0648\u0627\u0635\u0644",
  "Listed until {date}": "\u0645\u0639\u0631\u0648\u0636 \u062D\u062A\u0649 {date}",
  "All products": "\u0643\u0644 \u0627\u0644\u0645\u0646\u062A\u062C\u0627\u062A",
  "Everything you sell, across every outlet and media type. Describe a product once; the calendar puts it on sale by date.": "\u0643\u0644 \u0645\u0627 \u062A\u0628\u064A\u0639\u0647 \u0639\u0628\u0631 \u0643\u0644 \u0627\u0644\u0645\u0646\u0627\u0641\u0630 \u0648\u0623\u0646\u0648\u0627\u0639 \u0627\u0644\u0648\u0633\u0627\u0626\u0637. \u0635\u0650\u0641 \u0627\u0644\u0645\u0646\u062A\u062C \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629\u060C \u0648\u0627\u0644\u062A\u0642\u0648\u064A\u0645 \u064A\u0637\u0631\u062D\u0647 \u0644\u0644\u0628\u064A\u0639 \u062D\u0633\u0628 \u0627\u0644\u062A\u0627\u0631\u064A\u062E.",
  "Import rate card": "\u0627\u0633\u062A\u064A\u0631\u0627\u062F \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0623\u0633\u0639\u0627\u0631",
  "Add product": "\u0623\u0636\u0641 \u0645\u0646\u062A\u062C\u064B\u0627",
  "On sale now": "\u0645\u0639\u0631\u0648\u0636 \u0644\u0644\u0628\u064A\u0639 \u0627\u0644\u0622\u0646",
  "Open slots": "\u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u0645\u062A\u0627\u062D\u0629",
  "Open slots at starting price": "\u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u0645\u062A\u0627\u062D\u0629 \u0628\u0633\u0639\u0631 \u0627\u0644\u0628\u062F\u0627\u064A\u0629",
  "Media type": "\u0646\u0648\u0639 \u0627\u0644\u0648\u0633\u064A\u0644\u0629",
  "All ({n})": "\u0627\u0644\u0643\u0644 ({n})",
  "Search products\u2026": "\u0627\u0628\u062D\u062B \u0641\u064A \u0627\u0644\u0645\u0646\u062A\u062C\u0627\u062A\u2026",
  "Search products": "\u0627\u0628\u062D\u062B \u0641\u064A \u0627\u0644\u0645\u0646\u062A\u062C\u0627\u062A",
  "Not archived": "\u063A\u064A\u0631 \u0645\u0624\u0631\u0634\u0641",
  "Nothing on sale": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u0639\u0631\u0648\u0636",
  "Sort: name": "\u0627\u0644\u062A\u0631\u062A\u064A\u0628: \u0627\u0644\u0627\u0633\u0645",
  "Sort: price": "\u0627\u0644\u062A\u0631\u062A\u064A\u0628: \u0627\u0644\u0633\u0639\u0631",
  "Sort: most open slots": "\u0627\u0644\u062A\u0631\u062A\u064A\u0628: \u0627\u0644\u0623\u0643\u062B\u0631 \u0645\u0633\u0627\u062D\u0627\u062A \u0645\u062A\u0627\u062D\u0629",
  "No products match.": "\u0644\u0627 \u0645\u0646\u062A\u062C\u0627\u062A \u0645\u0637\u0627\u0628\u0642\u0629.",
  "No products yet.": "\u0644\u0627 \u0645\u0646\u062A\u062C\u0627\u062A \u0628\u0639\u062F.",
  "Add a product once, with its audience, pricing and timing; then put it on sale from the calendar.": "\u0623\u0636\u0641 \u0627\u0644\u0645\u0646\u062A\u062C \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \u0628\u062C\u0645\u0647\u0648\u0631\u0647 \u0648\u0623\u0633\u0639\u0627\u0631\u0647 \u0648\u062A\u0648\u0642\u064A\u062A\u0647\u060C \u062B\u0645 \u0627\u0637\u0631\u062D\u0647 \u0644\u0644\u0628\u064A\u0639 \u0645\u0646 \u0627\u0644\u062A\u0642\u0648\u064A\u0645.",
  "Close {name}": "\u0623\u063A\u0644\u0642 {name}",
  "Open {name}": "\u0627\u0641\u062A\u062D {name}",
  "Min. accepted: {price}": "\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u062F\u0646\u0649 \u0627\u0644\u0645\u0642\u0628\u0648\u0644: {price}",
  "See {name} on the calendar": "\u0627\u0639\u0631\u0636 {name} \u0641\u064A \u0627\u0644\u062A\u0642\u0648\u064A\u0645",
  "More for {name}": "\u0627\u0644\u0645\u0632\u064A\u062F \u0644\u0640 {name}",
  "Details": "\u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644",
  "Audience": "\u0627\u0644\u062C\u0645\u0647\u0648\u0631",
  "Sectors": "\u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A",
  "Requirements": "\u0627\u0644\u0645\u062A\u0637\u0644\u0628\u0627\u062A",
  "Timing": "\u0627\u0644\u062A\u0648\u0642\u064A\u062A",
  "On sale": "\u0645\u0639\u0631\u0648\u0636 \u0644\u0644\u0628\u064A\u0639",
  "Bidding closes": "\u064A\u064F\u063A\u0644\u0642 \u0627\u0644\u0645\u0632\u0627\u062F",
  "{n} open": "{n} \u0645\u062A\u0627\u062D\u0629",
  "Sectors you accept (tick any number; none ticked means every sector)": "\u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u0642\u0628\u0644\u0647\u0627 (\u0627\u062E\u062A\u0631 \u0623\u064A \u0639\u062F\u062F\u061B \u0625\u0646 \u0644\u0645 \u062A\u062E\u062A\u0631 \u0634\u064A\u0626\u064B\u0627 \u0641\u0643\u0644 \u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A \u0645\u0642\u0628\u0648\u0644\u0629)",
  "Sectors you accept": "\u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u0642\u0628\u0644\u0647\u0627",
  "{n} new slots on sale from {date}.": "{n} \u0645\u0648\u0627\u0639\u064A\u062F \u062C\u062F\u064A\u062F\u0629 \u0645\u0639\u0631\u0648\u0636\u0629 \u0644\u0644\u0628\u064A\u0639 \u0645\u0646 {date}.",
  "These dates were already on sale.": "\u0647\u0630\u0647 \u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0645\u0639\u0631\u0648\u0636\u0629 \u0644\u0644\u0628\u064A\u0639 \u0628\u0627\u0644\u0641\u0639\u0644.",
  "Price updated on {n} slots.": "\u062D\u064F\u062F\u0651\u062B \u0627\u0644\u0633\u0639\u0631 \u0641\u064A {n} \u0645\u0648\u0627\u0639\u064A\u062F.",
  "Add a product first; then put it on sale here.": "\u0623\u0636\u0641 \u0645\u0646\u062A\u062C\u064B\u0627 \u0623\u0648\u0644\u064B\u0627\u060C \u062B\u0645 \u0627\u0639\u0631\u0636\u0647 \u0644\u0644\u0628\u064A\u0639 \u0647\u0646\u0627.",
  "Add to calendar": "\u0623\u0636\u0641 \u0625\u0644\u0649 \u0627\u0644\u062A\u0642\u0648\u064A\u0645",
  "For": "\u0627\u0644\u0645\u062F\u0629",
  "One day": "\u064A\u0648\u0645 \u0648\u0627\u062D\u062F",
  "One week": "\u0623\u0633\u0628\u0648\u0639 \u0648\u0627\u062D\u062F",
  "Two weeks": "\u0623\u0633\u0628\u0648\u0639\u0627\u0646",
  "Four weeks": "\u0623\u0631\u0628\u0639\u0629 \u0623\u0633\u0627\u0628\u064A\u0639",
  "Starting bid (AED)": "\u0627\u0644\u0639\u0631\u0636 \u0627\u0644\u0627\u0641\u062A\u062A\u0627\u062D\u064A (\u062F\u0631\u0647\u0645)",
  "Price (AED)": "\u0627\u0644\u0633\u0639\u0631 (\u062F\u0631\u0647\u0645)",
  "The product's days and times decide which slots appear. The price is the product's own; change it here for these dates only.": "\u0623\u064A\u0627\u0645 \u0627\u0644\u0645\u0646\u062A\u062C \u0648\u0623\u0648\u0642\u0627\u062A\u0647 \u062A\u062D\u062F\u062F \u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F \u0627\u0644\u062A\u064A \u062A\u0638\u0647\u0631. \u0627\u0644\u0633\u0639\u0631 \u0647\u0648 \u0633\u0639\u0631 \u0627\u0644\u0645\u0646\u062A\u062C\u061B \u063A\u064A\u0651\u0631\u0647 \u0647\u0646\u0627 \u0644\u0647\u0630\u0647 \u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0641\u0642\u0637.",
  "Put on sale": "\u0627\u0639\u0631\u0636 \u0644\u0644\u0628\u064A\u0639",
  "Publisher offered another price": "\u0639\u0631\u0636 \u0627\u0644\u0646\u0627\u0634\u0631 \u0633\u0639\u0631\u064B\u0627 \u0622\u062E\u0631",
  "You agreed to the new price": "\u0648\u0627\u0641\u0642\u062A \u0639\u0644\u0649 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u062C\u062F\u064A\u062F",
  "You kept your offer": "\u0623\u0628\u0642\u064A\u062A \u0639\u0644\u0649 \u0639\u0631\u0636\u0643",
  "You offered another price": "\u0639\u0631\u0636\u062A \u0633\u0639\u0631\u064B\u0627 \u0622\u062E\u0631",
  "The buyer agreed to your price": "\u0648\u0627\u0641\u0642 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0639\u0644\u0649 \u0633\u0639\u0631\u0643",
  "The buyer kept their offer": "\u0623\u0628\u0642\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0639\u0644\u0649 \u0639\u0631\u0636\u0647",
  "The publisher offered {amount} instead of {was}.": "\u0639\u0631\u0636 \u0627\u0644\u0646\u0627\u0634\u0631 {amount} \u0628\u062F\u0644\u064B\u0627 \u0645\u0646 {was}.",
  "Agree and the booking is accepted at that price; you pay next. Keep your offer and the publisher decides on it.": "\u0625\u0646 \u0648\u0627\u0641\u0642\u062A \u064A\u064F\u0642\u0628\u0644 \u0627\u0644\u062D\u062C\u0632 \u0628\u0647\u0630\u0627 \u0627\u0644\u0633\u0639\u0631 \u0648\u062A\u062F\u0641\u0639 \u0628\u0639\u062F\u0647\u0627. \u0648\u0625\u0646 \u0623\u0628\u0642\u064A\u062A \u0639\u0644\u0649 \u0639\u0631\u0636\u0643 \u064A\u0642\u0631\u0631 \u0627\u0644\u0646\u0627\u0634\u0631 \u0628\u0634\u0623\u0646\u0647.",
  "Agreed. The booking is accepted.": "\u062A\u0645\u062A \u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629. \u0642\u064F\u0628\u0644 \u0627\u0644\u062D\u062C\u0632.",
  "Agree to {amount}": "\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 {amount}",
  "You kept your offer.": "\u0623\u0628\u0642\u064A\u062A \u0639\u0644\u0649 \u0639\u0631\u0636\u0643.",
  "Keep my offer": "\u0623\u0628\u0642\u0650 \u0639\u0644\u0649 \u0639\u0631\u0636\u064A",
  "The publisher offered {slot} at {amount} instead of {was}. Agree to book it, or keep your offer.": "\u0639\u0631\u0636 \u0627\u0644\u0646\u0627\u0634\u0631 {slot} \u0628\u0633\u0639\u0631 {amount} \u0628\u062F\u0644\u064B\u0627 \u0645\u0646 {was}. \u0648\u0627\u0641\u0642 \u0644\u062A\u062D\u062C\u0632\u0647\u060C \u0623\u0648 \u0623\u0628\u0642\u0650 \u0639\u0644\u0649 \u0639\u0631\u0636\u0643.",
  "The buyer agreed to your price of {amount}. The booking is accepted; they pay next.": "\u0648\u0627\u0641\u0642 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0639\u0644\u0649 \u0633\u0639\u0631\u0643 {amount}. \u0642\u064F\u0628\u0644 \u0627\u0644\u062D\u062C\u0632\u060C \u0648\u0633\u064A\u062F\u0641\u0639 \u0628\u0639\u062F\u0647\u0627.",
  "The buyer kept their offer of {was} instead of {amount}. Accept or decline it.": "\u0623\u0628\u0642\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0639\u0644\u0649 \u0639\u0631\u0636\u0647 {was} \u0628\u062F\u0644\u064B\u0627 \u0645\u0646 {amount}. \u0627\u0642\u0628\u0644\u0647 \u0623\u0648 \u0627\u0631\u0641\u0636\u0647.",
  "You offered {amount}. Waiting for the buyer to agree or keep their offer of {was}.": "\u0639\u0631\u0636\u062A {amount}. \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0623\u0646 \u064A\u0648\u0627\u0641\u0642 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0623\u0648 \u064A\u0628\u0642\u064A \u0639\u0644\u0649 \u0639\u0631\u0636\u0647 {was}.",
  "You can still accept their offer, decline, or offer another price.": "\u0645\u0627 \u0632\u0627\u0644 \u0628\u0625\u0645\u0643\u0627\u0646\u0643 \u0642\u0628\u0648\u0644 \u0639\u0631\u0636\u0647 \u0623\u0648 \u0631\u0641\u0636\u0647 \u0623\u0648 \u0639\u0631\u0636 \u0633\u0639\u0631 \u0622\u062E\u0631.",
  "Accept {amount}": "\u0627\u0642\u0628\u0644 {amount}",
  "Counter offer": "\u0639\u0631\u0636 \u0645\u0642\u0627\u0628\u0644",
  "Your price (AED, excl. VAT)": "\u0633\u0639\u0631\u0643 (\u062F\u0631\u0647\u0645\u060C \u062F\u0648\u0646 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629)",
  "Note to the buyer (optional)": "\u0645\u0644\u0627\u062D\u0638\u0629 \u0644\u0644\u0645\u0634\u062A\u0631\u064A (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "The buyer agrees and the booking is accepted at this price, or keeps their offer for you to decide. The request keeps its deadline.": "\u0625\u0645\u0627 \u0623\u0646 \u064A\u0648\u0627\u0641\u0642 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0641\u064A\u064F\u0642\u0628\u0644 \u0627\u0644\u062D\u062C\u0632 \u0628\u0647\u0630\u0627 \u0627\u0644\u0633\u0639\u0631\u060C \u0623\u0648 \u064A\u0628\u0642\u064A \u0639\u0644\u0649 \u0639\u0631\u0636\u0647 \u0644\u062A\u0642\u0631\u0631 \u0623\u0646\u062A. \u064A\u0628\u0642\u0649 \u0645\u0648\u0639\u062F \u0627\u0644\u0637\u0644\u0628 \u0643\u0645\u0627 \u0647\u0648.",
  "Counter offer sent to the buyer.": "\u0623\u064F\u0631\u0633\u0644 \u0627\u0644\u0639\u0631\u0636 \u0627\u0644\u0645\u0642\u0627\u0628\u0644 \u0625\u0644\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u064A.",
  "Send counter offer": "\u0623\u0631\u0633\u0644 \u0627\u0644\u0639\u0631\u0636 \u0627\u0644\u0645\u0642\u0627\u0628\u0644",
  "Bookings and tasks waiting on you, soonest deadline first.": "\u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0648\u0627\u0644\u0645\u0647\u0627\u0645 \u0627\u0644\u062A\u064A \u062A\u0646\u062A\u0638\u0631\u0643\u060C \u0627\u0644\u0623\u0642\u0631\u0628 \u0645\u0648\u0639\u062F\u064B\u0627 \u0623\u0648\u0644\u064B\u0627.",
  "Counter sent": "\u0623\u064F\u0631\u0633\u0644 \u0639\u0631\u0636 \u0645\u0642\u0627\u0628\u0644",
  "Choose a request to see it here.": "\u0627\u062E\u062A\u0631 \u0637\u0644\u0628\u064B\u0627 \u0644\u062A\u0631\u0627\u0647 \u0647\u0646\u0627.",
  "Back to the list": "\u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u0627\u0644\u0642\u0627\u0626\u0645\u0629",
  "Open the booking": "\u0627\u0641\u062A\u062D \u0627\u0644\u062D\u062C\u0632",
  "To decide": "\u0644\u0644\u0628\u062A",
  "Proof and issues": "\u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0648\u0627\u0644\u0645\u0634\u0643\u0644\u0627\u062A",
  "Invoices": "\u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631",
  "Show": "\u0627\u0639\u0631\u0636",
  "Go to products": "\u0627\u0630\u0647\u0628 \u0625\u0644\u0649 \u0627\u0644\u0645\u0646\u062A\u062C\u0627\u062A",
  "Media moves differently here.": "\u0627\u0644\u0625\u0639\u0644\u0627\u0645 \u064A\u062A\u062D\u0631\u0643 \u0647\u0646\u0627 \u0628\u0637\u0631\u064A\u0642\u0629 \u0645\u062E\u062A\u0644\u0641\u0629.",
  "Buy and sell premium media across the UAE in one marketplace: websites, newspapers, magazines, newsletters, radio, TV, podcasts and social. The money is held until the ad has run.": "\u0627\u0634\u062A\u0631\u0650 \u0648\u0628\u0650\u0639 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0627\u0644\u0645\u0645\u064A\u0632\u0629 \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A \u0645\u0646 \u0633\u0648\u0642 \u0648\u0627\u062D\u062F: \u0627\u0644\u0645\u0648\u0627\u0642\u0639 \u0648\u0627\u0644\u0635\u062D\u0641 \u0648\u0627\u0644\u0645\u062C\u0644\u0627\u062A \u0648\u0627\u0644\u0646\u0634\u0631\u0627\u062A \u0627\u0644\u0628\u0631\u064A\u062F\u064A\u0629 \u0648\u0627\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A \u0648\u0648\u0633\u0627\u0626\u0644 \u0627\u0644\u062A\u0648\u0627\u0635\u0644. \u064A\u0628\u0642\u0649 \u0627\u0644\u0645\u0628\u0644\u063A \u0645\u062D\u062C\u0648\u0632\u064B\u0627 \u062D\u062A\u0649 \u064A\u064F\u0639\u0631\u0636 \u0627\u0644\u0625\u0639\u0644\u0627\u0646.",
  "Get early access": "\u0627\u062D\u0635\u0644 \u0639\u0644\u0649 \u0648\u0635\u0648\u0644 \u0645\u0628\u0643\u0631",
  "Example booking": "\u0645\u062B\u0627\u0644 \u0639\u0644\u0649 \u062D\u062C\u0632",
  "Drive Home, Break 2 \xB7 17:15": "\u0628\u0631\u0646\u0627\u0645\u062C \u0627\u0644\u0639\u0648\u062F\u0629\u060C \u0627\u0644\u0641\u0627\u0635\u0644 2 \xB7 17:15",
  "Bid accepted": "\u0642\u064F\u0628\u0644 \u0627\u0644\u0639\u0631\u0636",
  "Winning bid": "\u0627\u0644\u0639\u0631\u0636 \u0627\u0644\u0641\u0627\u0626\u0632",
  "Where this booking is": "\u0645\u0631\u062D\u0644\u0629 \u0647\u0630\u0627 \u0627\u0644\u062D\u062C\u0632",
  "Paid, held": "\u0645\u062F\u0641\u0648\u0639 \u0648\u0645\u062D\u062C\u0648\u0632",
  "On air": "\u0639\u0644\u0649 \u0627\u0644\u0647\u0648\u0627\u0621",
  "The publisher is paid when you approve the as-run log.": "\u064A\u064F\u062F\u0641\u0639 \u0644\u0644\u0646\u0627\u0634\u0631 \u0639\u0646\u062F\u0645\u0627 \u062A\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u0633\u062C\u0644 \u0627\u0644\u0628\u062B.",
  "Your media co-pilot, launching soon": "\u0645\u0633\u0627\u0639\u062F\u0643 \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u060C \u0642\u0631\u064A\u0628\u064B\u0627",
  "Add each product once, then put dates on sale from your calendar at the price you choose.": "\u0623\u0636\u0641 \u0643\u0644 \u0645\u0646\u062A\u062C \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629\u060C \u062B\u0645 \u0627\u0639\u0631\u0636 \u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0644\u0644\u0628\u064A\u0639 \u0645\u0646 \u062A\u0642\u0648\u064A\u0645\u0643 \u0628\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0630\u064A \u062A\u062E\u062A\u0627\u0631\u0647.",
  "Accept, counter or decline each request with the buyer, the brief and what you receive in view.": "\u0627\u0642\u0628\u0644 \u0643\u0644 \u0637\u0644\u0628 \u0623\u0648 \u0642\u062F\u0651\u0645 \u0639\u0631\u0636\u064B\u0627 \u0645\u0642\u0627\u0628\u0644\u064B\u0627 \u0623\u0648 \u0627\u0631\u0641\u0636\u0647\u060C \u0648\u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0648\u0627\u0644\u0645\u0644\u062E\u0635 \u0648\u0645\u0627 \u0633\u062A\u062A\u0633\u0644\u0645\u0647 \u0623\u0645\u0627\u0645\u0643.",
  "Launching soon": "\u0642\u0631\u064A\u0628\u064B\u0627",
  "Meet Athena, your media co-pilot.": "\u062A\u0639\u0631\u0651\u0641 \u0639\u0644\u0649 \u0623\u062B\u064A\u0646\u0627\u060C \u0645\u0633\u0627\u0639\u062F\u0643 \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A.",
  "Ask in plain language and Athena suggests where your budget works hardest, compares outlets and drafts the plan for you to book.": "\u0627\u0633\u0623\u0644 \u0628\u0644\u063A\u0629 \u0628\u0633\u064A\u0637\u0629\u060C \u0648\u062A\u0642\u062A\u0631\u062D \u0623\u062B\u064A\u0646\u0627 \u0623\u064A\u0646 \u062A\u0639\u0645\u0644 \u0645\u064A\u0632\u0627\u0646\u064A\u062A\u0643 \u0628\u0623\u0641\u0636\u0644 \u0634\u0643\u0644\u060C \u0648\u062A\u0642\u0627\u0631\u0646 \u0627\u0644\u0645\u0646\u0627\u0641\u0630\u060C \u0648\u062A\u062C\u0647\u0651\u0632 \u0644\u0643 \u0627\u0644\u062E\u0637\u0629 \u0644\u062A\u062D\u062C\u0632\u0647\u0627.",
  "Join the waitlist": "\u0627\u0646\u0636\u0645 \u0625\u0644\u0649 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0627\u0646\u062A\u0638\u0627\u0631",
  "Athena preview": "\u0645\u0639\u0627\u064A\u0646\u0629 \u0623\u062B\u064A\u0646\u0627",
  "How should I spend AED 80,000 on a January launch for young professionals in Dubai?": "\u0643\u064A\u0641 \u0623\u0646\u0641\u0642 80,000 \u062F\u0631\u0647\u0645 \u0639\u0644\u0649 \u0625\u0637\u0644\u0627\u0642 \u0641\u064A \u064A\u0646\u0627\u064A\u0631 \u064A\u0633\u062A\u0647\u062F\u0641 \u0627\u0644\u0645\u0647\u0646\u064A\u064A\u0646 \u0627\u0644\u0634\u0628\u0627\u0628 \u0641\u064A \u062F\u0628\u064A\u061F",
  "Weekday drive-time radio and two business newsletters reach them best for that budget. I'd keep a fifth for a podcast read in week two.": "\u0625\u0630\u0627\u0639\u0629 \u0623\u0648\u0642\u0627\u062A \u0627\u0644\u0630\u0631\u0648\u0629 \u0641\u064A \u0623\u064A\u0627\u0645 \u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u0648\u0646\u0634\u0631\u062A\u0627\u0646 \u0628\u0631\u064A\u062F\u064A\u062A\u0627\u0646 \u0644\u0644\u0623\u0639\u0645\u0627\u0644 \u062A\u0635\u0644 \u0625\u0644\u064A\u0647\u0645 \u0628\u0623\u0641\u0636\u0644 \u0634\u0643\u0644 \u0628\u0647\u0630\u0647 \u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629. \u0623\u0646\u0635\u062D \u0628\u0625\u0628\u0642\u0627\u0621 \u0627\u0644\u062E\u064F\u0645\u0633 \u0644\u0625\u0639\u0644\u0627\u0646 \u0641\u064A \u0628\u0648\u062F\u0643\u0627\u0633\u062A \u0641\u064A \u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u0627\u0644\u062B\u0627\u0646\u064A.",
  "Show me the plan": "\u0627\u0639\u0631\u0636 \u0627\u0644\u062E\u0637\u0629",
  "Compare outlets": "\u0642\u0627\u0631\u0646 \u0627\u0644\u0645\u0646\u0627\u0641\u0630",
  "Anything else? Ask us from the help page once you're in.": "\u0644\u062F\u064A\u0643 \u0633\u0624\u0627\u0644 \u0622\u062E\u0631\u061F \u0627\u0633\u0623\u0644\u0646\u0627 \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0633\u0627\u0639\u062F\u0629 \u0628\u0639\u062F \u0627\u0644\u062F\u062E\u0648\u0644.",
  "booked through Nashr": "\u062D\u064F\u062C\u0632\u062A \u0639\u0628\u0631 \u0646\u0634\u0631",
  "Held until each ad ran.": "\u0645\u062D\u062C\u0648\u0632\u0629 \u062D\u062A\u0649 \u0639\u064F\u0631\u0636 \u0643\u0644 \u0625\u0639\u0644\u0627\u0646.",
  "slots open to book": "\u0645\u0648\u0639\u062F\u064B\u0627 \u0645\u062A\u0627\u062D\u064B\u0627 \u0644\u0644\u062D\u062C\u0632",
  "In the next 30 days, with prices to read.": "\u062E\u0644\u0627\u0644 \u0627\u0644\u062B\u0644\u0627\u062B\u064A\u0646 \u064A\u0648\u0645\u064B\u0627 \u0627\u0644\u0642\u0627\u062F\u0645\u0629\u060C \u0628\u0623\u0633\u0639\u0627\u0631 \u0648\u0627\u0636\u062D\u0629.",
  "Newspapers, broadcasters and digital-first brands.": "\u0635\u062D\u0641 \u0648\u0642\u0646\u0648\u0627\u062A \u0628\u062B \u0648\u0639\u0644\u0627\u0645\u0627\u062A \u0631\u0642\u0645\u064A\u0629.",
  "bookings completed": "\u062D\u062C\u0632\u064B\u0627 \u0645\u0643\u062A\u0645\u0644\u064B\u0627",
  "Each one paid only after proof.": "\u0643\u0644 \u0645\u0646\u0647\u0627 \u062F\u064F\u0641\u0639 \u0628\u0639\u062F \u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0641\u0642\u0637.",
  "Every format": "\u0643\u0644 \u0627\u0644\u0623\u0634\u0643\u0627\u0644",
  "Bought and sold in one place.": "\u062A\u064F\u0634\u062A\u0631\u0649 \u0648\u062A\u064F\u0628\u0627\u0639 \u0641\u064A \u0645\u0643\u0627\u0646 \u0648\u0627\u062D\u062F.",
  "from {amount}": "\u0645\u0646 {amount}",
  "Outlets you can book today": "\u0645\u0646\u0627\u0641\u0630 \u064A\u0645\u0643\u0646\u0643 \u062D\u062C\u0632\u0647\u0627 \u0627\u0644\u064A\u0648\u0645",
  "Radio and TV stations, newspapers, magazines and digital brands across the UAE. Prices are indicative until each publisher confirms its rate card.": "\u0645\u062D\u0637\u0627\u062A \u0625\u0630\u0627\u0639\u0629 \u0648\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0635\u062D\u0641 \u0648\u0645\u062C\u0644\u0627\u062A \u0648\u0639\u0644\u0627\u0645\u0627\u062A \u0631\u0642\u0645\u064A\u0629 \u0641\u064A \u0623\u0646\u062D\u0627\u0621 \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A. \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u062A\u0642\u062F\u064A\u0631\u064A\u0629 \u062D\u062A\u0649 \u064A\u0624\u0643\u062F \u0643\u0644 \u0646\u0627\u0634\u0631 \u0642\u0627\u0626\u0645\u0629 \u0623\u0633\u0639\u0627\u0631\u0647.",
  "Browse the directory": "\u062A\u0635\u0641\u062D \u0627\u0644\u062F\u0644\u064A\u0644",
  "Open for bids": "\u0645\u0641\u062A\u0648\u062D \u0644\u0644\u0645\u0632\u0627\u064A\u062F\u0629",
  "Bidding ({n})": "\u0645\u0632\u0627\u064A\u062F\u0629 ({n})",
  "Bids ({n})": "\u0627\u0644\u0639\u0631\u0648\u0636 ({n})",
  "Assets ({n})": "\u0627\u0644\u0645\u0644\u0641\u0627\u062A ({n})",
  "Assets": "\u0627\u0644\u0645\u0644\u0641\u0627\u062A",
  "Sale closes": "\u064A\u0646\u062A\u0647\u064A \u0627\u0644\u0628\u064A\u0639",
  "No bids yet. Buyers see this slot on the calendar now.": "\u0644\u0627 \u0639\u0631\u0648\u0636 \u0628\u0639\u062F. \u064A\u0631\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0639\u062F \u0641\u064A \u0627\u0644\u062A\u0642\u0648\u064A\u0645 \u0627\u0644\u0622\u0646.",
  "Open the request to accept, counter or decline": "\u0627\u0641\u062A\u062D \u0627\u0644\u0637\u0644\u0628 \u0644\u062A\u0642\u0628\u0644\u0647 \u0623\u0648 \u062A\u0642\u062F\u0651\u0645 \u0639\u0631\u0636\u064B\u0627 \u0645\u0642\u0627\u0628\u0644\u064B\u0627 \u0623\u0648 \u062A\u0631\u0641\u0636\u0647",
  "Creative and proof appear here once a buyer books this slot.": "\u062A\u0638\u0647\u0631 \u0627\u0644\u0645\u0648\u0627\u062F \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0648\u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0647\u0646\u0627 \u0628\u0639\u062F \u0623\u0646 \u064A\u062D\u062C\u0632 \u0645\u0634\u062A\u0631\u064D \u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0639\u062F.",
  "No creative yet.": "\u0644\u0627 \u0645\u0648\u0627\u062F \u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0628\u0639\u062F.",
  "Pending": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0642\u0631\u0627\u0631",
  "Bids": "\u0627\u0644\u0639\u0631\u0648\u0636",
  "Airs": "\u064A\u064F\u0639\u0631\u0636",
  "Proof": "\u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "Proof sent": "\u0623\u064F\u0631\u0633\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "Creative": "\u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Changes asked": "\u0637\u064F\u0644\u0628\u062A \u062A\u0639\u062F\u064A\u0644\u0627\u062A",
  "Technical fix asked": "\u0637\u064F\u0644\u0628 \u0625\u0635\u0644\u0627\u062D \u0641\u0646\u064A",
  "Waiting for your review": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0645\u0631\u0627\u062C\u0639\u062A\u0643",
  "Approved": "\u0645\u0639\u062A\u0645\u062F",
  "Rejected": "\u0645\u0631\u0641\u0648\u0636",
  "Booked": "\u0645\u062D\u062C\u0648\u0632",
  "Add {product} on {day}": "\u0623\u0636\u0641 {product} \u0641\u064A {day}",
  "Coverage": "\u0627\u0644\u062A\u063A\u0637\u064A\u0629",
  "Coverage review": "\u0645\u0631\u0627\u062C\u0639\u0629 \u0627\u0644\u062A\u063A\u0637\u064A\u0629",
  "Programmes and coverage that publishers want to sell. Approve and it goes on sale on its dates.": "\u0628\u0631\u0627\u0645\u062C \u0648\u062A\u063A\u0637\u064A\u0627\u062A \u064A\u0631\u064A\u062F \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0628\u064A\u0639\u0647\u0627. \u0648\u0627\u0641\u0642 \u0639\u0644\u064A\u0647\u0627 \u0644\u062A\u064F\u0639\u0631\u0636 \u0644\u0644\u0628\u064A\u0639 \u0641\u064A \u062A\u0648\u0627\u0631\u064A\u062E\u0647\u0627.",
  "Nothing waiting for review.": "\u0644\u0627 \u0634\u064A\u0621 \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629.",
  "Total price": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0625\u062C\u0645\u0627\u0644\u064A",
  "Submitted": "\u0623\u064F\u0631\u0633\u0644",
  "Note from Nashr: {note}": "\u0645\u0644\u0627\u062D\u0638\u0629 \u0645\u0646 \u0646\u0634\u0631: {note}",
  "On sale as a product.": "\u0645\u0639\u0631\u0648\u0636 \u0644\u0644\u0628\u064A\u0639 \u0643\u0645\u0646\u062A\u062C.",
  "See the calendar": "\u0627\u0639\u0631\u0636 \u0627\u0644\u062A\u0642\u0648\u064A\u0645",
  "Note to the publisher (needed to ask for changes or decline)": "\u0645\u0644\u0627\u062D\u0638\u0629 \u0644\u0644\u0646\u0627\u0634\u0631 (\u0645\u0637\u0644\u0648\u0628\u0629 \u0644\u0637\u0644\u0628 \u062A\u0639\u062F\u064A\u0644\u0627\u062A \u0623\u0648 \u0644\u0644\u0631\u0641\u0636)",
  "Approved. It is on sale on its dates.": "\u062A\u0645\u062A \u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629. \u0623\u0635\u0628\u062D \u0645\u0639\u0631\u0648\u0636\u064B\u0627 \u0644\u0644\u0628\u064A\u0639 \u0641\u064A \u062A\u0648\u0627\u0631\u064A\u062E\u0647.",
  "Approve and put on sale": "\u0648\u0627\u0641\u0642 \u0648\u0627\u0639\u0631\u0636\u0647 \u0644\u0644\u0628\u064A\u0639",
  "Sent back for changes.": "\u0623\u064F\u0639\u064A\u062F \u0644\u0625\u062C\u0631\u0627\u0621 \u062A\u0639\u062F\u064A\u0644\u0627\u062A.",
  "Ask for changes": "\u0627\u0637\u0644\u0628 \u062A\u0639\u062F\u064A\u0644\u0627\u062A",
  "Approving makes it a product at the total price, with one slot on each coverage date that is still far enough ahead to sell.": "\u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 \u062A\u062C\u0639\u0644\u0647 \u0645\u0646\u062A\u062C\u064B\u0627 \u0628\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0625\u062C\u0645\u0627\u0644\u064A\u060C \u0645\u0639 \u0645\u0648\u0639\u062F \u0648\u0627\u062D\u062F \u0641\u064A \u0643\u0644 \u062A\u0627\u0631\u064A\u062E \u062A\u063A\u0637\u064A\u0629 \u0645\u0627 \u0632\u0627\u0644 \u0628\u0639\u064A\u062F\u064B\u0627 \u0628\u0645\u0627 \u064A\u0643\u0641\u064A \u0644\u0628\u064A\u0639\u0647.",
  "{company} sent coverage for review: {name}.": "\u0623\u0631\u0633\u0644\u062A {company} \u062A\u063A\u0637\u064A\u0629 \u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629: {name}.",
  "Nashr approved {name}. It is on sale on its dates.": "\u0648\u0627\u0641\u0642\u062A \u0646\u0634\u0631 \u0639\u0644\u0649 {name}. \u0623\u0635\u0628\u062D \u0645\u0639\u0631\u0648\u0636\u064B\u0627 \u0644\u0644\u0628\u064A\u0639 \u0641\u064A \u062A\u0648\u0627\u0631\u064A\u062E\u0647.",
  "Nashr approved {name}. It goes on sale once your payout account is verified.": "\u0648\u0627\u0641\u0642\u062A \u0646\u0634\u0631 \u0639\u0644\u0649 {name}. \u0633\u064A\u064F\u0639\u0631\u0636 \u0644\u0644\u0628\u064A\u0639 \u0628\u0639\u062F \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0633\u0627\u0628 \u0627\u0644\u062F\u0641\u0639\u0627\u062A \u0644\u062F\u064A\u0643.",
  "Nashr asked for changes to {name}: {note}": "\u0637\u0644\u0628\u062A \u0646\u0634\u0631 \u062A\u0639\u062F\u064A\u0644\u0627\u062A \u0639\u0644\u0649 {name}: {note}",
  "Nashr declined {name}: {note}": "\u0631\u0641\u0636\u062A \u0646\u0634\u0631 {name}: {note}",
  "Media coverage": "\u0627\u0644\u062A\u063A\u0637\u064A\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u0629",
  "Offer a programme, show or coverage opportunity. Nashr reviews it, then it goes on sale on its dates.": "\u0627\u0639\u0631\u0636 \u0628\u0631\u0646\u0627\u0645\u062C\u064B\u0627 \u0623\u0648 \u0639\u0631\u0636\u064B\u0627 \u0623\u0648 \u0641\u0631\u0635\u0629 \u062A\u063A\u0637\u064A\u0629. \u062A\u0631\u0627\u062C\u0639\u0647 \u0646\u0634\u0631\u060C \u062B\u0645 \u064A\u064F\u0639\u0631\u0636 \u0644\u0644\u0628\u064A\u0639 \u0641\u064A \u062A\u0648\u0627\u0631\u064A\u062E\u0647.",
  "New coverage submission": "\u0637\u0644\u0628 \u062A\u063A\u0637\u064A\u0629 \u062C\u062F\u064A\u062F",
  "No coverage submissions yet.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0637\u0644\u0628\u0627\u062A \u062A\u063A\u0637\u064A\u0629 \u0628\u0639\u062F.",
  "Sponsored interviews, event coverage, feature segments: describe it once and Nashr puts it in front of buyers.": "\u0645\u0642\u0627\u0628\u0644\u0627\u062A \u0628\u0631\u0639\u0627\u064A\u0629\u060C \u062A\u063A\u0637\u064A\u0629 \u0641\u0639\u0627\u0644\u064A\u0627\u062A\u060C \u0641\u0642\u0631\u0627\u062A \u062E\u0627\u0635\u0629: \u0635\u0650\u0641\u0647\u0627 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \u0648\u062A\u0639\u0631\u0636\u0647\u0627 \u0646\u0634\u0631 \u0639\u0644\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646.",
  "Untitled": "\u0628\u0644\u0627 \u0639\u0646\u0648\u0627\u0646",
  "Fix the {n} highlighted fields, then submit.": "\u0635\u062D\u0651\u062D \u0627\u0644\u062D\u0642\u0648\u0644 \u0627\u0644\u0645\u062D\u062F\u062F\u0629 ({n})\u060C \u062B\u0645 \u0623\u0631\u0633\u0644.",
  "Choose one of your outlets.": "\u0627\u062E\u062A\u0631 \u0623\u062D\u062F \u0645\u0646\u0627\u0641\u0630\u0643.",
  "Submitted. Nashr reviews it and tells you here and by email.": "\u0623\u064F\u0631\u0633\u0644. \u062A\u0631\u0627\u062C\u0639\u0647 \u0646\u0634\u0631 \u0648\u062A\u0628\u0644\u063A\u0643 \u0647\u0646\u0627 \u0648\u0628\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A.",
  "Draft saved.": "\u062D\u064F\u0641\u0638\u062A \u0627\u0644\u0645\u0633\u0648\u062F\u0629.",
  "Media coverage submission": "\u0637\u0644\u0628 \u062A\u063A\u0637\u064A\u0629 \u0625\u0639\u0644\u0627\u0645\u064A\u0629",
  "Add a programme, show or coverage opportunity for {outlet}.": "\u0623\u0636\u0641 \u0628\u0631\u0646\u0627\u0645\u062C\u064B\u0627 \u0623\u0648 \u0639\u0631\u0636\u064B\u0627 \u0623\u0648 \u0641\u0631\u0635\u0629 \u062A\u063A\u0637\u064A\u0629 \u0644\u0640 {outlet}.",
  "Add a programme, show or coverage opportunity.": "\u0623\u0636\u0641 \u0628\u0631\u0646\u0627\u0645\u062C\u064B\u0627 \u0623\u0648 \u0639\u0631\u0636\u064B\u0627 \u0623\u0648 \u0641\u0631\u0635\u0629 \u062A\u063A\u0637\u064A\u0629.",
  "Where this submission is": "\u0645\u0631\u062D\u0644\u0629 \u0647\u0630\u0627 \u0627\u0644\u0637\u0644\u0628",
  "Draft": "\u0645\u0633\u0648\u062F\u0629",
  "With Nashr for review": "\u0644\u062F\u0649 \u0646\u0634\u0631 \u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629",
  "Approved, on sale": "\u0645\u0639\u062A\u0645\u062F \u0648\u0645\u0639\u0631\u0648\u0636 \u0644\u0644\u0628\u064A\u0639",
  "It is on sale as a product.": "\u0623\u0635\u0628\u062D \u0645\u0639\u0631\u0648\u0636\u064B\u0627 \u0644\u0644\u0628\u064A\u0639 \u0643\u0645\u0646\u062A\u062C.",
  "Open the product": "\u0627\u0641\u062A\u062D \u0627\u0644\u0645\u0646\u062A\u062C",
  "Programme or show name": "\u0627\u0633\u0645 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C \u0623\u0648 \u0627\u0644\u0639\u0631\u0636",
  "Market Close": "\u062E\u062A\u0627\u0645 \u0627\u0644\u0633\u0648\u0642",
  "Episode or edition": "\u0627\u0644\u062D\u0644\u0642\u0629 \u0623\u0648 \u0627\u0644\u0639\u062F\u062F",
  "Duration (min)": "\u0627\u0644\u0645\u062F\u0629 (\u062F\u0642\u064A\u0642\u0629)",
  "Frequency": "\u0627\u0644\u062A\u0643\u0631\u0627\u0631",
  "Coverage details": "\u062A\u0641\u0627\u0635\u064A\u0644 \u0627\u0644\u062A\u063A\u0637\u064A\u0629",
  "Coverage dates": "\u062A\u0648\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u063A\u0637\u064A\u0629",
  "Add a date": "\u0623\u0636\u0641 \u062A\u0627\u0631\u064A\u062E\u064B\u0627",
  "Add date": "\u0623\u0636\u0641 \u0627\u0644\u062A\u0627\u0631\u064A\u062E",
  "Remove {date}": "\u0627\u062D\u0630\u0641 {date}",
  "Time (UAE)": "\u0627\u0644\u0648\u0642\u062A (\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A)",
  "Venue or location": "\u0627\u0644\u0645\u0643\u0627\u0646",
  "Dubai studio": "\u0627\u0633\u062A\u0648\u062F\u064A\u0648 \u062F\u0628\u064A",
  "Coverage type": "\u0646\u0648\u0639 \u0627\u0644\u062A\u063A\u0637\u064A\u0629",
  "Editorial angle and description": "\u0627\u0644\u0632\u0627\u0648\u064A\u0629 \u0627\u0644\u062A\u062D\u0631\u064A\u0631\u064A\u0629 \u0648\u0627\u0644\u0648\u0635\u0641",
  "Editorial angle or key message": "\u0627\u0644\u0632\u0627\u0648\u064A\u0629 \u0627\u0644\u062A\u062D\u0631\u064A\u0631\u064A\u0629 \u0623\u0648 \u0627\u0644\u0631\u0633\u0627\u0644\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629",
  "UAE economic outlook and private sector growth.": "\u0622\u0641\u0627\u0642 \u0627\u0642\u062A\u0635\u0627\u062F \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A \u0648\u0646\u0645\u0648 \u0627\u0644\u0642\u0637\u0627\u0639 \u0627\u0644\u062E\u0627\u0635.",
  "Full description": "\u0627\u0644\u0648\u0635\u0641 \u0627\u0644\u0643\u0627\u0645\u0644",
  "Audience and reach": "\u0627\u0644\u062C\u0645\u0647\u0648\u0631 \u0648\u0627\u0644\u0648\u0635\u0648\u0644",
  "Estimated reach": "\u0627\u0644\u0648\u0635\u0648\u0644 \u0627\u0644\u0645\u062A\u0648\u0642\u0639",
  "Average viewers, listeners or readers per airing or edition.": "\u0645\u062A\u0648\u0633\u0637 \u0627\u0644\u0645\u0634\u0627\u0647\u062F\u064A\u0646 \u0623\u0648 \u0627\u0644\u0645\u0633\u062A\u0645\u0639\u064A\u0646 \u0623\u0648 \u0627\u0644\u0642\u0631\u0627\u0621 \u0644\u0643\u0644 \u0628\u062B \u0623\u0648 \u0639\u062F\u062F.",
  "Audience profile": "\u0645\u0644\u0641 \u0627\u0644\u062C\u0645\u0647\u0648\u0631",
  "Business professionals": "\u0645\u0647\u0646\u064A\u0648 \u0627\u0644\u0623\u0639\u0645\u0627\u0644",
  "Markets": "\u0627\u0644\u0623\u0633\u0648\u0627\u0642",
  "Deliverables": "\u0627\u0644\u0645\u062E\u0631\u062C\u0627\u062A",
  "Other deliverable": "\u0645\u062E\u0631\u062C \u0622\u062E\u0631",
  "Platforms": "\u0627\u0644\u0645\u0646\u0635\u0627\u062A",
  "Where will this coverage appear?": "\u0623\u064A\u0646 \u0633\u062A\u0638\u0647\u0631 \u0647\u0630\u0647 \u0627\u0644\u062A\u063A\u0637\u064A\u0629\u061F",
  "Add social media coverage": "\u0623\u0636\u0641 \u062A\u063A\u0637\u064A\u0629 \u0639\u0644\u0649 \u0648\u0633\u0627\u0626\u0644 \u0627\u0644\u062A\u0648\u0627\u0635\u0644",
  "Extend it across Instagram, TikTok, X and YouTube. Each price is added to the total.": "\u0648\u0633\u0651\u0639\u0647\u0627 \u0639\u0644\u0649 \u0625\u0646\u0633\u062A\u063A\u0631\u0627\u0645 \u0648\u062A\u064A\u0643 \u062A\u0648\u0643 \u0648\u0625\u0643\u0633 \u0648\u064A\u0648\u062A\u064A\u0648\u0628. \u064A\u064F\u0636\u0627\u0641 \u0643\u0644 \u0633\u0639\u0631 \u0625\u0644\u0649 \u0627\u0644\u0625\u062C\u0645\u0627\u0644\u064A.",
  "{platform} (AED)": "{platform} (\u062F\u0631\u0647\u0645)",
  "Not offered": "\u063A\u064A\u0631 \u0645\u062A\u0627\u062D",
  "Pricing": "\u0627\u0644\u062A\u0633\u0639\u064A\u0631",
  "Base price (AED, excl. VAT)": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u0633\u0627\u0633\u064A (\u062F\u0631\u0647\u0645\u060C \u062F\u0648\u0646 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629)",
  "Sells as": "\u064A\u064F\u0628\u0627\u0639 \u0628\u0646\u0638\u0627\u0645",
  "Bidding": "\u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629",
  "Buyers bid up from the total price.": "\u064A\u0632\u0627\u064A\u062F \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0628\u062F\u0621\u064B\u0627 \u0645\u0646 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0625\u062C\u0645\u0627\u0644\u064A.",
  "The first buyer to book at the total price gets it, once you confirm.": "\u064A\u062D\u0635\u0644 \u0639\u0644\u064A\u0647 \u0623\u0648\u0644 \u0645\u0634\u062A\u0631\u064D \u064A\u062D\u062C\u0632 \u0628\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0625\u062C\u0645\u0627\u0644\u064A\u060C \u0628\u0639\u062F \u062A\u0623\u0643\u064A\u062F\u0643.",
  "Sponsorship type": "\u0646\u0648\u0639 \u0627\u0644\u0631\u0639\u0627\u064A\u0629",
  "Segment sponsorship": "\u0631\u0639\u0627\u064A\u0629 \u0641\u0642\u0631\u0629",
  "Total price, social included": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0625\u062C\u0645\u0627\u0644\u064A \u0634\u0627\u0645\u0644\u064B\u0627 \u0648\u0633\u0627\u0626\u0644 \u0627\u0644\u062A\u0648\u0627\u0635\u0644",
  "Attachments": "\u0627\u0644\u0645\u0631\u0641\u0642\u0627\u062A",
  "Drop files here, or choose them": "\u0623\u0641\u0644\u062A \u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0647\u0646\u0627 \u0623\u0648 \u0627\u062E\u062A\u0631\u0647\u0627",
  "Media kit, audience data, past coverage. PDF, PowerPoint, Word, JPG or PNG; up to 10 files.": "\u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u060C \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062C\u0645\u0647\u0648\u0631\u060C \u062A\u063A\u0637\u064A\u0627\u062A \u0633\u0627\u0628\u0642\u0629. PDF \u0623\u0648 PowerPoint \u0623\u0648 Word \u0623\u0648 JPG \u0623\u0648 PNG\u061B \u062D\u062A\u0649 10 \u0645\u0644\u0641\u0627\u062A.",
  "Internal notes": "\u0645\u0644\u0627\u062D\u0638\u0627\u062A \u062F\u0627\u062E\u0644\u064A\u0629",
  "Only Nashr\u2019s team sees these.": "\u0644\u0627 \u064A\u0631\u0627\u0647\u0627 \u0625\u0644\u0627 \u0641\u0631\u064A\u0642 \u0646\u0634\u0631.",
  "Fields marked * are needed to submit. Drafts can be saved any time.": "\u0627\u0644\u062D\u0642\u0648\u0644 \u0627\u0644\u0645\u0639\u0644\u0651\u0645\u0629 \u0628\u0640 * \u0645\u0637\u0644\u0648\u0628\u0629 \u0644\u0644\u0625\u0631\u0633\u0627\u0644. \u064A\u0645\u0643\u0646 \u062D\u0641\u0638 \u0627\u0644\u0645\u0633\u0648\u062F\u0629 \u0641\u064A \u0623\u064A \u0648\u0642\u062A.",
  "Save draft": "\u0627\u062D\u0641\u0638 \u0627\u0644\u0645\u0633\u0648\u062F\u0629",
  "Submit for approval": "\u0623\u0631\u0633\u0644 \u0644\u0644\u0645\u0648\u0627\u0641\u0642\u0629",
  "Duration": "\u0627\u0644\u0645\u062F\u0629",
  "Audience, deliverables and platforms": "\u0627\u0644\u062C\u0645\u0647\u0648\u0631 \u0648\u0627\u0644\u0645\u062E\u0631\u062C\u0627\u062A \u0648\u0627\u0644\u0645\u0646\u0635\u0627\u062A",
  "Social add-ons": "\u0625\u0636\u0627\u0641\u0627\u062A \u0648\u0633\u0627\u0626\u0644 \u0627\u0644\u062A\u0648\u0627\u0635\u0644",
  "Base price": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u0633\u0627\u0633\u064A",
  "Submitted {when}": "\u0623\u064F\u0631\u0633\u0644 {when}",
  "Declined": "\u0645\u0631\u0641\u0648\u0636",
  "Programme": "\u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C",
  "Publisher": "\u0627\u0644\u0646\u0627\u0634\u0631",
  "Dates": "\u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E",
  "Status": "\u0627\u0644\u062D\u0627\u0644\u0629",
  "Outlet": "\u0627\u0644\u0645\u0646\u0641\u0630",
  "Your decision": "\u0642\u0631\u0627\u0631\u0643",
  "Choose\u2026": "\u0627\u062E\u062A\u0631\u2026",
  "Name": "\u0627\u0644\u0627\u0633\u0645",
  "Type": "\u0627\u0644\u0646\u0648\u0639",
  "Language": "\u0627\u0644\u0644\u063A\u0629",
  "English": "\u0627\u0644\u0625\u0646\u062C\u0644\u064A\u0632\u064A\u0629",
  "Arabic": "\u0627\u0644\u0639\u0631\u0628\u064A\u0629",
  "English and Arabic": "\u0627\u0644\u0625\u0646\u062C\u0644\u064A\u0632\u064A\u0629 \u0648\u0627\u0644\u0639\u0631\u0628\u064A\u0629",
  "Remove": "\u0627\u062D\u0630\u0641",
  "Download": "\u062A\u0646\u0632\u064A\u0644",
  "TV show": "\u0628\u0631\u0646\u0627\u0645\u062C \u062A\u0644\u0641\u0632\u064A\u0648\u0646\u064A",
  "Radio show": "\u0628\u0631\u0646\u0627\u0645\u062C \u0625\u0630\u0627\u0639\u064A",
  "Podcast": "\u0628\u0648\u062F\u0643\u0627\u0633\u062A",
  "Website feature": "\u0645\u0627\u062F\u0629 \u0639\u0644\u0649 \u0627\u0644\u0645\u0648\u0642\u0639",
  "Newspaper feature": "\u0645\u0627\u062F\u0629 \u0641\u064A \u0635\u062D\u064A\u0641\u0629",
  "Magazine feature": "\u0645\u0627\u062F\u0629 \u0641\u064A \u0645\u062C\u0644\u0629",
  "Newsletter feature": "\u0645\u0627\u062F\u0629 \u0641\u064A \u0646\u0634\u0631\u0629 \u0628\u0631\u064A\u062F\u064A\u0629",
  "Event": "\u0641\u0639\u0627\u0644\u064A\u0629",
  "Social media series": "\u0633\u0644\u0633\u0644\u0629 \u0639\u0644\u0649 \u0648\u0633\u0627\u0626\u0644 \u0627\u0644\u062A\u0648\u0627\u0635\u0644",
  "Live": "\u0645\u0628\u0627\u0634\u0631",
  "Recorded": "\u0645\u0633\u062C\u0651\u0644",
  "In studio": "\u0641\u064A \u0627\u0644\u0627\u0633\u062A\u0648\u062F\u064A\u0648",
  "On the ground": "\u0645\u064A\u062F\u0627\u0646\u064A",
  "One-off": "\u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629",
  "Daily": "\u064A\u0648\u0645\u064A",
  "Weekly": "\u0623\u0633\u0628\u0648\u0639\u064A",
  "Monthly": "\u0634\u0647\u0631\u064A",
  "Editorial mention": "\u0625\u0634\u0627\u0631\u0629 \u062A\u062D\u0631\u064A\u0631\u064A\u0629",
  "Interview": "\u0645\u0642\u0627\u0628\u0644\u0629",
  "Segment or feature": "\u0641\u0642\u0631\u0629 \u0623\u0648 \u0645\u0627\u062F\u0629 \u062E\u0627\u0635\u0629",
  "Event coverage": "\u062A\u063A\u0637\u064A\u0629 \u0641\u0639\u0627\u0644\u064A\u0629",
  "Live feed": "\u0628\u062B \u0645\u0628\u0627\u0634\u0631",
  "On-air mention": "\u0625\u0634\u0627\u0631\u0629 \u0639\u0644\u0649 \u0627\u0644\u0647\u0648\u0627\u0621",
  "Digital article": "\u0645\u0642\u0627\u0644 \u0631\u0642\u0645\u064A",
  "Logo on screen": "\u0634\u0639\u0627\u0631 \u0639\u0644\u0649 \u0627\u0644\u0634\u0627\u0634\u0629",
  "Social media coverage": "\u062A\u063A\u0637\u064A\u0629 \u0639\u0644\u0649 \u0648\u0633\u0627\u0626\u0644 \u0627\u0644\u062A\u0648\u0627\u0635\u0644",
  "Segment integration": "\u062F\u0645\u062C \u0636\u0645\u0646 \u0641\u0642\u0631\u0629",
  "Video clip (cut-down)": "\u0645\u0642\u0637\u0639 \u0641\u064A\u062F\u064A\u0648 \u0645\u062E\u062A\u0635\u0631",
  "Interview (up to 5 min)": "\u0645\u0642\u0627\u0628\u0644\u0629 (\u062D\u062A\u0649 5 \u062F\u0642\u0627\u0626\u0642)",
  "Other": "\u0623\u062E\u0631\u0649",
  "TV": "\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646",
  "Radio": "\u0627\u0644\u0625\u0630\u0627\u0639\u0629",
  "Mobile app": "\u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u062C\u0648\u0627\u0644",
  "Print": "\u0627\u0644\u0645\u0637\u0628\u0648\u0639\u0627\u062A",
  "UAE": "\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A",
  "Saudi Arabia": "\u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629",
  "Wider GCC": "\u0628\u0642\u064A\u0629 \u062F\u0648\u0644 \u0627\u0644\u062E\u0644\u064A\u062C",
  "Add the programme or show name.": "\u0623\u0636\u0641 \u0627\u0633\u0645 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C \u0623\u0648 \u0627\u0644\u0639\u0631\u0636.",
  "Choose the type.": "\u0627\u062E\u062A\u0631 \u0627\u0644\u0646\u0648\u0639.",
  "Choose the format.": "\u0627\u062E\u062A\u0631 \u0627\u0644\u0634\u0643\u0644.",
  "Add the duration in minutes.": "\u0623\u0636\u0641 \u0627\u0644\u0645\u062F\u0629 \u0628\u0627\u0644\u062F\u0642\u0627\u0626\u0642.",
  "Choose how often it runs.": "\u0627\u062E\u062A\u0631 \u0639\u062F\u062F \u0645\u0631\u0627\u062A \u0627\u0644\u0639\u0631\u0636.",
  "Add at least one coverage date.": "\u0623\u0636\u0641 \u062A\u0627\u0631\u064A\u062E \u062A\u063A\u0637\u064A\u0629 \u0648\u0627\u062D\u062F\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
  "Coverage dates must be today or later.": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u062A\u0648\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u063A\u0637\u064A\u0629 \u0627\u0644\u064A\u0648\u0645 \u0623\u0648 \u0628\u0639\u062F\u0647.",
  "Add the time (UAE).": "\u0623\u0636\u0641 \u0627\u0644\u0648\u0642\u062A (\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A).",
  "Choose at least one coverage type.": "\u0627\u062E\u062A\u0631 \u0646\u0648\u0639 \u062A\u063A\u0637\u064A\u0629 \u0648\u0627\u062D\u062F\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
  "Add the editorial angle or key message.": "\u0623\u0636\u0641 \u0627\u0644\u0632\u0627\u0648\u064A\u0629 \u0627\u0644\u062A\u062D\u0631\u064A\u0631\u064A\u0629 \u0623\u0648 \u0627\u0644\u0631\u0633\u0627\u0644\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629.",
  "Add the estimated reach.": "\u0623\u0636\u0641 \u0627\u0644\u0648\u0635\u0648\u0644 \u0627\u0644\u0645\u062A\u0648\u0642\u0639.",
  "Choose at least one deliverable.": "\u0627\u062E\u062A\u0631 \u0645\u062E\u0631\u062C\u064B\u0627 \u0648\u0627\u062D\u062F\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
  "Say what the other deliverable is.": "\u0648\u0636\u0651\u062D \u0645\u0627 \u0647\u0648 \u0627\u0644\u0645\u062E\u0631\u062C \u0627\u0644\u0622\u062E\u0631.",
  "Choose where the coverage appears.": "\u0627\u062E\u062A\u0631 \u0623\u064A\u0646 \u062A\u0638\u0647\u0631 \u0627\u0644\u062A\u063A\u0637\u064A\u0629.",
  "Add the base price.": "\u0623\u0636\u0641 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u0633\u0627\u0633\u064A.",
  "Choose how it sells: fixed price or bidding.": "\u0627\u062E\u062A\u0631 \u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u0628\u064A\u0639: \u0633\u0639\u0631 \u062B\u0627\u0628\u062A \u0623\u0648 \u0645\u0632\u0627\u064A\u062F\u0629.",
  "Add each placement once, then put dates on sale from your calendar at the price you choose.": "\u0623\u0636\u0641 \u0643\u0644 \u0645\u0633\u0627\u062D\u0629 \u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629\u060C \u062B\u0645 \u0627\u0639\u0631\u0636 \u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0644\u0644\u0628\u064A\u0639 \u0645\u0646 \u062A\u0642\u0648\u064A\u0645\u0643 \u0628\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0630\u064A \u062A\u062E\u062A\u0627\u0631\u0647.",
  "On sale as a placement.": "\u0645\u0639\u0631\u0648\u0636\u0629 \u0644\u0644\u0628\u064A\u0639 \u0643\u0645\u0633\u0627\u062D\u0629 \u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "Approving makes it a placement at the total price, with one slot on each coverage date that is still far enough ahead to sell.": "\u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 \u062A\u062C\u0639\u0644\u0647\u0627 \u0645\u0633\u0627\u062D\u0629 \u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0628\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0625\u062C\u0645\u0627\u0644\u064A\u060C \u0645\u0639 \u0645\u0648\u0639\u062F \u0648\u0627\u062D\u062F \u0641\u064A \u0643\u0644 \u062A\u0627\u0631\u064A\u062E \u062A\u063A\u0637\u064A\u0629 \u0645\u0627 \u0632\u0627\u0644 \u0628\u0639\u064A\u062F\u064B\u0627 \u0628\u0645\u0627 \u064A\u0643\u0641\u064A \u0644\u0628\u064A\u0639\u0647.",
  "It is on sale as a placement.": "\u0623\u0635\u0628\u062D\u062A \u0645\u0639\u0631\u0648\u0636\u0629 \u0644\u0644\u0628\u064A\u0639 \u0643\u0645\u0633\u0627\u062D\u0629 \u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "Open the placement": "\u0627\u0641\u062A\u062D \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Active listings": "\u0627\u0644\u0639\u0631\u0648\u0636 \u0627\u0644\u0646\u0634\u0637\u0629",
  "All listings": "\u0643\u0644 \u0627\u0644\u0639\u0631\u0648\u0636",
  "Everything you sell, across every outlet and media type. Describe a placement once; the calendar puts it on sale by date.": "\u0643\u0644 \u0645\u0627 \u062A\u0628\u064A\u0639\u0647 \u0641\u064A \u062C\u0645\u064A\u0639 \u0645\u0646\u0627\u0641\u0630\u0643 \u0648\u0623\u0646\u0648\u0627\u0639 \u0648\u0633\u0627\u0626\u0644\u0643 \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u0629. \u0635\u0650\u0641 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629\u060C \u0648\u064A\u0639\u0631\u0636\u0647\u0627 \u0627\u0644\u062A\u0642\u0648\u064A\u0645 \u0644\u0644\u0628\u064A\u0639 \u062D\u0633\u0628 \u0627\u0644\u062A\u0627\u0631\u064A\u062E.",
  "Search listings\u2026": "\u0627\u0628\u062D\u062B \u0641\u064A \u0627\u0644\u0639\u0631\u0648\u0636\u2026",
  "Search listings": "\u0627\u0628\u062D\u062B \u0641\u064A \u0627\u0644\u0639\u0631\u0648\u0636",
  "No listings match.": "\u0644\u0627 \u0639\u0631\u0648\u0636 \u0645\u0637\u0627\u0628\u0642\u0629.",
  "No listings yet.": "\u0644\u0627 \u0639\u0631\u0648\u0636 \u0628\u0639\u062F.",
  "Add a placement once, with its audience, pricing and timing; then put it on sale from the calendar.": "\u0623\u0636\u0641 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \u0628\u062C\u0645\u0647\u0648\u0631\u0647\u0627 \u0648\u062A\u0633\u0639\u064A\u0631\u0647\u0627 \u0648\u062A\u0648\u0642\u064A\u062A\u0647\u0627\u060C \u062B\u0645 \u0627\u0639\u0631\u0636\u0647\u0627 \u0644\u0644\u0628\u064A\u0639 \u0645\u0646 \u0627\u0644\u062A\u0642\u0648\u064A\u0645.",
  "Add a placement first; then put it on sale here.": "\u0623\u0636\u0641 \u0645\u0633\u0627\u062D\u0629 \u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0623\u0648\u0644\u064B\u0627\u060C \u062B\u0645 \u0627\u0639\u0631\u0636\u0647\u0627 \u0644\u0644\u0628\u064A\u0639 \u0647\u0646\u0627.",
  "The placement's days and times decide which slots appear. The price is the placement's own; change it here for these dates only.": "\u0623\u064A\u0627\u0645 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0648\u0623\u0648\u0642\u0627\u062A\u0647\u0627 \u062A\u062D\u062F\u062F \u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F \u0627\u0644\u062A\u064A \u062A\u0638\u0647\u0631. \u0627\u0644\u0633\u0639\u0631 \u0647\u0648 \u0633\u0639\u0631\u0647\u0627\u061B \u063A\u064A\u0651\u0631\u0647 \u0647\u0646\u0627 \u0644\u0647\u0630\u0647 \u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0641\u0642\u0637.",
  "Add {placement} on {day}": "\u0623\u0636\u0641 {placement} \u0641\u064A {day}",
  "Expand the menu": "\u0648\u0633\u0651\u0639 \u0627\u0644\u0642\u0627\u0626\u0645\u0629",
  "Collapse the menu": "\u0635\u063A\u0651\u0631 \u0627\u0644\u0642\u0627\u0626\u0645\u0629",
  "{outlet} content calendar": "\u062A\u0642\u0648\u064A\u0645 \u0645\u062D\u062A\u0648\u0649 {outlet}",
  "Content calendar": "\u062A\u0642\u0648\u064A\u0645 \u0627\u0644\u0645\u062D\u062A\u0648\u0649",
  "Plan, manage and sell your programming line-up. Dubai time, prices excluding VAT.": "\u062E\u0637\u0651\u0637 \u0644\u0628\u0631\u0627\u0645\u062C\u0643 \u0648\u0623\u062F\u0631\u0647\u0627 \u0648\u0628\u0650\u0639\u0647\u0627. \u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A\u060C \u0648\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u062F\u0648\u0646 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629.",
  "Publisher pages": "\u0635\u0641\u062D\u0627\u062A \u0627\u0644\u0646\u0627\u0634\u0631",
  "items": "\u0639\u0646\u0635\u0631\u064B\u0627",
  "No slots match these filters.": "\u0644\u0627 \u0645\u0648\u0627\u0639\u064A\u062F \u062A\u0637\u0627\u0628\u0642 \u0647\u0630\u0647 \u0627\u0644\u0641\u0644\u0627\u062A\u0631.",
  "Nothing listed on this day.": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u0639\u0631\u0648\u0636 \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u064A\u0648\u0645.",
  "Nothing listed in this period.": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u0639\u0631\u0648\u0636 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0641\u062A\u0631\u0629.",
  "Show the next one": "\u0627\u0639\u0631\u0636 \u0627\u0644\u062A\u0627\u0644\u064A",
  "{n} sec": "{n} \u062B\u0627\u0646\u064A\u0629",
  "{h} h {m} min": "{h} \u0633 {m} \u062F",
  "Add to calendar on {day}": "\u0623\u0636\u0641 \u0625\u0644\u0649 \u0627\u0644\u062A\u0642\u0648\u064A\u0645 \u0641\u064A {day}",
  "Open {day}": "\u0627\u0641\u062A\u062D {day}",
  "Bid summary": "\u0645\u0644\u062E\u0635 \u0627\u0644\u0639\u0631\u0648\u0636",
  "View bids": "\u0627\u0639\u0631\u0636 \u0627\u0644\u0639\u0631\u0648\u0636",
  "1 bid": "\u0639\u0631\u0636 \u0648\u0627\u062D\u062F",
  "Accepted:": "\u0627\u0644\u0645\u0642\u0628\u0648\u0644:",
  "Waiting for your decision:": "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0642\u0631\u0627\u0631\u0643:",
  "Highest bid:": "\u0623\u0639\u0644\u0649 \u0639\u0631\u0636:",
  "Buyer:": "\u0627\u0644\u0645\u0634\u062A\u0631\u064A:",
  "No bids.": "\u0644\u0627 \u0639\u0631\u0648\u0636.",
  "(UAE)": "(\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A)",
  "Sale closes {when}": "\u064A\u0646\u062A\u0647\u064A \u0627\u0644\u0628\u064A\u0639 {when}",
  "Creative due {when}": "\u0645\u0648\u0639\u062F \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 {when}",
  "Day": "\u064A\u0648\u0645",
  "Week": "\u0623\u0633\u0628\u0648\u0639",
  "Month": "\u0634\u0647\u0631",
  "List": "\u0642\u0627\u0626\u0645\u0629",
  "Edit": "\u062A\u0639\u062F\u064A\u0644",
  "Not connected": "\u063A\u064A\u0631 \u0645\u0631\u0628\u0648\u0637",
  "TRN missing": "\u0627\u0644\u0631\u0642\u0645 \u0627\u0644\u0636\u0631\u064A\u0628\u064A \u063A\u064A\u0631 \u0645\u0636\u0627\u0641",
  "Not VAT-registered": "\u063A\u064A\u0631 \u0645\u0633\u062C\u0651\u0644 \u0641\u064A \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629",
  "{n} outlets": "{n} \u0645\u0646\u0627\u0641\u0630",
  "None yet": "\u0644\u0627 \u0634\u064A\u0621 \u0628\u0639\u062F",
  "Shared with Nashr": "\u0645\u064F\u0634\u0627\u0631\u0643 \u0645\u0639 \u0646\u0634\u0631",
  "Not shared": "\u063A\u064A\u0631 \u0645\u064F\u0634\u0627\u0631\u0643",
  "How buyers see you, where your money goes, and who works with you. Pick a section.": "\u0643\u064A\u0641 \u064A\u0631\u0627\u0643 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646\u060C \u0648\u0625\u0644\u0649 \u0623\u064A\u0646 \u062A\u0630\u0647\u0628 \u0623\u0645\u0648\u0627\u0644\u0643\u060C \u0648\u0645\u0646 \u064A\u0639\u0645\u0644 \u0645\u0639\u0643. \u0627\u062E\u062A\u0631 \u0642\u0633\u0645\u064B\u0627.",
  "Sections": "\u0627\u0644\u0623\u0642\u0633\u0627\u0645",
  "Needs setting up": "\u064A\u062D\u062A\u0627\u062C \u0625\u0644\u0649 \u0625\u0639\u062F\u0627\u062F",
  "The stations, channels, publications and shows buyers book with. Open one to edit it.": "\u0627\u0644\u0645\u062D\u0637\u0627\u062A \u0648\u0627\u0644\u0642\u0646\u0648\u0627\u062A \u0648\u0627\u0644\u0645\u0637\u0628\u0648\u0639\u0627\u062A \u0648\u0627\u0644\u0628\u0631\u0627\u0645\u062C \u0627\u0644\u062A\u064A \u064A\u062D\u062C\u0632 \u0645\u0639\u0647\u0627 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646. \u0627\u0641\u062A\u062D \u0623\u062D\u062F\u0647\u0627 \u0644\u062A\u0639\u062F\u064A\u0644\u0647.",
  "{n} reached": "\u064A\u0635\u0644 \u0625\u0644\u0649 {n}",
  "{n} sectors": "{n} \u0642\u0637\u0627\u0639\u0627\u062A",
  "Every sector": "\u0643\u0644 \u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A",
  "{n} audiences": "{n} \u062C\u0645\u0627\u0647\u064A\u0631",
  "No audiences tagged": "\u0644\u0627 \u062C\u0645\u0627\u0647\u064A\u0631 \u0645\u062D\u062F\u062F\u0629",
  "{n} blocked": "{n} \u0645\u062D\u0638\u0648\u0631\u0629",
  "Released money is transferred to it automatically. See what is held and paid under Balances.": "\u062A\u064F\u062D\u0648\u064E\u0651\u0644 \u0627\u0644\u0623\u0645\u0648\u0627\u0644 \u0627\u0644\u0645\u064F\u0641\u0631\u062C \u0639\u0646\u0647\u0627 \u0625\u0644\u064A\u0647 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627. \u0631\u0627\u062C\u0639 \u0627\u0644\u0645\u062D\u062C\u0648\u0632 \u0648\u0627\u0644\u0645\u062F\u0641\u0648\u0639 \u0641\u064A \u0627\u0644\u0623\u0631\u0635\u062F\u0629.",
  "Open Balances": "\u0627\u0641\u062A\u062D \u0627\u0644\u0623\u0631\u0635\u062F\u0629",
  "Logo and cover": "\u0627\u0644\u0634\u0639\u0627\u0631 \u0648\u0635\u0648\u0631\u0629 \u0627\u0644\u063A\u0644\u0627\u0641",
  "Outlets": "\u0627\u0644\u0645\u0646\u0627\u0641\u0630",
  "Payout account": "\u062D\u0633\u0627\u0628 \u0627\u0644\u062F\u0641\u0639\u0627\u062A",
  "Tax and invoices": "\u0627\u0644\u0636\u0631\u0627\u0626\u0628 \u0648\u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631",
  "Rate card": "\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0623\u0633\u0639\u0627\u0631",
  "Team": "\u0627\u0644\u0641\u0631\u064A\u0642",
  "Verified": "\u062A\u0645 \u0627\u0644\u062A\u062D\u0642\u0642",
  "Tax details": "\u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629",
  "TRN {trn}": "\u0627\u0644\u0631\u0642\u0645 \u0627\u0644\u0636\u0631\u064A\u0628\u064A {trn}",
  "Add outlet": "\u0623\u0636\u0641 \u0645\u0646\u0641\u0630\u064B\u0627",
  "Click any card for detail.": "\u0627\u0646\u0642\u0631 \u0623\u064A \u0628\u0637\u0627\u0642\u0629 \u0644\u0631\u0624\u064A\u0629 \u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644.",
  "{p} publishers live \xB7 {b} buyer companies": "{p} \u0646\u0627\u0634\u0631\u064A\u0646 \u0646\u0634\u0637\u064A\u0646 \xB7 {b} \u0634\u0631\u0643\u0627\u062A \u0645\u0634\u062A\u0631\u064A\u0629",
  "{n} kinds of work waiting": "{n} \u0623\u0646\u0648\u0627\u0639 \u0645\u0646 \u0627\u0644\u0639\u0645\u0644 \u0628\u0627\u0646\u062A\u0638\u0627\u0631\u0643",
  "Nothing waiting": "\u0644\u0627 \u0634\u064A\u0621 \u0628\u0627\u0646\u062A\u0638\u0627\u0631\u0643",
  "Booked value by week": "\u0642\u064A\u0645\u0629 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0623\u0633\u0628\u0648\u0639\u064A\u064B\u0627",
  "excluding VAT": "\u062F\u0648\u0646 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629",
  "Booked value by week, excluding VAT": "\u0642\u064A\u0645\u0629 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0623\u0633\u0628\u0648\u0639\u064A\u064B\u0627 \u062F\u0648\u0646 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629",
  "Booked value by channel": "\u0642\u064A\u0645\u0629 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u062D\u0633\u0628 \u0627\u0644\u0648\u0633\u064A\u0644\u0629",
  "last 90 days": "\u0622\u062E\u0631 90 \u064A\u0648\u0645\u064B\u0627",
  "Top publishers": "\u0623\u0639\u0644\u0649 \u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646",
  "Top buyers": "\u0623\u0639\u0644\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646",
  "Your bookings, bids and spend at a glance. Click any card for detail.": "\u062D\u062C\u0648\u0632\u0627\u062A\u0643 \u0648\u0639\u0631\u0648\u0636\u0643 \u0648\u0625\u0646\u0641\u0627\u0642\u0643 \u0641\u064A \u0644\u0645\u062D\u0629. \u0627\u0646\u0642\u0631 \u0623\u064A \u0628\u0637\u0627\u0642\u0629 \u0644\u0631\u0624\u064A\u0629 \u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644.",
  "Paid, last 30 days": "\u0627\u0644\u0645\u062F\u0641\u0648\u0639 \u0622\u062E\u0631 30 \u064A\u0648\u0645\u064B\u0627",
  "Held for you": "\u0645\u062D\u062C\u0648\u0632 \u0644\u0643",
  "First by {when}": "\u0623\u0648\u0644\u0647\u0627 \u0642\u0628\u0644 {when}",
  "All paid": "\u0643\u0644\u0647\u0627 \u0645\u062F\u0641\u0648\u0639\u0629",
  "No open bids": "\u0644\u0627 \u0639\u0631\u0648\u0636 \u0645\u0641\u062A\u0648\u062D\u0629",
  "Spend by week": "\u0627\u0644\u0625\u0646\u0641\u0627\u0642 \u0623\u0633\u0628\u0648\u0639\u064A\u064B\u0627",
  "Paid by week, excluding VAT": "\u0627\u0644\u0645\u062F\u0641\u0648\u0639 \u0623\u0633\u0628\u0648\u0639\u064A\u064B\u0627 \u062F\u0648\u0646 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629",
  "Paid by week, excluding VAT.": "\u0627\u0644\u0645\u062F\u0641\u0648\u0639 \u0623\u0633\u0628\u0648\u0639\u064A\u064B\u0627 \u062F\u0648\u0646 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629.",
  "{n} outlets booked, {m} paid bookings so far.": "{n} \u0645\u0646\u0627\u0641\u0630 \u0645\u062D\u062C\u0648\u0632\u0629\u060C \u0648{m} \u062D\u062C\u0648\u0632\u0627\u062A \u0645\u062F\u0641\u0648\u0639\u0629 \u062D\u062A\u0649 \u0627\u0644\u0622\u0646.",
  "Where your budget went": "\u0623\u064A\u0646 \u0630\u0647\u0628\u062A \u0645\u064A\u0632\u0627\u0646\u064A\u062A\u0643",
  "Spent": "\u0627\u0644\u0645\u064F\u0646\u0641\u0642",
  "Nothing held": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u062D\u062C\u0648\u0632",
  "Listed: {n} new slots on sale from {date}.": "\u062A\u0645 \u0627\u0644\u0639\u0631\u0636: {n} \u0645\u0648\u0627\u0639\u064A\u062F \u062C\u062F\u064A\u062F\u0629 \u0644\u0644\u0628\u064A\u0639 \u0645\u0646 {date}.",
  "Nothing new went on sale: those dates are already listed, or too close to sell (bidding closes {n} days before).": "\u0644\u0645 \u064A\u064F\u0639\u0631\u0636 \u0634\u064A\u0621 \u062C\u062F\u064A\u062F: \u0647\u0630\u0647 \u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0645\u0639\u0631\u0648\u0636\u0629 \u0628\u0627\u0644\u0641\u0639\u0644\u060C \u0623\u0648 \u0642\u0631\u064A\u0628\u0629 \u062C\u062F\u064B\u0627 \u0644\u0644\u0628\u064A\u0639 (\u062A\u0646\u062A\u0647\u064A \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0642\u0628\u0644 {n} \u0623\u064A\u0627\u0645).",
  "List it": "\u0627\u0639\u0631\u0636\u0647 \u0644\u0644\u0628\u064A\u0639",
  "Add a product first; then list it here.": "\u0623\u0636\u0641 \u0645\u0646\u062A\u062C\u064B\u0627 \u0623\u0648\u0644\u064B\u0627\u060C \u062B\u0645 \u0627\u0639\u0631\u0636\u0647 \u0644\u0644\u0628\u064A\u0639 \u0647\u0646\u0627.",
  "Not on the list?": "\u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0641\u064A \u0627\u0644\u0642\u0627\u0626\u0645\u0629\u061F",
  "Create a new one": "\u0623\u0646\u0634\u0626 \u0648\u0627\u062D\u062F\u064B\u0627 \u062C\u062F\u064A\u062F\u064B\u0627",
  "Issue date": "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0639\u062F\u062F",
  "For how long": "\u0627\u0644\u0645\u062F\u0629",
  "Number of weeks": "\u0639\u062F\u062F \u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639",
  "weeks": "\u0623\u0633\u0627\u0628\u064A\u0639",
  "Always open 8 weeks ahead, topped up every day until you stop it.": "\u0645\u062A\u0627\u062D \u062F\u0627\u0626\u0645\u064B\u0627 \u0644\u062B\u0645\u0627\u0646\u064A\u0629 \u0623\u0633\u0627\u0628\u064A\u0639 \u0642\u0627\u062F\u0645\u0629\u060C \u0648\u064A\u064F\u062C\u062F\u064E\u0651\u062F \u064A\u0648\u0645\u064A\u064B\u0627 \u062D\u062A\u0649 \u062A\u0648\u0642\u0641\u0647.",
  "Only the days it runs go on sale. Bidding closes {n} days before each one.": "\u062A\u064F\u0639\u0631\u0636 \u0644\u0644\u0628\u064A\u0639 \u0627\u0644\u0623\u064A\u0627\u0645 \u0627\u0644\u062A\u064A \u064A\u064F\u0628\u062B \u0641\u064A\u0647\u0627 \u0641\u0642\u0637. \u062A\u0646\u062A\u0647\u064A \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0642\u0628\u0644 \u0643\u0644 \u0645\u0646\u0647\u0627 \u0628\u0640 {n} \u0623\u064A\u0627\u0645.",
  "Starting price (AED)": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0627\u0641\u062A\u062A\u0627\u062D\u064A (\u062F\u0631\u0647\u0645)",
  "Default price: {amount}": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A: {amount}",
  "Buy-now price (AED, optional)": "\u0633\u0639\u0631 \u0627\u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0641\u0648\u0631\u064A (\u062F\u0631\u0647\u0645\u060C \u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Minimum accepted (AED, optional)": "\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u062F\u0646\u0649 \u0627\u0644\u0645\u0642\u0628\u0648\u0644 (\u062F\u0631\u0647\u0645\u060C \u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Private: buyers never see it.": "\u062E\u0627\u0635: \u0644\u0627 \u064A\u0631\u0627\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0623\u0628\u062F\u064B\u0627.",
  "Any break package (AED, optional)": "\u0628\u0627\u0642\u0629 \u0623\u064A \u0641\u0627\u0635\u0644 (\u062F\u0631\u0647\u0645\u060C \u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "You choose which break the ad plays in.": "\u0623\u0646\u062A \u062A\u062E\u062A\u0627\u0631 \u0627\u0644\u0641\u0627\u0635\u0644 \u0627\u0644\u0630\u064A \u064A\u064F\u0628\u062B \u0641\u064A\u0647 \u0627\u0644\u0625\u0639\u0644\u0627\u0646.",
  "All breaks package (AED, optional)": "\u0628\u0627\u0642\u0629 \u0643\u0644 \u0627\u0644\u0641\u0648\u0627\u0635\u0644 (\u062F\u0631\u0647\u0645\u060C \u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "The ad plays in every break that day.": "\u064A\u064F\u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0641\u064A \u0643\u0644 \u0641\u0627\u0635\u0644 \u0630\u0644\u0643 \u0627\u0644\u064A\u0648\u0645.",
  "Save listing": "\u0627\u062D\u0641\u0638 \u0627\u0644\u0639\u0631\u0636",
  "Other: say what it is": "\u0623\u062E\u0631\u0649: \u0648\u0636\u0651\u062D \u0645\u0627 \u0647\u0648",
  "Say what it is": "\u0648\u0636\u0651\u062D \u0645\u0627 \u0647\u0648",
  "Break {n} time": "\u0648\u0642\u062A \u0627\u0644\u0641\u0627\u0635\u0644 {n}",
  "Remove break {n}": "\u0627\u062D\u0630\u0641 \u0627\u0644\u0641\u0627\u0635\u0644 {n}",
  "Airtime": "\u0648\u0642\u062A \u0627\u0644\u0628\u062B",
  "Starts": "\u064A\u0628\u062F\u0623",
  "Dubai time. Overnight like 23:00\u201302:00 works.": "\u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A. \u064A\u0635\u0644\u062D \u0627\u0644\u0628\u062B \u0627\u0644\u0644\u064A\u0644\u064A \u0645\u062B\u0644 23:00\u201302:00.",
  "Each break is sold on its own.": "\u064A\u064F\u0628\u0627\u0639 \u0643\u0644 \u0641\u0627\u0635\u0644 \u0639\u0644\u0649 \u062D\u062F\u0629.",
  "Fix the {n} highlighted fields, then save.": "\u0635\u062D\u0651\u062D \u0627\u0644\u062D\u0642\u0648\u0644 \u0627\u0644\u0645\u062D\u062F\u062F\u0629 ({n})\u060C \u062B\u0645 \u0627\u062D\u0641\u0638.",
  "Add a media type": "\u0623\u0636\u0641 \u0646\u0648\u0639 \u0648\u0633\u064A\u0644\u0629",
  "About it": "\u0639\u0646\u0647",
  "For example: Skyline FM 92.4": "\u0645\u062B\u0627\u0644: Skyline FM 92.4",
  "Cover image (optional)": "\u0635\u0648\u0631\u0629 \u0627\u0644\u063A\u0644\u0627\u0641 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Sell it by programme": "\u0628\u0650\u0639\u0647 \u062D\u0633\u0628 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C",
  "Each show, for example Morning Markets, gets its own days, airtime and breaks. Leave off to sell it as one.": "\u0644\u0643\u0644 \u0628\u0631\u0646\u0627\u0645\u062C\u060C \u0645\u062B\u0644 Morning Markets\u060C \u0623\u064A\u0627\u0645\u0647 \u0648\u0648\u0642\u062A \u0628\u062B\u0647 \u0648\u0641\u0648\u0627\u0635\u0644\u0647. \u0627\u062A\u0631\u0643\u0647 \u0645\u063A\u0644\u0642\u064B\u0627 \u0644\u062A\u0628\u064A\u0639\u0647 \u0643\u0648\u062D\u062F\u0629 \u0648\u0627\u062D\u062F\u0629.",
  "{type} details": "\u062A\u0641\u0627\u0635\u064A\u0644 {type}",
  "No time field: the date the magazine comes out is picked when you list it.": "\u0644\u0627 \u064A\u0648\u062C\u062F \u062D\u0642\u0644 \u0648\u0642\u062A: \u064A\u064F\u062E\u062A\u0627\u0631 \u062A\u0627\u0631\u064A\u062E \u0635\u062F\u0648\u0631 \u0627\u0644\u0645\u062C\u0644\u0629 \u0639\u0646\u062F \u0639\u0631\u0636\u0647\u0627 \u0644\u0644\u0628\u064A\u0639.",
  "Reach (optional)": "\u0627\u0644\u0648\u0635\u0648\u0644 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "What it counts": "\u0645\u0627 \u0627\u0644\u0630\u064A \u064A\u064F\u062D\u062A\u0633\u0628",
  "Sectors accepted": "\u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A \u0627\u0644\u0645\u0642\u0628\u0648\u0644\u0629",
  "All sectors": "\u0643\u0644 \u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A",
  "Sectors not accepted (optional)": "\u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A \u063A\u064A\u0631 \u0627\u0644\u0645\u0642\u0628\u0648\u0644\u0629 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Sectors not accepted": "\u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A \u063A\u064A\u0631 \u0627\u0644\u0645\u0642\u0628\u0648\u0644\u0629",
  "Price and deadlines": "\u0627\u0644\u0633\u0639\u0631 \u0648\u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F",
  "Default price (AED)": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A (\u062F\u0631\u0647\u0645)",
  "Pre-fills the price when you list it.": "\u064A\u0645\u0644\u0623 \u0627\u0644\u0633\u0639\u0631 \u0645\u0633\u0628\u0642\u064B\u0627 \u0639\u0646\u062F \u0627\u0644\u0639\u0631\u0636 \u0644\u0644\u0628\u064A\u0639.",
  "Creative due (days before it runs)": "\u0645\u0648\u0639\u062F \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 (\u0623\u064A\u0627\u0645 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B)",
  "Bidding closes (days before it runs)": "\u0627\u0646\u062A\u0647\u0627\u0621 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 (\u0623\u064A\u0627\u0645 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B)",
  "Bidding must close {n} days or more before it runs.": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0646\u062A\u0647\u064A \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B \u0628\u0640 {n} \u0623\u064A\u0627\u0645 \u0623\u0648 \u0623\u0643\u062B\u0631.",
  "File type": "\u0646\u0648\u0639 \u0627\u0644\u0645\u0644\u0641",
  "Length or size": "\u0627\u0644\u0645\u062F\u0629 \u0623\u0648 \u0627\u0644\u0645\u0642\u0627\u0633",
  "For example: 30 seconds, or 300\xD7250": "\u0645\u062B\u0627\u0644: 30 \u062B\u0627\u0646\u064A\u0629\u060C \u0623\u0648 300\xD7250",
  "Anything else buyers should know (optional)": "\u0623\u064A \u0634\u064A\u0621 \u0622\u062E\u0631 \u064A\u062C\u0628 \u0623\u0646 \u064A\u0639\u0631\u0641\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Add media type": "\u0623\u0636\u0641 \u0646\u0648\u0639 \u0627\u0644\u0648\u0633\u064A\u0644\u0629",
  "Add a programme": "\u0623\u0636\u0641 \u0628\u0631\u0646\u0627\u0645\u062C\u064B\u0627",
  "Programme name": "\u0627\u0633\u0645 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C",
  "Morning Markets": "Morning Markets",
  "Price and deadlines for this programme (optional)": "\u0627\u0644\u0633\u0639\u0631 \u0648\u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F \u0644\u0647\u0630\u0627 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Left empty, they come from the media type: {price}, creative {c} days and bidding {b} days before.": "\u0625\u0646 \u062A\u064F\u0631\u0643\u062A \u0641\u0627\u0631\u063A\u0629\u060C \u062A\u064F\u0624\u062E\u0630 \u0645\u0646 \u0646\u0648\u0639 \u0627\u0644\u0648\u0633\u064A\u0644\u0629: {price}\u060C \u0648\u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0642\u0628\u0644 {c} \u0623\u064A\u0627\u0645\u060C \u0648\u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0642\u0628\u0644 {b} \u0623\u064A\u0627\u0645.",
  "Add programme": "\u0623\u0636\u0641 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C",
  "Product saved.": "\u062D\u064F\u0641\u0638 \u0627\u0644\u0645\u0646\u062A\u062C.",
  "The product is your brand. Add each media type it has; for radio, TV and podcasts, add programmes if you sell by show.": "\u0627\u0644\u0645\u0646\u062A\u062C \u0647\u0648 \u0639\u0644\u0627\u0645\u062A\u0643 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629. \u0623\u0636\u0641 \u0643\u0644 \u0646\u0648\u0639 \u0648\u0633\u064A\u0644\u0629 \u0644\u062F\u064A\u0647\u060C \u0648\u0644\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A \u0623\u0636\u0641 \u0627\u0644\u0628\u0631\u0627\u0645\u062C \u0625\u0646 \u0643\u0646\u062A \u062A\u0628\u064A\u0639 \u062D\u0633\u0628 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C.",
  "Steps": "\u0627\u0644\u062E\u0637\u0648\u0627\u062A",
  "Media types": "\u0623\u0646\u0648\u0627\u0639 \u0627\u0644\u0648\u0633\u0627\u0626\u0644",
  "1. Product": "1. \u0627\u0644\u0645\u0646\u062A\u062C",
  "For example: Skyline FM": "\u0645\u062B\u0627\u0644: Skyline FM",
  "Save product": "\u0627\u062D\u0641\u0638 \u0627\u0644\u0645\u0646\u062A\u062C",
  "Save and add media types": "\u0627\u062D\u0641\u0638 \u0648\u0623\u0636\u0641 \u0623\u0646\u0648\u0627\u0639 \u0627\u0644\u0648\u0633\u0627\u0626\u0644",
  "2. Media types": "2. \u0623\u0646\u0648\u0627\u0639 \u0627\u0644\u0648\u0633\u0627\u0626\u0644",
  "Media type saved.": "\u062D\u064F\u0641\u0638 \u0646\u0648\u0639 \u0627\u0644\u0648\u0633\u064A\u0644\u0629.",
  "No media types yet. Add the first one: radio, TV, newspaper, magazine, website, newsletter, podcast or social media.": "\u0644\u0627 \u0623\u0646\u0648\u0627\u0639 \u0648\u0633\u0627\u0626\u0644 \u0628\u0639\u062F. \u0623\u0636\u0641 \u0627\u0644\u0623\u0648\u0644: \u0625\u0630\u0627\u0639\u0629 \u0623\u0648 \u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0623\u0648 \u0635\u062D\u064A\u0641\u0629 \u0623\u0648 \u0645\u062C\u0644\u0629 \u0623\u0648 \u0645\u0648\u0642\u0639 \u0623\u0648 \u0646\u0634\u0631\u0629 \u0628\u0631\u064A\u062F\u064A\u0629 \u0623\u0648 \u0628\u0648\u062F\u0643\u0627\u0633\u062A \u0623\u0648 \u0648\u0633\u0627\u0626\u0644 \u062A\u0648\u0627\u0635\u0644.",
  "default {amount}": "\u0627\u0641\u062A\u0631\u0627\u0636\u064A {amount}",
  "bidding closes {n} days before": "\u062A\u0646\u062A\u0647\u064A \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0642\u0628\u0644 {n} \u0623\u064A\u0627\u0645",
  "Saved. List it now?": "\u062A\u0645 \u0627\u0644\u062D\u0641\u0638. \u0647\u0644 \u062A\u0639\u0631\u0636\u0647 \u0644\u0644\u0628\u064A\u0639 \u0627\u0644\u0622\u0646\u061F",
  "Programmes": "\u0627\u0644\u0628\u0631\u0627\u0645\u062C",
  "Programme saved.": "\u062D\u064F\u0641\u0638 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C.",
  "Sold as one: {name}": "\u064A\u064F\u0628\u0627\u0639 \u0643\u0648\u062D\u062F\u0629 \u0648\u0627\u062D\u062F\u0629: {name}",
  "Delete {name}? What is not yet sold stops being sold; bookings already made carry on.": "\u062D\u0630\u0641 {name}\u061F \u064A\u062A\u0648\u0642\u0641 \u0628\u064A\u0639 \u0645\u0627 \u0644\u0645 \u064A\u064F\u0628\u0639 \u0628\u0639\u062F\u060C \u0648\u062A\u0633\u062A\u0645\u0631 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u0642\u0627\u0626\u0645\u0629.",
  "Each product with its media types, programmes and what is on sale. Add the details once; list them for the dates you choose.": "\u0643\u0644 \u0645\u0646\u062A\u062C \u0628\u0623\u0646\u0648\u0627\u0639 \u0648\u0633\u0627\u0626\u0644\u0647 \u0648\u0628\u0631\u0627\u0645\u062C\u0647 \u0648\u0645\u0627 \u0647\u0648 \u0645\u0639\u0631\u0648\u0636 \u0644\u0644\u0628\u064A\u0639. \u0623\u0636\u0641 \u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \u0648\u0627\u0639\u0631\u0636\u0647\u0627 \u0644\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u064A \u062A\u062E\u062A\u0627\u0631\u0647\u0627.",
  "products": "\u0645\u0646\u062A\u062C\u0627\u062A",
  "media types": "\u0623\u0646\u0648\u0627\u0639 \u0648\u0633\u0627\u0626\u0644",
  "listed now": "\u0645\u0639\u0631\u0648\u0636\u0629 \u0627\u0644\u0622\u0646",
  "slots on sale": "\u0645\u0648\u0627\u0639\u064A\u062F \u0644\u0644\u0628\u064A\u0639",
  "A product is your brand, for example Skyline FM. Under it, add each media type it has (radio, website, newsletter\u2026) and, for radio, TV and podcasts, its programmes. Then list them for the dates you choose.": "\u0627\u0644\u0645\u0646\u062A\u062C \u0647\u0648 \u0639\u0644\u0627\u0645\u062A\u0643 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629\u060C \u0645\u062B\u0644 Skyline FM. \u062A\u062D\u062A\u0647 \u0623\u0636\u0641 \u0643\u0644 \u0646\u0648\u0639 \u0648\u0633\u064A\u0644\u0629 \u0644\u062F\u064A\u0647 (\u0625\u0630\u0627\u0639\u0629\u060C \u0645\u0648\u0642\u0639\u060C \u0646\u0634\u0631\u0629 \u0628\u0631\u064A\u062F\u064A\u0629\u2026)\u060C \u0648\u0644\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A \u0628\u0631\u0627\u0645\u062C\u0647\u0627. \u062B\u0645 \u0627\u0639\u0631\u0636\u0647\u0627 \u0644\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u064A \u062A\u062E\u062A\u0627\u0631\u0647\u0627.",
  "No media types yet.": "\u0644\u0627 \u0623\u0646\u0648\u0627\u0639 \u0648\u0633\u0627\u0626\u0644 \u0628\u0639\u062F.",
  "Sold by programme, but no programme added yet.": "\u064A\u064F\u0628\u0627\u0639 \u062D\u0633\u0628 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C\u060C \u0648\u0644\u0645 \u064A\u064F\u0636\u0641 \u0628\u0631\u0646\u0627\u0645\u062C \u0628\u0639\u062F.",
  "Nothing to list yet.": "\u0644\u0627 \u0634\u064A\u0621 \u0644\u0644\u0639\u0631\u0636 \u0628\u0639\u062F.",
  "Sold as one": "\u064A\u064F\u0628\u0627\u0639 \u0643\u0648\u062D\u062F\u0629 \u0648\u0627\u062D\u062F\u0629",
  "{n} on sale": "{n} \u0645\u0639\u0631\u0648\u0636\u0629",
  "next {date}": "\u0627\u0644\u062A\u0627\u0644\u064A {date}",
  "Not listed": "\u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0636",
  "Kept on sale": "\u0645\u0639\u0631\u0648\u0636 \u0628\u0627\u0633\u062A\u0645\u0631\u0627\u0631",
  "default": "\u0627\u0641\u062A\u0631\u0627\u0636\u064A",
  "{n} media types": "{n} \u0623\u0646\u0648\u0627\u0639 \u0648\u0633\u0627\u0626\u0644",
  "Product": "\u0627\u0644\u0645\u0646\u062A\u062C",
  "Description": "\u0627\u0644\u0648\u0635\u0641",
  "Ad length": "\u0645\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  "Section": "\u0627\u0644\u0642\u0633\u0645",
  "Size": "\u0627\u0644\u0645\u0642\u0627\u0633",
  "How long it runs": "\u0645\u062F\u0629 \u0627\u0644\u0639\u0631\u0636",
  "Platform": "\u0627\u0644\u0645\u0646\u0635\u0629",
  "Days": "\u0627\u0644\u0623\u064A\u0627\u0645",
  "Days published": "\u0623\u064A\u0627\u0645 \u0627\u0644\u0635\u062F\u0648\u0631",
  "Days available": "\u0627\u0644\u0623\u064A\u0627\u0645 \u0627\u0644\u0645\u062A\u0627\u062D\u0629",
  "Send days": "\u0623\u064A\u0627\u0645 \u0627\u0644\u0625\u0631\u0633\u0627\u0644",
  "Release days": "\u0623\u064A\u0627\u0645 \u0627\u0644\u0646\u0634\u0631",
  "Add break": "\u0623\u0636\u0641 \u0641\u0627\u0635\u0644\u064B\u0627",
  "Break {n}": "\u0627\u0644\u0641\u0627\u0635\u0644 {n}",
  "Bilingual": "\u062B\u0646\u0627\u0626\u064A \u0627\u0644\u0644\u063A\u0629",
  "KSA": "\u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629",
  "GCC": "\u0627\u0644\u062E\u0644\u064A\u062C",
  "listeners": "\u0645\u0633\u062A\u0645\u0639\u0648\u0646",
  "readers": "\u0642\u0631\u0651\u0627\u0621",
  "visitors": "\u0632\u0648\u0627\u0631",
  "subscribers": "\u0645\u0634\u062A\u0631\u0643\u0648\u0646",
  "followers": "\u0645\u062A\u0627\u0628\u0639\u0648\u0646",
  "Ad spot": "\u0625\u0639\u0644\u0627\u0646",
  "Sponsorship": "\u0631\u0639\u0627\u064A\u0629",
  "Time check": "\u0625\u0639\u0644\u0627\u0646 \u0627\u0644\u0648\u0642\u062A",
  "Branded segment": "\u0641\u0642\u0631\u0629 \u0628\u0631\u0639\u0627\u064A\u0629",
  "Product placement": "\u0648\u0636\u0639 \u0645\u0646\u062A\u062C",
  "Weekdays only (Mon\u2013Fri)": "\u0623\u064A\u0627\u0645 \u0627\u0644\u0639\u0645\u0644 \u0641\u0642\u0637 (\u0627\u0644\u0625\u062B\u0646\u064A\u0646\u2013\u0627\u0644\u062C\u0645\u0639\u0629)",
  "Six days a week": "\u0633\u062A\u0629 \u0623\u064A\u0627\u0645 \u0641\u064A \u0627\u0644\u0623\u0633\u0628\u0648\u0639",
  "Twice a week": "\u0645\u0631\u062A\u0627\u0646 \u0641\u064A \u0627\u0644\u0623\u0633\u0628\u0648\u0639",
  "Weekend edition only": "\u0639\u062F\u062F \u0646\u0647\u0627\u064A\u0629 \u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u0641\u0642\u0637",
  "Full page": "\u0635\u0641\u062D\u0629 \u0643\u0627\u0645\u0644\u0629",
  "Quarter page": "\u0631\u0628\u0639 \u0635\u0641\u062D\u0629",
  "Back page": "\u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0623\u062E\u064A\u0631\u0629",
  "Insert": "\u0645\u0644\u062D\u0642",
  "Advertorial": "\u0625\u0639\u0644\u0627\u0646 \u062A\u062D\u0631\u064A\u0631\u064A",
  "News": "\u0623\u062E\u0628\u0627\u0631",
  "Business": "\u0623\u0639\u0645\u0627\u0644",
  "Sport": "\u0631\u064A\u0627\u0636\u0629",
  "Lifestyle": "\u0623\u0633\u0644\u0648\u0628 \u062D\u064A\u0627\u0629",
  "Every 2 weeks": "\u0643\u0644 \u0623\u0633\u0628\u0648\u0639\u064A\u0646",
  "Every 2 months": "\u0643\u0644 \u0634\u0647\u0631\u064A\u0646",
  "Quarterly": "\u0631\u0628\u0639 \u0633\u0646\u0648\u064A",
  "Twice a year": "\u0645\u0631\u062A\u0627\u0646 \u0641\u064A \u0627\u0644\u0633\u0646\u0629",
  "Yearly": "\u0633\u0646\u0648\u064A",
  "One-off special issue": "\u0639\u062F\u062F \u062E\u0627\u0635 \u0644\u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629",
  "Double page": "\u0635\u0641\u062D\u062A\u0627\u0646",
  "Back cover": "\u0627\u0644\u063A\u0644\u0627\u0641 \u0627\u0644\u062E\u0644\u0641\u064A",
  "Inside front cover": "\u0627\u0644\u063A\u0644\u0627\u0641 \u0627\u0644\u0623\u0645\u0627\u0645\u064A \u0627\u0644\u062F\u0627\u062E\u0644\u064A",
  "Inside back cover": "\u0627\u0644\u063A\u0644\u0627\u0641 \u0627\u0644\u062E\u0644\u0641\u064A \u0627\u0644\u062F\u0627\u062E\u0644\u064A",
  "Banner": "\u0644\u0627\u0641\u062A\u0629",
  "Video ad": "\u0625\u0639\u0644\u0627\u0646 \u0641\u064A\u062F\u064A\u0648",
  "24 hours": "24 \u0633\u0627\u0639\u0629",
  "1 week": "\u0623\u0633\u0628\u0648\u0639 \u0648\u0627\u062D\u062F",
  "Top sponsor slot": "\u0645\u0648\u0636\u0639 \u0627\u0644\u0631\u0627\u0639\u064A \u0627\u0644\u0631\u0626\u064A\u0633\u064A",
  "Host read": "\u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0645\u0642\u062F\u0645",
  "Instagram": "\u0625\u0646\u0633\u062A\u063A\u0631\u0627\u0645",
  "TikTok": "\u062A\u064A\u0643 \u062A\u0648\u0643",
  "X": "\u0625\u0643\u0633",
  "YouTube": "\u064A\u0648\u062A\u064A\u0648\u0628",
  "LinkedIn": "\u0644\u064A\u0646\u0643\u062F\u0625\u0646",
  "Snapchat": "\u0633\u0646\u0627\u0628 \u0634\u0627\u062A",
  "Post": "\u0645\u0646\u0634\u0648\u0631",
  "Reel or video": "\u0631\u064A\u0644 \u0623\u0648 \u0641\u064A\u062F\u064A\u0648",
  "Story": "\u0633\u062A\u0648\u0631\u064A",
  "Carousel": "\u0639\u0631\u0636 \u062F\u0648\u0651\u0627\u0631",
  "Print-ready PDF": "PDF \u062C\u0627\u0647\u0632 \u0644\u0644\u0637\u0628\u0627\u0639\u0629",
  "JPG or PNG": "JPG \u0623\u0648 PNG",
  "Script for a live read": "\u0646\u0635 \u0644\u0644\u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0645\u0628\u0627\u0634\u0631\u0629",
  "Script for a host read": "\u0646\u0635 \u0644\u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0645\u0642\u062F\u0645",
  "For example: 30 seconds": "\u0645\u062B\u0627\u0644: 30 \u062B\u0627\u0646\u064A\u0629",
  "Start and end time, Dubai time.": "\u0648\u0642\u062A \u0627\u0644\u0628\u062F\u0627\u064A\u0629 \u0648\u0627\u0644\u0646\u0647\u0627\u064A\u0629 \u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A.",
  "Pick the media type.": "\u0627\u062E\u062A\u0631 \u0646\u0648\u0639 \u0627\u0644\u0648\u0633\u064A\u0644\u0629.",
  "Say what the media type is.": "\u0648\u0636\u0651\u062D \u0646\u0648\u0639 \u0627\u0644\u0648\u0633\u064A\u0644\u0629.",
  "Add the name buyers see.": "\u0623\u0636\u0641 \u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0630\u064A \u064A\u0631\u0627\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646.",
  "Add a description.": "\u0623\u0636\u0641 \u0648\u0635\u0641\u064B\u0627.",
  "Pick the language.": "\u0627\u062E\u062A\u0631 \u0627\u0644\u0644\u063A\u0629.",
  "Describe the audience.": "\u0635\u0650\u0641 \u0627\u0644\u062C\u0645\u0647\u0648\u0631.",
  "Pick at least one market.": "\u0627\u062E\u062A\u0631 \u0633\u0648\u0642\u064B\u0627 \u0648\u0627\u062D\u062F\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
  "Add the default price.": "\u0623\u0636\u0641 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A.",
  "Add when the creative is due.": "\u0623\u0636\u0641 \u0645\u0648\u0639\u062F \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "Add when bidding closes.": "\u0623\u0636\u0641 \u0645\u0648\u0639\u062F \u0627\u0646\u062A\u0647\u0627\u0621 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629.",
  "Pick the creative file type.": "\u0627\u062E\u062A\u0631 \u0646\u0648\u0639 \u0645\u0644\u0641 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "Keep it to 500 characters.": "\u0644\u0627 \u062A\u062A\u062C\u0627\u0648\u0632 500 \u062D\u0631\u0641.",
  "Add the start and end time.": "\u0623\u0636\u0641 \u0648\u0642\u062A \u0627\u0644\u0628\u062F\u0627\u064A\u0629 \u0648\u0627\u0644\u0646\u0647\u0627\u064A\u0629.",
  "Add each break with its time.": "\u0623\u0636\u0641 \u0643\u0644 \u0641\u0627\u0635\u0644 \u0645\u0639 \u0648\u0642\u062A\u0647.",
  "Add the programme name.": "\u0623\u0636\u0641 \u0627\u0633\u0645 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C.",
  "Bidding must close at least 3 days before the creative is due (1 day for you to decide, 2 for the buyer to pay).": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0646\u062A\u0647\u064A \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0642\u0628\u0644 \u0645\u0648\u0639\u062F \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0628\u062B\u0644\u0627\u062B\u0629 \u0623\u064A\u0627\u0645 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644 (\u064A\u0648\u0645 \u0644\u062A\u0642\u0631\u0631\u060C \u0648\u064A\u0648\u0645\u0627\u0646 \u0644\u064A\u062F\u0641\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A).",
  "Fill this in.": "\u0627\u0645\u0644\u0623 \u0647\u0630\u0627 \u0627\u0644\u062D\u0642\u0644.",
  "None": "\u0644\u0627 \u064A\u0648\u062C\u062F",
  "{n} working days": "{n} \u0623\u064A\u0627\u0645 \u0639\u0645\u0644",
  "1 session": "\u062C\u0644\u0633\u0629 \u0648\u0627\u062D\u062F\u0629",
  "When the ad has run": "\u0628\u0639\u062F \u0639\u0631\u0636 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  "At payment": "\u0639\u0646\u062F \u0627\u0644\u062F\u0641\u0639",
  "Payment provider": "\u0645\u0632\u0648\u0651\u062F \u0627\u0644\u062F\u0641\u0639",
  "Publisher balance": "\u0631\u0635\u064A\u062F \u0627\u0644\u0646\u0627\u0634\u0631",
  "Publisher owes Nashr": "\u0645\u0633\u062A\u062D\u0642 \u0639\u0644\u0649 \u0627\u0644\u0646\u0627\u0634\u0631 \u0644\u0646\u0634\u0631",
  "Card processing fees": "\u0631\u0633\u0648\u0645 \u0645\u0639\u0627\u0644\u062C\u0629 \u0627\u0644\u0628\u0637\u0627\u0642\u0627\u062A",
  "Nashr losses": "\u062E\u0633\u0627\u0626\u0631 \u0646\u0634\u0631",
  "Nashr decision on a dispute": "\u0642\u0631\u0627\u0631 \u0646\u0634\u0631 \u0641\u064A \u0627\u0644\u0646\u0632\u0627\u0639",
  "Terms version": "\u0646\u0633\u062E\u0629 \u0627\u0644\u0634\u0631\u0648\u0637",
  "date of the current terms": "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0634\u0631\u0648\u0637 \u0627\u0644\u062D\u0627\u0644\u064A\u0629",
  "capped by the creative deadline": "\u0628\u062D\u062F \u0623\u0642\u0635\u0649 \u0645\u0648\u0639\u062F \u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  "Sent": "\u0623\u064F\u0631\u0633\u0644",
  "Week layout": "\u0639\u0631\u0636 \u0627\u0644\u0623\u0633\u0628\u0648\u0639",
  "By programme": "\u062D\u0633\u0628 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C",
  "By time": "\u062D\u0633\u0628 \u0627\u0644\u0648\u0642\u062A",
  "Show only": "\u0639\u0631\u0636 \u0641\u0642\u0637",
  "None in this period": "\u0644\u0627 \u0634\u064A\u0621 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0641\u062A\u0631\u0629",
  "{n} to decide": "{n} \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0642\u0631\u0627\u0631\u0643",
  "{sold} of {n} booked": "{sold} \u0645\u0646 {n} \u0645\u062D\u062C\u0648\u0632",
  "with bids": "\u0639\u0644\u064A\u0647\u0627 \u0639\u0631\u0648\u0636",
  "on sale": "\u0645\u0639\u0631\u0648\u0636\u0629 \u0644\u0644\u0628\u064A\u0639",
  "booked": "\u0645\u062D\u062C\u0648\u0632",
  "With bids": "\u0639\u0644\u064A\u0647\u0627 \u0639\u0631\u0648\u0636",
  "Still on sale": "\u0645\u0627 \u0632\u0627\u0644\u062A \u0645\u0639\u0631\u0648\u0636\u0629",
  "{amount} offered": "{amount} \u0645\u0639\u0631\u0648\u0636\u0629 \u0639\u0644\u064A\u0643",
  "{amount} in top bids": "{amount} \u0623\u0639\u0644\u0649 \u0627\u0644\u0639\u0631\u0648\u0636",
  "{amount} booked": "{amount} \u0645\u062D\u062C\u0648\u0632\u0629",
  "{amount} at starting prices": "{amount} \u0628\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0628\u062F\u0627\u064A\u0629",
  "In your plan": "\u0641\u064A \u062E\u0637\u062A\u0643",
  "Add to plan": "\u0623\u0636\u0641 \u0625\u0644\u0649 \u0627\u0644\u062E\u0637\u0629",
  "Your plan": "\u062E\u0637\u062A\u0643",
  "Plan": "\u0627\u0644\u062E\u0637\u0629",
  "Collect slots from any outlet, check the total, then send them together.": "\u0627\u062C\u0645\u0639 \u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F \u0645\u0646 \u0623\u064A \u0648\u0633\u064A\u0644\u0629\u060C \u0631\u0627\u062C\u0639 \u0627\u0644\u0645\u062C\u0645\u0648\u0639\u060C \u062B\u0645 \u0623\u0631\u0633\u0644\u0647\u0627 \u0645\u0639\u0627\u064B.",
  'Your plan is empty. Open a slot in the calendar and press "Add to plan".': "\u062E\u0637\u062A\u0643 \u0641\u0627\u0631\u063A\u0629. \u0627\u0641\u062A\u062D \u0645\u0648\u0639\u062F\u0627\u064B \u0641\u064A \u0627\u0644\u062A\u0642\u0648\u064A\u0645 \u0648\u0627\u0636\u063A\u0637 \xAB\u0623\u0636\u0641 \u0625\u0644\u0649 \u0627\u0644\u062E\u0637\u0629\xBB.",
  "This slot is no longer on sale.": "\u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0639\u062F \u0644\u0645 \u064A\u0639\u062F \u0645\u0639\u0631\u0648\u0636\u0627\u064B \u0644\u0644\u0628\u064A\u0639.",
  "Open this slot": "\u0627\u0641\u062A\u062D \u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0639\u062F",
  "No longer on sale": "\u0644\u0645 \u064A\u0639\u062F \u0645\u0639\u0631\u0648\u0636\u0627\u064B",
  "Remove from plan": "\u0625\u0632\u0627\u0644\u0629 \u0645\u0646 \u0627\u0644\u062E\u0637\u0629",
  "Excluding VAT, at today's prices": "\u063A\u064A\u0631 \u0634\u0627\u0645\u0644 \u0627\u0644\u0636\u0631\u064A\u0628\u0629\u060C \u0628\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u064A\u0648\u0645",
  "{amount} over what is left in this budget ({left}).": "{amount} \u0641\u0648\u0642 \u0627\u0644\u0645\u062A\u0628\u0642\u064A \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629 ({left}).",
  "{amount} of the {left} left in this budget.": "{amount} \u0645\u0646 \u0623\u0635\u0644 {left} \u0645\u062A\u0628\u0642\u064A\u0629 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629.",
  "One brief for all of them": "\u0645\u0648\u062C\u0632 \u0648\u0627\u062D\u062F \u0644\u0647\u0627 \u0643\u0644\u0647\u0627",
  "Auctions get a bid at the minimum next bid, fixed prices are booked, quick sales get your interest at the asking price. Bids are binding. You pay only when a publisher accepts.": "\u0627\u0644\u0645\u0632\u0627\u062F\u0627\u062A \u064A\u064F\u0642\u062F\u064E\u0651\u0645 \u0641\u064A\u0647\u0627 \u0639\u0631\u0636 \u0628\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u062F\u0646\u0649 \u0627\u0644\u062A\u0627\u0644\u064A\u060C \u0648\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u062B\u0627\u0628\u062A\u0629 \u062A\u064F\u062D\u062C\u0632\u060C \u0648\u0627\u0644\u0628\u064A\u0639 \u0627\u0644\u0633\u0631\u064A\u0639 \u064A\u064F\u0631\u0633\u0644 \u0641\u064A\u0647 \u0627\u0647\u062A\u0645\u0627\u0645\u0643 \u0628\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0645\u0637\u0644\u0648\u0628. \u0627\u0644\u0639\u0631\u0648\u0636 \u0645\u0644\u0632\u0645\u0629. \u062A\u062F\u0641\u0639 \u0641\u0642\u0637 \u0639\u0646\u062F\u0645\u0627 \u064A\u0648\u0627\u0641\u0642 \u0627\u0644\u0646\u0627\u0634\u0631.",
  "All sent.": "\u0623\u064F\u0631\u0633\u0644\u062A \u0643\u0644\u0647\u0627.",
  "See them in Bookings": "\u0634\u0627\u0647\u062F\u0647\u0627 \u0641\u064A \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A",
  "Add the advertiser and what the ad will say.": "\u0623\u0636\u0641 \u0627\u0644\u0645\u0639\u0644\u0646 \u0648\u0645\u0627 \u0633\u064A\u0642\u0648\u0644\u0647 \u0627\u0644\u0625\u0639\u0644\u0627\u0646.",
  "{n} left as they were (they have bids, are packages, or are already that way).": "{n} \u0628\u0642\u064A\u062A \u0643\u0645\u0627 \u0647\u064A (\u0639\u0644\u064A\u0647\u0627 \u0639\u0631\u0648\u0636\u060C \u0623\u0648 \u0628\u0627\u0642\u0627\u062A\u060C \u0623\u0648 \u0647\u064A \u0643\u0630\u0644\u0643 \u0623\u0635\u0644\u0627\u064B).",
  "Repeated: {n} new slots on sale over the next {w} weeks.": "\u062A\u0645 \u0627\u0644\u062A\u0643\u0631\u0627\u0631: {n} \u0645\u0648\u0639\u062F\u0627\u064B \u062C\u062F\u064A\u062F\u0627\u064B \u0645\u0639\u0631\u0648\u0636\u0627\u064B \u0644\u0644\u0628\u064A\u0639 \u062E\u0644\u0627\u0644 {w} \u0623\u0633\u0627\u0628\u064A\u0639 \u0642\u0627\u062F\u0645\u0629.",
  "Nothing new went on sale: those weeks are already listed.": "\u0644\u0645 \u064A\u064F\u0639\u0631\u0636 \u0634\u064A\u0621 \u062C\u062F\u064A\u062F: \u062A\u0644\u0643 \u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0645\u0639\u0631\u0648\u0636\u0629 \u0623\u0635\u0644\u0627\u064B.",
  "Done selecting": "\u0627\u0646\u062A\u0647\u064A\u062A \u0645\u0646 \u0627\u0644\u062A\u062D\u062F\u064A\u062F",
  "Select": "\u062A\u062D\u062F\u064A\u062F",
  "Repeat this week": "\u0643\u0631\u0651\u0631 \u0647\u0630\u0627 \u0627\u0644\u0623\u0633\u0628\u0648\u0639",
  "Everything listed in {range} goes on sale again on the same days, at each programme's current price. Weeks already listed are left alone.": "\u0643\u0644 \u0645\u0627 \u0647\u0648 \u0645\u0639\u0631\u0648\u0636 \u0641\u064A {range} \u064A\u064F\u0639\u0631\u0636 \u0644\u0644\u0628\u064A\u0639 \u0645\u062C\u062F\u062F\u0627\u064B \u0641\u064A \u0627\u0644\u0623\u064A\u0627\u0645 \u0646\u0641\u0633\u0647\u0627\u060C \u0628\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u062D\u0627\u0644\u064A \u0644\u0643\u0644 \u0628\u0631\u0646\u0627\u0645\u062C. \u0627\u0644\u0623\u0633\u0627\u0628\u064A\u0639 \u0627\u0644\u0645\u0639\u0631\u0648\u0636\u0629 \u0623\u0635\u0644\u0627\u064B \u062A\u0628\u0642\u0649 \u0643\u0645\u0627 \u0647\u064A.",
  "Repeat": "\u0643\u0631\u0651\u0631",
  "Change the selected slots": "\u062A\u063A\u064A\u064A\u0631 \u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F \u0627\u0644\u0645\u062D\u062F\u062F\u0629",
  "Press breaks, a programme name or a day to select.": "\u0627\u0636\u063A\u0637 \u0639\u0644\u0649 \u0627\u0644\u0641\u0648\u0627\u0635\u0644 \u0623\u0648 \u0627\u0633\u0645 \u0628\u0631\u0646\u0627\u0645\u062C \u0623\u0648 \u064A\u0648\u0645 \u0644\u0644\u062A\u062D\u062F\u064A\u062F.",
  "New price (AED)": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u062C\u062F\u064A\u062F (\u062F\u0631\u0647\u0645)",
  "Set price": "\u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0633\u0639\u0631",
  "Done": "\u062A\u0645",
  "Select {day}": "\u062D\u062F\u062F {day}",
  "1 slot changed.": "\u062A\u0645 \u062A\u063A\u064A\u064A\u0631 \u0645\u0648\u0639\u062F \u0648\u0627\u062D\u062F.",
  "{n} slots changed.": "\u062A\u0645 \u062A\u063A\u064A\u064A\u0631 {n} \u0645\u0648\u0639\u062F\u0627\u064B.",
  "1 selected": "\u0645\u062D\u062F\u062F \u0648\u0627\u062D\u062F",
  "{n} selected": "{n} \u0645\u062D\u062F\u062F\u0629",
  "Next week": "\u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u0627\u0644\u0642\u0627\u062F\u0645",
  "Bid placed": "\u062A\u0645 \u062A\u0642\u062F\u064A\u0645 \u0627\u0644\u0639\u0631\u0636",
  "Interest sent": "\u0623\u064F\u0631\u0633\u0644 \u0627\u0644\u0627\u0647\u062A\u0645\u0627\u0645",
  "minimum bid": "\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u062F\u0646\u0649 \u0644\u0644\u0639\u0631\u0636",
  "asking price": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0645\u0637\u0644\u0648\u0628",
  "1 slot to send": "\u0645\u0648\u0639\u062F \u0648\u0627\u062D\u062F \u0644\u0644\u0625\u0631\u0633\u0627\u0644",
  "{n} slots to send": "{n} \u0645\u0648\u0627\u0639\u064A\u062F \u0644\u0644\u0625\u0631\u0633\u0627\u0644",
  "Send 1 slot \xB7 {amount}": "\u0623\u0631\u0633\u0644 \u0645\u0648\u0639\u062F\u0627\u064B \u0648\u0627\u062D\u062F\u0627\u064B \xB7 {amount}",
  "Send all {n} \xB7 {amount}": "\u0623\u0631\u0633\u0644 \u0627\u0644\u0643\u0644 {n} \xB7 {amount}",
  "Sending\u2026": "\u062C\u0627\u0631\u064D \u0627\u0644\u0625\u0631\u0633\u0627\u0644\u2026",
  "This page does not exist, or it has moved.": "\u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u062D\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629 \u0623\u0648 \u062A\u0645 \u0646\u0642\u0644\u0647\u0627.",
  "Example week and booking": "\u0645\u062B\u0627\u0644 \u0644\u0623\u0633\u0628\u0648\u0639 \u0648\u062D\u062C\u0632",
  "Plan total against your budget": "\u0645\u062C\u0645\u0648\u0639 \u0627\u0644\u062E\u0637\u0629 \u0645\u0642\u0627\u0628\u0644 \u0645\u064A\u0632\u0627\u0646\u064A\u062A\u0643",
  "Released to you after proof": "\u064A\u064F\u062D\u0648\u064E\u0651\u0644 \u0625\u0644\u064A\u0643 \u0628\u0639\u062F \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "Every slot and price is open to browse": "\u0643\u0644 \u0645\u0648\u0639\u062F \u0648\u0633\u0639\u0631 \u0645\u062A\u0627\u062D \u0644\u0644\u062A\u0635\u0641\u062D",
  "You pay only when a publisher accepts": "\u062A\u062F\u0641\u0639 \u0641\u0642\u0637 \u0639\u0646\u062F\u0645\u0627 \u064A\u0648\u0627\u0641\u0642 \u0627\u0644\u0646\u0627\u0634\u0631",
  "Your money is held until the ad has run": "\u0623\u0645\u0648\u0627\u0644\u0643 \u0645\u062D\u0641\u0648\u0638\u0629 \u062D\u062A\u0649 \u064A\u064F\u0639\u0631\u0636 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  "Back to home": "\u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629",
  "You are browsing as a guest.": "\u0623\u0646\u062A \u062A\u062A\u0635\u0641\u062D \u0643\u0632\u0627\u0626\u0631.",
  "Every slot and price is open to read. Sign in to bid or book.": "\u0643\u0644 \u0645\u0648\u0639\u062F \u0648\u0633\u0639\u0631 \u0645\u062A\u0627\u062D \u0644\u0644\u0642\u0631\u0627\u0621\u0629. \u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0644\u062A\u0642\u062F\u064A\u0645 \u0639\u0631\u0636 \u0623\u0648 \u0644\u0644\u062D\u062C\u0632.",
  "This week": "\u0647\u0630\u0627 \u0627\u0644\u0623\u0633\u0628\u0648\u0639",
  "Book": "\u0627\u062D\u062C\u0632",
  "Bid": "\u0642\u062F\u0651\u0645 \u0639\u0631\u0636\u0627\u064B",
  "Bidding closes {when}": "\u062A\u064F\u063A\u0644\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 {when}",
  "Anything else buyers should know": "\u0623\u064A \u0634\u064A\u0621 \u0622\u062E\u0631 \u064A\u0646\u0628\u063A\u064A \u0623\u0646 \u064A\u0639\u0631\u0641\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646",
  "Show less": "\u0627\u0639\u0631\u0636 \u0623\u0642\u0644",
  "Show all": "\u0627\u0639\u0631\u0636 \u0627\u0644\u0643\u0644",
  "Add an outlet and a product first; then list it here.": "\u0623\u0636\u0641 \u0645\u0646\u0641\u0630\u064B\u0627 \u0648\u0645\u0646\u062A\u062C\u064B\u0627 \u0623\u0648\u0644\u064B\u0627\u060C \u062B\u0645 \u0627\u0639\u0631\u0636\u0647 \u0644\u0644\u0628\u064A\u0639 \u0647\u0646\u0627.",
  "Add a product": "\u0623\u0636\u0641 \u0645\u0646\u062A\u062C\u064B\u0627",
  "For example: Skyline FM Radio": "\u0645\u062B\u0627\u0644: \u0625\u0630\u0627\u0639\u0629 \u0633\u0643\u0627\u064A \u0644\u0627\u064A\u0646 \u0625\u0641 \u0625\u0645",
  "You'll add each programme after saving.": "\u0633\u062A\u0636\u064A\u0641 \u0643\u0644 \u0628\u0631\u0646\u0627\u0645\u062C \u0628\u0639\u062F \u0627\u0644\u062D\u0641\u0638.",
  "Left empty, they come from the product: {price}, creative {c} days and bidding {b} days before.": "\u0625\u0646 \u062A\u064F\u0631\u0643\u062A \u0641\u0627\u0631\u063A\u0629 \u062A\u0624\u062E\u0630 \u0645\u0646 \u0627\u0644\u0645\u0646\u062A\u062C: {price}\u060C \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0642\u0628\u0644 {c} \u0623\u064A\u0627\u0645 \u0648\u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0642\u0628\u0644 {b} \u0623\u064A\u0627\u0645.",
  "{n} days before it runs": "\u0642\u0628\u0644 {n} \u0623\u064A\u0627\u0645 \u0645\u0646 \u0627\u0644\u0639\u0631\u0636",
  "Default price": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A",
  "Outlet saved.": "\u062A\u0645 \u062D\u0641\u0638 \u0627\u0644\u0645\u0646\u0641\u0630.",
  "The outlet is your brand. Add each product it sells; for radio, TV and podcasts, add programmes if you sell by show.": "\u0627\u0644\u0645\u0646\u0641\u0630 \u0647\u0648 \u0639\u0644\u0627\u0645\u062A\u0643 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629. \u0623\u0636\u0641 \u0643\u0644 \u0645\u0646\u062A\u062C \u064A\u0628\u064A\u0639\u0647\u061B \u0648\u0644\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A \u0623\u0636\u0641 \u0627\u0644\u0628\u0631\u0627\u0645\u062C \u0625\u0646 \u0643\u0646\u062A \u062A\u0628\u064A\u0639 \u062D\u0633\u0628 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C.",
  "1. Outlet": "1. \u0627\u0644\u0645\u0646\u0641\u0630",
  "Edit outlet": "\u0639\u062F\u0651\u0644 \u0627\u0644\u0645\u0646\u0641\u0630",
  "You can add the logo (JPG or PNG) as soon as the outlet is saved. Until then buyers see its initials.": "\u064A\u0645\u0643\u0646\u0643 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0634\u0639\u0627\u0631 (JPG \u0623\u0648 PNG) \u0641\u0648\u0631 \u062D\u0641\u0638 \u0627\u0644\u0645\u0646\u0641\u0630. \u062D\u062A\u0649 \u0630\u0644\u0643 \u0627\u0644\u062D\u064A\u0646 \u064A\u0631\u0649 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0627\u0644\u0623\u062D\u0631\u0641 \u0627\u0644\u0623\u0648\u0644\u0649 \u0645\u0646 \u0627\u0633\u0645\u0647.",
  "Save outlet": "\u0627\u062D\u0641\u0638 \u0627\u0644\u0645\u0646\u0641\u0630",
  "Save and add products": "\u0627\u062D\u0641\u0638 \u0648\u0623\u0636\u0641 \u0627\u0644\u0645\u0646\u062A\u062C\u0627\u062A",
  "2. Products": "2. \u0627\u0644\u0645\u0646\u062A\u062C\u0627\u062A",
  "No products yet. Add the first one: a radio station, a TV channel, a newspaper, a magazine, a website, a newsletter, a podcast or a social media account.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0646\u062A\u062C\u0627\u062A \u0628\u0639\u062F. \u0623\u0636\u0641 \u0627\u0644\u0623\u0648\u0644: \u0625\u0630\u0627\u0639\u0629 \u0623\u0648 \u0642\u0646\u0627\u0629 \u062A\u0644\u0641\u0632\u064A\u0648\u0646\u064A\u0629 \u0623\u0648 \u0635\u062D\u064A\u0641\u0629 \u0623\u0648 \u0645\u062C\u0644\u0629 \u0623\u0648 \u0645\u0648\u0642\u0639 \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0648 \u0646\u0634\u0631\u0629 \u0628\u0631\u064A\u062F\u064A\u0629 \u0623\u0648 \u0628\u0648\u062F\u0643\u0627\u0633\u062A \u0623\u0648 \u062D\u0633\u0627\u0628 \u0639\u0644\u0649 \u0648\u0633\u0627\u0626\u0644 \u0627\u0644\u062A\u0648\u0627\u0635\u0644.",
  "Each outlet with its products, programmes and what is on sale. Add the details once; list them for the dates you choose.": "\u0643\u0644 \u0645\u0646\u0641\u0630 \u0628\u0645\u0646\u062A\u062C\u0627\u062A\u0647 \u0648\u0628\u0631\u0627\u0645\u062C\u0647 \u0648\u0645\u0627 \u0647\u0648 \u0645\u0639\u0631\u0648\u0636 \u0644\u0644\u0628\u064A\u0639. \u0623\u0636\u0641 \u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \u0648\u0627\u0639\u0631\u0636\u0647\u0627 \u0644\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u064A \u062A\u062E\u062A\u0627\u0631\u0647\u0627.",
  "Add your first outlet": "\u0623\u0636\u0641 \u0645\u0646\u0641\u0630\u0643 \u0627\u0644\u0623\u0648\u0644",
  "An outlet is your brand, for example Skyline FM. Under it, add each product it sells (its radio station, its website, its newsletter\u2026) and, for radio, TV and podcasts, its programmes. Then list them for the dates you choose.": "\u0627\u0644\u0645\u0646\u0641\u0630 \u0647\u0648 \u0639\u0644\u0627\u0645\u062A\u0643 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629\u060C \u0645\u062B\u0644 \u0633\u0643\u0627\u064A \u0644\u0627\u064A\u0646 \u0625\u0641 \u0625\u0645. \u0623\u0636\u0641 \u062A\u062D\u062A\u0647 \u0643\u0644 \u0645\u0646\u062A\u062C \u064A\u0628\u064A\u0639\u0647 (\u0625\u0630\u0627\u0639\u062A\u0647\u060C \u0645\u0648\u0642\u0639\u0647\u060C \u0646\u0634\u0631\u062A\u0647 \u0627\u0644\u0628\u0631\u064A\u062F\u064A\u0629\u2026) \u0648\u0644\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A \u0628\u0631\u0627\u0645\u062C\u0647. \u062B\u0645 \u0627\u0639\u0631\u0636\u0647\u0627 \u0644\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u064A \u062A\u062E\u062A\u0627\u0631\u0647\u0627.",
  "Top products": "\u0623\u0628\u0631\u0632 \u0627\u0644\u0645\u0646\u062A\u062C\u0627\u062A",
  "No products yet. Open the outlet to add the first one.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0646\u062A\u062C\u0627\u062A \u0628\u0639\u062F. \u0627\u0641\u062A\u062D \u0627\u0644\u0645\u0646\u0641\u0630 \u0644\u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0623\u0648\u0644.",
  "outlet": "\u0645\u0646\u0641\u0630",
  "outlets": "\u0645\u0646\u0627\u0641\u0630",
  "product": "\u0645\u0646\u062A\u062C",
  "1 programme": "\u0628\u0631\u0646\u0627\u0645\u062C \u0648\u0627\u062D\u062F",
  "{n} programmes": "{n} \u0628\u0631\u0627\u0645\u062C",
  "Logo chosen. It is saved with the outlet.": "\u062A\u0645 \u0627\u062E\u062A\u064A\u0627\u0631 \u0627\u0644\u0634\u0639\u0627\u0631. \u064A\u064F\u062D\u0641\u0638 \u0645\u0639 \u0627\u0644\u0645\u0646\u0641\u0630.",
  "Pick the product": "\u0627\u062E\u062A\u0631 \u0627\u0644\u0645\u0646\u062A\u062C",
  "{n} products": "{n} \u0645\u0646\u062A\u062C\u0627\u062A",
  "1 slot": "\u0645\u0633\u0627\u062D\u0629 \u0648\u0627\u062D\u062F\u0629",
  "Add an outlet and a product first; then import your rate card.": "\u0623\u0636\u0641 \u0645\u0646\u0641\u0630\u064B\u0627 \u0648\u0645\u0646\u062A\u062C\u064B\u0627 \u0623\u0648\u0644\u064B\u0627\u060C \u062B\u0645 \u0627\u0633\u062A\u0648\u0631\u062F \u0642\u0627\u0626\u0645\u0629 \u0623\u0633\u0639\u0627\u0631\u0643.",
  'Product "{name}" was not found in this outlet.': "\u0644\u0645 \u064A\u064F\u0639\u062B\u0631 \u0639\u0644\u0649 \u0627\u0644\u0645\u0646\u062A\u062C \xAB{name}\xBB \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u0645\u0646\u0641\u0630.",
  "This outlet has several products. Say which one in the product column.": "\u0644\u0647\u0630\u0627 \u0627\u0644\u0645\u0646\u0641\u0630 \u0639\u062F\u0629 \u0645\u0646\u062A\u062C\u0627\u062A. \u062D\u062F\u0651\u062F \u0627\u0644\u0645\u0642\u0635\u0648\u062F \u0641\u064A \u0639\u0645\u0648\u062F \u0627\u0644\u0645\u0646\u062A\u062C.",
  "This product is sold by programme. Add the programme name.": "\u0647\u0630\u0627 \u0627\u0644\u0645\u0646\u062A\u062C \u064A\u064F\u0628\u0627\u0639 \u062D\u0633\u0628 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C. \u0623\u0636\u0641 \u0627\u0633\u0645 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C.",
  "This product has nothing to list yet. Open it and save its details first.": "\u0644\u0627 \u064A\u0648\u062C\u062F \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u0645\u0646\u062A\u062C \u0645\u0627 \u064A\u064F\u0639\u0631\u0636 \u0628\u0639\u062F. \u0627\u0641\u062A\u062D\u0647 \u0648\u0627\u062D\u0641\u0638 \u062A\u0641\u0627\u0635\u064A\u0644\u0647 \u0623\u0648\u0644\u064B\u0627.",
  "List the product": "\u0639\u0631\u0636 \u0627\u0644\u0645\u0646\u062A\u062C \u0644\u0644\u0628\u064A\u0639",
  "Only Radio, TV and Podcast have programmes.": "\u0627\u0644\u0628\u0631\u0627\u0645\u062C \u0644\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A \u0641\u0642\u0637.",
  "List the programme": "\u0639\u0631\u0636 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C \u0644\u0644\u0628\u064A\u0639",
  "A new programme needs its start and end time, like 07:30.": "\u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C \u0627\u0644\u062C\u062F\u064A\u062F \u064A\u062D\u062A\u0627\u062C \u0648\u0642\u062A \u0627\u0644\u0628\u062F\u0627\u064A\u0629 \u0648\u0627\u0644\u0646\u0647\u0627\u064A\u0629\u060C \u0645\u062B\u0644 07:30.",
  "A new programme needs its break times, like 07:30;08:30.": "\u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C \u0627\u0644\u062C\u062F\u064A\u062F \u064A\u062D\u062A\u0627\u062C \u0623\u0648\u0642\u0627\u062A \u0627\u0644\u0641\u0648\u0627\u0635\u0644\u060C \u0645\u062B\u0644 07:30;08:30.",
  "Add the programme and list it": "\u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C \u0648\u0639\u0631\u0636\u0647 \u0644\u0644\u0628\u064A\u0639",
  "Programme added. List it once your payout account is verified.": "\u0623\u064F\u0636\u064A\u0641 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C. \u0627\u0639\u0631\u0636\u0647 \u0644\u0644\u0628\u064A\u0639 \u0628\u0639\u062F \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0633\u0627\u0628 \u0627\u0644\u062F\u0641\u0639\u0627\u062A.",
  "Not listed: slots can go on sale once your payout account is verified.": "\u0644\u0645 \u064A\u064F\u0639\u0631\u0636: \u062A\u064F\u0639\u0631\u0636 \u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F \u0644\u0644\u0628\u064A\u0639 \u0628\u0639\u062F \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0633\u0627\u0628 \u0627\u0644\u062F\u0641\u0639\u0627\u062A.",
  "Programme added.": "\u0623\u064F\u0636\u064A\u0641 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C.",
  "{n} slots on sale.": "{n} \u0645\u0648\u0639\u062F\u064B\u0627 \u0645\u0639\u0631\u0648\u0636\u064B\u0627 \u0644\u0644\u0628\u064A\u0639.",
  "Already on sale for these dates; price and way of selling updated.": "\u0645\u0639\u0631\u0648\u0636 \u0644\u0644\u0628\u064A\u0639 \u0623\u0635\u0644\u064B\u0627 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E\u061B \u062D\u064F\u062F\u0651\u062B \u0627\u0644\u0633\u0639\u0631 \u0648\u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u0628\u064A\u0639.",
  "List many programmes and products at once from a spreadsheet saved as CSV. Each row goes on sale and is kept on sale 8 weeks ahead; you can change any of them afterwards.": "\u0627\u0639\u0631\u0636 \u0628\u0631\u0627\u0645\u062C \u0648\u0645\u0646\u062A\u062C\u0627\u062A \u0643\u062B\u064A\u0631\u0629 \u062F\u0641\u0639\u0629 \u0648\u0627\u062D\u062F\u0629 \u0645\u0646 \u062C\u062F\u0648\u0644 \u0645\u062D\u0641\u0648\u0638 \u0628\u0635\u064A\u063A\u0629 CSV. \u0643\u0644 \u0635\u0641 \u064A\u064F\u0639\u0631\u0636 \u0644\u0644\u0628\u064A\u0639 \u0648\u064A\u0628\u0642\u0649 \u0645\u0639\u0631\u0648\u0636\u064B\u0627 8 \u0623\u0633\u0627\u0628\u064A\u0639 \u0642\u0627\u062F\u0645\u0629\u060C \u0648\u064A\u0645\u0643\u0646\u0643 \u062A\u0639\u062F\u064A\u0644 \u0623\u064A \u0645\u0646\u0647\u0627 \u0644\u0627\u062D\u0642\u064B\u0627.",
  "The file lists products you already have. Add an outlet and its products first; then import your rate card.": "\u0627\u0644\u0645\u0644\u0641 \u064A\u0639\u0631\u0636 \u0645\u0646\u062A\u062C\u0627\u062A \u0645\u0648\u062C\u0648\u062F\u0629 \u0644\u062F\u064A\u0643. \u0623\u0636\u0641 \u0645\u0646\u0641\u0630\u064B\u0627 \u0648\u0645\u0646\u062A\u062C\u0627\u062A\u0647 \u0623\u0648\u0644\u064B\u0627\u060C \u062B\u0645 \u0627\u0633\u062A\u0648\u0631\u062F \u0642\u0627\u0626\u0645\u0629 \u0623\u0633\u0639\u0627\u0631\u0643.",
  "Your brand, as on the Products page.": "\u0639\u0644\u0627\u0645\u062A\u0643 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629\u060C \u0643\u0645\u0627 \u0641\u064A \u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0646\u062A\u062C\u0627\u062A.",
  "What the outlet sells: its radio station, newspaper or website.": "\u0645\u0627 \u064A\u0628\u064A\u0639\u0647 \u0627\u0644\u0645\u0646\u0641\u0630: \u0625\u0630\u0627\u0639\u062A\u0647 \u0623\u0648 \u0635\u062D\u064A\u0641\u062A\u0647 \u0623\u0648 \u0645\u0648\u0642\u0639\u0647.",
  "For radio, TV and podcasts. A new name adds the programme; leave it empty to list the product itself.": "\u0644\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A. \u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u062C\u062F\u064A\u062F \u064A\u0636\u064A\u0641 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C\u061B \u0627\u062A\u0631\u0643\u0647 \u0641\u0627\u0631\u063A\u064B\u0627 \u0644\u0639\u0631\u0636 \u0627\u0644\u0645\u0646\u062A\u062C \u0646\u0641\u0633\u0647.",
  "Your payout account is not verified yet, so programmes are added but nothing goes on sale.": "\u0644\u0645 \u064A\u064F\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0633\u0627\u0628 \u0627\u0644\u062F\u0641\u0639\u0627\u062A \u0628\u0639\u062F\u060C \u0644\u0630\u0627 \u062A\u064F\u0636\u0627\u0641 \u0627\u0644\u0628\u0631\u0627\u0645\u062C \u0648\u0644\u0627 \u064A\u064F\u0639\u0631\u0636 \u0634\u064A\u0621 \u0644\u0644\u0628\u064A\u0639.",
  "{n} to fix in the file": "{n} \u062A\u062D\u062A\u0627\u062C \u062A\u0635\u062D\u064A\u062D\u064B\u0627 \u0641\u064A \u0627\u0644\u0645\u0644\u0641",
  "{n} imported": "\u062A\u0645 \u0627\u0633\u062A\u064A\u0631\u0627\u062F {n}",
  "Product or programme": "\u0627\u0644\u0645\u0646\u062A\u062C \u0623\u0648 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C",
  "What happens": "\u0645\u0627 \u0633\u064A\u062D\u062F\u062B",
  "Import 1 row": "\u0627\u0633\u062A\u0648\u0631\u062F \u0635\u0641\u064B\u0627 \u0648\u0627\u062D\u062F\u064B\u0627",
  "Import {n} rows": "\u0627\u0633\u062A\u0648\u0631\u062F {n} \u0635\u0641\u0648\u0641",
  "Go to Products": "\u0627\u0630\u0647\u0628 \u0625\u0644\u0649 \u0627\u0644\u0645\u0646\u062A\u062C\u0627\u062A",
  "1 row": "\u0635\u0641 \u0648\u0627\u062D\u062F",
  "{n} rows": "{n} \u0635\u0641\u0648\u0641",
  "The programme was not added, so this row was not listed.": "\u0644\u0645 \u064A\u064F\u0636\u0641 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C\u060C \u0644\u0630\u0627 \u0644\u0645 \u064A\u064F\u0639\u0631\u0636 \u0647\u0630\u0627 \u0627\u0644\u0635\u0641 \u0644\u0644\u0628\u064A\u0639.",
  "Nothing left to import": "\u0644\u0627 \u0634\u064A\u0621 \u0622\u062E\u0631 \u0644\u0644\u0627\u0633\u062A\u064A\u0631\u0627\u062F",
  "Audience tags (optional)": "\u0648\u0633\u0648\u0645 \u0627\u0644\u062C\u0645\u0647\u0648\u0631 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Buyers filter the calendar by these, and the product shows on the matching Audiences pages.": "\u064A\u0635\u0641\u0651\u064A \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0627\u0644\u062A\u0642\u0648\u064A\u0645 \u0628\u0647\u0627\u060C \u0648\u064A\u0638\u0647\u0631 \u0627\u0644\u0645\u0646\u062A\u062C \u0641\u064A \u0635\u0641\u062D\u0627\u062A \u0627\u0644\u062C\u0645\u0627\u0647\u064A\u0631 \u0627\u0644\u0645\u0637\u0627\u0628\u0642\u0629.",
  "Audience tags": "\u0648\u0633\u0648\u0645 \u0627\u0644\u062C\u0645\u0647\u0648\u0631",
  "Advertisers not run": "\u0645\u0639\u0644\u0646\u0648\u0646 \u0644\u0627 \u064A\u064F\u0642\u0628\u0644\u0648\u0646",
  "Name in Arabic (optional)": "\u0627\u0644\u0627\u0633\u0645 \u0628\u0627\u0644\u0639\u0631\u0628\u064A\u0629 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Website (optional)": "\u0627\u0644\u0645\u0648\u0642\u0639 \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "The website must start with https:// or http://.": "\u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u0648\u0642\u0639 \u0628\u0640 https:// \u0623\u0648 http://.",
  "This product is sold through what you added before: {names}. Edit or list them from the product's row.": "\u0647\u0630\u0627 \u0627\u0644\u0645\u0646\u062A\u062C \u064A\u064F\u0628\u0627\u0639 \u0639\u0628\u0631 \u0645\u0627 \u0623\u0636\u0641\u062A\u0647 \u0633\u0627\u0628\u0642\u064B\u0627: {names}. \u0639\u062F\u0651\u0644\u0647\u0627 \u0623\u0648 \u0627\u0639\u0631\u0636\u0647\u0627 \u0644\u0644\u0628\u064A\u0639 \u0645\u0646 \u0635\u0641 \u0627\u0644\u0645\u0646\u062A\u062C.",
  "What it sells": "\u0645\u0627 \u064A\u0628\u064A\u0639\u0647",
  "Description (optional)": "\u0627\u0644\u0648\u0635\u0641 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "What the buyer gets (optional)": "\u0645\u0627 \u064A\u062D\u0635\u0644 \u0639\u0644\u064A\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u064A (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Creative specs (optional)": "\u0645\u0648\u0627\u0635\u0641\u0627\u062A \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "It runs on {days}.": "\u064A\u064F\u0646\u0634\u0631 \u0623\u064A\u0627\u0645 {days}.",
  "Dates already on sale with no bid take the new name, price and deadlines; a date someone has bid on keeps what they bid on.": "\u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0627\u0644\u0645\u0639\u0631\u0648\u0636\u0629 \u0644\u0644\u0628\u064A\u0639 \u0627\u0644\u062A\u064A \u0644\u0645 \u064A\u064F\u0642\u062F\u064E\u0651\u0645 \u0639\u0644\u064A\u0647\u0627 \u0639\u0631\u0636 \u062A\u0623\u062E\u0630 \u0627\u0644\u0627\u0633\u0645 \u0648\u0627\u0644\u0633\u0639\u0631 \u0648\u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F \u0627\u0644\u062C\u062F\u064A\u062F\u0629\u061B \u0648\u0627\u0644\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0630\u064A \u0642\u064F\u062F\u0651\u0645 \u0639\u0644\u064A\u0647 \u0639\u0631\u0636 \u064A\u0628\u0642\u0649 \u0643\u0645\u0627 \u0642\u064F\u062F\u0651\u0645 \u0639\u0644\u064A\u0647.",
  "Add the price.": "\u0623\u0636\u0641 \u0627\u0644\u0633\u0639\u0631.",
  "Add both deadlines.": "\u0623\u0636\u0641 \u0627\u0644\u0645\u0648\u0639\u062F\u064A\u0646.",
  "Saved. 1 date on sale was updated.": "\u062A\u0645 \u0627\u0644\u062D\u0641\u0638. \u062D\u064F\u062F\u0651\u062B \u062A\u0627\u0631\u064A\u062E \u0648\u0627\u062D\u062F \u0645\u0639\u0631\u0648\u0636 \u0644\u0644\u0628\u064A\u0639.",
  "Saved. {n} dates on sale were updated.": "\u062A\u0645 \u0627\u0644\u062D\u0641\u0638. \u062D\u064F\u062F\u0651\u062B {n} \u0645\u0646 \u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0627\u0644\u0645\u0639\u0631\u0648\u0636\u0629 \u0644\u0644\u0628\u064A\u0639.",
  "Logo saved. Publishers see it now.": "\u062A\u0645 \u062D\u0641\u0638 \u0627\u0644\u0634\u0639\u0627\u0631. \u064A\u0631\u0627\u0647 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0627\u0644\u0622\u0646.",
  "Publishers that do not run ads for your industry are told before they decide.": "\u064A\u064F\u0628\u0644\u064E\u0651\u063A \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0627\u0644\u0630\u064A\u0646 \u0644\u0627 \u064A\u0642\u0628\u0644\u0648\u0646 \u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0642\u0637\u0627\u0639\u0643 \u0642\u0628\u0644 \u0623\u0646 \u064A\u0642\u0631\u0631\u0648\u0627.",
  "Bookings the publisher accepted, from payment to proof. Your payment is held until you approve that the ad ran.": "\u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u062A\u064A \u0642\u0628\u0644\u0647\u0627 \u0627\u0644\u0646\u0627\u0634\u0631\u060C \u0645\u0646 \u0627\u0644\u062F\u0641\u0639 \u062D\u062A\u0649 \u0625\u062B\u0628\u0627\u062A \u0627\u0644\u0646\u0634\u0631. \u062A\u0628\u0642\u0649 \u062F\u0641\u0639\u062A\u0643 \u0645\u062D\u0641\u0648\u0638\u0629 \u062D\u062A\u0649 \u062A\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u0623\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0646\u064F\u0634\u0631.",
  "Back to bookings": "\u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A",
  "Nothing is waiting for a publisher.": "\u0644\u0627 \u0634\u064A\u0621 \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0631\u062F \u0627\u0644\u0646\u0627\u0634\u0631.",
  "No bookings yet. Once a publisher accepts your bid or request, it shows here.": "\u0644\u0627 \u062D\u062C\u0648\u0632\u0627\u062A \u0628\u0639\u062F. \u0639\u0646\u062F\u0645\u0627 \u064A\u0642\u0628\u0644 \u0627\u0644\u0646\u0627\u0634\u0631 \u0639\u0631\u0636\u0643 \u0623\u0648 \u0637\u0644\u0628\u0643 \u064A\u0638\u0647\u0631 \u0647\u0646\u0627.",
  "Industry (optional)": "\u0627\u0644\u0642\u0637\u0627\u0639 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Billing email (optional)": "\u0628\u0631\u064A\u062F \u0627\u0644\u0641\u0648\u062A\u0631\u0629 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "For the client's receipts and report. Only your team sees it.": "\u0644\u0625\u064A\u0635\u0627\u0644\u0627\u062A \u0627\u0644\u0639\u0645\u064A\u0644 \u0648\u062A\u0642\u0631\u064A\u0631\u0647. \u064A\u0631\u0627\u0647 \u0641\u0631\u064A\u0642\u0643 \u0641\u0642\u0637.",
  "This email address is not complete.": "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0628\u0631\u064A\u062F \u0647\u0630\u0627 \u063A\u064A\u0631 \u0645\u0643\u062A\u0645\u0644.",
  "Optional: book for each client and send it its own receipts and report. Picking a client is never required.": "\u0627\u062E\u062A\u064A\u0627\u0631\u064A: \u0627\u062D\u062C\u0632 \u0644\u0643\u0644 \u0639\u0645\u064A\u0644 \u0648\u0623\u0631\u0633\u0644 \u0644\u0647 \u0625\u064A\u0635\u0627\u0644\u0627\u062A\u0647 \u0648\u062A\u0642\u0631\u064A\u0631\u0647. \u0627\u062E\u062A\u064A\u0627\u0631 \u0639\u0645\u064A\u0644 \u0644\u064A\u0633 \u0645\u0637\u0644\u0648\u0628\u064B\u0627 \u0623\u0628\u062F\u064B\u0627.",
  "Logo saved.": "\u062A\u0645 \u062D\u0641\u0638 \u0627\u0644\u0634\u0639\u0627\u0631.",
  "Prices excl. VAT. Budgets are set on campaigns.": "\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0644\u0627 \u062A\u0634\u0645\u0644 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629. \u062A\u064F\u062D\u062F\u064E\u0651\u062F \u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0627\u062A \u0641\u064A \u0627\u0644\u062D\u0645\u0644\u0627\u062A.",
  "What needs you first, then your conversations with publishers.": "\u0645\u0627 \u064A\u062D\u062A\u0627\u062C\u0643 \u0623\u0648\u0644\u064B\u0627\u060C \u062B\u0645 \u0645\u062D\u0627\u062F\u062B\u0627\u062A\u0643 \u0645\u0639 \u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646.",
  "within {n} days": "\u062E\u0644\u0627\u0644 {n} \u0623\u064A\u0627\u0645",
  "within {n} hours": "\u062E\u0644\u0627\u0644 {n} \u0633\u0627\u0639\u0629",
  "within 1 hour": "\u062E\u0644\u0627\u0644 \u0633\u0627\u0639\u0629",
  "Nothing to do right now. Payments, creatives and proofs that need you will show here.": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u0637\u0644\u0648\u0628 \u0627\u0644\u0622\u0646. \u0633\u062A\u0638\u0647\u0631 \u0647\u0646\u0627 \u0627\u0644\u062F\u0641\u0639\u0627\u062A \u0648\u0627\u0644\u0645\u0648\u0627\u062F \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0648\u0625\u062B\u0628\u0627\u062A\u0627\u062A \u0627\u0644\u0646\u0634\u0631 \u0627\u0644\u062A\u064A \u062A\u062D\u062A\u0627\u062C\u0643.",
  "1 request is waiting for the publisher": "\u0637\u0644\u0628 \u0648\u0627\u062D\u062F \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0631\u062F \u0627\u0644\u0646\u0627\u0634\u0631",
  "{n} requests are waiting for the publisher": "{n} \u0645\u0646 \u0627\u0644\u0637\u0644\u0628\u0627\u062A \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0631\u062F \u0627\u0644\u0646\u0627\u0634\u0631",
  "Send creative": "\u0623\u0631\u0633\u0644 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Ran, check proof": "\u0646\u064F\u0634\u0631\u060C \u0631\u0627\u062C\u0639 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "Not paid in time": "\u0644\u0645 \u064A\u064F\u062F\u0641\u0639 \u0641\u064A \u0627\u0644\u0648\u0642\u062A",
  "File on record": "\u0645\u0644\u0641 \u0645\u062D\u0641\u0648\u0638",
  "Add the campaign name.": "\u0623\u0636\u0641 \u0627\u0633\u0645 \u0627\u0644\u062D\u0645\u0644\u0629.",
  "Add the start and end dates.": "\u0623\u0636\u0641 \u062A\u0627\u0631\u064A\u062E\u064A \u0627\u0644\u0628\u062F\u0627\u064A\u0629 \u0648\u0627\u0644\u0646\u0647\u0627\u064A\u0629.",
  "The end date must be on or after the start date.": "\u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0646\u0647\u0627\u064A\u0629 \u0641\u064A \u064A\u0648\u0645 \u0627\u0644\u0628\u062F\u0627\u064A\u0629 \u0623\u0648 \u0628\u0639\u062F\u0647.",
  "The budget must be a number above zero, or left empty.": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629 \u0631\u0642\u0645\u064B\u0627 \u0623\u0643\u0628\u0631 \u0645\u0646 \u0635\u0641\u0631\u060C \u0623\u0648 \u062A\u064F\u062A\u0631\u0643 \u0641\u0627\u0631\u063A\u0629.",
  "Add the advertiser or brand.": "\u0623\u0636\u0641 \u0627\u0644\u0645\u0639\u0644\u0646 \u0623\u0648 \u0627\u0644\u0639\u0644\u0627\u0645\u0629 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629.",
  "Choose the industry.": "\u0627\u062E\u062A\u0631 \u0627\u0644\u0642\u0637\u0627\u0639.",
  "Say what the ad will say.": "\u0627\u0643\u062A\u0628 \u0645\u0627 \u0633\u064A\u0642\u0648\u0644\u0647 \u0627\u0644\u0625\u0639\u0644\u0627\u0646.",
  "Say which language the creative is in.": "\u0627\u0630\u0643\u0631 \u0644\u063A\u0629 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  'Upload the creative or tick "Creative to follow".': "\u0627\u0631\u0641\u0639 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0623\u0648 \u0627\u062E\u062A\u0631 \xAB\u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0644\u0627\u062D\u0642\u064B\u0627\xBB.",
  "The landing page link must start with https://.": "\u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0631\u0627\u0628\u0637 \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0642\u0635\u0648\u062F\u0629 \u0628\u0640 https://.",
  "Edit campaign": "\u062A\u0639\u062F\u064A\u0644 \u0627\u0644\u062D\u0645\u0644\u0629",
  "The campaign": "\u0627\u0644\u062D\u0645\u0644\u0629",
  "Only your team sees these.": "\u0644\u0627 \u064A\u0631\u0649 \u0647\u0630\u0647 \u0625\u0644\u0627 \u0641\u0631\u064A\u0642\u0643.",
  "Q4 business cards launch": "\u0625\u0637\u0644\u0627\u0642 \u0628\u0637\u0627\u0642\u0627\u062A \u0627\u0644\u0623\u0639\u0645\u0627\u0644 \u0641\u064A \u0627\u0644\u0631\u0628\u0639 \u0627\u0644\u0631\u0627\u0628\u0639",
  "Client (optional)": "\u0627\u0644\u0639\u0645\u064A\u0644 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Publishers see the client as the advertiser.": "\u064A\u0631\u0649 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0627\u0644\u0639\u0645\u064A\u0644 \u0628\u0648\u0635\u0641\u0647 \u0627\u0644\u0645\u0639\u0644\u0646.",
  "Start date": "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0628\u062F\u0627\u064A\u0629",
  "End date": "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0646\u0647\u0627\u064A\u0629",
  "Yours only: publishers never see it.": "\u0644\u0643 \u0648\u062D\u062F\u0643: \u0644\u0627 \u064A\u0631\u0627\u0647\u0627 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0623\u0628\u062F\u064B\u0627.",
  "Objective (optional)": "\u0627\u0644\u0647\u062F\u0641 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Campaign brief": "\u0645\u0644\u062E\u0635 \u0627\u0644\u062D\u0645\u0644\u0629",
  "Filled in once and sent with every bid or request in this campaign. Publishers see it before they decide.": "\u064A\u064F\u0645\u0644\u0623 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \u0648\u064A\u064F\u0631\u0633\u0644 \u0645\u0639 \u0643\u0644 \u0639\u0631\u0636 \u0623\u0648 \u0637\u0644\u0628 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u062D\u0645\u0644\u0629. \u064A\u0631\u0627\u0647 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0642\u0628\u0644 \u0623\u0646 \u064A\u0642\u0631\u0631\u0648\u0627.",
  "Which language": "\u0623\u064A \u0644\u063A\u0629",
  "Replace file": "\u0627\u0633\u062A\u0628\u062F\u0627\u0644 \u0627\u0644\u0645\u0644\u0641",
  "Upload a file": "\u0631\u0641\u0639 \u0645\u0644\u0641",
  "Required disclaimer or licence number (optional)": "\u0625\u062E\u0644\u0627\u0621 \u0627\u0644\u0645\u0633\u0624\u0648\u0644\u064A\u0629 \u0627\u0644\u0645\u0637\u0644\u0648\u0628 \u0623\u0648 \u0631\u0642\u0645 \u0627\u0644\u062A\u0631\u062E\u064A\u0635 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Landing page link (optional, needed for websites)": "\u0631\u0627\u0628\u0637 \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0642\u0635\u0648\u062F\u0629 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A\u060C \u0645\u0637\u0644\u0648\u0628 \u0644\u0644\u0645\u0648\u0627\u0642\u0639)",
  "Create campaign": "\u0625\u0646\u0634\u0627\u0621 \u0627\u0644\u062D\u0645\u0644\u0629",
  "Optional: plan products, dates and a budget, with one brief sent with every bid. You can always just bid.": "\u0627\u062E\u062A\u064A\u0627\u0631\u064A: \u062E\u0637\u0637 \u0644\u0644\u0645\u0646\u062A\u062C\u0627\u062A \u0648\u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0648\u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629\u060C \u0628\u0645\u0644\u062E\u0635 \u0648\u0627\u062D\u062F \u064A\u064F\u0631\u0633\u0644 \u0645\u0639 \u0643\u0644 \u0639\u0631\u0636. \u064A\u0645\u0643\u0646\u0643 \u062F\u0627\u0626\u0645\u064B\u0627 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0645\u0628\u0627\u0634\u0631\u0629.",
  "No campaigns yet. A campaign holds your dates, budget and brief; add products to it from the Directory or the Calendar.": "\u0644\u0627 \u062D\u0645\u0644\u0627\u062A \u0628\u0639\u062F. \u062A\u062D\u0641\u0638 \u0627\u0644\u062D\u0645\u0644\u0629 \u062A\u0648\u0627\u0631\u064A\u062E\u0643 \u0648\u0645\u064A\u0632\u0627\u0646\u064A\u062A\u0643 \u0648\u0645\u0644\u062E\u0635\u0643\u061B \u0623\u0636\u0641 \u0625\u0644\u064A\u0647\u0627 \u0645\u0646\u062A\u062C\u0627\u062A \u0645\u0646 \u0627\u0644\u062F\u0644\u064A\u0644 \u0623\u0648 \u0627\u0644\u062A\u0642\u0648\u064A\u0645.",
  "Estimated": "\u0627\u0644\u062A\u0642\u062F\u064A\u0631",
  "Stage: {stage}": "\u0627\u0644\u0645\u0631\u062D\u0644\u0629: {stage}",
  "{amount} waiting for publishers": "{amount} \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646",
  "{a} committed and {b} estimated of a {c} budget": "{a} \u0645\u0644\u062A\u0632\u0645 \u0628\u0647 \u0648{b} \u062A\u0642\u062F\u064A\u0631\u064A \u0645\u0646 \u0645\u064A\u0632\u0627\u0646\u064A\u0629 {c}",
  "{name} taken out of the plan.": "\u0623\u064F\u0632\u064A\u0644 {name} \u0645\u0646 \u0627\u0644\u062E\u0637\u0629.",
  "Campaign saved.": "\u062A\u0645 \u062D\u0641\u0638 \u0627\u0644\u062D\u0645\u0644\u0629.",
  "Prices excl. VAT. Estimated uses each product's default price; committed is what publishers accepted.": "\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0644\u0627 \u062A\u0634\u0645\u0644 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629. \u064A\u0639\u062A\u0645\u062F \u0627\u0644\u062A\u0642\u062F\u064A\u0631 \u0639\u0644\u0649 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A \u0644\u0643\u0644 \u0645\u0646\u062A\u062C\u061B \u0648\u0627\u0644\u0645\u0644\u062A\u0632\u0645 \u0628\u0647 \u0647\u0648 \u0645\u0627 \u0642\u0628\u0644\u0647 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646.",
  "Add products": "\u0625\u0636\u0627\u0641\u0629 \u0645\u0646\u062A\u062C\u0627\u062A",
  'No products yet. Add them from the Directory, or with "Add to campaign" when you open a slot in the Calendar.': "\u0644\u0627 \u0645\u0646\u062A\u062C\u0627\u062A \u0628\u0639\u062F. \u0623\u0636\u0641\u0647\u0627 \u0645\u0646 \u0627\u0644\u062F\u0644\u064A\u0644\u060C \u0623\u0648 \u0639\u0628\u0631 \xAB\u0623\u0636\u0641 \u0625\u0644\u0649 \u0627\u0644\u062D\u0645\u0644\u0629\xBB \u0639\u0646\u062F \u0641\u062A\u062D \u0641\u062A\u0631\u0629 \u0641\u064A \u0627\u0644\u062A\u0642\u0648\u064A\u0645.",
  "Estimated cost": "\u0627\u0644\u062A\u0643\u0644\u0641\u0629 \u0627\u0644\u062A\u0642\u062F\u064A\u0631\u064A\u0629",
  "Where it is": "\u0623\u064A\u0646 \u0648\u0635\u0644",
  "See their dates in the Calendar": "\u0627\u0639\u0631\u0636 \u062A\u0648\u0627\u0631\u064A\u062E\u0647\u0627 \u0641\u064A \u0627\u0644\u062A\u0642\u0648\u064A\u0645",
  "Results for this campaign": "\u0646\u062A\u0627\u0626\u062C \u0647\u0630\u0647 \u0627\u0644\u062D\u0645\u0644\u0629",
  "By product in the plan: the amount committed, or the estimated cost while that is higher.": "\u062D\u0633\u0628 \u0627\u0644\u0645\u0646\u062A\u062C \u0641\u064A \u0627\u0644\u062E\u0637\u0629: \u0627\u0644\u0645\u0628\u0644\u063A \u0627\u0644\u0645\u0644\u062A\u0632\u0645 \u0628\u0647\u060C \u0623\u0648 \u0627\u0644\u062A\u0643\u0644\u0641\u0629 \u0627\u0644\u062A\u0642\u062F\u064A\u0631\u064A\u0629 \u0645\u0627 \u062F\u0627\u0645\u062A \u0623\u0639\u0644\u0649.",
  "No products in the plan yet.": "\u0644\u0627 \u0645\u0646\u062A\u062C\u0627\u062A \u0641\u064A \u0627\u0644\u062E\u0637\u0629 \u0628\u0639\u062F.",
  "Figures as of {date}; estimated costs use each product's default price until a publisher accepts.": "\u0627\u0644\u0623\u0631\u0642\u0627\u0645 \u062D\u062A\u0649 {date}\u061B \u062A\u0639\u062A\u0645\u062F \u0627\u0644\u062A\u0643\u0627\u0644\u064A\u0641 \u0627\u0644\u062A\u0642\u062F\u064A\u0631\u064A\u0629 \u0639\u0644\u0649 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A \u0644\u0643\u0644 \u0645\u0646\u062A\u062C \u062D\u062A\u0649 \u064A\u0642\u0628\u0644 \u0627\u0644\u0646\u0627\u0634\u0631.",
  "Added": "\u0623\u064F\u0636\u064A\u0641",
  "Ran": "\u0646\u064F\u0634\u0631",
  "Campaign creative": "\u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0644\u0644\u062D\u0645\u0644\u0629",
  "Campaign (optional)": "\u0627\u0644\u062D\u0645\u0644\u0629 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "Your campaign brief and creative will be sent to {outlet}.": "\u0633\u064A\u064F\u0631\u0633\u0644 \u0645\u0644\u062E\u0635 \u062D\u0645\u0644\u062A\u0643 \u0648\u0645\u0627\u062F\u062A\u0647\u0627 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0625\u0644\u0649 {outlet}.",
  "This campaign has no brief yet.": "\u0644\u0627 \u0645\u0644\u062E\u0635 \u0644\u0647\u0630\u0647 \u0627\u0644\u062D\u0645\u0644\u0629 \u0628\u0639\u062F.",
  "Edit for this bid": "\u0639\u062F\u0651\u0644 \u0644\u0647\u0630\u0627 \u0627\u0644\u0639\u0631\u0636",
  "Brief for this bid": "\u0645\u0644\u062E\u0635 \u0647\u0630\u0627 \u0627\u0644\u0639\u0631\u0636",
  "Only this bid uses these changes; the campaign keeps its brief.": "\u0647\u0630\u0647 \u0627\u0644\u062A\u063A\u064A\u064A\u0631\u0627\u062A \u0644\u0647\u0630\u0627 \u0627\u0644\u0639\u0631\u0636 \u0641\u0642\u0637\u061B \u0648\u062A\u062D\u062A\u0641\u0638 \u0627\u0644\u062D\u0645\u0644\u0629 \u0628\u0645\u0644\u062E\u0635\u0647\u0627.",
  "Use the campaign brief": "\u0627\u0633\u062A\u062E\u062F\u0645 \u0645\u0644\u062E\u0635 \u0627\u0644\u062D\u0645\u0644\u0629",
  "Notes for the publisher (optional)": "\u0645\u0644\u0627\u062D\u0638\u0627\u062A \u0644\u0644\u0646\u0627\u0634\u0631 (\u0627\u062E\u062A\u064A\u0627\u0631\u064A)",
  "{left} left \xB7 after this bid {after}": "\u0627\u0644\u0645\u062A\u0628\u0642\u064A {left} \xB7 \u0628\u0639\u062F \u0647\u0630\u0627 \u0627\u0644\u0639\u0631\u0636 {after}",
  "Only you see this.": "\u0644\u0627 \u064A\u0631\u0627\u0647 \u063A\u064A\u0631\u0643.",
  "Choose a campaign\u2026": "\u0627\u062E\u062A\u0631 \u062D\u0645\u0644\u0629\u2026",
  "No campaign yet.": "\u0644\u0627 \u062D\u0645\u0644\u0629 \u0628\u0639\u062F.",
  "Open the campaign": "\u0627\u0641\u062A\u062D \u0627\u0644\u062D\u0645\u0644\u0629",
  "Products in {name}": "\u0645\u0646\u062A\u062C\u0627\u062A {name}",
  "this campaign": "\u0647\u0630\u0647 \u0627\u0644\u062D\u0645\u0644\u0629",
  "Show everything": "\u0627\u0639\u0631\u0636 \u0627\u0644\u0643\u0644",
  "Only {name}": "{name} \u0641\u0642\u0637",
  "One product": "\u0645\u0646\u062A\u062C \u0648\u0627\u062D\u062F",
  "What you have added, the estimated total and the budget left. Campaigns are optional: you can always just bid.": "\u0645\u0627 \u0623\u0636\u0641\u062A\u0647\u060C \u0648\u0627\u0644\u0625\u062C\u0645\u0627\u0644\u064A \u0627\u0644\u062A\u0642\u062F\u064A\u0631\u064A\u060C \u0648\u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629 \u0627\u0644\u0645\u062A\u0628\u0642\u064A\u0629. \u0627\u0644\u062D\u0645\u0644\u0627\u062A \u0627\u062E\u062A\u064A\u0627\u0631\u064A\u0629: \u064A\u0645\u0643\u0646\u0643 \u062F\u0627\u0626\u0645\u064B\u0627 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0645\u0628\u0627\u0634\u0631\u0629.",
  "No campaign yet. A campaign holds your dates, budget and one brief that goes with every bid.": "\u0644\u0627 \u062D\u0645\u0644\u0629 \u0628\u0639\u062F. \u062A\u062D\u0641\u0638 \u0627\u0644\u062D\u0645\u0644\u0629 \u062A\u0648\u0627\u0631\u064A\u062E\u0643 \u0648\u0645\u064A\u0632\u0627\u0646\u064A\u062A\u0643 \u0648\u0645\u0644\u062E\u0635\u064B\u0627 \u0648\u0627\u062D\u062F\u064B\u0627 \u064A\u064F\u0631\u0633\u0644 \u0645\u0639 \u0643\u0644 \u0639\u0631\u0636.",
  "Budget left": "\u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629 \u0627\u0644\u0645\u062A\u0628\u0642\u064A\u0629",
  "No budget": "\u0628\u0644\u0627 \u0645\u064A\u0632\u0627\u0646\u064A\u0629",
  'Nothing added yet. Open a slot and press "Add to campaign", or add products from the Directory.': "\u0644\u0645 \u062A\u064F\u0636\u0641 \u0634\u064A\u0626\u064B\u0627 \u0628\u0639\u062F. \u0627\u0641\u062A\u062D \u0641\u062A\u0631\u0629 \u0648\u0627\u0636\u063A\u0637 \xAB\u0623\u0636\u0641 \u0625\u0644\u0649 \u0627\u0644\u062D\u0645\u0644\u0629\xBB\u060C \u0623\u0648 \u0623\u0636\u0641 \u0645\u0646\u062A\u062C\u0627\u062A \u0645\u0646 \u0627\u0644\u062F\u0644\u064A\u0644.",
  "See dates": "\u0627\u0639\u0631\u0636 \u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E",
  "Remove {name} from saved": "\u0623\u0632\u0644 {name} \u0645\u0646 \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629",
  "Save {name}": "\u0627\u062D\u0641\u0638 {name}",
  "Saved": "\u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629",
  "Sort by:": "\u0627\u0644\u062A\u0631\u062A\u064A\u0628 \u062D\u0633\u0628:",
  "Media type:": "\u0646\u0648\u0639 \u0627\u0644\u0648\u0633\u064A\u0644\u0629:",
  "Price:": "\u0627\u0644\u0633\u0639\u0631:",
  "AED from": "\u0645\u0646 (\u062F\u0631\u0647\u0645)",
  "Fits my budget": "\u0636\u0645\u0646 \u0645\u064A\u0632\u0627\u0646\u064A\u062A\u064A",
  "{amount} left in {name}": "\u0627\u0644\u0645\u062A\u0628\u0642\u064A {amount} \u0641\u064A {name}",
  "No saved outlets match. Tap the star on an outlet to save it.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0648\u0633\u0627\u0626\u0644 \u0645\u062D\u0641\u0648\u0638\u0629 \u0645\u0637\u0627\u0628\u0642\u0629. \u0627\u0636\u063A\u0637 \u0627\u0644\u0646\u062C\u0645\u0629 \u0639\u0644\u0649 \u0623\u064A \u0648\u0633\u064A\u0644\u0629 \u0644\u062D\u0641\u0638\u0647\u0627.",
  "From {amount}": "\u0645\u0646 {amount}",
  "Compare": "\u0642\u0627\u0631\u0646",
  "You can compare up to 3.": "\u064A\u0645\u0643\u0646\u0643 \u0627\u0644\u0645\u0642\u0627\u0631\u0646\u0629 \u0628\u064A\u0646 3 \u0643\u062D\u062F \u0623\u0642\u0635\u0649.",
  "Clear": "\u0645\u0633\u062D",
  "Compare ({n})": "\u0642\u0627\u0631\u0646 ({n})",
  "Target audience": "\u0627\u0644\u062C\u0645\u0647\u0648\u0631 \u0627\u0644\u0645\u0633\u062A\u0647\u062F\u0641",
  "Nothing on sale now": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u0639\u0631\u0648\u0636 \u0644\u0644\u0628\u064A\u0639 \u0627\u0644\u0622\u0646",
  "Most popular": "\u0627\u0644\u0623\u0643\u062B\u0631 \u0637\u0644\u0628\u064B\u0627",
  "Newest on Nashr": "\u0627\u0644\u0623\u062D\u062F\u062B \u0639\u0644\u0649 \u0646\u0634\u0631",
  "Shortcuts: \u2190 \u2192 move \xB7 T today \xB7 D W views \xB7 / search": "\u0627\u0644\u0627\u062E\u062A\u0635\u0627\u0631\u0627\u062A: \u2190 \u2192 \u0644\u0644\u062A\u0646\u0642\u0644 \xB7 T \u0627\u0644\u064A\u0648\u0645 \xB7 D W \u0637\u0631\u0642 \u0627\u0644\u0639\u0631\u0636 \xB7 / \u0627\u0644\u0628\u062D\u062B",
  "Sale type:": "\u0646\u0648\u0639 \u0627\u0644\u0628\u064A\u0639:",
  "{n} outlets with dates on sale this week": "{n} \u0645\u0646 \u0627\u0644\u0648\u0633\u0627\u0626\u0644 \u0644\u062F\u064A\u0647\u0627 \u062A\u0648\u0627\u0631\u064A\u062E \u0645\u0639\u0631\u0648\u0636\u0629 \u0647\u0630\u0627 \u0627\u0644\u0623\u0633\u0628\u0648\u0639",
  "Choose a file": "\u0627\u062E\u062A\u0631 \u0645\u0644\u0641\u064B\u0627",
  "One time only": "\u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \u0641\u0642\u0637",
  "4 weeks": "4 \u0623\u0633\u0627\u0628\u064A\u0639",
  "8 weeks": "8 \u0623\u0633\u0627\u0628\u064A\u0639",
  "12 weeks": "12 \u0623\u0633\u0628\u0648\u0639\u064B\u0627",
  "Buyers bid against each other; you accept the best bid.": "\u064A\u062A\u0646\u0627\u0641\u0633 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0628\u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629\u061B \u0648\u062A\u0642\u0628\u0644 \u0623\u0646\u062A \u0623\u0641\u0636\u0644 \u0639\u0631\u0636.",
  "One price. Several buyers can make offers at that price; you pick one.": "\u0633\u0639\u0631 \u0648\u0627\u062D\u062F. \u064A\u0645\u0643\u0646 \u0644\u0639\u062F\u0629 \u0645\u0634\u062A\u0631\u064A\u0646 \u0627\u0644\u062A\u0642\u062F\u0651\u0645 \u0628\u0647\u0630\u0627 \u0627\u0644\u0633\u0639\u0631\u061B \u0648\u062A\u062E\u062A\u0627\u0631 \u0623\u0646\u062A \u0648\u0627\u062D\u062F\u064B\u0627.",
  "Buyers can offer lower, higher or the same as the price; you pick one.": "\u064A\u0645\u0643\u0646 \u0644\u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u0639\u0631\u0636 \u0633\u0639\u0631 \u0623\u0642\u0644 \u0623\u0648 \u0623\u0639\u0644\u0649 \u0623\u0648 \u0645\u0633\u0627\u0648\u064D\u061B \u0648\u062A\u062E\u062A\u0627\u0631 \u0623\u0646\u062A \u0648\u0627\u062D\u062F\u064B\u0627.",
  "List it for the dates you choose": "\u0627\u0639\u0631\u0636\u0647 \u0644\u0644\u0628\u064A\u0639 \u0641\u064A \u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u064A \u062A\u062E\u062A\u0627\u0631\u0647\u0627",
  "This document is in English for now. The Arabic version will be published once it has been reviewed by a UAE lawyer.": "\u0647\u0630\u0647 \u0627\u0644\u0648\u062B\u064A\u0642\u0629 \u0645\u062A\u0627\u062D\u0629 \u0628\u0627\u0644\u0625\u0646\u062C\u0644\u064A\u0632\u064A\u0629 \u062D\u0627\u0644\u064A\u064B\u0627. \u0633\u062A\u064F\u0646\u0634\u0631 \u0627\u0644\u0646\u0633\u062E\u0629 \u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0628\u0639\u062F \u0645\u0631\u0627\u062C\u0639\u062A\u0647\u0627 \u0645\u0646 \u0645\u062D\u0627\u0645\u064D \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A.",
  "bid on this slot": "\u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0639\u0644\u0649 \u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629",
  "book this slot": "\u062D\u062C\u0632 \u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629",
  "request a quote": "\u0637\u0644\u0628 \u0639\u0631\u0636 \u0633\u0639\u0631",
  "Sign in to see this page. You'll come straight back to it.": "\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0644\u0639\u0631\u0636 \u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u062D\u0629\u060C \u0648\u0633\u062A\u0639\u0648\u062F \u0625\u0644\u064A\u0647\u0627 \u0645\u0628\u0627\u0634\u0631\u0629.",
  "Nashr signed {user} out of every device. Reason: {reason}": "\u0633\u062C\u0651\u0644\u062A \u0646\u0634\u0631 \u062E\u0631\u0648\u062C {user} \u0645\u0646 \u062C\u0645\u064A\u0639 \u0627\u0644\u0623\u062C\u0647\u0632\u0629. \u0627\u0644\u0633\u0628\u0628: {reason}",
  "{user} reset their password with their authenticator app and was signed out everywhere.": "\u0623\u0639\u0627\u062F {user} \u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0628\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629\u060C \u0648\u0633\u064F\u062C\u0651\u0644 \u062E\u0631\u0648\u062C\u0647 \u0645\u0646 \u062C\u0645\u064A\u0639 \u0627\u0644\u0623\u062C\u0647\u0632\u0629.",
  "{user} was removed from your team.": "\u0623\u064F\u0632\u064A\u0644 {user} \u0645\u0646 \u0641\u0631\u064A\u0642\u0643.",
  "Upload your tax invoice for order {order}.": "\u0627\u0631\u0641\u0639 \u0641\u0627\u062A\u0648\u0631\u062A\u0643 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629 \u0644\u0644\u0637\u0644\u0628 {order}.",
  "This booking was refunded. Upload a credit note for invoice {invoice}.": "\u0627\u0633\u062A\u064F\u0631\u062F \u0645\u0628\u0644\u063A \u0647\u0630\u0627 \u0627\u0644\u062D\u062C\u0632. \u0627\u0631\u0641\u0639 \u0625\u0634\u0639\u0627\u0631\u064B\u0627 \u062F\u0627\u0626\u0646\u064B\u0627 \u0644\u0644\u0641\u0627\u062A\u0648\u0631\u0629 {invoice}.",
  "Theme": "\u0627\u0644\u0645\u0638\u0647\u0631",
  "Light": "\u0641\u0627\u062A\u062D",
  "Dark": "\u062F\u0627\u0643\u0646",
  "Switch to the dark theme": "\u0627\u0644\u062A\u0628\u062F\u064A\u0644 \u0625\u0644\u0649 \u0627\u0644\u0645\u0638\u0647\u0631 \u0627\u0644\u062F\u0627\u0643\u0646",
  "Switch to the light theme": "\u0627\u0644\u062A\u0628\u062F\u064A\u0644 \u0625\u0644\u0649 \u0627\u0644\u0645\u0638\u0647\u0631 \u0627\u0644\u0641\u0627\u062A\u062D",
  "Light, dark, or the same as your phone or computer. Kept in this browser.": "\u0641\u0627\u062A\u062D \u0623\u0648 \u062F\u0627\u0643\u0646\u060C \u0623\u0648 \u0645\u062B\u0644 \u0647\u0627\u062A\u0641\u0643 \u0623\u0648 \u062D\u0627\u0633\u0648\u0628\u0643. \u064A\u064F\u062D\u0641\u0638 \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u0645\u062A\u0635\u0641\u062D."
};

// web/src/i18n-ar.ts
var AR = {
  // Navigation, roles, shell
  "Home": "\u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629",
  "Calendar": "\u0627\u0644\u062A\u0642\u0648\u064A\u0645",
  "Directory": "\u0627\u0644\u062F\u0644\u064A\u0644",
  "Sign in": "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644",
  "Sign out": "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062E\u0631\u0648\u062C",
  "Request access": "\u0637\u0644\u0628 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645",
  "Dashboard": "\u0644\u0648\u062D\u0629 \u0627\u0644\u062A\u062D\u0643\u0645",
  "Campaigns": "\u0627\u0644\u062D\u0645\u0644\u0627\u062A",
  "Bookings": "\u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A",
  "Athena": "\u0623\u062B\u064A\u0646\u0627",
  "Inbox": "\u0627\u0644\u0648\u0627\u0631\u062F",
  "Deals": "\u0627\u0644\u0635\u0641\u0642\u0627\u062A",
  "Earnings": "\u0627\u0644\u0623\u0631\u0628\u0627\u062D",
  "Listings": "\u0627\u0644\u0639\u0631\u0648\u0636",
  "Profile": "\u0627\u0644\u0645\u0644\u0641",
  "Overview": "\u0646\u0638\u0631\u0629 \u0639\u0627\u0645\u0629",
  "Access": "\u0637\u0644\u0628\u0627\u062A \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645",
  "Accounts": "\u0627\u0644\u062D\u0633\u0627\u0628\u0627\u062A",
  "Disputes": "\u0627\u0644\u0646\u0632\u0627\u0639\u0627\u062A",
  "Funds": "\u0627\u0644\u0623\u0645\u0648\u0627\u0644",
  "Payouts": "\u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A",
  "Reports": "\u0627\u0644\u062A\u0642\u0627\u0631\u064A\u0631",
  "Audit": "\u0633\u062C\u0644 \u0627\u0644\u062A\u062F\u0642\u064A\u0642",
  "Settings": "\u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A",
  "Money": "\u0627\u0644\u0645\u0627\u0644",
  "System": "\u0627\u0644\u0646\u0638\u0627\u0645",
  "Your business": "\u0623\u0639\u0645\u0627\u0644\u0643",
  "Plan and book": "\u0627\u0644\u062A\u062E\u0637\u064A\u0637 \u0648\u0627\u0644\u062D\u062C\u0632",
  "Buyer": "\u0645\u0634\u062A\u0631\u064D",
  "Publisher": "\u0646\u0627\u0634\u0631",
  "Nashr operations": "\u0639\u0645\u0644\u064A\u0627\u062A \u0646\u0634\u0631",
  "Nashr founder": "\u0645\u0624\u0633\u0633 \u0646\u0634\u0631",
  "Menu": "\u0627\u0644\u0642\u0627\u0626\u0645\u0629",
  "Main": "\u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629",
  "Loading\u2026": "\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0645\u064A\u0644\u2026",
  "Not found": "\u0627\u0644\u0635\u0641\u062D\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629",
  "Back to the start": "\u0627\u0644\u0639\u0648\u062F\u0629 \u0625\u0644\u0649 \u0627\u0644\u0628\u062F\u0627\u064A\u0629",
  "Stop viewing": "\u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u0639\u0631\u0636",
  "soon": "\u0642\u0631\u064A\u0628\u064B\u0627",
  "Nashr home": "\u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629 \u0644\u0646\u0634\u0631",
  "Viewing {name} as Nashr, read only. Every page you open is logged.": "\u062A\u0639\u0631\u0636 \u062D\u0633\u0627\u0628 {name} \u0628\u0635\u0641\u062A\u0643 \u0646\u0634\u0631\u060C \u0644\u0644\u0642\u0631\u0627\u0621\u0629 \u0641\u0642\u0637. \u062A\u064F\u0633\u062C\u064E\u0651\u0644 \u0643\u0644 \u0635\u0641\u062D\u0629 \u062A\u0641\u062A\u062D\u0647\u0627.",
  "Sign in to {action}.": "\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0644\u0640{action}.",
  "bid or book": "\u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0623\u0648 \u0627\u0644\u062D\u062C\u0632",
  "Nashr is invite-only for UAE brands, agencies and media outlets.": "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0646\u0634\u0631 \u0628\u062F\u0639\u0648\u0629 \u0641\u0642\u0637 \u0644\u0644\u0639\u0644\u0627\u0645\u0627\u062A \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629 \u0648\u0627\u0644\u0648\u0643\u0627\u0644\u0627\u062A \u0648\u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u0629 \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A.",
  // Channels and sale types
  "Radio": "\u0625\u0630\u0627\u0639\u0629",
  "TV": "\u062A\u0644\u0641\u0632\u064A\u0648\u0646",
  "Print": "\u0635\u062D\u0641 \u0648\u0645\u0637\u0628\u0648\u0639\u0627\u062A",
  "Digital": "\u0631\u0642\u0645\u064A",
  "Podcast": "\u0628\u0648\u062F\u0643\u0627\u0633\u062A",
  "Podcasts": "\u0628\u0648\u062F\u0643\u0627\u0633\u062A",
  "Auction": "\u0645\u0632\u0627\u062F",
  "Quick sale": "\u0628\u064A\u0639 \u0633\u0631\u064A\u0639",
  "quick sale": "\u0628\u064A\u0639 \u0633\u0631\u064A\u0639",
  // Landing
  "Live in the UAE. Saudi Arabia next.": "\u0645\u062A\u0627\u062D \u0627\u0644\u0622\u0646 \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A\u060C \u0648\u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629 \u0642\u0631\u064A\u0628\u064B\u0627.",
  "Book UAE airtime and pages in one place.": "\u0627\u062D\u062C\u0632 \u0625\u0639\u0644\u0627\u0646\u0643 \u0641\u064A \u0627\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0635\u062D\u0641 \u0645\u0646 \u0645\u0643\u0627\u0646 \u0648\u0627\u062D\u062F.",
  "Bid on radio breaks, TV spots, print pages, homepage takeovers and podcast reads, directly from the publishers. Your payment is held until the publisher proves the ad ran.": "\u0632\u0627\u064A\u062F \u0639\u0644\u0649 \u0627\u0644\u0641\u0648\u0627\u0635\u0644 \u0627\u0644\u0625\u0630\u0627\u0639\u064A\u0629 \u0648\u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646\u064A\u0629 \u0648\u0635\u0641\u062D\u0627\u062A \u0627\u0644\u0635\u062D\u0641 \u0648\u0627\u0644\u0635\u0641\u062D\u0627\u062A \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629 \u0644\u0644\u0645\u0648\u0627\u0642\u0639 \u0648\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A\u060C \u0645\u0628\u0627\u0634\u0631\u0629\u064B \u0645\u0646 \u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646. \u062A\u0628\u0642\u0649 \u062F\u0641\u0639\u062A\u0643 \u0645\u062D\u0641\u0648\u0638\u0629 \u062D\u062A\u0649 \u064A\u064F\u062B\u0628\u062A \u0627\u0644\u0646\u0627\u0634\u0631 \u0623\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0642\u062F \u0628\u064F\u062B.",
  "Browse the calendar": "\u062A\u0635\u0641\u0651\u062D \u0627\u0644\u062A\u0642\u0648\u064A\u0645",
  "Every slot and price is open to browse. Sign in when you're ready to bid.": "\u062C\u0645\u064A\u0639 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0648\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0645\u062A\u0627\u062D\u0629 \u0644\u0644\u062A\u0635\u0641\u0651\u062D. \u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0639\u0646\u062F\u0645\u0627 \u062A\u0643\u0648\u0646 \u0645\u0633\u062A\u0639\u062F\u064B\u0627 \u0644\u0644\u0645\u0632\u0627\u064A\u062F\u0629.",
  "How it works": "\u0643\u064A\u0641 \u064A\u0639\u0645\u0644",
  "Example programme board. Open the live calendar": "\u0644\u0648\u062D\u0629 \u0628\u0631\u0627\u0645\u062C \u062A\u0648\u0636\u064A\u062D\u064A\u0629. \u0627\u0641\u062A\u062D \u0627\u0644\u062A\u0642\u0648\u064A\u0645 \u0627\u0644\u0645\u0628\u0627\u0634\u0631",
  "Dubai time": "\u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A",
  "Bidding live": "\u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u062C\u0627\u0631\u064A\u0629",
  "Skyline FM, Break 2 at 07:15": "Skyline FM\u060C \u0627\u0644\u0641\u0627\u0635\u0644 2 \u0627\u0644\u0633\u0627\u0639\u0629 07:15",
  "Top bid, 3% steps": "\u0623\u0639\u0644\u0649 \u0645\u0632\u0627\u064A\u062F\u0629\u060C \u0628\u0632\u064A\u0627\u062F\u0627\u062A 3%",
  "You lead": "\u0623\u0646\u062A \u0641\u064A \u0627\u0644\u0645\u0642\u062F\u0645\u0629",
  "Closes in {n}h": "\u064A\u064F\u063A\u0644\u0642 \u062E\u0644\u0627\u0644 {n} \u0633",
  "Closes in {n}m": "\u064A\u064F\u063A\u0644\u0642 \u062E\u0644\u0627\u0644 {n} \u062F",
  "Bidding closed": "\u0623\u064F\u063A\u0644\u0642\u062A \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629",
  "What you can book": "\u0645\u0627 \u064A\u0645\u0643\u0646\u0643 \u062D\u062C\u0632\u0647",
  "Morning": "\u0627\u0644\u0635\u0628\u0627\u062D",
  "4 breaks": "4 \u0641\u0648\u0627\u0635\u0644",
  "Drive": "\u0648\u0642\u062A \u0627\u0644\u0630\u0631\u0648\u0629",
  "News": "\u0627\u0644\u0623\u062E\u0628\u0627\u0631",
  "booked": "\u0645\u062D\u062C\u0648\u0632",
  "Evening": "\u0627\u0644\u0645\u0633\u0627\u0621",
  "2 spots": "\u0625\u0639\u0644\u0627\u0646\u0627\u0646",
  "Full page, business section": "\u0635\u0641\u062D\u0629 \u0643\u0627\u0645\u0644\u0629\u060C \u0642\u0633\u0645 \u0627\u0644\u0623\u0639\u0645\u0627\u0644",
  "all day, from AED 20,000": "\u0637\u0648\u0627\u0644 \u0627\u0644\u064A\u0648\u0645\u060C \u0627\u0628\u062A\u062F\u0627\u0621\u064B \u0645\u0646 20,000 \u062F\u0631\u0647\u0645",
  "Weekly episode": "\u0627\u0644\u062D\u0644\u0642\u0629 \u0627\u0644\u0623\u0633\u0628\u0648\u0639\u064A\u0629",
  "pre-roll and mid-roll": "\u0642\u0628\u0644 \u0627\u0644\u062D\u0644\u0642\u0629 \u0648\u0641\u064A \u0645\u0646\u062A\u0635\u0641\u0647\u0627",
  "Single breaks, any break, packages": "\u0641\u0648\u0627\u0635\u0644 \u0645\u0646\u0641\u0631\u062F\u0629\u060C \u0623\u064A \u0641\u0627\u0635\u0644\u060C \u0628\u0627\u0642\u0627\u062A",
  "Spots by programme and time": "\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u062D\u0633\u0628 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C \u0648\u0627\u0644\u0648\u0642\u062A",
  "Pages by edition and section": "\u0635\u0641\u062D\u0627\u062A \u062D\u0633\u0628 \u0627\u0644\u0639\u062F\u062F \u0648\u0627\u0644\u0642\u0633\u0645",
  "Homepage takeovers by day": "\u0627\u0644\u0627\u0633\u062A\u062D\u0648\u0627\u0630 \u0639\u0644\u0649 \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629 \u0628\u0627\u0644\u064A\u0648\u0645",
  "Pre-roll, mid-roll, post-roll": "\u0642\u0628\u0644 \u0627\u0644\u062D\u0644\u0642\u0629\u060C \u0641\u064A \u0645\u0646\u062A\u0635\u0641\u0647\u0627\u060C \u0628\u0639\u062F\u0647\u0627",
  "Your media plan, money and proof on one desk.": "\u062E\u0637\u062A\u0643 \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u0629 \u0648\u0623\u0645\u0648\u0627\u0644\u0643 \u0648\u0625\u062B\u0628\u0627\u062A\u0627\u062A \u0627\u0644\u0628\u062B \u0641\u064A \u0645\u0643\u0627\u0646 \u0648\u0627\u062D\u062F.",
  "See what you've committed, what's held and what needs you today. Publishers see their sales, buyers and payouts the same way.": "\u0627\u0637\u0651\u0644\u0639 \u0639\u0644\u0649 \u0645\u0627 \u0627\u0644\u062A\u0632\u0645\u062A \u0628\u0647 \u0648\u0645\u0627 \u0647\u0648 \u0645\u062D\u0641\u0648\u0638 \u0648\u0645\u0627 \u064A\u062D\u062A\u0627\u062C \u0625\u0644\u0649 \u0625\u062C\u0631\u0627\u0621 \u0645\u0646\u0643 \u0627\u0644\u064A\u0648\u0645. \u0648\u064A\u0631\u0649 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0645\u0628\u064A\u0639\u0627\u062A\u0647\u0645 \u0648\u0645\u0634\u062A\u0631\u064A\u0647\u0645 \u0648\u0645\u062F\u0641\u0648\u0639\u0627\u062A\u0647\u0645 \u0628\u0627\u0644\u0637\u0631\u064A\u0642\u0629 \u0646\u0641\u0633\u0647\u0627.",
  "The buyer dashboard: money held, weekly spend, payments due and live bids": "\u0644\u0648\u062D\u0629 \u062A\u062D\u0643\u0645 \u0627\u0644\u0645\u0634\u062A\u0631\u064A: \u0627\u0644\u0623\u0645\u0648\u0627\u0644 \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629 \u0648\u0627\u0644\u0625\u0646\u0641\u0627\u0642 \u0627\u0644\u0623\u0633\u0628\u0648\u0639\u064A \u0648\u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062D\u0642\u0629 \u0648\u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0627\u062A \u0627\u0644\u062C\u0627\u0631\u064A\u0629",
  "Every slot, in Dubai time": "\u0643\u0644 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A",
  "Radio breaks, TV spots, pages and takeovers by day, week or month, with the price and what's left.": "\u0627\u0644\u0641\u0648\u0627\u0635\u0644 \u0627\u0644\u0625\u0630\u0627\u0639\u064A\u0629 \u0648\u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646\u064A\u0629 \u0648\u0627\u0644\u0635\u0641\u062D\u0627\u062A \u0648\u0627\u0644\u0627\u0633\u062A\u062D\u0648\u0627\u0630\u0627\u062A \u0628\u0627\u0644\u064A\u0648\u0645 \u0623\u0648 \u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u0623\u0648 \u0627\u0644\u0634\u0647\u0631\u060C \u0645\u0639 \u0627\u0644\u0633\u0639\u0631 \u0648\u0627\u0644\u0645\u062A\u0628\u0642\u064A.",
  "Prices you can read": "\u0623\u0633\u0639\u0627\u0631 \u0648\u0627\u0636\u062D\u0629",
  "Every price says where it comes from, so you know what's typical before you bid.": "\u0643\u0644 \u0633\u0639\u0631 \u064A\u0648\u0636\u0651\u062D \u0645\u0635\u062F\u0631\u0647\u060C \u0644\u062A\u0639\u0631\u0641 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0645\u0639\u062A\u0627\u062F \u0642\u0628\u0644 \u0623\u0646 \u062A\u0632\u0627\u064A\u062F.",
  "Price labels": "\u062A\u0635\u0646\u064A\u0641\u0627\u062A \u0627\u0644\u0623\u0633\u0639\u0627\u0631",
  "AED 15,000\u201318,000": "15,000\u201318,000 \u062F\u0631\u0647\u0645",
  "AED 9,000": "9,000 \u062F\u0631\u0647\u0645",
  "AED 18,000\u201326,000": "18,000\u201326,000 \u062F\u0631\u0647\u0645",
  "Typical on Nashr": "\u0627\u0644\u0645\u0639\u062A\u0627\u062F \u0639\u0644\u0649 \u0646\u0634\u0631",
  "Publisher's rate": "\u0633\u0639\u0631 \u0627\u0644\u0646\u0627\u0634\u0631",
  "Estimate, unconfirmed": "\u062A\u0642\u062F\u064A\u0631 \u063A\u064A\u0631 \u0645\u0624\u0643\u062F",
  "Paid only after proof": "\u0644\u0627 \u062F\u0641\u0639 \u0625\u0644\u0627 \u0628\u0639\u062F \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "The publisher is paid when you approve the as-run log, tearsheet or screenshots.": "\u064A\u064F\u062F\u0641\u0639 \u0644\u0644\u0646\u0627\u0634\u0631 \u0639\u0646\u062F\u0645\u0627 \u062A\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u0633\u062C\u0644 \u0627\u0644\u0628\u062B \u0623\u0648 \u0646\u0633\u062E\u0629 \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0629 \u0623\u0648 \u0644\u0642\u0637\u0627\u062A \u0627\u0644\u0634\u0627\u0634\u0629.",
  "Held": "\u0645\u062D\u0641\u0648\u0638",
  "Brief, creative and proof in one place": "\u0627\u0644\u0645\u0648\u062C\u0632 \u0648\u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0648\u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0641\u064A \u0645\u0643\u0627\u0646 \u0648\u0627\u062D\u062F",
  "No email chains. Every booking keeps its own record, from the first bid to the tax invoice.": "\u0644\u0627 \u0645\u0632\u064A\u062F \u0645\u0646 \u0633\u0644\u0627\u0633\u0644 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A. \u0644\u0643\u0644 \u062D\u062C\u0632 \u0633\u062C\u0644\u0647 \u0627\u0644\u062E\u0627\u0635\u060C \u0645\u0646 \u0623\u0648\u0644 \u0645\u0632\u0627\u064A\u062F\u0629 \u062D\u062A\u0649 \u0627\u0644\u0641\u0627\u062A\u0648\u0631\u0629 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629.",
  "Example booking record": "\u0645\u062B\u0627\u0644 \u0639\u0644\u0649 \u0633\u062C\u0644 \u062D\u062C\u0632",
  "Brief sent with the bid": "\u0623\u064F\u0631\u0633\u0644 \u0627\u0644\u0645\u0648\u062C\u0632 \u0645\u0639 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629",
  "Creative approved": "\u0627\u0639\u062A\u064F\u0645\u062F\u062A \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Proof received": "\u0627\u0633\u062A\u064F\u0644\u0645 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "Approve and release": "\u0648\u0627\u0641\u0642 \u0648\u062D\u0631\u0651\u0631 \u0627\u0644\u062F\u0641\u0639\u0629",
  "From bid to broadcast, with the money held in between.": "\u0645\u0646 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0625\u0644\u0649 \u0627\u0644\u0628\u062B\u060C \u0648\u0627\u0644\u0645\u0627\u0644 \u0645\u062D\u0641\u0648\u0638 \u0637\u0648\u0627\u0644 \u0627\u0644\u0637\u0631\u064A\u0642.",
  "Every booking follows the same five steps, with a clock on each one so nobody is left waiting.": "\u064A\u0645\u0631 \u0643\u0644 \u062D\u062C\u0632 \u0628\u0627\u0644\u062E\u0637\u0648\u0627\u062A \u0627\u0644\u062E\u0645\u0633 \u0646\u0641\u0633\u0647\u0627\u060C \u0648\u0644\u0643\u0644 \u062E\u0637\u0648\u0629 \u0645\u0647\u0644\u0629 \u0632\u0645\u0646\u064A\u0629 \u062D\u062A\u0649 \u0644\u0627 \u064A\u0646\u062A\u0638\u0631 \u0623\u062D\u062F.",
  "Bid or request": "\u0632\u0627\u064A\u062F \u0623\u0648 \u0627\u0637\u0644\u0628",
  "Bid in 3% steps, set an auto-bid limit, or ask for the buy-now price. Nothing is charged.": "\u0632\u0627\u064A\u062F \u0628\u0632\u064A\u0627\u062F\u0627\u062A 3%\u060C \u0623\u0648 \u062D\u062F\u0651\u062F \u0633\u0642\u0641\u064B\u0627 \u0644\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A\u0629\u060C \u0623\u0648 \u0627\u0637\u0644\u0628 \u0633\u0639\u0631 \u0627\u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0641\u0648\u0631\u064A. \u0644\u0627 \u064A\u064F\u062E\u0635\u0645 \u0623\u064A \u0645\u0628\u0644\u063A.",
  "Publisher accepts": "\u0627\u0644\u0646\u0627\u0634\u0631 \u064A\u0648\u0627\u0641\u0642",
  "The publisher sees your brief and decides within 24 hours.": "\u064A\u0637\u0651\u0644\u0639 \u0627\u0644\u0646\u0627\u0634\u0631 \u0639\u0644\u0649 \u0645\u0648\u062C\u0632\u0643 \u0648\u064A\u0642\u0631\u0631 \u062E\u0644\u0627\u0644 24 \u0633\u0627\u0639\u0629.",
  "Pay, money held": "\u0627\u062F\u0641\u0639\u060C \u0648\u0627\u0644\u0645\u0627\u0644 \u0645\u062D\u0641\u0648\u0638",
  "Pay within 48 hours. The money waits with Nashr, not the publisher.": "\u0627\u062F\u0641\u0639 \u062E\u0644\u0627\u0644 48 \u0633\u0627\u0639\u0629. \u064A\u0628\u0642\u0649 \u0627\u0644\u0645\u0627\u0644 \u0644\u062F\u0649 \u0646\u0634\u0631\u060C \u0644\u0627 \u0644\u062F\u0649 \u0627\u0644\u0646\u0627\u0634\u0631.",
  "Ad runs, proof sent": "\u064A\u064F\u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0648\u064A\u064F\u0631\u0633\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "The publisher sends proof: the as-run log, the tearsheet, the screenshots.": "\u064A\u0631\u0633\u0644 \u0627\u0644\u0646\u0627\u0634\u0631 \u0627\u0644\u0625\u062B\u0628\u0627\u062A: \u0633\u062C\u0644 \u0627\u0644\u0628\u062B \u0623\u0648 \u0646\u0633\u062E\u0629 \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0629 \u0623\u0648 \u0644\u0642\u0637\u0627\u062A \u0627\u0644\u0634\u0627\u0634\u0629.",
  "Approve, money released": "\u0648\u0627\u0641\u0642\u060C \u0648\u064A\u064F\u062D\u0631\u064E\u0651\u0631 \u0627\u0644\u0645\u0627\u0644",
  "Approve and the publisher is paid, or it releases itself after 5 working days.": "\u0648\u0627\u0641\u0642 \u0644\u064A\u064F\u062F\u0641\u0639 \u0644\u0644\u0646\u0627\u0634\u0631\u060C \u0623\u0648 \u064A\u064F\u062D\u0631\u064E\u0651\u0631 \u0627\u0644\u0645\u0628\u0644\u063A \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627 \u0628\u0639\u062F 5 \u0623\u064A\u0627\u0645 \u0639\u0645\u0644.",
  "A planning team mapping a campaign on a glass wall": "\u0641\u0631\u064A\u0642 \u062A\u062E\u0637\u064A\u0637 \u064A\u0631\u0633\u0645 \u062D\u0645\u0644\u0629 \u0639\u0644\u0649 \u062C\u062F\u0627\u0631 \u0632\u062C\u0627\u062C\u064A",
  "For brands and agencies": "\u0644\u0644\u0639\u0644\u0627\u0645\u0627\u062A \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629 \u0648\u0627\u0644\u0648\u0643\u0627\u0644\u0627\u062A",
  "Every UAE outlet on one calendar.": "\u0643\u0644 \u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u0629 \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A \u0639\u0644\u0649 \u062A\u0642\u0648\u064A\u0645 \u0648\u0627\u062D\u062F.",
  "Browse slots by day, week or month, in Dubai time, with prices excluding VAT.": "\u062A\u0635\u0641\u0651\u062D \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0628\u0627\u0644\u064A\u0648\u0645 \u0623\u0648 \u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u0623\u0648 \u0627\u0644\u0634\u0647\u0631 \u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A\u060C \u0648\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0644\u0627 \u062A\u0634\u0645\u0644 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629.",
  "Plan campaigns against a budget, with committed and remaining spend.": "\u062E\u0637\u0651\u0637 \u062D\u0645\u0644\u0627\u062A\u0643 \u0648\u0641\u0642 \u0645\u064A\u0632\u0627\u0646\u064A\u0629\u060C \u0645\u0639 \u0627\u0644\u0625\u0646\u0641\u0627\u0642 \u0627\u0644\u0645\u0644\u062A\u0632\u0645 \u0628\u0647 \u0648\u0627\u0644\u0645\u062A\u0628\u0642\u064A.",
  "Upload creative, approve proof and download the publisher's tax invoice in one place.": "\u0627\u0631\u0641\u0639 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0648\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0648\u0646\u0632\u0651\u0644 \u0627\u0644\u0641\u0627\u062A\u0648\u0631\u0629 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u0629 \u0644\u0644\u0646\u0627\u0634\u0631 \u0645\u0646 \u0645\u0643\u0627\u0646 \u0648\u0627\u062D\u062F.",
  "Broadcast camera operators filming a live programme": "\u0645\u0635\u0648\u0631\u0648 \u0628\u062B \u064A\u0635\u0648\u0651\u0631\u0648\u0646 \u0628\u0631\u0646\u0627\u0645\u062C\u064B\u0627 \u0645\u0628\u0627\u0634\u0631\u064B\u0627",
  "For radio, TV, print, digital and podcasts": "\u0644\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0635\u062D\u0641 \u0648\u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0627\u0644\u0631\u0642\u0645\u064A\u0629 \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A",
  "Sell your inventory to serious buyers.": "\u0628\u0650\u0639 \u0645\u0633\u0627\u062D\u0627\u062A\u0643 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u062C\u0627\u062F\u0651\u064A\u0646.",
  "List programmes with their breaks, set a reserve, a buy-now price and a package price.": "\u0627\u0639\u0631\u0636 \u0627\u0644\u0628\u0631\u0627\u0645\u062C \u0628\u0641\u0648\u0627\u0635\u0644\u0647\u0627\u060C \u0648\u062D\u062F\u0651\u062F \u0633\u0639\u0631\u064B\u0627 \u0623\u062F\u0646\u0649 \u0648\u0633\u0639\u0631 \u0634\u0631\u0627\u0621 \u0641\u0648\u0631\u064A \u0648\u0633\u0639\u0631 \u0628\u0627\u0642\u0629.",
  "Decide with the full picture: the buyer, the brief and exactly what you receive.": "\u0642\u0631\u0651\u0631 \u0648\u0623\u0646\u062A \u062A\u0631\u0649 \u0627\u0644\u0635\u0648\u0631\u0629 \u0643\u0627\u0645\u0644\u0629: \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0648\u0627\u0644\u0645\u0648\u062C\u0632 \u0648\u0645\u0627 \u0633\u062A\u0633\u062A\u0644\u0645\u0647 \u0628\u0627\u0644\u0636\u0628\u0637.",
  "Tax invoices in your name and TRN, and a monthly payout statement.": "\u0641\u0648\u0627\u062A\u064A\u0631 \u0636\u0631\u064A\u0628\u064A\u0629 \u0628\u0627\u0633\u0645\u0643 \u0648\u0631\u0642\u0645\u0643 \u0627\u0644\u0636\u0631\u064A\u0628\u064A\u060C \u0648\u0643\u0634\u0641 \u0645\u062F\u0641\u0648\u0639\u0627\u062A \u0634\u0647\u0631\u064A.",
  "List your outlet": "\u0623\u0636\u0641 \u0645\u0646\u0635\u062A\u0643",
  "Nobody is paid until the ad has run.": "\u0644\u0627 \u064A\u064F\u062F\u0641\u0639 \u0644\u0623\u062D\u062F \u062D\u062A\u0649 \u064A\u064F\u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646.",
  "The buyer pays Nashr, Nashr holds it, and the publisher is paid when the proof is approved. If the ad doesn't run, the buyer is refunded. VAT and fees are shown before anyone commits.": "\u064A\u062F\u0641\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0644\u0646\u0634\u0631\u060C \u0648\u062A\u062D\u062A\u0641\u0638 \u0646\u0634\u0631 \u0628\u0627\u0644\u0645\u0628\u0644\u063A\u060C \u0648\u064A\u064F\u062F\u0641\u0639 \u0644\u0644\u0646\u0627\u0634\u0631 \u0639\u0646\u062F \u0627\u0639\u062A\u0645\u0627\u062F \u0627\u0644\u0625\u062B\u0628\u0627\u062A. \u0648\u0625\u0630\u0627 \u0644\u0645 \u064A\u064F\u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u064A\u064F\u0633\u062A\u0631\u062F \u0627\u0644\u0645\u0628\u0644\u063A \u0644\u0644\u0645\u0634\u062A\u0631\u064A. \u0648\u062A\u064F\u0639\u0631\u0636 \u0627\u0644\u0636\u0631\u064A\u0628\u0629 \u0648\u0627\u0644\u0631\u0633\u0648\u0645 \u0642\u0628\u0644 \u0623\u064A \u0627\u0644\u062A\u0632\u0627\u0645.",
  "Example booking: AED 5,500 radio break": "\u0645\u062B\u0627\u0644 \u0639\u0644\u0649 \u062D\u062C\u0632: \u0641\u0627\u0635\u0644 \u0625\u0630\u0627\u0639\u064A \u0628\u06405,500 \u062F\u0631\u0647\u0645",
  "Example: one radio break": "\u0645\u062B\u0627\u0644: \u0641\u0627\u0635\u0644 \u0625\u0630\u0627\u0639\u064A \u0648\u0627\u062D\u062F",
  "Held until proof": "\u0645\u062D\u0641\u0648\u0638 \u062D\u062A\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A",
  "Break price": "\u0633\u0639\u0631 \u0627\u0644\u0641\u0627\u0635\u0644",
  "AED 5,500": "5,500 \u062F\u0631\u0647\u0645",
  "VAT, charged by the publisher (5%)": "\u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629 \u064A\u0641\u0631\u0636\u0647\u0627 \u0627\u0644\u0646\u0627\u0634\u0631 (5%)",
  "AED 275": "275 \u062F\u0631\u0647\u0645",
  "Buyer pays": "\u064A\u062F\u0641\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "AED 5,775": "5,775 \u062F\u0631\u0647\u0645",
  "Nashr commission (example, 12%)": "\u0639\u0645\u0648\u0644\u0629 \u0646\u0634\u0631 (\u0645\u062B\u0627\u0644\u060C 12%)",
  "\u2212AED 660": "\u2212660 \u062F\u0631\u0647\u0645",
  "Publisher receives on approval": "\u064A\u0633\u062A\u0644\u0645 \u0627\u0644\u0646\u0627\u0634\u0631 \u0639\u0646\u062F \u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629",
  "AED 5,115": "5,115 \u062F\u0631\u0647\u0645",
  "Example figures. The commission rate is agreed with each publisher.": "\u0623\u0631\u0642\u0627\u0645 \u062A\u0648\u0636\u064A\u062D\u064A\u0629. \u064A\u064F\u062A\u0641\u0642 \u0639\u0644\u0649 \u0646\u0633\u0628\u0629 \u0627\u0644\u0639\u0645\u0648\u0644\u0629 \u0645\u0639 \u0643\u0644 \u0646\u0627\u0634\u0631.",
  "Questions buyers and publishers ask": "\u0623\u0633\u0626\u0644\u0629 \u064A\u0637\u0631\u062D\u0647\u0627 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646 \u0648\u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646",
  "Ready when your next campaign is.": "\u062C\u0627\u0647\u0632\u0648\u0646 \u0644\u062D\u0645\u0644\u062A\u0643 \u0627\u0644\u0642\u0627\u062F\u0645\u0629.",
  "Nashr is invite-only for UAE brands, agencies and media outlets. Our team reviews every request and sends an invite to your work email.": "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0646\u0634\u0631 \u0628\u062F\u0639\u0648\u0629 \u0641\u0642\u0637 \u0644\u0644\u0639\u0644\u0627\u0645\u0627\u062A \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629 \u0648\u0627\u0644\u0648\u0643\u0627\u0644\u0627\u062A \u0648\u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u0629 \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A. \u064A\u0631\u0627\u062C\u0639 \u0641\u0631\u064A\u0642\u0646\u0627 \u0643\u0644 \u0637\u0644\u0628 \u0648\u064A\u0631\u0633\u0644 \u062F\u0639\u0648\u0629 \u0625\u0644\u0649 \u0628\u0631\u064A\u062F\u0643 \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0644\u0644\u0639\u0645\u0644.",
  "The UAE media marketplace. Prices in AED, times in Dubai time.": "\u0633\u0648\u0642 \u0627\u0644\u0625\u0639\u0644\u0627\u0645 \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A. \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0628\u0627\u0644\u062F\u0631\u0647\u0645 \u0648\u0627\u0644\u0623\u0648\u0642\u0627\u062A \u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A.",
  "Product": "\u0627\u0644\u0645\u0646\u062A\u062C",
  "Account": "\u0627\u0644\u062D\u0633\u0627\u0628",
  "Legal": "\u0627\u0644\u0634\u0624\u0648\u0646 \u0627\u0644\u0642\u0627\u0646\u0648\u0646\u064A\u0629",
  "Terms": "\u0627\u0644\u0634\u0631\u0648\u0637",
  "Privacy": "\u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629",
  "Refunds": "\u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F",
  "Made for the UAE media market": "\u0635\u064F\u0645\u0651\u0645 \u0644\u0633\u0648\u0642 \u0627\u0644\u0625\u0639\u0644\u0627\u0645 \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A",
  // FAQ
  "What is Nashr?": "\u0645\u0627 \u0647\u064A \u0646\u0634\u0631\u061F",
  "Nashr is an online marketplace where UAE brands and agencies book advertising directly from radio stations, TV channels, newspapers, websites and podcasts.": "\u0646\u0634\u0631 \u0633\u0648\u0642 \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u062A\u062D\u062C\u0632 \u0641\u064A\u0647 \u0627\u0644\u0639\u0644\u0627\u0645\u0627\u062A \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629 \u0648\u0627\u0644\u0648\u0643\u0627\u0644\u0627\u062A \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A \u0625\u0639\u0644\u0627\u0646\u0627\u062A\u0647\u0627 \u0645\u0628\u0627\u0634\u0631\u0629\u064B \u0645\u0646 \u0645\u062D\u0637\u0627\u062A \u0627\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0642\u0646\u0648\u0627\u062A \u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0635\u062D\u0641 \u0648\u0627\u0644\u0645\u0648\u0627\u0642\u0639 \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A\u0629 \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A.",
  "How do I buy advertising on Nashr?": "\u0643\u064A\u0641 \u0623\u0634\u062A\u0631\u064A \u0625\u0639\u0644\u0627\u0646\u064B\u0627 \u0639\u0644\u0649 \u0646\u0634\u0631\u061F",
  "Find a slot on the calendar or in the directory, place a bid or request the buy-now price, and send your brief. Nothing is charged until the publisher accepts; then you pay within 48 hours.": "\u0627\u0628\u062D\u062B \u0639\u0646 \u0645\u0633\u0627\u062D\u0629 \u0641\u064A \u0627\u0644\u062A\u0642\u0648\u064A\u0645 \u0623\u0648 \u0627\u0644\u062F\u0644\u064A\u0644\u060C \u0648\u0642\u062F\u0651\u0645 \u0645\u0632\u0627\u064A\u062F\u0629 \u0623\u0648 \u0627\u0637\u0644\u0628 \u0633\u0639\u0631 \u0627\u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0641\u0648\u0631\u064A\u060C \u0648\u0623\u0631\u0633\u0644 \u0645\u0648\u062C\u0632\u0643. \u0644\u0627 \u064A\u064F\u062E\u0635\u0645 \u0623\u064A \u0645\u0628\u0644\u063A \u062D\u062A\u0649 \u064A\u0648\u0627\u0641\u0642 \u0627\u0644\u0646\u0627\u0634\u0631\u060C \u062B\u0645 \u062A\u062F\u0641\u0639 \u062E\u0644\u0627\u0644 48 \u0633\u0627\u0639\u0629.",
  "Is my payment safe?": "\u0647\u0644 \u062F\u0641\u0639\u062A\u064A \u0622\u0645\u0646\u0629\u061F",
  "Your payment is held by Nashr, not the publisher. The publisher is paid only after you approve proof that the ad ran, or automatically after five working days.": "\u062A\u062D\u062A\u0641\u0638 \u0646\u0634\u0631 \u0628\u062F\u0641\u0639\u062A\u0643\u060C \u0644\u0627 \u0627\u0644\u0646\u0627\u0634\u0631. \u0648\u0644\u0627 \u064A\u064F\u062F\u0641\u0639 \u0644\u0644\u0646\u0627\u0634\u0631 \u0625\u0644\u0627 \u0628\u0639\u062F \u0645\u0648\u0627\u0641\u0642\u062A\u0643 \u0639\u0644\u0649 \u0625\u062B\u0628\u0627\u062A \u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u060C \u0623\u0648 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627 \u0628\u0639\u062F \u062E\u0645\u0633\u0629 \u0623\u064A\u0627\u0645 \u0639\u0645\u0644.",
  "Are prices shown with VAT?": "\u0647\u0644 \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0645\u0639\u0631\u0648\u0636\u0629 \u062A\u0634\u0645\u0644 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629\u061F",
  "Prices are shown excluding VAT. Where the publisher is VAT-registered, 5% VAT is added at payment and shown before you pay.": "\u062A\u064F\u0639\u0631\u0636 \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u062F\u0648\u0646 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629. \u0648\u0625\u0630\u0627 \u0643\u0627\u0646 \u0627\u0644\u0646\u0627\u0634\u0631 \u0645\u0633\u062C\u0651\u0644\u064B\u0627 \u0641\u064A \u0627\u0644\u0636\u0631\u064A\u0628\u0629 \u062A\u064F\u0636\u0627\u0641 \u0636\u0631\u064A\u0628\u0629 5% \u0639\u0646\u062F \u0627\u0644\u062F\u0641\u0639 \u0648\u062A\u0638\u0647\u0631 \u0644\u0643 \u0642\u0628\u0644 \u0623\u0646 \u062A\u062F\u0641\u0639.",
  "Can I cancel a booking?": "\u0647\u0644 \u064A\u0645\u0643\u0646\u0646\u064A \u0625\u0644\u063A\u0627\u0621 \u062D\u062C\u0632\u061F",
  "Yes. Cancelling within 24 hours of paying is free apart from the card processing cost; after that a 15% cancellation fee applies, and there is no refund after the creative deadline.": "\u0646\u0639\u0645. \u0627\u0644\u0625\u0644\u063A\u0627\u0621 \u062E\u0644\u0627\u0644 24 \u0633\u0627\u0639\u0629 \u0645\u0646 \u0627\u0644\u062F\u0641\u0639 \u0645\u062C\u0627\u0646\u064A \u0628\u0627\u0633\u062A\u062B\u0646\u0627\u0621 \u0631\u0633\u0648\u0645 \u0645\u0639\u0627\u0644\u062C\u0629 \u0627\u0644\u0628\u0637\u0627\u0642\u0629\u060C \u0648\u0628\u0639\u062F \u0630\u0644\u0643 \u062A\u064F\u0637\u0628\u0651\u0642 \u0631\u0633\u0648\u0645 \u0625\u0644\u063A\u0627\u0621 \u0628\u0646\u0633\u0628\u0629 15%\u060C \u0648\u0644\u0627 \u064A\u064F\u0633\u062A\u0631\u062F \u0623\u064A \u0645\u0628\u0644\u063A \u0628\u0639\u062F \u0627\u0644\u0645\u0648\u0639\u062F \u0627\u0644\u0646\u0647\u0627\u0626\u064A \u0644\u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "How do publishers sell on Nashr?": "\u0643\u064A\u0641 \u064A\u0628\u064A\u0639 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0639\u0644\u0649 \u0646\u0634\u0631\u061F",
  "Publishers list programmes, breaks, pages or placements with a starting price, reserve and buy-now price, accept the bookings they want, and are paid after the buyer approves proof.": "\u064A\u0639\u0631\u0636 \u0627\u0644\u0646\u0627\u0634\u0631\u0648\u0646 \u0627\u0644\u0628\u0631\u0627\u0645\u062C \u0623\u0648 \u0627\u0644\u0641\u0648\u0627\u0635\u0644 \u0623\u0648 \u0627\u0644\u0635\u0641\u062D\u0627\u062A \u0623\u0648 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0628\u0633\u0639\u0631 \u0628\u062F\u0627\u064A\u0629 \u0648\u0633\u0639\u0631 \u0623\u062F\u0646\u0649 \u0648\u0633\u0639\u0631 \u0634\u0631\u0627\u0621 \u0641\u0648\u0631\u064A\u060C \u0648\u064A\u0642\u0628\u0644\u0648\u0646 \u0627\u0644\u062D\u062C\u0648\u0632\u0627\u062A \u0627\u0644\u062A\u064A \u064A\u0631\u064A\u062F\u0648\u0646\u0647\u0627\u060C \u0648\u064A\u064F\u062F\u0641\u0639 \u0644\u0647\u0645 \u0628\u0639\u062F \u0645\u0648\u0627\u0641\u0642\u0629 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0639\u0644\u0649 \u0627\u0644\u0625\u062B\u0628\u0627\u062A.",
  // Sign in and sign up
  "About Nashr": "\u0639\u0646 \u0646\u0634\u0631",
  "Channels": "\u0627\u0644\u0642\u0646\u0648\u0627\u062A",
  "Bid on radio breaks, TV spots, print pages, homepages and podcasts. Your money is held until the publisher proves the ad ran.": "\u0632\u0627\u064A\u062F \u0639\u0644\u0649 \u0627\u0644\u0641\u0648\u0627\u0635\u0644 \u0627\u0644\u0625\u0630\u0627\u0639\u064A\u0629 \u0648\u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646\u064A\u0629 \u0648\u0635\u0641\u062D\u0627\u062A \u0627\u0644\u0635\u062D\u0641 \u0648\u0627\u0644\u0645\u0648\u0627\u0642\u0639 \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A. \u064A\u0628\u0642\u0649 \u0645\u0627\u0644\u0643 \u0645\u062D\u0641\u0648\u0638\u064B\u0627 \u062D\u062A\u0649 \u064A\u064F\u062B\u0628\u062A \u0627\u0644\u0646\u0627\u0634\u0631 \u0623\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0642\u062F \u0628\u064F\u062B.",
  "Welcome back. Bid, book and follow every payment in one place.": "\u0623\u0647\u0644\u064B\u0627 \u0628\u0639\u0648\u062F\u062A\u0643. \u0632\u0627\u064A\u062F \u0648\u0627\u062D\u062C\u0632 \u0648\u062A\u0627\u0628\u0639 \u0643\u0644 \u062F\u0641\u0639\u0629 \u0645\u0646 \u0645\u0643\u0627\u0646 \u0648\u0627\u062D\u062F.",
  "Work email": "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0644\u0644\u0639\u0645\u0644",
  "Password": "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
  "Code from your authenticator app": "\u0627\u0644\u0631\u0645\u0632 \u0645\u0646 \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629",
  "6 digits": "6 \u0623\u0631\u0642\u0627\u0645",
  "Hide": "\u0625\u062E\u0641\u0627\u0621",
  "Show": "\u0625\u0638\u0647\u0627\u0631",
  "Signing in\u2026": "\u062C\u0627\u0631\u064D \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644\u2026",
  "New to Nashr?": "\u062C\u062F\u064A\u062F \u0639\u0644\u0649 \u0646\u0634\u0631\u061F",
  "Request sent": "\u0623\u064F\u0631\u0633\u0644 \u0627\u0644\u0637\u0644\u0628",
  "Thanks. Nashr's team reviews every request and will email you an invite link once approved.": "\u0634\u0643\u0631\u064B\u0627 \u0644\u0643. \u064A\u0631\u0627\u062C\u0639 \u0641\u0631\u064A\u0642 \u0646\u0634\u0631 \u0643\u0644 \u0637\u0644\u0628 \u0648\u0633\u064A\u0631\u0633\u0644 \u0625\u0644\u064A\u0643 \u0631\u0627\u0628\u0637 \u0627\u0644\u062F\u0639\u0648\u0629 \u0628\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0639\u0646\u062F \u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629.",
  "Nashr is invite-only for UAE brands, agencies and media outlets. Tell us who you are and we will be in touch.": "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0646\u0634\u0631 \u0628\u062F\u0639\u0648\u0629 \u0641\u0642\u0637 \u0644\u0644\u0639\u0644\u0627\u0645\u0627\u062A \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629 \u0648\u0627\u0644\u0648\u0643\u0627\u0644\u0627\u062A \u0648\u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u0629 \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A. \u0639\u0631\u0651\u0641\u0646\u0627 \u0628\u0646\u0641\u0633\u0643 \u0648\u0633\u0646\u062A\u0648\u0627\u0635\u0644 \u0645\u0639\u0643.",
  "Full name": "\u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0643\u0627\u0645\u0644",
  "Phone": "\u0627\u0644\u0647\u0627\u062A\u0641",
  "Company": "\u0627\u0644\u0634\u0631\u0643\u0629",
  "Your role": "\u0645\u0646\u0635\u0628\u0643",
  "You are": "\u0623\u0646\u062A",
  "A brand": "\u0639\u0644\u0627\u0645\u0629 \u062A\u062C\u0627\u0631\u064A\u0629",
  "An agency": "\u0648\u0643\u0627\u0644\u0629",
  "A media outlet": "\u0645\u0646\u0635\u0629 \u0625\u0639\u0644\u0627\u0645\u064A\u0629",
  "Sending\u2026": "\u062C\u0627\u0631\u064D \u0627\u0644\u0625\u0631\u0633\u0627\u0644\u2026",
  "Send request": "\u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0637\u0644\u0628",
  "By sending, you agree to Nashr's": "\u0628\u0627\u0644\u0625\u0631\u0633\u0627\u0644\u060C \u0641\u0625\u0646\u0643 \u062A\u0648\u0627\u0641\u0642 \u0639\u0644\u0649",
  "terms of use": "\u0634\u0631\u0648\u0637 \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645",
  "and": "\u0648",
  "privacy policy": "\u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629 \u0644\u062F\u0649 \u0646\u0634\u0631",
  "Already invited?": "\u0644\u062F\u064A\u0643 \u062F\u0639\u0648\u0629\u061F",
  "You are in": "\u062A\u0645 \u0627\u0644\u062A\u0641\u0639\u064A\u0644",
  "Set your password": "\u0639\u064A\u0651\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
  "Your account is ready. Sign in with your work email and new password.": "\u062D\u0633\u0627\u0628\u0643 \u062C\u0627\u0647\u0632. \u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0628\u0631\u064A\u062F\u0643 \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0644\u0644\u0639\u0645\u0644 \u0648\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062C\u062F\u064A\u062F\u0629.",
  "Choose a password for your Nashr account. Use at least 12 characters.": "\u0627\u062E\u062A\u0631 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u0644\u062D\u0633\u0627\u0628\u0643 \u0641\u064A \u0646\u0634\u0631\u060C \u0645\u0646 12 \u062D\u0631\u0641\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
  "Repeat password": "\u0623\u0639\u062F \u0643\u062A\u0627\u0628\u0629 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
  "Staff accounts need an authenticator app. Add this key to your app, then enter the 6-digit code.": "\u062A\u062A\u0637\u0644\u0628 \u062D\u0633\u0627\u0628\u0627\u062A \u0627\u0644\u0645\u0648\u0638\u0641\u064A\u0646 \u062A\u0637\u0628\u064A\u0642 \u0645\u0635\u0627\u062F\u0642\u0629. \u0623\u0636\u0641 \u0647\u0630\u0627 \u0627\u0644\u0645\u0641\u062A\u0627\u062D \u0625\u0644\u0649 \u0627\u0644\u062A\u0637\u0628\u064A\u0642\u060C \u062B\u0645 \u0623\u062F\u062E\u0644 \u0627\u0644\u0631\u0645\u0632 \u0627\u0644\u0645\u0643\u0648\u0651\u0646 \u0645\u0646 6 \u0623\u0631\u0642\u0627\u0645.",
  "Activate": "\u062A\u0641\u0639\u064A\u0644",
  "Continue": "\u0645\u062A\u0627\u0628\u0639\u0629",
  // Directory and outlet pages
  "UAE radio, TV, print, digital and podcasts. Outlets on Nashr can be booked; others take a quote request.": "\u0627\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0635\u062D\u0641 \u0648\u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0627\u0644\u0631\u0642\u0645\u064A\u0629 \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A. \u064A\u0645\u0643\u0646 \u062D\u062C\u0632 \u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0627\u0644\u0645\u0633\u062C\u0651\u0644\u0629 \u0639\u0644\u0649 \u0646\u0634\u0631\u060C \u0648\u0644\u0644\u0645\u0646\u0635\u0627\u062A \u0627\u0644\u0623\u062E\u0631\u0649 \u064A\u0645\u0643\u0646\u0643 \u0637\u0644\u0628 \u0639\u0631\u0636 \u0633\u0639\u0631.",
  "Price on request": "\u0627\u0644\u0633\u0639\u0631 \u0639\u0646\u062F \u0627\u0644\u0637\u0644\u0628",
  "Book slots": "\u0627\u062D\u062C\u0632 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A",
  "Coming soon": "\u0642\u0631\u064A\u0628\u064B\u0627",
  "Not on Nashr yet \xB7 request a quote": "\u063A\u064A\u0631 \u0645\u0633\u062C\u0651\u0644\u0629 \u0639\u0644\u0649 \u0646\u0634\u0631 \u0628\u0639\u062F \xB7 \u0627\u0637\u0644\u0628 \u0639\u0631\u0636 \u0633\u0639\u0631",
  "On Nashr \xB7 book slots": "\u0639\u0644\u0649 \u0646\u0634\u0631 \xB7 \u0627\u062D\u062C\u0632 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A",
  "Request quote": "\u0637\u0644\u0628 \u0639\u0631\u0636 \u0633\u0639\u0631",
  "All": "\u0627\u0644\u0643\u0644",
  "Channel": "\u0627\u0644\u0642\u0646\u0627\u0629",
  "Grid": "\u0634\u0628\u0643\u0629",
  "List": "\u0642\u0627\u0626\u0645\u0629",
  "No outlets match. Clear the filters to see everything.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0646\u0635\u0627\u062A \u0645\u0637\u0627\u0628\u0642\u0629. \u0627\u0645\u0633\u062D \u0639\u0648\u0627\u0645\u0644 \u0627\u0644\u062A\u0635\u0641\u064A\u0629 \u0644\u0631\u0624\u064A\u0629 \u0643\u0644 \u0634\u064A\u0621.",
  "Outlet": "\u0627\u0644\u0645\u0646\u0635\u0629",
  "Price": "\u0627\u0644\u0633\u0639\u0631",
  "Sectors": "\u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A",
  "UAE": "\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A",
  "KSA \xB7 coming soon": "\u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629 \xB7 \u0642\u0631\u064A\u0628\u064B\u0627",
  "Market": "\u0627\u0644\u0633\u0648\u0642",
  "Search": "\u0628\u062D\u062B",
  "View": "\u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u0639\u0631\u0636",
  "Search outlets, sectors, audiences": "\u0627\u0628\u062D\u062B \u0639\u0646 \u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0648\u0627\u0644\u0642\u0637\u0627\u0639\u0627\u062A \u0648\u0627\u0644\u062C\u0645\u0627\u0647\u064A\u0631",
  "On Nashr only": "\u0627\u0644\u0645\u0633\u062C\u0651\u0644\u0629 \u0639\u0644\u0649 \u0646\u0634\u0631 \u0641\u0642\u0637",
  "Saudi Arabia opens soon. You can add Saudi outlets to a campaign plan now; booking opens with the market.": "\u064A\u064F\u0641\u062A\u062A\u062D \u0633\u0648\u0642 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629 \u0642\u0631\u064A\u0628\u064B\u0627. \u064A\u0645\u0643\u0646\u0643 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629 \u0625\u0644\u0649 \u062E\u0637\u0629 \u062D\u0645\u0644\u062A\u0643 \u0627\u0644\u0622\u0646\u060C \u0648\u064A\u064F\u0641\u062A\u062D \u0627\u0644\u062D\u062C\u0632 \u0645\u0639 \u0627\u0641\u062A\u062A\u0627\u062D \u0627\u0644\u0633\u0648\u0642.",
  "Tell me when KSA opens": "\u0623\u0628\u0644\u063A\u0646\u064A \u0639\u0646\u062F \u0627\u0641\u062A\u062A\u0627\u062D \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629",
  "You're on the list. We'll tell you when it opens.": "\u062A\u0645\u062A \u0625\u0636\u0627\u0641\u062A\u0643 \u0625\u0644\u0649 \u0627\u0644\u0642\u0627\u0626\u0645\u0629. \u0633\u0646\u0628\u0644\u063A\u0643 \u0639\u0646\u062F \u0627\u0644\u0627\u0641\u062A\u062A\u0627\u062D.",
  "Add to campaign": "\u0623\u0636\u0641 \u0625\u0644\u0649 \u062D\u0645\u0644\u0629",
  "Add to campaign\u2026": "\u0623\u0636\u0641 \u0625\u0644\u0649 \u062D\u0645\u0644\u0629\u2026",
  "Added to {name}.": "\u0623\u064F\u0636\u064A\u0641\u062A \u0625\u0644\u0649 {name}.",
  "Coming soon: this market is not open yet. You can plan it in a campaign; booking opens with the market.": "\u0642\u0631\u064A\u0628\u064B\u0627: \u0647\u0630\u0627 \u0627\u0644\u0633\u0648\u0642 \u063A\u064A\u0631 \u0645\u0641\u062A\u0648\u062D \u0628\u0639\u062F. \u064A\u0645\u0643\u0646\u0643 \u0625\u0636\u0627\u0641\u062A\u0647 \u0625\u0644\u0649 \u062E\u0637\u0629 \u062D\u0645\u0644\u0629\u060C \u0648\u064A\u064F\u0641\u062A\u062D \u0627\u0644\u062D\u062C\u0632 \u0645\u0639 \u0627\u0641\u062A\u062A\u0627\u062D \u0627\u0644\u0633\u0648\u0642.",
  "On Nashr": "\u0639\u0644\u0649 \u0646\u0634\u0631",
  "{n} completed bookings": "{n} \u062D\u062C\u0632\u064B\u0627 \u0645\u0643\u062A\u0645\u0644\u064B\u0627",
  "New on Nashr": "\u062C\u062F\u064A\u062F \u0639\u0644\u0649 \u0646\u0634\u0631",
  "Website": "\u0627\u0644\u0645\u0648\u0642\u0639 \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
  "This range is Nashr's estimate. The outlet has not confirmed it.": "\u0647\u0630\u0627 \u0627\u0644\u0646\u0637\u0627\u0642 \u062A\u0642\u062F\u064A\u0631 \u0645\u0646 \u0646\u0634\u0631\u060C \u0648\u0644\u0645 \u062A\u0624\u0643\u062F\u0647 \u0627\u0644\u0645\u0646\u0635\u0629.",
  "Request a quote": "\u0627\u0637\u0644\u0628 \u0639\u0631\u0636 \u0633\u0639\u0631",
  "This outlet isn't on Nashr yet. Tell us what you need and Nashr's team will get you a price.": "\u0647\u0630\u0647 \u0627\u0644\u0645\u0646\u0635\u0629 \u063A\u064A\u0631 \u0645\u0633\u062C\u0651\u0644\u0629 \u0639\u0644\u0649 \u0646\u0634\u0631 \u0628\u0639\u062F. \u0623\u062E\u0628\u0631\u0646\u0627 \u0628\u0645\u0627 \u062A\u062D\u062A\u0627\u062C\u0647 \u0648\u0633\u064A\u062D\u0635\u0644 \u0644\u0643 \u0641\u0631\u064A\u0642 \u0646\u0634\u0631 \u0639\u0644\u0649 \u0627\u0644\u0633\u0639\u0631.",
  "What you'd like to book": "\u0645\u0627 \u0627\u0644\u0630\u064A \u062A\u0631\u064A\u062F \u062D\u062C\u0632\u0647",
  "Dates, formats, budget": "\u0627\u0644\u062A\u0648\u0627\u0631\u064A\u062E \u0648\u0627\u0644\u0635\u064A\u063A \u0648\u0627\u0644\u0645\u064A\u0632\u0627\u0646\u064A\u0629",
  "Emails and phone numbers are not allowed.": "\u0644\u0627 \u064A\u064F\u0633\u0645\u062D \u0628\u0639\u0646\u0627\u0648\u064A\u0646 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0648\u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0647\u0648\u0627\u062A\u0641.",
  "Sent. Nashr will come back to you with a quote.": "\u062A\u0645 \u0627\u0644\u0625\u0631\u0633\u0627\u0644. \u0633\u062A\u0639\u0648\u062F \u0625\u0644\u064A\u0643 \u0646\u0634\u0631 \u0628\u0639\u0631\u0636 \u0633\u0639\u0631.",
  "What buyers say": "\u0622\u0631\u0627\u0621 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646",
  "Verified booking": "\u062D\u062C\u0632 \u0645\u0648\u062B\u0651\u0642",
  "Placement": "\u0627\u0644\u0645\u0633\u0627\u062D\u0629",
  "When": "\u0627\u0644\u0645\u0648\u0639\u062F",
  "Sold as": "\u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u0628\u064A\u0639",
  "From": "\u0627\u0628\u062A\u062F\u0627\u0621\u064B \u0645\u0646",
  "Options": "\u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A",
  "Next open": "\u0627\u0644\u062A\u0627\u0644\u064A \u0627\u0644\u0645\u062A\u0627\u062D",
  "{n} positions": "{n} \u0645\u0648\u0627\u0636\u0639",
  "{n} breaks": "{n} \u0641\u0648\u0627\u0635\u0644",
  "buy now {price}": "\u0634\u0631\u0627\u0621 \u0641\u0648\u0631\u064A \u0628\u0640{price}",
  "Any break {price}": "\u0623\u064A \u0641\u0627\u0635\u0644 \u0628\u0640{price}",
  "All breaks {price}": "\u062C\u0645\u064A\u0639 \u0627\u0644\u0641\u0648\u0627\u0635\u0644 \u0628\u0640{price}",
  "{n} open": "{n} \u0645\u062A\u0627\u062D",
  "Nothing open": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u062A\u0627\u062D",
  "Mon": "\u0627\u0644\u0625\u062B\u0646\u064A\u0646",
  "Tue": "\u0627\u0644\u062B\u0644\u0627\u062B\u0627\u0621",
  "Wed": "\u0627\u0644\u0623\u0631\u0628\u0639\u0627\u0621",
  "Thu": "\u0627\u0644\u062E\u0645\u064A\u0633",
  "Fri": "\u0627\u0644\u062C\u0645\u0639\u0629",
  "Sat": "\u0627\u0644\u0633\u0628\u062A",
  "Sun": "\u0627\u0644\u0623\u062D\u062F",
  // Calendar
  "Not available": "\u063A\u064A\u0631 \u0645\u062A\u0627\u062D",
  "Outbid": "\u062A\u062C\u0627\u0648\u0632\u0643 \u0622\u062E\u0631\u0648\u0646",
  "Open to offers": "\u0645\u0641\u062A\u0648\u062D \u0644\u0644\u0639\u0631\u0648\u0636",
  "Starting price": "\u0633\u0639\u0631 \u0627\u0644\u0628\u062F\u0627\u064A\u0629",
  "{n} interested": "{n} \u0645\u0647\u062A\u0645\u0651\u0648\u0646",
  "{n} bids": "{n} \u0645\u0632\u0627\u064A\u062F\u0627\u062A",
  "Nothing open for these days. Bidding closes a few days before air.": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u062A\u0627\u062D \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0623\u064A\u0627\u0645. \u062A\u064F\u063A\u0644\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B \u0628\u0628\u0636\u0639\u0629 \u0623\u064A\u0627\u0645.",
  "Show the next week": "\u0627\u0639\u0631\u0636 \u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u0627\u0644\u062A\u0627\u0644\u064A",
  "All day": "\u0637\u0648\u0627\u0644 \u0627\u0644\u064A\u0648\u0645",
  ", {n} options": "\u060C {n} \u062E\u064A\u0627\u0631\u0627\u062A",
  "from {price}": "\u0627\u0628\u062A\u062F\u0627\u0621\u064B \u0645\u0646 {price}",
  "Filters": "\u0639\u0648\u0627\u0645\u0644 \u0627\u0644\u062A\u0635\u0641\u064A\u0629",
  "Sign in to save this search and get an alert when new slots match.": "\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0644\u062D\u0641\u0638 \u0647\u0630\u0627 \u0627\u0644\u0628\u062D\u062B \u0648\u062A\u0644\u0642\u0651\u064A \u062A\u0646\u0628\u064A\u0647 \u0639\u0646\u062F \u062A\u0648\u0641\u0651\u0631 \u0645\u0633\u0627\u062D\u0627\u062A \u062C\u062F\u064A\u062F\u0629 \u0645\u0637\u0627\u0628\u0642\u0629.",
  "Outlet, programme or audience": "\u0627\u0644\u0645\u0646\u0635\u0629 \u0623\u0648 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C \u0623\u0648 \u0627\u0644\u062C\u0645\u0647\u0648\u0631",
  "Sale type": "\u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u0628\u064A\u0639",
  "Sector": "\u0627\u0644\u0642\u0637\u0627\u0639",
  "Any sector": "\u0623\u064A \u0642\u0637\u0627\u0639",
  "Up to (AED, excl. VAT)": "\u062D\u062A\u0649 (\u0628\u0627\u0644\u062F\u0631\u0647\u0645\u060C \u062F\u0648\u0646 \u0627\u0644\u0636\u0631\u064A\u0628\u0629)",
  "Any price": "\u0623\u064A \u0633\u0639\u0631",
  "Time of day": "\u0648\u0642\u062A \u0627\u0644\u064A\u0648\u0645",
  "Bidding closes within 24 hours": "\u062A\u064F\u063A\u0644\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u062E\u0644\u0627\u0644 24 \u0633\u0627\u0639\u0629",
  "Clear filters": "\u0645\u0633\u062D \u0639\u0648\u0627\u0645\u0644 \u0627\u0644\u062A\u0635\u0641\u064A\u0629",
  "Key": "\u062F\u0644\u064A\u0644 \u0627\u0644\u0631\u0645\u0648\u0632",
  "Closes soon": "\u064A\u064F\u063A\u0644\u0642 \u0642\u0631\u064A\u0628\u064B\u0627",
  "All times are Dubai time. Prices exclude VAT.": "\u062C\u0645\u064A\u0639 \u0627\u0644\u0623\u0648\u0642\u0627\u062A \u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A. \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0644\u0627 \u062A\u0634\u0645\u0644 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629.",
  "Every open radio break, TV spot, page and takeover, in Dubai time. Prices exclude VAT.": "\u0643\u0644 \u0627\u0644\u0641\u0648\u0627\u0635\u0644 \u0627\u0644\u0625\u0630\u0627\u0639\u064A\u0629 \u0648\u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646\u064A\u0629 \u0648\u0627\u0644\u0635\u0641\u062D\u0627\u062A \u0648\u0627\u0644\u0627\u0633\u062A\u062D\u0648\u0627\u0630\u0627\u062A \u0627\u0644\u0645\u062A\u0627\u062D\u0629 \u0628\u062A\u0648\u0642\u064A\u062A \u062F\u0628\u064A. \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0644\u0627 \u062A\u0634\u0645\u0644 \u0636\u0631\u064A\u0628\u0629 \u0627\u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629.",
  "{n} of {total} slots": "{n} \u0645\u0646 {total} \u0645\u0633\u0627\u062D\u0629",
  "Today": "\u0627\u0644\u064A\u0648\u0645",
  "Previous": "\u0627\u0644\u0633\u0627\u0628\u0642",
  "Next": "\u0627\u0644\u062A\u0627\u0644\u064A",
  "Day": "\u064A\u0648\u0645",
  "Week": "\u0623\u0633\u0628\u0648\u0639",
  "Month": "\u0634\u0647\u0631",
  "Week of {from} \u2013 {to}": "\u0623\u0633\u0628\u0648\u0639 {from} \u2013 {to}",
  "No slots match these filters this week.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0633\u0627\u062D\u0627\u062A \u0645\u0637\u0627\u0628\u0642\u0629 \u0644\u0639\u0648\u0627\u0645\u0644 \u0627\u0644\u062A\u0635\u0641\u064A\u0629 \u0647\u0630\u0627 \u0627\u0644\u0623\u0633\u0628\u0648\u0639.",
  "No slots match these filters this day.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0633\u0627\u062D\u0627\u062A \u0645\u0637\u0627\u0628\u0642\u0629 \u0644\u0639\u0648\u0627\u0645\u0644 \u0627\u0644\u062A\u0635\u0641\u064A\u0629 \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u064A\u0648\u0645.",
  "No slots match these filters this month.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0633\u0627\u062D\u0627\u062A \u0645\u0637\u0627\u0628\u0642\u0629 \u0644\u0639\u0648\u0627\u0645\u0644 \u0627\u0644\u062A\u0635\u0641\u064A\u0629 \u0647\u0630\u0627 \u0627\u0644\u0634\u0647\u0631.",
  "Your payment is held until the publisher proves the ad ran. You pay only once the publisher accepts.": "\u062A\u0628\u0642\u0649 \u062F\u0641\u0639\u062A\u0643 \u0645\u062D\u0641\u0648\u0638\u0629 \u062D\u062A\u0649 \u064A\u064F\u062B\u0628\u062A \u0627\u0644\u0646\u0627\u0634\u0631 \u0623\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0642\u062F \u0628\u064F\u062B. \u0648\u0644\u0627 \u062A\u062F\u0641\u0639 \u0625\u0644\u0627 \u0628\u0639\u062F \u0645\u0648\u0627\u0641\u0642\u0629 \u0627\u0644\u0646\u0627\u0634\u0631.",
  "{n} breaks \xB7 from ": "{n} \u0641\u0648\u0627\u0635\u0644 \xB7 \u0627\u0628\u062A\u062F\u0627\u0621\u064B \u0645\u0646 ",
  "You lead on {n}": "\u0623\u0646\u062A \u0641\u064A \u0627\u0644\u0645\u0642\u062F\u0645\u0629 \u0641\u064A {n}",
  "+{n} more": "+{n} \u0623\u062E\u0631\u0649",
  "Nothing on sale this day. Try the next day or the week view.": "\u0644\u0627 \u0634\u064A\u0621 \u0645\u0639\u0631\u0648\u0636 \u0644\u0644\u0628\u064A\u0639 \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u064A\u0648\u0645. \u062C\u0631\u0651\u0628 \u0627\u0644\u064A\u0648\u0645 \u0627\u0644\u062A\u0627\u0644\u064A \u0623\u0648 \u0639\u0631\u0636 \u0627\u0644\u0623\u0633\u0628\u0648\u0639.",
  "Close": "\u0625\u063A\u0644\u0627\u0642",
  "Morning (5\u201312)": "\u0627\u0644\u0635\u0628\u0627\u062D (5\u201312)",
  "Afternoon (12\u201317)": "\u0627\u0644\u0638\u0647\u064A\u0631\u0629 (12\u201317)",
  "Evening (17\u201324)": "\u0627\u0644\u0645\u0633\u0627\u0621 (17\u201324)",
  "All day (pages, takeovers)": "\u0637\u0648\u0627\u0644 \u0627\u0644\u064A\u0648\u0645 (\u0635\u0641\u062D\u0627\u062A\u060C \u0627\u0633\u062A\u062D\u0648\u0627\u0630\u0627\u062A)"
};
Object.assign(AR, AR_BUYER, AR_SELLER, AR_ADMIN, AR_UPGRADE, AR_CALENDAR, AR_FLOW);

// web/src/notices.ts
function noticeTexts(t, money2, day2, server = (s) => s) {
  const lab = (l) => (l ?? "").split(" \xB7 ").map((x) => x && server(x)).join(" \xB7 ");
  const aedOf = (n2) => n2 == null ? "" : money2(n2);
  return {
    "deal.awaiting_payment": () => t("The publisher accepted. Pay to secure the slot."),
    "deal.declined": () => t("Your request was not selected."),
    "deal.countered": (n2) => t("The publisher offered {slot} at {amount} instead of {was}. Agree to book it, or keep your offer.", { slot: `${n2.data?.outlet ? `${n2.data.outlet} \xB7 ` : ""}${lab(n2.data?.label) ?? t("a slot")}`, amount: aedOf(n2.data?.amount), was: aedOf(n2.data?.was) }),
    "deal.counter_agreed": (n2) => t("The buyer agreed to your price of {amount}. The booking is accepted; they pay next.", { amount: aedOf(n2.data?.amount) }),
    "deal.counter_refused": (n2) => t("The buyer kept their offer of {was} instead of {amount}. Accept or decline it.", { amount: aedOf(n2.data?.amount), was: aedOf(n2.data?.was) }),
    "deal.lapsed": () => t("The payment window passed and the booking lapsed."),
    "deal.secured": () => t("Payment is secured."),
    "deal.cancelled": () => t("The booking was cancelled."),
    "deal.refunded": () => t("A refund was issued."),
    "deal.released": () => t("Payment was released."),
    "access.staff_signed_in": (n2) => t("Nashr's team signed in to your account as {user} to help. Reason: {reason}", { user: n2.data?.user ?? "", reason: server(n2.data?.reason ?? "") }),
    "support.new": (n2) => t("New question from {company}.", { company: n2.data?.company ?? "" }),
    "support.replied": () => t("Nashr answered your question."),
    "ops.alert": (n2) => t("Needs attention: {detail}", { detail: server(n2.data?.detail ?? "") }),
    "ops.cleared": (n2) => t("Cleared: {detail}", { detail: server(n2.data?.detail ?? "") }),
    "access.two_step_reset": (n2) => t("Nashr turned off two-step sign-in for {user}. Reason: {reason}", { user: n2.data?.user ?? "", reason: server(n2.data?.reason ?? "") }),
    "access.reset_issued": (n2) => t("Nashr issued a password reset link for {user}, who asked for one.", { user: n2.data?.user ?? "" }),
    "chargeback.closed": (n2) => n2.data?.won ? t("The bank decided a chargeback for Nashr. Decide the dispute now.") : t("The bank decided a chargeback for the buyer. The booking is closed as refunded."),
    "bid.won": (n2) => t("You won {slot} at {amount}. The publisher confirms next, then you pay.", { slot: `${n2.data?.outlet} \xB7 ${lab(n2.data?.label)}`, amount: aedOf(n2.data?.amount ?? 0) }),
    "bid.closed_lost": (n2) => t("Bidding closed on {slot}. Another bid was higher; if the publisher passes on it, you may be offered the slot.", { slot: `${n2.data?.outlet} \xB7 ${lab(n2.data?.label)}` }),
    "deal.opened": (n2) => n2.data?.kind === "buy_now" ? t("New buy-now request.") : t("New booking to decide on."),
    "access.reset_requested": () => t("Someone asked to reset their password. Send them a link from their account page."),
    "bid.not_selected": (n2) => t("Your bid on {slot} was not selected. The slot has gone to another buyer or is no longer on sale.", { slot: `${n2.data?.outlet ? `${n2.data.outlet} \xB7 ` : ""}${lab(n2.data?.label) ?? t("a slot")}` }),
    "interest.received": (n2) => t("A buyer is interested in {slot}. Accept to book it.", { slot: `${n2.data?.outlet ? `${n2.data.outlet} \xB7 ` : ""}${lab(n2.data?.label) ?? t("a slot")}` }),
    "interest.not_selected": (n2) => t("The publisher booked {slot} with another buyer.", { slot: `${n2.data?.outlet ? `${n2.data.outlet} \xB7 ` : ""}${lab(n2.data?.label) ?? t("a slot")}` }),
    "interest.expired": (n2) => t("The publisher did not take up your interest in {slot} before it closed.", { slot: `${n2.data?.outlet ? `${n2.data.outlet} \xB7 ` : ""}${lab(n2.data?.label) ?? t("a slot")}` }),
    "bid.outbid": (n2) => n2.data?.max ? t("Your auto-bid maximum of {max} on {slot} was passed. Raise it to get back in front.", { max: aedOf(n2.data.max), slot: `${n2.data?.outlet ? `${n2.data.outlet} \xB7 ` : ""}${lab(n2.data?.label) ?? t("a slot")}` }) : t("You were outbid on {slot}.", { slot: `${n2.data?.outlet ? `${n2.data.outlet} \xB7 ` : ""}${lab(n2.data?.label) ?? t("a slot")}` }),
    "bid.auto_raised": (n2) => t("Auto-bid kept you in front on {slot}: you lead at {amount} (maximum {max}).", { slot: `${n2.data?.outlet ? `${n2.data.outlet} \xB7 ` : ""}${lab(n2.data?.label)}`, amount: aedOf(n2.data?.amount), max: aedOf(n2.data?.max) }),
    "bid.auto_cap": (n2) => t("Auto-bid reached your maximum of {max} on {slot}. You still lead; raise it in case someone bids again.", { slot: `${n2.data?.outlet ? `${n2.data.outlet} \xB7 ` : ""}${lab(n2.data?.label)}`, max: aedOf(n2.data?.max) }),
    "creative.sent": () => t("New creative to review."),
    "creative.approved": () => t("Your creative was approved."),
    "creative.changes_requested": (n2) => n2.data?.reason ? t("The publisher asked for changes: {reason}", { reason: server(n2.data.reason) }) : t("The publisher asked for changes."),
    "creative.technical_issue": () => t("Your file has a technical problem. Upload a fixed version."),
    "creative.rejected": () => t("Your creative was rejected."),
    "proof.ready": () => t("Proof is ready for your review."),
    "reminder.decide": () => t("Reminder: a booking request is waiting for your decision."),
    "reminder.pay": () => t("Reminder: pay to secure your booking before the deadline."),
    "reminder.review": () => t("Reminder: review the proof. The money is released automatically at the deadline."),
    "reminder.issue": () => t("Reminder: respond to the reported issue, or it goes to Nashr to decide."),
    "access.signed_out": (n2) => t("Nashr signed {user} out of every device. Reason: {reason}", { user: n2.data?.user ?? "", reason: server(n2.data?.reason ?? "") }),
    "access.password_reset_self": (n2) => t("{user} reset their password with their authenticator app and was signed out everywhere.", { user: n2.data?.user ?? "" }),
    "team.removed": (n2) => t("{user} was removed from your team.", { user: n2.data?.user ?? "" }),
    "invoice.upload_needed": (n2) => t("Upload your tax invoice for order {order}.", { order: n2.data?.order ?? "" }),
    "invoice.credit_note_needed": (n2) => t("This booking was refunded. Upload a credit note for invoice {invoice}.", { invoice: n2.data?.invoice ?? "" }),
    "issue.reported": () => t("The buyer reported an issue."),
    "issue.offer": () => t("The publisher offered a fix for your issue."),
    "issue.resolved": () => t("The issue was resolved."),
    "dispute.opened": (n2) => n2.data?.decideBy ? t("Nashr will decide this dispute by {date}. Add your side and any files from the booking.", { date: day2(n2.data.decideBy) }) : t("A dispute was opened."),
    "dispute.statement": (n2) => n2.data?.side === "buyer" ? t("The buyer added to the dispute case.") : t("The publisher added to the dispute case."),
    "dispute.decided": (n2) => ({
      release: t("Nashr decided the dispute: the payment is released to the publisher."),
      refund: t("Nashr decided the dispute: full refund to the buyer."),
      partial_refund: t("Nashr decided the dispute: a partial refund to the buyer."),
      make_good: t("Nashr decided the dispute: the ad runs again.")
    }[n2.data?.outcome] ?? t("Nashr decided the dispute.")) + (n2.data?.reason ? ` ${t("Reason: {reason}", { reason: server(n2.data.reason) })}` : ""),
    "deal.nashr_action": (n2) => ({
      cancel: t("Nashr cancelled this booking."),
      refund: t("Nashr refunded this booking in full."),
      partial_refund: t("Nashr refunded part of this booking and released the rest."),
      release: t("Nashr released the payment to the publisher.")
    })[n2.data?.action] + (n2.data?.reason ? ` ${t("Reason: {reason}", { reason: server(n2.data.reason) })}` : ""),
    "bid.voided": (n2) => t("Nashr voided your bid on {slot}. Reason: {reason}", { slot: `${n2.data?.outlet ? `${n2.data.outlet} \xB7 ` : ""}${lab(n2.data?.label)}`, reason: server(n2.data?.reason ?? "") }),
    "chargeback.opened": (n2) => n2.data?.released ? t("A buyer's bank disputed a payment that was already released. Recover it from the publisher.") : t("A buyer's bank disputed a payment. The booking is now a dispute for Nashr."),
    "prerun.confirm_final_version": () => t("Confirm the final version before air."),
    "prerun.confirm_slot_and_creative": () => t("Confirm the slot and creative before air."),
    "message.new": (n2) => n2.data?.from === "seller" ? t("New message from the publisher.") : t("New message from the buyer."),
    "search.match": (n2) => t(n2.data?.count === 1 ? "1 new slot matches your search \u201C{name}\u201D." : "{n} new slots match your search \u201C{name}\u201D.", { n: n2.data?.count ?? "", name: n2.data?.name ?? "" }),
    "access.requested": (n2) => t("{company} requested access.", { company: n2.data?.company ?? t("Someone") }),
    "quote.requested": (n2) => t("Quote requested for {outlet}.", { outlet: n2.data?.outlet ?? t("an outlet") })
  };
}
function noticeHref(n2, role) {
  if (role === "admin" || role === "founder") {
    if (n2.kind === "access.requested") return "/access";
    if (n2.kind === "quote.requested") return "/directory";
    if (n2.kind.startsWith("ops.") && !n2.dealId) return "/admin";
    if (n2.dealId && n2.kind !== "message.new" && n2.kind !== "support.new") return `/deals/${n2.dealId}`;
  }
  return n2.kind === "support.new" ? "/support" : n2.kind.startsWith("ops.") ? "/admin" : n2.kind === "support.replied" ? "/help" : n2.kind === "message.new" && n2.dealId ? `/messages/${n2.dealId}` : n2.dealId ? role === "seller" ? `/deals/${n2.dealId}` : `/bookings/${n2.dealId}` : n2.kind === "access.reset_requested" && n2.data?.companyId ? `/accounts/${n2.data.companyId}` : n2.kind === "interest.received" && n2.data?.slotId ? `/slots/${n2.data.slotId}` : n2.kind.startsWith("bid.") || n2.kind.startsWith("interest.") ? "/calendar" : n2.kind === "search.match" ? `/calendar?search=${n2.data?.searchId}` : void 0;
}

// web/src/server-text.ts
var SERVER_AR = {
  "Email is not set up yet: add the SMTP details to the server settings first.": "\u0627\u0644\u0628\u0631\u064A\u062F \u063A\u064A\u0631 \u0645\u064F\u0639\u062F \u0628\u0639\u062F: \u0623\u0636\u0641 \u0628\u064A\u0627\u0646\u0627\u062A SMTP \u0625\u0644\u0649 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u062E\u0627\u062F\u0645 \u0623\u0648\u0644\u064B\u0627.",
  "The email server refused: {}": "\u0631\u0641\u0636 \u062E\u0627\u062F\u0645 \u0627\u0644\u0628\u0631\u064A\u062F: {1}",
  "Your company needs at least one active team manager. Make someone else a manager first.": "\u062A\u062D\u062A\u0627\u062C \u0634\u0631\u0643\u062A\u0643 \u0625\u0644\u0649 \u0645\u062F\u064A\u0631 \u0641\u0631\u064A\u0642 \u0646\u0634\u0637 \u0648\u0627\u062D\u062F \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644. \u0627\u062C\u0639\u0644 \u0634\u062E\u0635\u064B\u0627 \u0622\u062E\u0631 \u0645\u062F\u064A\u0631\u064B\u0627 \u0623\u0648\u0644\u064B\u0627.",
  "Invite colleagues with a work email at {}. For anyone else, ask Nashr.": "\u0627\u062F\u0639\u064F \u0627\u0644\u0632\u0645\u0644\u0627\u0621 \u0628\u0628\u0631\u064A\u062F \u0639\u0645\u0644 \u0639\u0644\u0649 {1}. \u0648\u0644\u0623\u064A \u0634\u062E\u0635 \u0622\u062E\u0631\u060C \u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0646\u0634\u0631.",
  "You cannot remove yourself. Ask another team manager.": "\u0644\u0627 \u064A\u0645\u0643\u0646\u0643 \u0625\u0632\u0627\u0644\u0629 \u0646\u0641\u0633\u0643. \u0627\u0637\u0644\u0628 \u0630\u0644\u0643 \u0645\u0646 \u0645\u062F\u064A\u0631 \u0641\u0631\u064A\u0642 \u0622\u062E\u0631.",
  "This person is not removed.": "\u0647\u0630\u0627 \u0627\u0644\u0634\u062E\u0635 \u063A\u064A\u0631 \u0645\u064F\u0632\u0627\u0644.",
  "This person never joined. Send them a new invite instead.": "\u0644\u0645 \u064A\u0646\u0636\u0645 \u0647\u0630\u0627 \u0627\u0644\u0634\u062E\u0635 \u0642\u0637. \u0623\u0631\u0633\u0644 \u0644\u0647 \u062F\u0639\u0648\u0629 \u062C\u062F\u064A\u062F\u0629 \u0628\u062F\u0644\u064B\u0627 \u0645\u0646 \u0630\u0644\u0643.",
  "Accept the updated terms of use to carry on.": "\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u0634\u0631\u0648\u0637 \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0645\u062D\u062F\u0651\u062B\u0629 \u0644\u0644\u0645\u062A\u0627\u0628\u0639\u0629.",
  "Too many failed sign-ins for this account. Try again in 15 minutes, or reset your password.": "\u0645\u062D\u0627\u0648\u0644\u0627\u062A \u062F\u062E\u0648\u0644 \u0641\u0627\u0634\u0644\u0629 \u0643\u062B\u064A\u0631\u0629 \u0644\u0647\u0630\u0627 \u0627\u0644\u062D\u0633\u0627\u0628. \u062D\u0627\u0648\u0644 \u0628\u0639\u062F 15 \u062F\u0642\u064A\u0642\u0629\u060C \u0623\u0648 \u0623\u0639\u062F \u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631.",
  "Only the founder can sign a staff member out.": "\u0627\u0644\u0645\u0624\u0633\u0633 \u0648\u062D\u062F\u0647 \u064A\u0645\u0643\u0646\u0647 \u062A\u0633\u062C\u064A\u0644 \u062E\u0631\u0648\u062C \u0623\u062D\u062F \u0623\u0641\u0631\u0627\u062F \u0627\u0644\u0641\u0631\u064A\u0642.",
  "Write why this person is being signed out.": "\u0627\u0643\u062A\u0628 \u0633\u0628\u0628 \u062A\u0633\u062C\u064A\u0644 \u062E\u0631\u0648\u062C \u0647\u0630\u0627 \u0627\u0644\u0634\u062E\u0635.",
  "Write just the name.": "\u0627\u0643\u062A\u0628 \u0627\u0644\u0627\u0633\u0645 \u0641\u0642\u0637.",
  "Someone already uses this email on Nashr.": "\u0647\u0646\u0627\u0643 \u0645\u0646 \u064A\u0633\u062A\u062E\u062F\u0645 \u0647\u0630\u0627 \u0627\u0644\u0628\u0631\u064A\u062F \u0639\u0644\u0649 \u0646\u0634\u0631 \u0628\u0627\u0644\u0641\u0639\u0644.",
  "This person has already joined.": "\u0627\u0646\u0636\u0645 \u0647\u0630\u0627 \u0627\u0644\u0634\u062E\u0635 \u0628\u0627\u0644\u0641\u0639\u0644.",
  "Only the founder can invite staff.": "\u0627\u0644\u0645\u0624\u0633\u0633 \u0648\u062D\u062F\u0647 \u064A\u0645\u0643\u0646\u0647 \u062F\u0639\u0648\u0629 \u0623\u0641\u0631\u0627\u062F \u0627\u0644\u0641\u0631\u064A\u0642.",
  "Accept the terms of use to join.": "\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u0634\u0631\u0648\u0637 \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0644\u0644\u0627\u0646\u0636\u0645\u0627\u0645.",
  "The terms changed while you were reading. Read the latest version and accept again.": "\u062A\u063A\u064A\u0651\u0631\u062A \u0627\u0644\u0634\u0631\u0648\u0637 \u0623\u062B\u0646\u0627\u0621 \u0642\u0631\u0627\u0621\u062A\u0643. \u0627\u0642\u0631\u0623 \u0623\u062D\u062F\u062B \u0625\u0635\u062F\u0627\u0631 \u0648\u0648\u0627\u0641\u0642 \u0645\u062C\u062F\u062F\u064B\u0627.",
  "The email or the code is not right.": "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0648 \u0627\u0644\u0631\u0645\u0632 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D.",
  "Statements can be added only while Nashr is deciding a dispute.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0625\u0636\u0627\u0641\u0629 \u0625\u0641\u0627\u062F\u0627\u062A \u0625\u0644\u0627 \u0623\u062B\u0646\u0627\u0621 \u0646\u0638\u0631 \u0646\u0634\u0631 \u0641\u064A \u0627\u0644\u0646\u0632\u0627\u0639.",
  "Explain your side in a few sentences.": "\u0627\u0634\u0631\u062D \u0631\u0648\u0627\u064A\u062A\u0643 \u0641\u064A \u0628\u0636\u0639 \u062C\u0645\u0644.",
  "Emails and phone numbers are not allowed here.": "\u0644\u0627 \u064A\u064F\u0633\u0645\u062D \u0647\u0646\u0627 \u0628\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0648\u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0647\u0627\u062A\u0641.",
  "Each side can add up to five statements. Nashr has your case.": "\u064A\u0645\u0643\u0646 \u0644\u0643\u0644 \u0637\u0631\u0641 \u0625\u0636\u0627\u0641\u0629 \u062E\u0645\u0633 \u0625\u0641\u0627\u062F\u0627\u062A \u0643\u062D\u062F \u0623\u0642\u0635\u0649. \u0645\u0644\u0641\u0643 \u0644\u062F\u0649 \u0646\u0634\u0631.",
  "Emails and phone numbers are not allowed in the address.": "\u0644\u0627 \u064A\u064F\u0633\u0645\u062D \u0628\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0648\u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0647\u0627\u062A\u0641 \u0641\u064A \u0627\u0644\u0639\u0646\u0648\u0627\u0646.",
  "Too many live connections.": "\u0639\u062F\u062F \u0643\u0628\u064A\u0631 \u062C\u062F\u064B\u0627 \u0645\u0646 \u0627\u0644\u0627\u062A\u0635\u0627\u0644\u0627\u062A \u0627\u0644\u0645\u0628\u0627\u0634\u0631\u0629.",
  'This person has not asked for a password reset. They ask from "Forgot your password?" on the sign-in page.': "\u0644\u0645 \u064A\u0637\u0644\u0628 \u0647\u0630\u0627 \u0627\u0644\u0634\u062E\u0635 \u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631. \u064A\u0637\u0644\u0628\u0647\u0627 \u0645\u0646 \xAB\u0646\u0633\u064A\u062A \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631\u061F\xBB \u0641\u064A \u0635\u0641\u062D\u0629 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644.",
  "The buyer's bank is deciding a chargeback on this payment. Wait for its decision.": "\u064A\u0628\u062A\u0651 \u0628\u0646\u0643 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0641\u064A \u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0639\u0644\u0649 \u0647\u0630\u0647 \u0627\u0644\u062F\u0641\u0639\u0629. \u0627\u0646\u062A\u0638\u0631 \u0642\u0631\u0627\u0631\u0647.",
  "The buyer's bank decided the chargeback for the buyer": "\u062D\u0633\u0645 \u0628\u0646\u0643 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0644\u0635\u0627\u0644\u062D \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "chargeback fee": "\u0631\u0633\u0648\u0645 \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0627\u0644\u0628\u0646\u0643\u064A",
  "chargeback won": "\u0643\u0633\u0628 \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0627\u0644\u0628\u0646\u0643\u064A",
  "chargeback lost: payout withheld": "\u062E\u0633\u0627\u0631\u0629 \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0627\u0644\u0628\u0646\u0643\u064A: \u062D\u064F\u062C\u0628\u062A \u0627\u0644\u062F\u0641\u0639\u0629",
  "Two-step sign-in is already on.": "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646 \u0645\u0641\u0639\u0651\u0644 \u0628\u0627\u0644\u0641\u0639\u0644.",
  "Two-step sign-in is already off.": "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646 \u0645\u062A\u0648\u0642\u0641 \u0628\u0627\u0644\u0641\u0639\u0644.",
  "Write why two-step sign-in is being turned off.": "\u0627\u0643\u062A\u0628 \u0633\u0628\u0628 \u0625\u064A\u0642\u0627\u0641 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646.",
  "Two-step sign-in is not on for this user.": "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646 \u063A\u064A\u0631 \u0645\u0641\u0639\u0651\u0644 \u0644\u0647\u0630\u0627 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645.",
  "Turn on two-step sign-in under Your account before paying.": "\u0641\u0639\u0651\u0644 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646 \u0645\u0646 \u0635\u0641\u062D\u0629 \u062D\u0633\u0627\u0628\u0643 \u0642\u0628\u0644 \u0627\u0644\u062F\u0641\u0639.",
  "Turn on two-step sign-in under Your account before connecting your payout account.": "\u0641\u0639\u0651\u0644 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062E\u0637\u0648\u062A\u064A\u0646 \u0645\u0646 \u0635\u0641\u062D\u0629 \u062D\u0633\u0627\u0628\u0643 \u0642\u0628\u0644 \u0631\u0628\u0637 \u062D\u0633\u0627\u0628 \u0627\u0644\u062A\u062D\u0648\u064A\u0644\u0627\u062A.",
  "Tell us a little more, so we can help the first time.": "\u0623\u062E\u0628\u0631\u0646\u0627 \u0628\u0627\u0644\u0645\u0632\u064A\u062F \u0642\u0644\u064A\u0644\u064B\u0627\u060C \u0644\u0646\u0633\u0627\u0639\u062F\u0643 \u0645\u0646 \u0627\u0644\u0645\u0631\u0629 \u0627\u0644\u0623\u0648\u0644\u0649.",
  "You have 10 open requests. Nashr will answer those first.": "\u0644\u062F\u064A\u0643 10 \u0637\u0644\u0628\u0627\u062A \u0645\u0641\u062A\u0648\u062D\u0629. \u0633\u062A\u062C\u064A\u0628 \u0646\u0634\u0631 \u0639\u0646\u0647\u0627 \u0623\u0648\u0644\u064B\u0627.",
  "Write the answer.": "\u0627\u0643\u062A\u0628 \u0627\u0644\u0625\u062C\u0627\u0628\u0629.",
  "Nashr is signed in as this user. The person must do this step themselves.": "\u0646\u0634\u0631 \u0645\u0633\u062C\u0651\u0644\u0629 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0627\u0633\u0645 \u0647\u0630\u0627 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645. \u064A\u062C\u0628 \u0623\u0646 \u064A\u0642\u0648\u0645 \u0627\u0644\u0634\u062E\u0635 \u0628\u0647\u0630\u0647 \u0627\u0644\u062E\u0637\u0648\u0629 \u0628\u0646\u0641\u0633\u0647.",
  "Write why you are signing in as this user.": "\u0627\u0643\u062A\u0628 \u0633\u0628\u0628 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0627\u0633\u0645 \u0647\u0630\u0627 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645.",
  "You can sign in only as an active buyer or publisher user.": "\u064A\u0645\u0643\u0646\u0643 \u0627\u0644\u062F\u062E\u0648\u0644 \u0641\u0642\u0637 \u0628\u0627\u0633\u0645 \u0645\u0633\u062A\u062E\u062F\u0645 \u0645\u0634\u062A\u0631\u064D \u0623\u0648 \u0646\u0627\u0634\u0631 \u0646\u0634\u0637.",
  "You are not signed in as another user.": "\u0623\u0646\u062A \u0644\u0633\u062A \u0645\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0627\u0633\u0645 \u0645\u0633\u062A\u062E\u062F\u0645 \u0622\u062E\u0631.",
  // Account self-service and Nashr stepping in
  "You are viewing another account. Changes are not allowed.": "\u0623\u0646\u062A \u062A\u0639\u0631\u0636 \u062D\u0633\u0627\u0628\u064B\u0627 \u0622\u062E\u0631. \u0627\u0644\u062A\u063A\u064A\u064A\u0631\u0627\u062A \u063A\u064A\u0631 \u0645\u0633\u0645\u0648\u062D\u0629.",
  "A reset link can be issued only for an active buyer or publisher user.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0625\u0635\u062F\u0627\u0631 \u0631\u0627\u0628\u0637 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062A\u0639\u064A\u064A\u0646 \u0625\u0644\u0627 \u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0645\u0634\u062A\u0631\u064D \u0623\u0648 \u0646\u0627\u0634\u0631 \u0646\u0634\u0637.",
  "This reset link has expired. Ask Nashr for a new one.": "\u0627\u0646\u062A\u0647\u062A \u0635\u0644\u0627\u062D\u064A\u0629 \u0631\u0627\u0628\u0637 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062A\u0639\u064A\u064A\u0646 \u0647\u0630\u0627. \u0627\u0637\u0644\u0628 \u0631\u0627\u0628\u0637\u064B\u0627 \u062C\u062F\u064A\u062F\u064B\u0627 \u0645\u0646 \u0646\u0634\u0631.",
  "Your current password is not right.": "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062D\u0627\u0644\u064A\u0629 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629.",
  "Choose a new password, not the current one.": "\u0627\u062E\u062A\u0631 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u062C\u062F\u064A\u062F\u0629\u060C \u0644\u0627 \u0627\u0644\u062D\u0627\u0644\u064A\u0629.",
  "Write the reason the buyer will see.": "\u0627\u0643\u062A\u0628 \u0627\u0644\u0633\u0628\u0628 \u0627\u0644\u0630\u064A \u0633\u064A\u0631\u0627\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u064A.",
  "Only a live bid on an open auction can be voided.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0625\u0644\u063A\u0627\u0621 \u0625\u0644\u0627 \u0639\u0631\u0636 \u0642\u0627\u0626\u0645 \u0641\u064A \u0645\u0632\u0627\u062F \u0645\u0641\u062A\u0648\u062D.",
  "Write the reason both sides will see.": "\u0627\u0643\u062A\u0628 \u0627\u0644\u0633\u0628\u0628 \u0627\u0644\u0630\u064A \u0633\u064A\u0631\u0627\u0647 \u0627\u0644\u0637\u0631\u0641\u0627\u0646.",
  "This step is not possible for a deal in this state.": "\u0647\u0630\u0647 \u0627\u0644\u062E\u0637\u0648\u0629 \u063A\u064A\u0631 \u0645\u0645\u0643\u0646\u0629 \u0644\u0635\u0641\u0642\u0629 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u062D\u0627\u0644\u0629.",
  "The buyer's bank disputed the payment": "\u0627\u0639\u062A\u0631\u0636 \u0628\u0646\u0643 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0639\u0644\u0649 \u0627\u0644\u062F\u0641\u0639\u0629",
  // Requests and access
  "Send JSON.": "\u0623\u0631\u0633\u0644 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0628\u0635\u064A\u063A\u0629 JSON.",
  "Please sign in.": "\u064A\u0631\u062C\u0649 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644.",
  "The file is too large.": "\u0627\u0644\u0645\u0644\u0641 \u0643\u0628\u064A\u0631 \u062C\u062F\u064B\u0627.",
  "Requests must come from Nashr.": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0635\u062F\u0631 \u0627\u0644\u0637\u0644\u0628\u0627\u062A \u0645\u0646 \u0646\u0634\u0631.",
  "Some fields are missing or not valid.": "\u0628\u0639\u0636 \u0627\u0644\u062D\u0642\u0648\u0644 \u0646\u0627\u0642\u0635\u0629 \u0623\u0648 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629.",
  "Something went wrong on our side.": "\u062D\u062F\u062B \u062E\u0637\u0623 \u0645\u0646 \u062C\u0647\u062A\u0646\u0627.",
  "Something went wrong.": "\u062D\u062F\u062B \u062E\u0637\u0623 \u0645\u0627.",
  "Add the campaign name.": "\u0623\u0636\u0641 \u0627\u0633\u0645 \u0627\u0644\u062D\u0645\u0644\u0629.",
  "The end date must be on or after the start date.": "\u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0646\u0647\u0627\u064A\u0629 \u0641\u064A \u064A\u0648\u0645 \u0627\u0644\u0628\u062F\u0627\u064A\u0629 \u0623\u0648 \u0628\u0639\u062F\u0647.",
  "Fill in the campaign brief.": "\u0627\u0645\u0644\u0623 \u0645\u0644\u062E\u0635 \u0627\u0644\u062D\u0645\u0644\u0629.",
  "This product is no longer on sale.": "\u0644\u0645 \u064A\u0639\u062F \u0647\u0630\u0627 \u0627\u0644\u0645\u0646\u062A\u062C \u0645\u0639\u0631\u0648\u0636\u064B\u0627 \u0644\u0644\u0628\u064A\u0639.",
  "Say which language the creative is in.": "\u0627\u0630\u0643\u0631 \u0644\u063A\u0629 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "A security check stopped this request. Reload the page and try again.": "\u0623\u0648\u0642\u0641 \u0641\u062D\u0635 \u0623\u0645\u0646\u064A \u0647\u0630\u0627 \u0627\u0644\u0637\u0644\u0628. \u0623\u0639\u062F \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0635\u0641\u062D\u0629 \u0648\u062D\u0627\u0648\u0644 \u0645\u0631\u0629 \u0623\u062E\u0631\u0649.",
  "Nashr is not answering right now. Try again in a minute.": "\u0646\u0634\u0631 \u0644\u0627 \u064A\u0633\u062A\u062C\u064A\u0628 \u0627\u0644\u0622\u0646. \u062D\u0627\u0648\u0644 \u0645\u0631\u0629 \u0623\u062E\u0631\u0649 \u0628\u0639\u062F \u062F\u0642\u064A\u0642\u0629.",
  "Upload failed.": "\u062A\u0639\u0630\u0651\u0631 \u0627\u0644\u0631\u0641\u0639.",
  "View only: you are viewing this account as an admin.": "\u0644\u0644\u0639\u0631\u0636 \u0641\u0642\u0637: \u0623\u0646\u062A \u062A\u0639\u0631\u0636 \u0647\u0630\u0627 \u0627\u0644\u062D\u0633\u0627\u0628 \u0628\u0635\u0641\u0629 \u0645\u0634\u0631\u0641.",
  "You do not have access to this.": "\u0644\u0627 \u062A\u0645\u0644\u0643 \u0635\u0644\u0627\u062D\u064A\u0629 \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u0647\u0630\u0627.",
  "Not found.": "\u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F.",
  "Not signed in.": "\u0644\u0645 \u062A\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644.",
  "Too many requests. Try again in a minute.": "\u0637\u0644\u0628\u0627\u062A \u0643\u062B\u064A\u0631\u0629 \u062C\u062F\u064B\u0627. \u062D\u0627\u0648\u0644 \u0628\u0639\u062F \u062F\u0642\u064A\u0642\u0629.",
  "Too many attempts. Try again in a minute.": "\u0645\u062D\u0627\u0648\u0644\u0627\u062A \u0643\u062B\u064A\u0631\u0629 \u062C\u062F\u064B\u0627. \u062D\u0627\u0648\u0644 \u0628\u0639\u062F \u062F\u0642\u064A\u0642\u0629.",
  "Signature check failed.": "\u0641\u0634\u0644 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u062A\u0648\u0642\u064A\u0639.",
  "Enter a valid work email.": "\u0623\u062F\u062E\u0644 \u0628\u0631\u064A\u062F\u064B\u0627 \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A\u064B\u0627 \u0635\u062D\u064A\u062D\u064B\u0627 \u0644\u0644\u0639\u0645\u0644.",
  "Please use your business email. Free email addresses are not accepted.": "\u064A\u0631\u062C\u0649 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0628\u0631\u064A\u062F \u0627\u0644\u0639\u0645\u0644. \u0644\u0627 \u062A\u064F\u0642\u0628\u0644 \u0639\u0646\u0627\u0648\u064A\u0646 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0645\u062C\u0627\u0646\u064A\u0629.",
  "This request has already been decided.": "\u0633\u0628\u0642 \u0627\u0644\u0628\u062A\u0651 \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u0637\u0644\u0628.",
  "A reason is required to reject.": "\u064A\u0644\u0632\u0645 \u0630\u0643\u0631 \u0633\u0628\u0628 \u0644\u0644\u0631\u0641\u0636.",
  "Say what information you need.": "\u0627\u0630\u0643\u0631 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u062D\u062A\u0627\u062C\u0647\u0627.",
  "This invite link has expired. Ask Nashr for a new one.": "\u0627\u0646\u062A\u0647\u062A \u0635\u0644\u0627\u062D\u064A\u0629 \u0631\u0627\u0628\u0637 \u0627\u0644\u062F\u0639\u0648\u0629. \u0627\u0637\u0644\u0628 \u0631\u0627\u0628\u0637\u064B\u0627 \u062C\u062F\u064A\u062F\u064B\u0627 \u0645\u0646 \u0646\u0634\u0631.",
  "Use a password of at least 12 characters.": "\u0627\u0633\u062A\u062E\u062F\u0645 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u0645\u0646 12 \u062D\u0631\u0641\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
  "The code from your authenticator app is not right.": "\u0627\u0644\u0631\u0645\u0632 \u0645\u0646 \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D.",
  "Email or password is not right.": "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0648 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629.",
  "Enter the code from your authenticator app.": "\u0623\u062F\u062E\u0644 \u0627\u0644\u0631\u0645\u0632 \u0645\u0646 \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629.",
  // Marketplace
  "This market is coming soon. Join the waiting list to hear when it opens.": "\u0647\u0630\u0627 \u0627\u0644\u0633\u0648\u0642 \u0642\u0627\u062F\u0645 \u0642\u0631\u064A\u0628\u064B\u0627. \u0627\u0646\u0636\u0645 \u0625\u0644\u0649 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0627\u0646\u062A\u0638\u0627\u0631 \u0644\u062A\u0639\u0631\u0641 \u0645\u0648\u0639\u062F \u0627\u0641\u062A\u062A\u0627\u062D\u0647.",
  "Choose one of your active campaigns.": "\u0627\u062E\u062A\u0631 \u0625\u062D\u062F\u0649 \u062D\u0645\u0644\u0627\u062A\u0643 \u0627\u0644\u0646\u0634\u0637\u0629.",
  "Bidding is closed for this slot.": "\u0623\u064F\u063A\u0644\u0642\u062A \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0639\u0644\u0649 \u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629.",
  "You are already the top bidder at this amount.": "\u0623\u0646\u062A \u0628\u0627\u0644\u0641\u0639\u0644 \u0635\u0627\u062D\u0628 \u0623\u0639\u0644\u0649 \u0645\u0632\u0627\u064A\u062F\u0629 \u0628\u0647\u0630\u0627 \u0627\u0644\u0645\u0628\u0644\u063A.",
  "Your bid must be at least {}.": "\u064A\u062C\u0628 \u0623\u0644\u0627 \u062A\u0642\u0644 \u0645\u0632\u0627\u064A\u062F\u062A\u0643 \u0639\u0646 {1}.",
  "Buy now is not available for this slot.": "\u0627\u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0641\u0648\u0631\u064A \u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u0644\u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629.",
  "You already have a buy-now request on this slot.": "\u0644\u062F\u064A\u0643 \u0628\u0627\u0644\u0641\u0639\u0644 \u0637\u0644\u0628 \u0634\u0631\u0627\u0621 \u0641\u0648\u0631\u064A \u0639\u0644\u0649 \u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629.",
  "This person has already set their password, or the request was not approved.": "\u0623\u0643\u0645\u0644 \u0647\u0630\u0627 \u0627\u0644\u0634\u062E\u0635 \u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631\u060C \u0623\u0648 \u0644\u0645 \u062A\u062A\u0645 \u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 \u0639\u0644\u0649 \u0627\u0644\u0637\u0644\u0628.",
  "Emails and phone numbers are not allowed in what buyers see.": "\u0644\u0627 \u064A\u064F\u0633\u0645\u062D \u0628\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0648\u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0647\u0627\u062A\u0641 \u0641\u064A\u0645\u0627 \u064A\u0631\u0627\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646.",
  "The buy-now price must be above the starting price.": "\u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0633\u0639\u0631 \u0627\u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0641\u0648\u0631\u064A \u0623\u0639\u0644\u0649 \u0645\u0646 \u0633\u0639\u0631 \u0627\u0644\u0628\u062F\u0627\u064A\u0629.",
  "A week-long placement starts on one day and has no breaks.": "\u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0623\u0633\u0628\u0648\u0639\u064A\u0629 \u062A\u0628\u062F\u0623 \u0641\u064A \u064A\u0648\u0645 \u0648\u0627\u062D\u062F \u0648\u0644\u0627 \u062A\u062D\u062A\u0648\u064A \u0639\u0644\u0649 \u0641\u0648\u0627\u0635\u0644.",
  "This slot is no longer available.": "\u0644\u0645 \u062A\u0639\u062F \u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0645\u062A\u0627\u062D\u0629.",
  "This request has expired.": "\u0627\u0646\u062A\u0647\u062A \u0635\u0644\u0627\u062D\u064A\u0629 \u0647\u0630\u0627 \u0627\u0644\u0637\u0644\u0628.",
  "It is too close to the creative deadline for another buyer to pay. The slot will be relisted.": "\u0627\u0642\u062A\u0631\u0628 \u0645\u0648\u0639\u062F \u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0645\u0627\u062F\u0629 \u0643\u062B\u064A\u0631\u064B\u0627 \u0648\u0644\u0627 \u064A\u062A\u0633\u0639 \u0627\u0644\u0648\u0642\u062A \u0644\u062F\u0641\u0639 \u0645\u0634\u062A\u0631\u064D \u0622\u062E\u0631. \u0633\u062A\u064F\u0639\u0627\u062F \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0644\u0644\u0639\u0631\u0636.",
  "Choose a valid date range.": "\u0627\u062E\u062A\u0631 \u0646\u0637\u0627\u0642 \u062A\u0648\u0627\u0631\u064A\u062E \u0635\u062D\u064A\u062D\u064B\u0627.",
  "An overlapping booking was accepted": "\u0642\u064F\u0628\u0644 \u062D\u062C\u0632 \u0645\u062A\u062F\u0627\u062E\u0644 \u0645\u0639 \u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629",
  "Buy-now and reserve prices are for auctions only.": "\u0633\u0639\u0631 \u0627\u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0641\u0648\u0631\u064A \u0648\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u062F\u0646\u0649 \u0644\u0644\u0645\u0632\u0627\u062F\u0627\u062A \u0641\u0642\u0637.",
  "This slot is not sold at a fixed price.": "\u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0644\u0627 \u062A\u064F\u0628\u0627\u0639 \u0628\u0633\u0639\u0631 \u062B\u0627\u0628\u062A.",
  "Someone has just booked this slot, or it is no longer on sale.": "\u062D\u062C\u0632 \u0623\u062D\u062F\u0647\u0645 \u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0644\u0644\u062A\u0648\u060C \u0623\u0648 \u0644\u0645 \u062A\u0639\u062F \u0645\u0639\u0631\u0648\u0636\u0629 \u0644\u0644\u0628\u064A\u0639.",
  "This outlet does not accept {} advertising.": "\u0644\u0627 \u062A\u0642\u0628\u0644 \u0647\u0630\u0647 \u0627\u0644\u0645\u0646\u0635\u0629 \u0625\u0639\u0644\u0627\u0646\u0627\u062A {1}.",
  "This outlet does not run ads for this advertiser.": "\u0644\u0627 \u062A\u0646\u0634\u0631 \u0647\u0630\u0647 \u0627\u0644\u0645\u0646\u0635\u0629 \u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0644\u0647\u0630\u0627 \u0627\u0644\u0645\u0639\u0644\u0646.",
  "This slot is not a quick sale.": "\u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0644\u064A\u0633\u062A \u0644\u0644\u0628\u064A\u0639 \u0627\u0644\u0633\u0631\u064A\u0639.",
  "Offers cannot be below {}.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0623\u0646 \u062A\u0642\u0644 \u0627\u0644\u0639\u0631\u0648\u0636 \u0639\u0646 {1}.",
  "This interest can no longer be accepted.": "\u0644\u0645 \u064A\u0639\u062F \u0645\u0645\u0643\u0646\u064B\u0627 \u0642\u0628\u0648\u0644 \u0647\u0630\u0627 \u0627\u0644\u0627\u0647\u062A\u0645\u0627\u0645.",
  "A reason is required to decline.": "\u064A\u0644\u0632\u0645 \u0630\u0643\u0631 \u0633\u0628\u0628 \u0644\u0644\u0631\u0641\u0636.",
  "This bid cannot be chosen.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0627\u062E\u062A\u064A\u0627\u0631 \u0647\u0630\u0647 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629.",
  "You can save up to {} searches. Delete one to save another.": "\u064A\u0645\u0643\u0646\u0643 \u062D\u0641\u0638 {1} \u0639\u0645\u0644\u064A\u0627\u062A \u0628\u062D\u062B \u0643\u062D\u062F \u0623\u0642\u0635\u0649. \u0627\u062D\u0630\u0641 \u0648\u0627\u062D\u062F\u0629 \u0644\u062A\u062D\u0641\u0638 \u0623\u062E\u0631\u0649.",
  // Booking brief
  "A booking brief is required with your first bid.": "\u064A\u0644\u0632\u0645 \u0645\u0644\u062E\u0635 \u062D\u062C\u0632 \u0645\u0639 \u0623\u0648\u0644 \u0645\u0632\u0627\u064A\u062F\u0629 \u0644\u0643.",
  "Add the advertiser or brand.": "\u0623\u0636\u0641 \u0627\u0644\u0645\u0639\u0644\u0646 \u0623\u0648 \u0627\u0644\u0639\u0644\u0627\u0645\u0629 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629.",
  "Choose the industry.": "\u0627\u062E\u062A\u0631 \u0627\u0644\u0642\u0637\u0627\u0639.",
  "Say what the ad will say.": "\u0627\u0630\u0643\u0631 \u0645\u0636\u0645\u0648\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646.",
  "What the ad will say must be 280 characters or fewer.": "\u064A\u062C\u0628 \u0623\u0644\u0627 \u064A\u062A\u062C\u0627\u0648\u0632 \u0645\u0636\u0645\u0648\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 280 \u062D\u0631\u0641\u064B\u0627.",
  "Choose the creative language.": "\u0627\u062E\u062A\u0631 \u0644\u063A\u0629 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "A landing page link is required for digital placements.": "\u064A\u0644\u0632\u0645 \u0631\u0627\u0628\u0637 \u0635\u0641\u062D\u0629 \u0647\u0628\u0648\u0637 \u0644\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u0631\u0642\u0645\u064A\u0629.",
  "The landing page link must start with https://.": "\u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0631\u0627\u0628\u0637 \u0635\u0641\u062D\u0629 \u0627\u0644\u0647\u0628\u0648\u0637 \u0628\u0640 https://.",
  'Upload a draft of the creative or tick "creative to follow".': '\u0627\u0631\u0641\u0639 \u0645\u0633\u0648\u062F\u0629 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0623\u0648 \u0627\u062E\u062A\u0631 "\u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0644\u0627\u062D\u0642\u064B\u0627".',
  "Remove the email or phone number from {}. Talk to the publisher through Nashr messages.": "\u0627\u062D\u0630\u0641 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0648 \u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641 \u0645\u0646 {1}. \u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0627\u0644\u0646\u0627\u0634\u0631 \u0639\u0628\u0631 \u0631\u0633\u0627\u0626\u0644 \u0646\u0634\u0631.",
  "the notes": "\u0627\u0644\u0645\u0644\u0627\u062D\u0638\u0627\u062A",
  "advertiser": "\u0627\u0644\u0645\u0639\u0644\u0646",
  "message": "\u0645\u0636\u0645\u0648\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
  // Publisher: placements, slots, profile
  "Bidding must close at least {} days before air so there is time to accept, pay and deliver the creative.": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u064F\u063A\u0644\u0642 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B \u0628\u0640{1} \u0623\u064A\u0627\u0645 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644 \u0644\u064A\u062A\u0633\u0639 \u0627\u0644\u0648\u0642\u062A \u0644\u0644\u0642\u0628\u0648\u0644 \u0648\u0627\u0644\u062F\u0641\u0639 \u0648\u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "The end time must be after the start time.": "\u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0648\u0642\u062A \u0627\u0644\u0646\u0647\u0627\u064A\u0629 \u0628\u0639\u062F \u0648\u0642\u062A \u0627\u0644\u0628\u062F\u0627\u064A\u0629.",
  "Slots can go live once your payout account is verified.": "\u062A\u064F\u0639\u0631\u0636 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0628\u0639\u062F \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0633\u0627\u0628 \u0627\u0633\u062A\u0644\u0627\u0645 \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A.",
  "This overlaps {} on {} of the same days.": "\u062A\u062A\u062F\u0627\u062E\u0644 \u0645\u0639 {1} \u0641\u064A {2} \u0645\u0646 \u0627\u0644\u0623\u064A\u0627\u0645 \u0646\u0641\u0633\u0647\u0627.",
  "Only open slots with no bids can be taken off sale.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0625\u064A\u0642\u0627\u0641 \u0628\u064A\u0639 \u0625\u0644\u0627 \u0627\u0644\u0645\u0633\u0627\u062D\u0627\u062A \u0627\u0644\u0645\u0639\u0631\u0648\u0636\u0629 \u0627\u0644\u062A\u064A \u0644\u0627 \u0645\u0632\u0627\u064A\u062F\u0627\u062A \u0639\u0644\u064A\u0647\u0627.",
  "This slot cannot be put back on sale.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0625\u0639\u0627\u062F\u0629 \u0639\u0631\u0636 \u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0644\u0644\u0628\u064A\u0639.",
  "Upload the invoice file first.": "\u0627\u0631\u0641\u0639 \u0645\u0644\u0641 \u0627\u0644\u0641\u0627\u062A\u0648\u0631\u0629 \u0623\u0648\u0644\u064B\u0627.",
  "Emails and phone numbers are not allowed in the profile.": "\u0644\u0627 \u064A\u064F\u0633\u0645\u062D \u0628\u0639\u0646\u0627\u0648\u064A\u0646 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0648 \u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0647\u0648\u0627\u062A\u0641 \u0641\u064A \u0627\u0644\u0645\u0644\u0641.",
  "A VAT-registered publisher needs its TRN on invoices.": "\u0627\u0644\u0646\u0627\u0634\u0631 \u0627\u0644\u0645\u0633\u062C\u0644 \u0641\u064A \u0627\u0644\u0636\u0631\u064A\u0628\u0629 \u064A\u062D\u062A\u0627\u062C \u0625\u0644\u0649 \u0631\u0642\u0645\u0647 \u0627\u0644\u0636\u0631\u064A\u0628\u064A \u0639\u0644\u0649 \u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631.",
  "Payout onboarding opens with the payment provider. It is not connected yet.": "\u064A\u0628\u062F\u0623 \u0625\u0639\u062F\u0627\u062F \u0627\u0633\u062A\u0644\u0627\u0645 \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A \u0644\u062F\u0649 \u0645\u0632\u0648\u0651\u062F \u0627\u0644\u062F\u0641\u0639\u060C \u0648\u0647\u0648 \u063A\u064A\u0631 \u0645\u0631\u0628\u0648\u0637 \u0628\u0639\u062F.",
  "The publisher has not set up a payout account.": "\u0644\u0645 \u064A\u064F\u0639\u062F\u0651 \u0627\u0644\u0646\u0627\u0634\u0631 \u062D\u0633\u0627\u0628 \u0627\u0633\u062A\u0644\u0627\u0645 \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0627\u062A.",
  "Nashr issues this invoice for you.": "\u062A\u0635\u062F\u0631 \u0646\u0634\u0631 \u0647\u0630\u0647 \u0627\u0644\u0641\u0627\u062A\u0648\u0631\u0629 \u0646\u064A\u0627\u0628\u0629 \u0639\u0646\u0643.",
  // Files, photos, ratings, plans
  "Choose a file to upload.": "\u0627\u062E\u062A\u0631 \u0645\u0644\u0641\u064B\u0627 \u0644\u0631\u0641\u0639\u0647.",
  "Upload the file first.": "\u0627\u0631\u0641\u0639 \u0627\u0644\u0645\u0644\u0641 \u0623\u0648\u0644\u064B\u0627.",
  "Attach only files your own company uploaded.": "\u0623\u0631\u0641\u0642 \u0641\u0642\u0637 \u0645\u0644\u0641\u0627\u062A \u0631\u0641\u0639\u062A\u0647\u0627 \u0634\u0631\u0643\u062A\u0643.",
  "Choose a photo to upload.": "\u0627\u062E\u062A\u0631 \u0635\u0648\u0631\u0629 \u0644\u0631\u0641\u0639\u0647\u0627.",
  "The photo is too large. Use one under 3 MB.": "\u0627\u0644\u0635\u0648\u0631\u0629 \u0643\u0628\u064A\u0631\u0629 \u062C\u062F\u064B\u0627. \u0627\u0633\u062A\u062E\u062F\u0645 \u0635\u0648\u0631\u0629 \u0623\u0635\u063A\u0631 \u0645\u0646 3 \u0645\u064A\u063A\u0627\u0628\u0627\u064A\u062A.",
  "Use a JPEG or PNG photo.": "\u0627\u0633\u062A\u062E\u062F\u0645 \u0635\u0648\u0631\u0629 JPEG \u0623\u0648 PNG.",
  "Only outlets not on Nashr can be changed here.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0647\u0646\u0627 \u062A\u063A\u064A\u064A\u0631 \u0625\u0644\u0627 \u0627\u0644\u0645\u0646\u0635\u0627\u062A \u063A\u064A\u0631 \u0627\u0644\u0645\u0646\u0636\u0645\u0629 \u0625\u0644\u0649 \u0646\u0634\u0631.",
  "You can rate the publisher after the booking is complete and the payment is released.": "\u064A\u0645\u0643\u0646\u0643 \u062A\u0642\u064A\u064A\u0645 \u0627\u0644\u0646\u0627\u0634\u0631 \u0628\u0639\u062F \u0627\u0643\u062A\u0645\u0627\u0644 \u0627\u0644\u062D\u062C\u0632 \u0648\u062A\u062D\u0631\u064A\u0631 \u0627\u0644\u062F\u0641\u0639\u0629.",
  "Emails and phone numbers are not allowed in a rating.": "\u0644\u0627 \u064A\u064F\u0633\u0645\u062D \u0628\u0639\u0646\u0627\u0648\u064A\u0646 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0648 \u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0647\u0648\u0627\u062A\u0641 \u0641\u064A \u0627\u0644\u062A\u0642\u064A\u064A\u0645.",
  "Emails and phone numbers are not allowed. Talk through Nashr.": "\u0644\u0627 \u064A\u064F\u0633\u0645\u062D \u0628\u0639\u0646\u0627\u0648\u064A\u0646 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0648 \u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0647\u0648\u0627\u062A\u0641. \u062A\u0648\u0627\u0635\u0644\u0648\u0627 \u0639\u0628\u0631 \u0646\u0634\u0631.",
  // Creative, proof, issues
  "This booking is not yours.": "\u0647\u0630\u0627 \u0627\u0644\u062D\u062C\u0632 \u0644\u064A\u0633 \u0644\u0643.",
  "Creative can be sent once the publisher has accepted.": "\u064A\u0645\u0643\u0646 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0628\u0639\u062F \u0645\u0648\u0627\u0641\u0642\u0629 \u0627\u0644\u0646\u0627\u0634\u0631.",
  "The material deadline has passed.": "\u0627\u0646\u0642\u0636\u0649 \u0645\u0648\u0639\u062F \u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0645\u0627\u062F\u0629.",
  "The creative is already approved.": "\u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0645\u0639\u062A\u0645\u062F\u0629 \u0628\u0627\u0644\u0641\u0639\u0644.",
  "The publisher is still reviewing your last file.": "\u0645\u0627 \u0632\u0627\u0644 \u0627\u0644\u0646\u0627\u0634\u0631 \u064A\u0631\u0627\u062C\u0639 \u0645\u0644\u0641\u0643 \u0627\u0644\u0623\u062E\u064A\u0631.",
  "There is no creative waiting for review.": "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0627\u062F\u0629 \u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629.",
  "Both change rounds are used. Approve the creative or reject it with a reason.": "\u0627\u0633\u062A\u064F\u0646\u0641\u062F\u062A \u062C\u0648\u0644\u062A\u0627 \u0627\u0644\u062A\u0639\u062F\u064A\u0644. \u0627\u0639\u062A\u0645\u062F \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0623\u0648 \u0627\u0631\u0641\u0636\u0647\u0627 \u0645\u0639 \u0630\u0643\u0631 \u0627\u0644\u0633\u0628\u0628.",
  "Say what needs to change.": "\u0627\u0630\u0643\u0631 \u0645\u0627 \u064A\u062C\u0628 \u062A\u0639\u062F\u064A\u0644\u0647.",
  "Choose a rejection reason.": "\u0627\u062E\u062A\u0631 \u0633\u0628\u0628 \u0627\u0644\u0631\u0641\u0636.",
  "Add {} before sending proof.": "\u0623\u0636\u0641 {1} \u0642\u0628\u0644 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A.",
  "Proof can be sent once the ad has run.": "\u064A\u0645\u0643\u0646 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0628\u0639\u062F \u0628\u062B \u0627\u0644\u0625\u0639\u0644\u0627\u0646.",
  "The pre-run check is not open yet.": "\u0644\u0645 \u064A\u064F\u0641\u062A\u062D \u0641\u062D\u0635 \u0645\u0627 \u0642\u0628\u0644 \u0627\u0644\u0628\u062B \u0628\u0639\u062F.",
  "Choose what went wrong.": "\u0627\u062E\u062A\u0631 \u0645\u0627 \u0627\u0644\u0630\u064A \u062D\u062F\u062B.",
  "Add a short note.": "\u0623\u0636\u0641 \u0645\u0644\u0627\u062D\u0638\u0629 \u0642\u0635\u064A\u0631\u0629.",
  "Choose a future date for the rerun.": "\u0627\u062E\u062A\u0631 \u062A\u0627\u0631\u064A\u062E\u064B\u0627 \u0642\u0627\u062F\u0645\u064B\u0627 \u0644\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0628\u062B.",
  "The publisher has not answered yet.": "\u0644\u0645 \u064A\u0631\u062F\u0651 \u0627\u0644\u0646\u0627\u0634\u0631 \u0628\u0639\u062F.",
  "the tearsheet": "\u0635\u0641\u062D\u0629 \u0627\u0644\u0646\u0634\u0631",
  "dated screenshots": "\u0644\u0642\u0637\u0627\u062A \u0634\u0627\u0634\u0629 \u0645\u0624\u0631\u062E\u0629",
  "the live link": "\u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0645\u0628\u0627\u0634\u0631",
  "the start time": "\u0648\u0642\u062A \u0627\u0644\u0628\u062F\u0627\u064A\u0629",
  "the end time": "\u0648\u0642\u062A \u0627\u0644\u0646\u0647\u0627\u064A\u0629",
  "the as-run log": "\u0633\u062C\u0644 \u0627\u0644\u0628\u062B",
  "the audio clip": "\u0627\u0644\u0645\u0642\u0637\u0639 \u0627\u0644\u0635\u0648\u062A\u064A",
  "the video clip": "\u0645\u0642\u0637\u0639 \u0627\u0644\u0641\u064A\u062F\u064A\u0648",
  "the episode link": "\u0631\u0627\u0628\u0637 \u0627\u0644\u062D\u0644\u0642\u0629",
  "the time of the ad in the episode": "\u0648\u0642\u062A \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0641\u064A \u0627\u0644\u062D\u0644\u0642\u0629",
  // Payments and cancellations
  "This booking is not waiting for payment.": "\u0647\u0630\u0627 \u0627\u0644\u062D\u062C\u0632 \u0644\u0627 \u064A\u0646\u062A\u0638\u0631 \u0627\u0644\u062F\u0641\u0639.",
  "Your bank is still waiting for you to confirm the last payment.": "\u0645\u0627 \u0632\u0627\u0644 \u0628\u0646\u0643\u0643 \u064A\u0646\u062A\u0638\u0631 \u062A\u0623\u0643\u064A\u062F\u0643 \u0644\u0644\u062F\u0641\u0639\u0629 \u0627\u0644\u0623\u062E\u064A\u0631\u0629.",
  "Enter a partial refund between zero and the amount paid.": "\u0623\u062F\u062E\u0644 \u0645\u0628\u0644\u063A \u0627\u0633\u062A\u0631\u062F\u0627\u062F \u062C\u0632\u0626\u064A \u0628\u064A\u0646 \u0627\u0644\u0635\u0641\u0631 \u0648\u0627\u0644\u0645\u0628\u0644\u063A \u0627\u0644\u0645\u062F\u0641\u0648\u0639.",
  "This choice is available once the material deadline has passed.": "\u064A\u062A\u0627\u062D \u0647\u0630\u0627 \u0627\u0644\u062E\u064A\u0627\u0631 \u0628\u0639\u062F \u0627\u0646\u0642\u0636\u0627\u0621 \u0645\u0648\u0639\u062F \u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0645\u0627\u062F\u0629.",
  "The creative was approved.": "\u0627\u0639\u062A\u064F\u0645\u062F\u062A \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "Your card was declined.": "\u0631\u064F\u0641\u0636\u062A \u0628\u0637\u0627\u0642\u062A\u0643.",
  "Only a paid booking that has not run can be cancelled.": "\u0644\u0627 \u064A\u064F\u0644\u063A\u0649 \u0625\u0644\u0627 \u062D\u062C\u0632 \u0645\u062F\u0641\u0648\u0639 \u0644\u0645 \u064A\u064F\u0628\u062B \u0628\u0639\u062F.",
  "This booking can no longer be cancelled for a refund: the creative deadline has passed.": "\u0644\u0645 \u064A\u0639\u062F \u0645\u0645\u0643\u0646\u064B\u0627 \u0625\u0644\u063A\u0627\u0621 \u0647\u0630\u0627 \u0627\u0644\u062D\u062C\u0632 \u0645\u0639 \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F: \u0627\u0646\u0642\u0636\u0649 \u0645\u0648\u0639\u062F \u062A\u0633\u0644\u064A\u0645 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "Stripe answered {}": "\u0631\u062F\u0651 Stripe: {1}",
  // Team and settings
  "This user cannot be suspended or restored.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0625\u064A\u0642\u0627\u0641 \u0647\u0630\u0627 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0623\u0648 \u0625\u0639\u0627\u062F\u0629 \u062A\u0641\u0639\u064A\u0644\u0647.",
  "Only active buyer or seller users can be suspended or restored.": "\u0644\u0627 \u064A\u064F\u0648\u0642\u0641 \u0623\u0648 \u064A\u064F\u0639\u0627\u062F \u062A\u0641\u0639\u064A\u0644 \u0625\u0644\u0627 \u0645\u0633\u062A\u062E\u062F\u0645\u0648 \u0627\u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u0623\u0648 \u0627\u0644\u0646\u0627\u0634\u0631\u064A\u0646 \u0627\u0644\u0646\u0634\u0637\u0648\u0646.",
  "Only the founder can add a founder.": "\u0648\u062D\u062F\u0647 \u0627\u0644\u0645\u0624\u0633\u0633 \u064A\u0645\u0643\u0646\u0647 \u0625\u0636\u0627\u0641\u0629 \u0645\u0624\u0633\u0633.",
  "Only a failed payout or refund can be retried.": "\u0644\u0627 \u062A\u064F\u0639\u0627\u062F \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u0625\u0644\u0627 \u0644\u062A\u062D\u0648\u064A\u0644 \u0623\u0648 \u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0641\u0634\u0644.",
  "The high estimate must not be below the low one.": "\u064A\u062C\u0628 \u0623\u0644\u0627 \u064A\u0642\u0644 \u0627\u0644\u062A\u0642\u062F\u064A\u0631 \u0627\u0644\u0623\u0639\u0644\u0649 \u0639\u0646 \u0627\u0644\u0623\u062F\u0646\u0649.",
  "Nothing to change.": "\u0644\u0627 \u0634\u064A\u0621 \u0644\u062A\u063A\u064A\u064A\u0631\u0647.",
  "Only outlets not on Nashr can be edited here.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0647\u0646\u0627 \u062A\u0639\u062F\u064A\u0644 \u0625\u0644\u0627 \u0627\u0644\u0645\u0646\u0635\u0627\u062A \u063A\u064A\u0631 \u0627\u0644\u0645\u0646\u0636\u0645\u0629 \u0625\u0644\u0649 \u0646\u0634\u0631.",
  "Only the founder can change financial settings.": "\u0648\u062D\u062F\u0647 \u0627\u0644\u0645\u0624\u0633\u0633 \u064A\u0645\u0643\u0646\u0647 \u062A\u063A\u064A\u064A\u0631 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0645\u0627\u0644\u064A\u0629.",
  "Unknown setting.": "\u0625\u0639\u062F\u0627\u062F \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641.",
  "This setting takes a {}.": "\u064A\u0623\u062E\u0630 \u0647\u0630\u0627 \u0627\u0644\u0625\u0639\u062F\u0627\u062F \u0642\u064A\u0645\u0629 \u0645\u0646 \u0646\u0648\u0639 {1}.",
  "Use a whole number, zero or more.": "\u0627\u0633\u062A\u062E\u062F\u0645 \u0639\u062F\u062F\u064B\u0627 \u0635\u062D\u064A\u062D\u064B\u0627\u060C \u0635\u0641\u0631\u064B\u0627 \u0623\u0648 \u0623\u0643\u062B\u0631.",
  "number": "\u0631\u0642\u0645",
  "boolean": "\u0635\u062D \u0623\u0648 \u062E\u0637\u0623",
  "string": "\u0646\u0635",
  "list": "\u0642\u0627\u0626\u0645\u0629",
  // Timeline notes and ledger references
  "Another request was accepted": "\u0642\u064F\u0628\u0644 \u0637\u0644\u0628 \u0622\u062E\u0631",
  "Corrected proof accepted": "\u0642\u064F\u0628\u0644 \u0627\u0644\u0625\u062B\u0628\u0627\u062A \u0627\u0644\u0645\u0635\u062D\u0651\u062D",
  "Partial refund accepted": "\u0642\u064F\u0628\u0644 \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0627\u0644\u062C\u0632\u0626\u064A",
  "Rerun accepted": "\u0642\u064F\u0628\u0644\u062A \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0628\u062B",
  "Inside the free cancellation window": "\u0636\u0645\u0646 \u0645\u0647\u0644\u0629 \u0627\u0644\u0625\u0644\u063A\u0627\u0621 \u0627\u0644\u0645\u062C\u0627\u0646\u064A",
  "Cancellation fee applies": "\u062A\u064F\u0637\u0628\u064E\u0651\u0642 \u0631\u0633\u0648\u0645 \u0627\u0644\u0625\u0644\u063A\u0627\u0621",
  "The buyer did not supply the creative": "\u0644\u0645 \u064A\u0633\u0644\u0651\u0645 \u0627\u0644\u0645\u0634\u062A\u0631\u064A \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629",
  "Corrected proof": "\u0625\u062B\u0628\u0627\u062A \u0645\u0635\u062D\u0651\u062D",
  "card cost kept from refund": "\u0631\u0633\u0648\u0645 \u0627\u0644\u0628\u0637\u0627\u0642\u0629 \u0645\u0642\u062A\u0637\u0639\u0629 \u0645\u0646 \u0627\u0644\u0627\u0633\u062A\u0631\u062F\u0627\u062F",
  "card cost recoverable from seller": "\u0631\u0633\u0648\u0645 \u0627\u0644\u0628\u0637\u0627\u0642\u0629 \u0645\u0633\u062A\u062D\u0642\u0629 \u0639\u0644\u0649 \u0627\u0644\u0646\u0627\u0634\u0631",
  "deducted from payout": "\u0645\u062E\u0635\u0648\u0645\u0629 \u0645\u0646 \u0627\u0644\u062A\u062D\u0648\u064A\u0644",
  "fee {}": "\u0631\u0633\u0648\u0645 {1}",
  // Receipts and invoices
  "{} \xB7 {} \xB7 {}": "{1} \xB7 {2} \xB7 {3}",
  "Booking confirmed by the publisher, arranged by Nashr as the publisher's agent. Pay by the deadline to secure the slot. This is not a tax invoice.": "\u062D\u062C\u0632 \u0623\u0643\u0651\u062F\u0647 \u0627\u0644\u0646\u0627\u0634\u0631\u060C \u0631\u062A\u0651\u0628\u062A\u0647 \u0646\u0634\u0631 \u0628\u0635\u0641\u062A\u0647\u0627 \u0648\u0643\u064A\u0644\u064B\u0627 \u0639\u0646 \u0627\u0644\u0646\u0627\u0634\u0631. \u0627\u062F\u0641\u0639 \u0642\u0628\u0644 \u0627\u0644\u0645\u0648\u0639\u062F \u0644\u062A\u0623\u0645\u064A\u0646 \u0627\u0644\u0645\u0633\u0627\u062D\u0629. \u0647\u0630\u0647 \u0644\u064A\u0633\u062A \u0641\u0627\u062A\u0648\u0631\u0629 \u0636\u0631\u064A\u0628\u064A\u0629.",
  // Slot names the server writes for packages
  "Any break": "\u0623\u064A \u0641\u0627\u0635\u0644",
  "All {} breaks": "\u0627\u0644\u0641\u0648\u0627\u0635\u0644 \u0627\u0644\u0640{1} \u0643\u0644\u0647\u0627",
  "Break {}": "\u0627\u0644\u0641\u0627\u0635\u0644 {1}",
  "Full week": "\u0623\u0633\u0628\u0648\u0639 \u0643\u0627\u0645\u0644",
  "Full page": "\u0635\u0641\u062D\u0629 \u0643\u0627\u0645\u0644\u0629",
  "Half page": "\u0646\u0635\u0641 \u0635\u0641\u062D\u0629",
  "Quarter page": "\u0631\u0628\u0639 \u0635\u0641\u062D\u0629",
  "Pre-roll": "\u0642\u0628\u0644 \u0627\u0644\u062D\u0644\u0642\u0629",
  "Mid-roll": "\u0648\u0633\u0637 \u0627\u0644\u062D\u0644\u0642\u0629",
  "Post-roll": "\u0646\u0647\u0627\u064A\u0629 \u0627\u0644\u062D\u0644\u0642\u0629",
  // Withdrawing a request; editing a placement
  "Only a buy-now request the publisher has not answered can be withdrawn.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0633\u062D\u0628 \u0625\u0644\u0627 \u0637\u0644\u0628 \u0634\u0631\u0627\u0621 \u0641\u0648\u0631\u064A \u0644\u0645 \u064A\u0631\u062F\u0651 \u0639\u0644\u064A\u0647 \u0627\u0644\u0646\u0627\u0634\u0631.",
  "Withdrawn by the buyer": "\u0633\u062D\u0628\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u064A",
  "This placement is not yours.": "\u0647\u0630\u0647 \u0627\u0644\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0644\u064A\u0633\u062A \u0644\u0643.",
  "Set a reserve price to accept bids automatically.": "\u062D\u062F\u0651\u062F \u0633\u0639\u0631\u064B\u0627 \u0623\u062F\u0646\u0649 \u0644\u0642\u0628\u0648\u0644 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0627\u062A \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627.",
  "The reserve cannot be above the buy-now price.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0623\u0646 \u064A\u062A\u062C\u0627\u0648\u0632 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u062F\u0646\u0649 \u0633\u0639\u0631 \u0627\u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0641\u0648\u0631\u064A.",
  // Messages
  "Write a message first.": "\u0627\u0643\u062A\u0628 \u0631\u0633\u0627\u0644\u0629 \u0623\u0648\u0644\u064B\u0627.",
  "Messages open once the booking is paid.": "\u062A\u064F\u0641\u062A\u062D \u0627\u0644\u0631\u0633\u0627\u0626\u0644 \u0628\u0639\u062F \u062F\u0641\u0639 \u0627\u0644\u062D\u062C\u0632.",
  "This deal is finished, so the conversation is closed.": "\u0627\u0646\u062A\u0647\u062A \u0627\u0644\u0635\u0641\u0642\u0629\u060C \u0644\u0630\u0627 \u0623\u064F\u063A\u0644\u0642\u062A \u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0629.",
  "Payment for Order {}: {} \xB7 {} \xB7 {}": "\u062F\u0641\u0639\u0629 \u0627\u0644\u0637\u0644\u0628 {1}: {2} \xB7 {3} \xB7 {4}",
  "{} \xB7 {} \xB7 {} \xB7 Order {}": "{1} \xB7 {2} \xB7 {3} \xB7 \u0627\u0644\u0637\u0644\u0628 {4}",
  "Order {}": "\u0627\u0644\u0637\u0644\u0628 {1}",
  "Nashr commission ({}%) on Order {}": "\u0639\u0645\u0648\u0644\u0629 \u0646\u0634\u0631 ({1}%) \u0639\u0644\u0649 \u0627\u0644\u0637\u0644\u0628 {2}",
  "Credit for invoice {}": "\u0625\u0634\u0639\u0627\u0631 \u062F\u0627\u0626\u0646 \u0644\u0644\u0641\u0627\u062A\u0648\u0631\u0629 {1}",
  "Received by Nashr on behalf of {}. This is not a tax invoice.": "\u0627\u0633\u062A\u0644\u0645\u062A\u0647\u0627 \u0646\u0634\u0631 \u0646\u064A\u0627\u0628\u0629 \u0639\u0646 {1}. \u0647\u0630\u0647 \u0644\u064A\u0633\u062A \u0641\u0627\u062A\u0648\u0631\u0629 \u0636\u0631\u064A\u0628\u064A\u0629.",
  "Issued by Nashr on behalf of {}.": "\u0623\u0635\u062F\u0631\u062A\u0647\u0627 \u0646\u0634\u0631 \u0646\u064A\u0627\u0628\u0629 \u0639\u0646 {1}.",
  "Paid by deduction from your payout.": "\u0633\u064F\u062F\u0651\u062F\u062A \u0628\u0627\u0644\u062E\u0635\u0645 \u0645\u0646 \u062A\u062D\u0648\u064A\u0644\u0643.",
  "Add the client's name.": "\u0623\u0636\u0641 \u0627\u0633\u0645 \u0627\u0644\u0639\u0645\u064A\u0644.",
  "A UAE TRN has 15 digits.": "\u0627\u0644\u0631\u0642\u0645 \u0627\u0644\u0636\u0631\u064A\u0628\u064A \u0641\u064A \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A \u0645\u0646 15 \u0631\u0642\u0645\u064B\u0627.",
  "Leave out email addresses and phone numbers.": "\u0644\u0627 \u062A\u0643\u062A\u0628 \u0639\u0646\u0627\u0648\u064A\u0646 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0648\u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0647\u0648\u0627\u062A\u0641.",
  "You already have a client with this name.": "\u0644\u062F\u064A\u0643 \u0639\u0645\u064A\u0644 \u0628\u0647\u0630\u0627 \u0627\u0644\u0627\u0633\u0645 \u0628\u0627\u0644\u0641\u0639\u0644.",
  "Choose one of your active clients.": "\u0627\u062E\u062A\u0631 \u0623\u062D\u062F \u0639\u0645\u0644\u0627\u0626\u0643 \u0627\u0644\u0646\u0634\u0637\u064A\u0646.",
  "Choose one of your clients.": "\u0627\u062E\u062A\u0631 \u0623\u062D\u062F \u0639\u0645\u0644\u0627\u0626\u0643.",
  "This campaign is for another client.": "\u0647\u0630\u0647 \u0627\u0644\u062D\u0645\u0644\u0629 \u0644\u0639\u0645\u064A\u0644 \u0622\u062E\u0631.",
  "This would take {} over its budget: {} is left.": "\u0633\u064A\u062A\u062C\u0627\u0648\u0632 \u0647\u0630\u0627 \u0645\u064A\u0632\u0627\u0646\u064A\u0629 {1}: \u0627\u0644\u0645\u062A\u0628\u0642\u064A {2}.",
  "The timer job last ran {} ago: auctions do not close and deadlines do not pass.": "\u0622\u062E\u0631 \u062A\u0634\u063A\u064A\u0644 \u0644\u0645\u0647\u0645\u0629 \u0627\u0644\u0645\u0624\u0642\u062A \u0643\u0627\u0646 \u0642\u0628\u0644 {1}: \u0627\u0644\u0645\u0632\u0627\u062F\u0627\u062A \u0644\u0627 \u062A\u064F\u063A\u0644\u0642 \u0648\u0627\u0644\u0645\u0647\u0644 \u0644\u0627 \u062A\u0646\u0642\u0636\u064A.",
  "A payment for order {} came back as {} instead of {}. The booking was not marked paid. Check it with the payment provider.": "\u0639\u0627\u062F\u062A \u062F\u0641\u0639\u0629 \u0627\u0644\u0637\u0644\u0628 {1} \u0628\u0645\u0628\u0644\u063A {2} \u0628\u062F\u0644\u064B\u0627 \u0645\u0646 {3}. \u0644\u0645 \u064A\u064F\u0639\u0644\u064E\u0651\u0645 \u0627\u0644\u062D\u062C\u0632 \u0645\u062F\u0641\u0648\u0639\u064B\u0627. \u0631\u0627\u062C\u0639\u0647 \u0645\u0639 \u0645\u0632\u0648\u062F \u0627\u0644\u062F\u0641\u0639.",
  "Payouts or refunds that failed and need a person: {}. Check Funds.": "\u062A\u062D\u0648\u064A\u0644\u0627\u062A \u0623\u0648 \u0627\u0633\u062A\u0631\u062F\u0627\u062F\u0627\u062A \u0641\u0634\u0644\u062A \u0648\u062A\u062D\u062A\u0627\u062C \u0625\u0644\u0649 \u062A\u062F\u062E\u0651\u0644 \u064A\u062F\u0648\u064A: {1}. \u0631\u0627\u062C\u0639 \u0627\u0644\u0623\u0645\u0648\u0627\u0644.",
  "Emails that could not be sent in the last day: {}. Check Emails.": "\u0631\u0633\u0627\u0626\u0644 \u062A\u0639\u0630\u0651\u0631 \u0625\u0631\u0633\u0627\u0644\u0647\u0627 \u062E\u0644\u0627\u0644 \u0627\u0644\u064A\u0648\u0645 \u0627\u0644\u0645\u0627\u0636\u064A: {1}. \u0631\u0627\u062C\u0639 \u0631\u0633\u0627\u0626\u0644 \u0627\u0644\u0628\u0631\u064A\u062F.",
  "Disputes past their decision date: {}. Check Disputes.": "\u0646\u0632\u0627\u0639\u0627\u062A \u062A\u062C\u0627\u0648\u0632\u062A \u0645\u0648\u0639\u062F \u0642\u0631\u0627\u0631\u0647\u0627: {1}. \u0631\u0627\u062C\u0639 \u0627\u0644\u0646\u0632\u0627\u0639\u0627\u062A.",
  "Server errors in the last 10 minutes: {}, latest: {}. Check the logs (journalctl -u nashr).": "\u0623\u062E\u0637\u0627\u0621 \u0627\u0644\u062E\u0627\u062F\u0645 \u062E\u0644\u0627\u0644 \u0622\u062E\u0631 10 \u062F\u0642\u0627\u0626\u0642: {1}\u060C \u0622\u062E\u0631\u0647\u0627: {2}. \u0631\u0627\u062C\u0639 \u0627\u0644\u0633\u062C\u0644\u0627\u062A (journalctl -u nashr).",
  "Upload the creative.": "\u0627\u0631\u0641\u0639 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "Upload the creative again: that file was not found.": "\u0627\u0631\u0641\u0639 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0645\u062C\u062F\u062F\u064B\u0627: \u0644\u0645 \u064A\u064F\u0639\u062B\u0631 \u0639\u0644\u0649 \u0630\u0644\u0643 \u0627\u0644\u0645\u0644\u0641.",
  "The timer job has not run yet.": "\u0644\u0645 \u062A\u0639\u0645\u0644 \u0645\u0647\u0645\u0629 \u0627\u0644\u0645\u0624\u0642\u062A \u0628\u0639\u062F.",
  "A payout or refund has been waiting {}. Check Funds.": "\u062A\u062D\u0648\u064A\u0644 \u0623\u0648 \u0627\u0633\u062A\u0631\u062F\u0627\u062F \u064A\u0646\u062A\u0638\u0631 \u0645\u0646\u0630 {1}. \u0631\u0627\u062C\u0639 \u0627\u0644\u0623\u0645\u0648\u0627\u0644.",
  "{} payout or refund failed and needs a person. Check Funds.": "\u0641\u0634\u0644 {1} \u062A\u062D\u0648\u064A\u0644 \u0623\u0648 \u0627\u0633\u062A\u0631\u062F\u0627\u062F \u0648\u064A\u062D\u062A\u0627\u062C \u0625\u0644\u0649 \u0645\u062A\u0627\u0628\u0639\u0629. \u0631\u0627\u062C\u0639 \u0627\u0644\u0623\u0645\u0648\u0627\u0644.",
  "The ledger and the payment provider disagree on the cash Nashr holds. Check Funds.": "\u0627\u0644\u0633\u062C\u0644 \u0627\u0644\u0645\u062D\u0627\u0633\u0628\u064A \u0648\u0645\u0632\u0648\u062F \u0627\u0644\u062F\u0641\u0639 \u0645\u062E\u062A\u0644\u0641\u0627\u0646 \u0639\u0644\u0649 \u0627\u0644\u0646\u0642\u062F \u0627\u0644\u0630\u064A \u062A\u062D\u062A\u0641\u0638 \u0628\u0647 \u0646\u0634\u0631. \u0631\u0627\u062C\u0639 \u0627\u0644\u0623\u0645\u0648\u0627\u0644.",
  "{} email could not be sent in the last day. Check Emails.": "\u062A\u0639\u0630\u0651\u0631 \u0625\u0631\u0633\u0627\u0644 {1} \u0628\u0631\u064A\u062F \u062E\u0644\u0627\u0644 \u0627\u0644\u064A\u0648\u0645 \u0627\u0644\u0645\u0627\u0636\u064A. \u0631\u0627\u062C\u0639 \u0631\u0633\u0627\u0626\u0644 \u0627\u0644\u0628\u0631\u064A\u062F.",
  "Emails have been retrying for {}. Check Emails.": "\u062A\u064F\u0639\u0627\u062F \u0645\u062D\u0627\u0648\u0644\u0629 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0631\u0633\u0627\u0626\u0644 \u0645\u0646\u0630 {1}. \u0631\u0627\u062C\u0639 \u0631\u0633\u0627\u0626\u0644 \u0627\u0644\u0628\u0631\u064A\u062F.",
  "{} dispute is past its decision date. Check Disputes.": "{1} \u0646\u0632\u0627\u0639 \u062A\u062C\u0627\u0648\u0632 \u0645\u0648\u0639\u062F \u0642\u0631\u0627\u0631\u0647. \u0631\u0627\u062C\u0639 \u0627\u0644\u0646\u0632\u0627\u0639\u0627\u062A.",
  "{} server errors in the last 10 minutes, latest: {}. Check the logs (journalctl -u nashr).": "{1} \u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u062E\u0627\u062F\u0645 \u062E\u0644\u0627\u0644 \u0622\u062E\u0631 10 \u062F\u0642\u0627\u0626\u0642\u060C \u0622\u062E\u0631\u0647\u0627: {2}. \u0631\u0627\u062C\u0639 \u0627\u0644\u0633\u062C\u0644\u0627\u062A (journalctl -u nashr).",
  "The last backup failed. Check: journalctl -u nashr-backup.": "\u0641\u0634\u0644\u062A \u0622\u062E\u0631 \u0646\u0633\u062E\u0629 \u0627\u062D\u062A\u064A\u0627\u0637\u064A\u0629. \u0631\u0627\u062C\u0639: journalctl -u nashr-backup.",
  "The last backup is {} old.": "\u0639\u0645\u0631 \u0622\u062E\u0631 \u0646\u0633\u062E\u0629 \u0627\u062D\u062A\u064A\u0627\u0637\u064A\u0629 {1}.",
  "No backup has been made yet.": "\u0644\u0645 \u062A\u064F\u0646\u0634\u0623 \u0623\u064A \u0646\u0633\u062E\u0629 \u0627\u062D\u062A\u064A\u0627\u0637\u064A\u0629 \u0628\u0639\u062F.",
  "The last restore drill failed: a backup may not restore. Check: journalctl -u nashr-restore-drill.": "\u0641\u0634\u0644\u062A \u0622\u062E\u0631 \u062A\u062C\u0631\u0628\u0629 \u0627\u0633\u062A\u0639\u0627\u062F\u0629: \u0642\u062F \u0644\u0627 \u062A\u064F\u0633\u062A\u0639\u0627\u062F \u0646\u0633\u062E\u0629 \u0627\u062D\u062A\u064A\u0627\u0637\u064A\u0629. \u0631\u0627\u062C\u0639: journalctl -u nashr-restore-drill.",
  "No restore drill has passed for over a week.": "\u0644\u0645 \u062A\u0646\u062C\u062D \u0623\u064A \u062A\u062C\u0631\u0628\u0629 \u0627\u0633\u062A\u0639\u0627\u062F\u0629 \u0645\u0646\u0630 \u0623\u0643\u062B\u0631 \u0645\u0646 \u0623\u0633\u0628\u0648\u0639.",
  "Only a request waiting on you can get a counter offer.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u062A\u0642\u062F\u064A\u0645 \u0639\u0631\u0636 \u0645\u0642\u0627\u0628\u0644 \u0625\u0644\u0627 \u0639\u0644\u0649 \u0637\u0644\u0628 \u064A\u0646\u062A\u0638\u0631 \u0642\u0631\u0627\u0631\u0643.",
  "A counter offer needs a different price. To take this price, accept the request.": "\u0627\u0644\u0639\u0631\u0636 \u0627\u0644\u0645\u0642\u0627\u0628\u0644 \u064A\u062D\u062A\u0627\u062C \u0633\u0639\u0631\u064B\u0627 \u0645\u062E\u062A\u0644\u0641\u064B\u0627. \u0644\u062A\u0623\u062E\u0630 \u0647\u0630\u0627 \u0627\u0644\u0633\u0639\u0631\u060C \u0627\u0642\u0628\u0644 \u0627\u0644\u0637\u0644\u0628.",
  "There is no counter offer to answer.": "\u0644\u0627 \u064A\u0648\u062C\u062F \u0639\u0631\u0636 \u0645\u0642\u0627\u0628\u0644 \u0644\u0644\u0631\u062F \u0639\u0644\u064A\u0647.",
  "This submission is with Nashr or already decided, so it cannot be changed.": "\u0647\u0630\u0627 \u0627\u0644\u0637\u0644\u0628 \u0644\u062F\u0649 \u0646\u0634\u0631 \u0623\u0648 \u062A\u0645 \u0627\u0644\u0628\u062A \u0641\u064A\u0647\u060C \u0644\u0630\u0627 \u0644\u0627 \u064A\u0645\u0643\u0646 \u062A\u0639\u062F\u064A\u0644\u0647.",
  "This submission was not found.": "\u0644\u0645 \u064A\u064F\u0639\u062B\u0631 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0637\u0644\u0628.",
  "This submission is already with Nashr.": "\u0647\u0630\u0627 \u0627\u0644\u0637\u0644\u0628 \u0644\u062F\u0649 \u0646\u0634\u0631 \u0628\u0627\u0644\u0641\u0639\u0644.",
  "Only a submission waiting for review can be decided.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0627\u0644\u0628\u062A \u0625\u0644\u0627 \u0641\u064A \u0637\u0644\u0628 \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629.",
  "Say what needs changing, so the publisher can act on it.": "\u0648\u0636\u0651\u062D \u0645\u0627 \u064A\u062D\u062A\u0627\u062C \u0625\u0644\u0649 \u062A\u0639\u062F\u064A\u0644 \u0644\u064A\u062A\u0645\u0643\u0646 \u0627\u0644\u0646\u0627\u0634\u0631 \u0645\u0646 \u0627\u0644\u0639\u0645\u0644 \u0639\u0644\u064A\u0647.",
  "Every coverage date has passed. Ask the publisher for new dates.": "\u0645\u0631\u0651\u062A \u0643\u0644 \u062A\u0648\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u063A\u0637\u064A\u0629. \u0627\u0637\u0644\u0628 \u0645\u0646 \u0627\u0644\u0646\u0627\u0634\u0631 \u062A\u0648\u0627\u0631\u064A\u062E \u062C\u062F\u064A\u062F\u0629.",
  "Choose one of your outlets.": "\u0627\u062E\u062A\u0631 \u0623\u062D\u062F \u0645\u0646\u0627\u0641\u0630\u0643.",
  "Add the programme or show name.": "\u0623\u0636\u0641 \u0627\u0633\u0645 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C \u0623\u0648 \u0627\u0644\u0639\u0631\u0636.",
  "Choose the type.": "\u0627\u062E\u062A\u0631 \u0627\u0644\u0646\u0648\u0639.",
  "Choose the format.": "\u0627\u062E\u062A\u0631 \u0627\u0644\u0634\u0643\u0644.",
  "Add the duration in minutes.": "\u0623\u0636\u0641 \u0627\u0644\u0645\u062F\u0629 \u0628\u0627\u0644\u062F\u0642\u0627\u0626\u0642.",
  "Choose how often it runs.": "\u0627\u062E\u062A\u0631 \u0639\u062F\u062F \u0645\u0631\u0627\u062A \u0627\u0644\u0639\u0631\u0636.",
  "Add at least one coverage date.": "\u0623\u0636\u0641 \u062A\u0627\u0631\u064A\u062E \u062A\u063A\u0637\u064A\u0629 \u0648\u0627\u062D\u062F\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
  "Coverage dates must be today or later.": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u062A\u0648\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u063A\u0637\u064A\u0629 \u0627\u0644\u064A\u0648\u0645 \u0623\u0648 \u0628\u0639\u062F\u0647.",
  "Add the time (UAE).": "\u0623\u0636\u0641 \u0627\u0644\u0648\u0642\u062A (\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A).",
  "Choose at least one coverage type.": "\u0627\u062E\u062A\u0631 \u0646\u0648\u0639 \u062A\u063A\u0637\u064A\u0629 \u0648\u0627\u062D\u062F\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
  "Add the editorial angle or key message.": "\u0623\u0636\u0641 \u0627\u0644\u0632\u0627\u0648\u064A\u0629 \u0627\u0644\u062A\u062D\u0631\u064A\u0631\u064A\u0629 \u0623\u0648 \u0627\u0644\u0631\u0633\u0627\u0644\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629.",
  "Add the estimated reach.": "\u0623\u0636\u0641 \u0627\u0644\u0648\u0635\u0648\u0644 \u0627\u0644\u0645\u062A\u0648\u0642\u0639.",
  "Choose at least one deliverable.": "\u0627\u062E\u062A\u0631 \u0645\u062E\u0631\u062C\u064B\u0627 \u0648\u0627\u062D\u062F\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
  "Say what the other deliverable is.": "\u0648\u0636\u0651\u062D \u0645\u0627 \u0647\u0648 \u0627\u0644\u0645\u062E\u0631\u062C \u0627\u0644\u0622\u062E\u0631.",
  "Choose where the coverage appears.": "\u0627\u062E\u062A\u0631 \u0623\u064A\u0646 \u062A\u0638\u0647\u0631 \u0627\u0644\u062A\u063A\u0637\u064A\u0629.",
  "Add the base price.": "\u0623\u0636\u0641 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0623\u0633\u0627\u0633\u064A.",
  "Choose how it sells: fixed price or bidding.": "\u0627\u062E\u062A\u0631 \u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u0628\u064A\u0639: \u0633\u0639\u0631 \u062B\u0627\u0628\u062A \u0623\u0648 \u0645\u0632\u0627\u064A\u062F\u0629.",
  "Add the product name.": "\u0623\u0636\u0641 \u0627\u0633\u0645 \u0627\u0644\u0645\u0646\u062A\u062C.",
  "Add a description.": "\u0623\u0636\u0641 \u0648\u0635\u0641\u064B\u0627.",
  "Keep it to 500 characters.": "\u0644\u0627 \u062A\u062A\u062C\u0627\u0648\u0632 500 \u062D\u0631\u0641.",
  "This product was not found.": "\u0644\u0645 \u064A\u064F\u0639\u062B\u0631 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0645\u0646\u062A\u062C.",
  "Add the outlet name.": "\u0623\u0636\u0641 \u0627\u0633\u0645 \u0627\u0644\u0645\u0646\u0641\u0630.",
  "The website must start with https:// or http://.": "\u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u0648\u0642\u0639 \u0628\u0640 https:// \u0623\u0648 http://.",
  "This outlet was not found.": "\u0644\u0645 \u064A\u064F\u0639\u062B\u0631 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0645\u0646\u0641\u0630.",
  "Enter the new price.": "\u0623\u062F\u062E\u0644 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u062C\u062F\u064A\u062F.",
  "Nothing is listed in this week to repeat.": "\u0644\u0627 \u064A\u0648\u062C\u062F \u0634\u064A\u0621 \u0645\u0639\u0631\u0648\u0636 \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u0623\u0633\u0628\u0648\u0639 \u0644\u062A\u0643\u0631\u0627\u0631\u0647.",
  "This media type was not found.": "\u0644\u0645 \u064A\u064F\u0639\u062B\u0631 \u0639\u0644\u0649 \u0646\u0648\u0639 \u0627\u0644\u0648\u0633\u064A\u0644\u0629 \u0647\u0630\u0627.",
  "The media type cannot change once it is added. Add a new one instead.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u062A\u063A\u064A\u064A\u0631 \u0646\u0648\u0639 \u0627\u0644\u0648\u0633\u064A\u0644\u0629 \u0628\u0639\u062F \u0625\u0636\u0627\u0641\u062A\u0647. \u0623\u0636\u0641 \u0646\u0648\u0639\u064B\u0627 \u062C\u062F\u064A\u062F\u064B\u0627 \u0628\u062F\u0644\u064B\u0627 \u0645\u0646\u0647.",
  "Only Radio, TV and Podcast have programmes.": "\u0627\u0644\u0628\u0631\u0627\u0645\u062C \u0644\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u0644\u0628\u0648\u062F\u0643\u0627\u0633\u062A \u0641\u0642\u0637.",
  "Add the programme name.": "\u0623\u0636\u0641 \u0627\u0633\u0645 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C.",
  "This programme was not found.": "\u0644\u0645 \u064A\u064F\u0639\u062B\u0631 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C.",
  "Buy-now and minimum accepted prices are for auctions only.": "\u0633\u0639\u0631 \u0627\u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0641\u0648\u0631\u064A \u0648\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u062F\u0646\u0649 \u0627\u0644\u0645\u0642\u0628\u0648\u0644 \u0644\u0644\u0645\u0632\u0627\u062F\u0627\u062A \u0641\u0642\u0637.",
  "The minimum accepted cannot be above the buy-now price.": "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0623\u0646 \u064A\u062A\u062C\u0627\u0648\u0632 \u0627\u0644\u062D\u062F \u0627\u0644\u0623\u062F\u0646\u0649 \u0627\u0644\u0645\u0642\u0628\u0648\u0644 \u0633\u0639\u0631 \u0627\u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0641\u0648\u0631\u064A.",
  "Add the start and end time.": "\u0623\u0636\u0641 \u0648\u0642\u062A \u0627\u0644\u0628\u062F\u0627\u064A\u0629 \u0648\u0627\u0644\u0646\u0647\u0627\u064A\u0629.",
  "Add each break with its time.": "\u0623\u0636\u0641 \u0643\u0644 \u0641\u0627\u0635\u0644 \u0645\u0639 \u0648\u0642\u062A\u0647.",
  "Fill in {}.": "\u0627\u0645\u0644\u0623 {1}.",
  "Pick the media type.": "\u0627\u062E\u062A\u0631 \u0646\u0648\u0639 \u0627\u0644\u0648\u0633\u064A\u0644\u0629.",
  "Say what the media type is.": "\u0648\u0636\u0651\u062D \u0646\u0648\u0639 \u0627\u0644\u0648\u0633\u064A\u0644\u0629.",
  "Add the name buyers see.": "\u0623\u0636\u0641 \u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0630\u064A \u064A\u0631\u0627\u0647 \u0627\u0644\u0645\u0634\u062A\u0631\u0648\u0646.",
  "Pick the language.": "\u0627\u062E\u062A\u0631 \u0627\u0644\u0644\u063A\u0629.",
  "Describe the audience.": "\u0635\u0650\u0641 \u0627\u0644\u062C\u0645\u0647\u0648\u0631.",
  "Pick at least one market.": "\u0627\u062E\u062A\u0631 \u0633\u0648\u0642\u064B\u0627 \u0648\u0627\u062D\u062F\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
  "Add the default price.": "\u0623\u0636\u0641 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A.",
  "Add when the creative is due.": "\u0623\u0636\u0641 \u0645\u0648\u0639\u062F \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "Add when bidding closes.": "\u0623\u0636\u0641 \u0645\u0648\u0639\u062F \u0627\u0646\u062A\u0647\u0627\u0621 \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629.",
  "Pick the creative file type.": "\u0627\u062E\u062A\u0631 \u0646\u0648\u0639 \u0645\u0644\u0641 \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629.",
  "Bidding must close at least 3 days before the creative is due (1 day for you to decide, 2 for the buyer to pay).": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0646\u062A\u0647\u064A \u0627\u0644\u0645\u0632\u0627\u064A\u062F\u0629 \u0642\u0628\u0644 \u0645\u0648\u0639\u062F \u0627\u0644\u0645\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u064A\u0629 \u0628\u062B\u0644\u0627\u062B\u0629 \u0623\u064A\u0627\u0645 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644 (\u064A\u0648\u0645 \u0644\u062A\u0642\u0631\u0631\u060C \u0648\u064A\u0648\u0645\u0627\u0646 \u0644\u064A\u062F\u0641\u0639 \u0627\u0644\u0645\u0634\u062A\u0631\u064A)."
};
var esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
var exact = new Map(Object.entries(SERVER_AR).filter(([k]) => !k.includes("{}")));
var patterns = Object.entries(SERVER_AR).filter(([k]) => k.includes("{}")).sort((a, b) => b[0].replace(/\{\}/g, "").length - a[0].replace(/\{\}/g, "").length).map(([k, v]) => [new RegExp("^" + k.split("{}").map(esc).join("(.+?)") + "$", "s"), v]);
var UNITS = { minutes: ["\u062F\u0642\u064A\u0642\u0629 \u0648\u0627\u062D\u062F\u0629", "\u062F\u0642\u064A\u0642\u062A\u064A\u0646", "\u062F\u0642\u0627\u0626\u0642", "\u062F\u0642\u064A\u0642\u0629"], hours: ["\u0633\u0627\u0639\u0629 \u0648\u0627\u062D\u062F\u0629", "\u0633\u0627\u0639\u062A\u064A\u0646", "\u0633\u0627\u0639\u0627\u062A", "\u0633\u0627\u0639\u0629"] };
var span = (v) => {
  const m = v.match(/^(\d+) (minutes|hours)$/);
  if (!m) return null;
  const n2 = Number(m[1]), [one3, two, few, many] = UNITS[m[2]];
  return n2 === 1 ? one3 : n2 === 2 ? two : n2 <= 10 ? `${n2} ${few}` : `${n2} ${many}`;
};
var word = (v) => exact.get(v) ?? AR[v] ?? span(v) ?? (v.includes(" \xB7 ") ? v.split(" \xB7 ").map(word).join(" \xB7 ") : v.length < 40 && one2(v) ? one2(v) : /^AED [\d,.]+$/.test(v) ? `${v.slice(4)} \u062F\u0631\u0647\u0645` : /^\d{4,}(\.\d+)?$/.test(v) ? Number(v).toLocaleString("en-US") : v.includes(" and ") ? v.split(" and ").map(word).join(" \u0648") : v);
function one2(s) {
  const hit = exact.get(s) ?? AR[s];
  if (hit) return hit;
  if (/^[a-z]+(_[a-z]+)+$/.test(s)) return AR[s.replace(/_/g, " ")] ?? null;
  for (const [re, ar] of patterns) {
    const m = s.match(re);
    if (m) return ar.replace(/\{(\d)\}/g, (_, i) => word(m[Number(i)]));
  }
  return null;
}
function arabicFor(msg) {
  if (!msg) return "";
  const whole = one2(msg);
  if (whole) return whole;
  const parts = msg.split(/(?<=[.!?:])\s+(?=[A-Z])/), out = [];
  for (let i = 0; i < parts.length; ) {
    let j = parts.length, hit = null;
    for (; j > i && !(hit = one2(parts.slice(i, j).join(" "))); j--) ;
    if (hit) {
      out.push(hit);
      i = j;
    } else out.push(parts[i++]);
  }
  return out.join(" ");
}

// server/core/mail.ts
var site = () => (process.env.SITE_URL ?? "http://localhost:5173").replace(/\/$/, "");
var tr = (lang) => (en, vars = {}) => (lang === "ar" ? AR[en] ?? en : en).replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? ""));
var money = (lang) => (fils) => {
  const n2 = (fils / 100).toLocaleString("en-US", { maximumFractionDigits: fils % 100 ? 2 : 0, minimumFractionDigits: fils % 100 ? 2 : 0 });
  return lang === "ar" ? `${n2} \u062F\u0631\u0647\u0645` : `AED ${n2}`;
};
var day = (lang) => (iso) => new Date(iso).toLocaleDateString(lang === "ar" ? "ar-AE-u-nu-latn" : "en-GB", { timeZone: "Asia/Dubai", day: "numeric", month: "short" });
var esc2 = (s) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var side = (text) => {
  const first = text.match(/[A-Za-z\u0600-\u06FF]/)?.[0] ?? "a";
  return /[\u0600-\u06FF]/.test(first) ? 'dir="rtl" style="text-align:right;' : 'dir="ltr" style="text-align:left;';
};
function renderEmail(lang, e) {
  const dir2 = lang === "ar" ? "rtl" : "ltr", align = lang === "ar" ? "right" : "left";
  const font = lang === "ar" ? "'Readex Pro', Tahoma, Arial, sans-serif" : "'Source Sans 3', 'Segoe UI', Arial, Helvetica, sans-serif";
  const html = `<!doctype html><html lang="${lang}" dir="${dir2}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${esc2(e.title)}</title></head>
<body style="margin:0;padding:0;background:#f4f4f2;font-family:${font};color:#0b0b0c">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f2;padding:24px 12px"><tr><td align="center">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:10px;overflow:hidden;border:1px solid #e4e3e0" dir="${dir2}">
<tr><td style="background:#ffffff;padding:20px 24px 16px;text-align:${align};border-bottom:1px solid #e4e3e0"><img src="${site()}/brand/logo/nashr-logo-primary-email.png" width="148" height="24" alt="Nashr \u0646\u0634\u0631" style="display:inline-block;border:0;height:24px;width:148px;color:#0b0b0c;font-size:18px;font-weight:600"></td></tr>
<tr><td style="padding:24px;text-align:${align};font-size:15px;line-height:1.6">
<h1 ${side(e.title)}margin:0 0 12px;font-size:20px;line-height:1.35">${esc2(e.title)}</h1>
${e.paragraphs.map((p) => `<p ${side(p)}margin:0 0 12px">${esc2(p)}</p>`).join("\n")}
${e.cta ? `<p style="margin:20px 0 4px"><a href="${esc2(e.cta.url)}" style="display:inline-block;background:#0b0b0c;color:#ffffff;text-decoration:none;padding:12px 20px;border-radius:6px;font-weight:600">${esc2(e.cta.label)}</a></p>` : ""}
</td></tr>
<tr><td style="padding:16px 24px;border-top:1px solid #e4e3e0;font-size:13px;color:#55534f;line-height:1.5">${e.footer.split("\n").map((l) => `<div ${side(l)}">${esc2(l)}</div>`).join("")}</td></tr>
</table></td></tr></table></body></html>`;
  const text = [e.title, "", ...e.paragraphs, ...e.cta ? ["", `${e.cta.label}: ${e.cta.url}`] : [], "", "\u2014", e.footer].join("\n");
  return { html, text };
}
async function queue(db, m, at) {
  const on = !!smtpConfig();
  await db.query(`insert into outbox (to_email, user_id, company_id, kind, subject, text_body, html_body, status, next_attempt_at, created_at)
    values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $9)`, [m.to, m.userId ?? null, m.companyId ?? null, m.kind, m.subject.slice(0, 200), m.text, m.html, on ? "queued" : "held", at]);
  return on;
}
function choice(kind) {
  if (kind === "message.new") return "messages";
  if (kind === "search.match") return "alerts";
  if (["bid.outbid", "bid.auto_raised", "bid.auto_cap", "bid.closed_lost", "bid.not_selected", "interest.not_selected", "interest.expired"].includes(kind)) return "bids";
  return null;
}
function noticeMessage(lang, role, kind, dealId, data) {
  const t = tr(lang);
  const said = noticeTexts(t, money(lang), day(lang), lang === "ar" ? arabicFor : (s) => s)[kind]?.({ kind, dealId, data }) ?? t("You have a new notification on Nashr.");
  const title = said.length > 90 ? said.slice(0, 87).replace(/\s+\S*$/, "") + "\u2026" : said;
  return { said, title, url: site() + (noticeHref({ kind, dealId, data }, role) ?? "/") };
}
var wantsNotice = (kind, prefs) => {
  const pick = choice(kind);
  return !pick || { bids: true, alerts: true, messages: true, ...prefs }[pick] !== false;
};
async function queueNoticeEmails(db, companyId, kind, dealId, data, at) {
  const people = (await db.query(`select id, email, role, lang, email_prefs from users where company_id = $1 and status = 'active'`, [companyId])).rows;
  if (!people.length) return;
  const ref = dealId ? (await db.query(`select ref from deals where id = $1`, [dealId])).rows[0]?.ref ?? null : null;
  const pick = choice(kind);
  for (const p of people) {
    if (pick && { bids: true, alerts: true, messages: true, ...p.email_prefs }[pick] === false) continue;
    const lang = p.lang === "ar" ? "ar" : "en", t = tr(lang);
    const { said, title, url } = noticeMessage(lang, p.role, kind, dealId, data);
    const { html, text } = renderEmail(lang, {
      title,
      paragraphs: [...said !== title ? [said] : [], ...ref ? [t("Order {ref}", { ref })] : []],
      cta: { label: t("Open in Nashr"), url },
      footer: pick ? t("You get these emails because of your choices on Nashr. Change them under Your account.") : t("Nashr sends this email about your bookings, payments or account. It cannot be switched off.")
    });
    await queue(db, { to: p.email, userId: p.id, companyId, kind, subject: title, text, html }, at);
  }
}

// server/core/push.ts
import { createECDH, createHmac as createHmac2, createCipheriv, createPrivateKey, createSign, randomBytes as randomBytes2 } from "node:crypto";
var b64u = (b) => b.toString("base64url");
var unb64u = (s) => Buffer.from(s, "base64url");
var cached = null;
async function vapidKeys(db = pool) {
  if (cached) return cached;
  if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) return cached = { publicKey: process.env.VAPID_PUBLIC_KEY, privateKey: process.env.VAPID_PRIVATE_KEY };
  const row = (await db.query(`select value from server_keys where name = 'vapid'`)).rows[0];
  if (row) return cached = row.value;
  const ecdh = createECDH("prime256v1");
  ecdh.generateKeys();
  const made = { publicKey: b64u(ecdh.getPublicKey()), privateKey: b64u(ecdh.getPrivateKey()) };
  await db.query(`insert into server_keys (name, value) values ('vapid', $1) on conflict (name) do nothing`, [JSON.stringify(made)]);
  return cached = (await db.query(`select value from server_keys where name = 'vapid'`)).rows[0].value;
}
function vapidAuth(endpoint, keys, subject, now2 = Date.now()) {
  const pub = unb64u(keys.publicKey);
  const key = createPrivateKey({ format: "jwk", key: { kty: "EC", crv: "P-256", d: keys.privateKey, x: b64u(pub.subarray(1, 33)), y: b64u(pub.subarray(33, 65)) } });
  const header = b64u(Buffer.from(JSON.stringify({ typ: "JWT", alg: "ES256" })));
  const claims = b64u(Buffer.from(JSON.stringify({ aud: new URL(endpoint).origin, exp: Math.floor(now2 / 1e3) + 12 * 3600, sub: subject })));
  const signature = createSign("SHA256").update(`${header}.${claims}`).sign({ key, dsaEncoding: "ieee-p1363" });
  return `vapid t=${header}.${claims}.${b64u(signature)}, k=${keys.publicKey}`;
}
var hmac = (key, data) => createHmac2("sha256", key).update(data).digest();
function encrypt(payload, sub, salt = randomBytes2(16)) {
  const sender = createECDH("prime256v1");
  sender.generateKeys();
  const uaPublic = unb64u(sub.p256dh), authSecret = unb64u(sub.auth), asPublic = sender.getPublicKey();
  const shared = sender.computeSecret(uaPublic);
  const ikm = hmac(hmac(authSecret, shared), Buffer.concat([Buffer.from("WebPush: info\0"), uaPublic, asPublic, Buffer.from([1])]));
  const prk = hmac(salt, ikm);
  const cek = hmac(prk, Buffer.concat([Buffer.from("Content-Encoding: aes128gcm\0"), Buffer.from([1])])).subarray(0, 16);
  const nonce = hmac(prk, Buffer.concat([Buffer.from("Content-Encoding: nonce\0"), Buffer.from([1])])).subarray(0, 12);
  const cipher = createCipheriv("aes-128-gcm", cek, nonce);
  const body = Buffer.concat([cipher.update(Buffer.concat([payload, Buffer.from([2])])), cipher.final(), cipher.getAuthTag()]);
  const rs = Buffer.alloc(4);
  rs.writeUInt32BE(4096);
  return Buffer.concat([salt, rs, Buffer.from([asPublic.length]), asPublic, body]);
}
async function pushTo(sub, message, opts = {}) {
  const keys = await vapidKeys();
  const subject = (process.env.SITE_URL ?? "https://nashr.ae").replace(/\/$/, "");
  const res = await (opts.post ?? fetch)(sub.endpoint, {
    method: "POST",
    body: encrypt(Buffer.from(JSON.stringify(message)), sub),
    headers: { authorization: vapidAuth(sub.endpoint, keys, subject), "content-encoding": "aes128gcm", "content-type": "application/octet-stream", ttl: "86400", urgency: opts.urgent ? "high" : "normal" }
  });
  if (res.status === 404 || res.status === 410) await pool.query(`delete from push_subscriptions where id = $1`, [sub.id]);
  else if (res.status < 300) await pool.query(`update push_subscriptions set last_used_at = now() where id = $1`, [sub.id]);
  return res.status;
}
var URGENT = /^(deal\.(opened|awaiting_payment)|bid\.(outbid|won)|issue\.|dispute\.|interest\.received|chargeback\.|deadline\.)/;
async function pushNotice(companyId, kind, dealId, data, post2) {
  const subs = (await pool.query(`select s.id, s.endpoint, s.p256dh, s.auth, u.role, u.lang, u.email_prefs from push_subscriptions s join users u on u.id = s.user_id
    where u.company_id = $1 and u.status = 'active'`, [companyId])).rows;
  for (const s of subs) {
    if (!wantsNotice(kind, s.email_prefs)) continue;
    const m = noticeMessage(s.lang === "ar" ? "ar" : "en", s.role, kind, dealId, data);
    await pushTo(s, { title: s.lang === "ar" ? "\u0646\u0634\u0631" : "Nashr", body: m.said, url: m.url, tag: dealId ?? kind }, { urgent: URGENT.test(kind), post: post2 }).catch(() => 0);
  }
}

// server/core/notify.ts
async function notify(db, companyId, kind, dealId, data, at) {
  await db.query(
    `insert into notifications (company_id, kind, deal_id, data, created_at) values ($1, $2, $3, $4, $5)`,
    [companyId, kind, dealId, data == null ? null : JSON.stringify(data), at]
  );
  signalCompany(db, companyId);
  await queueNoticeEmails(db, companyId, kind, dealId, data, at);
  afterCommit(db, () => pushNotice(companyId, kind, dealId, data));
}

// server/marketplace/deals.ts
var TRANSITIONS = {
  // admin_* events: Nashr's team steps in on a live deal, always with a written reason (SPEC 6D "All deals: release/refund/cancel")
  awaiting_seller: { accept: "awaiting_payment", decline: "declined", expire: "declined", supersede: "declined", withdraw: "cancelled", admin_cancel: "cancelled" },
  awaiting_payment: { pay: "secured", lapse: "lapsed", admin_cancel: "cancelled" },
  secured: {
    submit_proof: "in_review",
    cancel_by_buyer: "cancelled",
    cancel_by_seller: "cancelled",
    creative_missed: "cancelled",
    proof_missed: "refunded",
    admin_refund: "refunded",
    admin_release: "released",
    chargeback: "disputed"
  },
  in_review: { approve: "released", auto_release: "released", report_issue: "issue_open", admin_refund: "refunded", admin_release: "released", chargeback: "disputed" },
  issue_open: { resolve: "in_review", make_good: "secured", partial_refund: "released", escalate: "disputed", admin_refund: "refunded", admin_release: "released", chargeback: "disputed" },
  disputed: { release: "released", refund: "refunded", partial_refund: "released", make_good: "secured" },
  released: { paid_out: "paid_out" }
};
var TELL = {
  awaiting_payment: ["buyer"],
  declined: ["buyer"],
  lapsed: ["buyer", "seller"],
  secured: ["seller"],
  cancelled: ["buyer", "seller"],
  refunded: ["buyer", "seller"],
  released: ["seller"]
};
var ON_DEADLINE = {
  awaiting_seller: "expire",
  awaiting_payment: "lapse",
  secured: "proof_missed",
  in_review: "auto_release",
  issue_open: "escalate"
};
var hours = (t, h) => new Date(t.getTime() + h * 36e5);
var earliest = (...ts) => new Date(Math.min(...ts.map((t) => t.getTime())));
async function deadlineFor(db, deal, status, at) {
  const slot = await one(db, `select s.closes_at, s.creative_due_at, s.starts_at, s.ends_at, o.market from slots s join placements p on p.id = s.placement_id
                              join outlets o on o.id = p.outlet_id where s.id = $1`, [deal.slot_id]);
  switch (status) {
    case "awaiting_seller": {
      const d = hours(at, await setting(db, "seller_window_hours", at));
      return deal.kind === "buy_now" ? earliest(d, slot.closes_at) : d;
    }
    case "awaiting_payment":
      return earliest(hours(at, await setting(db, "payment_window_hours", at)), slot.creative_due_at);
    case "secured":
      return addWorkingDays(db, deal.make_good_at ?? slot.ends_at ?? slot.starts_at, await setting(db, "proof_due_working_days", at), slot.market);
    case "in_review":
      return addWorkingDays(db, at, await setting(db, "review_working_days", at), slot.market);
    case "issue_open":
      return hours(at, await setting(db, "issue_response_hours", at));
    default:
      return null;
  }
}
async function transition(db, dealId, event, actor, at, note) {
  const deal = await one(db, `select * from deals where id = $1 for update`, [dealId]);
  const to = TRANSITIONS[deal.status]?.[event];
  if (!to) throw new Error(`Cannot ${event} a deal that is ${deal.status}`);
  const deadline = await deadlineFor(db, deal, to, at);
  const updated = await one(
    db,
    `update deals set status = $2, next_deadline_at = $3,
       accepted_at = case when $2 = 'awaiting_payment' then $4 else accepted_at end,
       proof_at = case when $2 = 'in_review' and proof_at is null then $4 else proof_at end
     where id = $1 returning *`,
    [dealId, to, deadline, at]
  );
  await db.query(
    `insert into deal_events (deal_id, at, event, from_status, to_status, actor, note) values ($1, $2, $3, $4, $5, $6, $7)`,
    [dealId, at, event, deal.status, to, actor, note ?? null]
  );
  await audit(db, actor, `deal.${event}`, "deal", dealId, { from: deal.status, to, note }, at);
  for (const side2 of TELL[to] ?? []) await notify(db, side2 === "buyer" ? deal.buyer_id : deal.seller_id, `deal.${to}`, dealId, null, at);
  return updated;
}
async function openDeal(db, slot, bid, kind, actor, at) {
  const seller = await one(db, `select o.company_id from placements p join outlets o on o.id = p.outlet_id where p.id = $1`, [slot.placement_id]);
  const deal = await one(
    db,
    `insert into deals (slot_id, bid_id, buyer_id, seller_id, kind, status, amount, currency, created_at, campaign_id, client_id)
     values ($1, $2, $3, $4, $5, 'awaiting_seller', $6, $7, $8,
             -- an auto-bid placed by the system carries the campaign and client of the buyer's own last tagged bid
             coalesce($9::uuid, (select campaign_id from bids where slot_id = $1 and buyer_id = $3 and campaign_id is not null order by seq desc limit 1)),
             coalesce($10::uuid, (select client_id from bids where slot_id = $1 and buyer_id = $3 and client_id is not null order by seq desc limit 1))) returning *`,
    [slot.id, bid.id, bid.buyer_id, seller.company_id, kind, bid.amount, slot.currency, at, bid.campaign_id ?? null, bid.client_id ?? null]
  );
  const deadline = await deadlineFor(db, deal, "awaiting_seller", at);
  await db.query(`update deals set next_deadline_at = $2 where id = $1`, [deal.id, deadline]);
  await db.query(
    `insert into deal_events (deal_id, at, event, from_status, to_status, actor) values ($1, $2, 'opened', null, 'awaiting_seller', $3)`,
    [deal.id, at, actor]
  );
  await audit(db, actor, "deal.opened", "deal", deal.id, { kind, amount: bid.amount }, at);
  await notify(db, deal.seller_id, "deal.opened", deal.id, { kind }, at);
  return { ...deal, next_deadline_at: deadline };
}

// server/core/contact.ts
var ARABIC_DIGITS = /[٠-٩۰-۹]/g;
var toLatin = (s) => s.replace(ARABIC_DIGITS, (d) => String((d.charCodeAt(0) & 15) % 10));
var EMAIL = /[a-z0-9._%+-]+\s*(@|\(at\)|\[at\]|\sat\s)\s*[a-z0-9-]+\s*(\.|\(dot\)|\[dot\]|\sdot\s)\s*[a-z]{2,}/i;
var PHONE = /(\+?\d[\d\s().-]{6,}\d)/;
function containsContactDetails(text) {
  if (!text) return false;
  const t = toLatin(text);
  return EMAIL.test(t) || [...t.matchAll(new RegExp(PHONE, "g"))].some((m) => m[0].replace(/\D/g, "").length >= 8);
}

// server/fulfilment/brief.ts
function briefProblems(b, channel) {
  if (!b) return ["A booking brief is required with your first bid."];
  const out = [];
  if (!b.advertiser?.trim()) out.push("Add the advertiser or brand.");
  if (!b.industry?.trim()) out.push("Choose the industry.");
  if (!b.message?.trim()) out.push("Say what the ad will say.");
  else if (b.message.length > 280) out.push("What the ad will say must be 280 characters or fewer.");
  if (!["arabic", "english", "bilingual", "other"].includes(b.language)) out.push("Choose the creative language.");
  else if (b.language === "other" && !b.languageOther?.trim()) out.push("Say which language the creative is in.");
  if (channel === "digital" && !b.landingUrl) out.push("A landing page link is required for digital placements.");
  if (b.landingUrl && !/^https:\/\/\S+$/.test(b.landingUrl)) out.push("The landing page link must start with https://.");
  if (!b.draftFileKey) out.push("Upload the creative.");
  for (const [k, v] of Object.entries({ advertiser: b.advertiser, message: b.message, notes: b.notes, disclaimer: b.disclaimer }))
    if (containsContactDetails(v)) out.push(`Remove the email or phone number from ${k === "notes" ? "the notes" : k}. Talk to the publisher through Nashr messages.`);
  return out;
}
function brandSafetyProblem(b, outlet2) {
  const norm = (x) => x.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
  if (b.industry && (outlet2.blocked_industries ?? []).some((i) => norm(i) === norm(b.industry))) return `This outlet does not accept ${b.industry} advertising.`;
  const adv = norm(b.advertiser ?? "");
  if (adv && (outlet2.blocked_advertisers ?? []).some((n2) => norm(n2) && adv.includes(norm(n2)))) return "This outlet does not run ads for this advertiser.";
  return null;
}

// server/documents/documents.ts
var PREFIX = { order: "ORD", receipt: "RCT", media_invoice: "INV", commission_invoice: "NCI", credit_note: "CN" };
async function nextNumber(db, type, issuerId, at) {
  const year = at.getUTCFullYear();
  const { last } = await one(db, `insert into document_series (series, last) values ($1, 1)
                                  on conflict (series) do update set last = document_series.last + 1 returning last`, [`${type}:${issuerId ?? "nashr"}:${year}`]);
  return `${PREFIX[type]}-${year}-${String(last).padStart(6, "0")}`;
}
async function parties(db, issuerId, recipientId, at) {
  const party = async (id) => one(db, `select id, name, trn, vat_registered, address from companies where id = $1`, [id]);
  const issuer = issuerId ? await party(issuerId) : {
    id: null,
    name: await setting(db, "nashr_legal_name", at),
    trn: await setting(db, "nashr_trn", at),
    vat_registered: await setting(db, "nashr_vat_registered", at),
    address: await setting(db, "nashr_address", at)
  };
  return { issuer, recipient: await party(recipientId) };
}
async function issue(db, d, at) {
  const number = d.number ?? await nextNumber(db, d.type, d.issuerId, at);
  const client = (await db.query(
    `select c.name, c.trn, c.address from deals x join clients c on c.id = x.client_id where x.id = $1 and x.buyer_id = $2`,
    [d.dealId, d.recipientId]
  )).rows[0] ?? null;
  const lines = { ...await parties(db, d.issuerId, d.recipientId, at), items: d.items, note: d.note ?? null, client };
  return one(
    db,
    `insert into documents (type, number, issuer_id, recipient_id, deal_id, related_id, on_behalf, tax_document, currency,
                    subtotal, vat_bp, vat, total, lines, file_key, issued_at)
                  values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16) returning *`,
    [
      d.type,
      number,
      d.issuerId,
      d.recipientId,
      d.dealId,
      d.relatedId ?? null,
      d.onBehalf ?? false,
      d.tax,
      d.currency,
      d.subtotal,
      d.vatBp,
      d.vat,
      d.subtotal + d.vat,
      JSON.stringify(lines),
      d.fileKey ?? null,
      at
    ]
  );
}
var describe = (db, dealId) => one(
  db,
  `select d.*, s.label, s.air_date::text air_date, brand_name(o) outlet, c.invoice_mode from deals d join slots s on s.id = d.slot_id
   join placements p on p.id = s.placement_id join outlets o on o.id = p.outlet_id join companies c on c.id = d.seller_id where d.id = $1`,
  [dealId]
);
async function issueOrder(db, dealId, at) {
  const d = await describe(db, dealId);
  const s = split(d.amount, { commissionBp: 0, mediaVatBp: d.media_vat_bp ?? 0, feeVatBp: 0 });
  return issue(db, {
    type: "order",
    issuerId: null,
    recipientId: d.buyer_id,
    dealId,
    tax: false,
    currency: d.currency,
    subtotal: d.amount,
    vatBp: d.media_vat_bp ?? 0,
    vat: s.mediaVat,
    number: d.ref,
    items: [{ description: `${d.outlet} \xB7 ${d.label} \xB7 ${d.air_date}`, quantity: 1, unitPrice: d.amount }],
    note: "Booking confirmed by the publisher, arranged by Nashr as the publisher's agent. Pay by the deadline to secure the slot. This is not a tax invoice."
  }, at);
}
async function issueReceipt(db, dealId, amount, paymentRef, at) {
  const d = await describe(db, dealId);
  return issue(db, {
    type: "receipt",
    issuerId: null,
    recipientId: d.buyer_id,
    dealId,
    tax: false,
    currency: d.currency,
    subtotal: amount,
    vatBp: 0,
    vat: 0,
    items: [{ description: `Payment for Order ${d.ref}: ${d.outlet} \xB7 ${d.label} \xB7 ${d.air_date}`, amount, paymentRef }],
    note: `Received by Nashr on behalf of ${d.outlet}. This is not a tax invoice.`
  }, at);
}
async function issueMediaInvoice(db, dealId, at, price) {
  const d = await describe(db, dealId);
  if (d.invoice_mode !== "generate") return notify(db, d.seller_id, "invoice.upload_needed", dealId, { order: d.ref }, at);
  const p = price ?? d.amount;
  const s = split(p, { commissionBp: 0, mediaVatBp: d.media_vat_bp, feeVatBp: 0 });
  return issue(db, {
    type: "media_invoice",
    issuerId: d.seller_id,
    recipientId: d.buyer_id,
    dealId,
    onBehalf: true,
    tax: d.media_vat_bp > 0,
    currency: d.currency,
    subtotal: p,
    vatBp: d.media_vat_bp,
    vat: s.mediaVat,
    items: [{ description: `${d.outlet} \xB7 ${d.label} \xB7 ${d.air_date} \xB7 Order ${d.ref}`, quantity: 1, unitPrice: p }],
    note: `Issued by Nashr on behalf of ${d.outlet}.`
  }, at);
}
async function issueCommissionInvoice(db, dealId, fee, feeVat, at) {
  const d = await describe(db, dealId);
  return issue(db, {
    type: "commission_invoice",
    issuerId: null,
    recipientId: d.seller_id,
    dealId,
    tax: d.fee_vat_bp > 0,
    currency: d.currency,
    subtotal: fee,
    vatBp: d.fee_vat_bp,
    vat: feeVat,
    items: [{ description: `Nashr commission (${d.commission_bp / 100}%) on Order ${d.ref}`, amount: fee }],
    note: "Paid by deduction from your payout."
  }, at);
}
async function reissueAfterRefund(db, dealId, keptPrice, at) {
  const d = await describe(db, dealId);
  const open = (await db.query(`select * from documents i where deal_id = $1 and type = 'media_invoice'
      and not exists (select 1 from documents c where c.related_id = i.id) order by issued_at desc limit 1`, [dealId])).rows[0];
  if (!open) return keptPrice > 0 ? issueMediaInvoice(db, dealId, at, keptPrice) : void 0;
  if (open.file_key) return notify(db, d.seller_id, "invoice.credit_note_needed", dealId, { invoice: open.number, keptPrice }, at);
  await issue(db, {
    type: "credit_note",
    issuerId: open.issuer_id,
    recipientId: open.recipient_id,
    dealId,
    relatedId: open.id,
    onBehalf: open.on_behalf,
    tax: open.tax_document,
    currency: open.currency,
    subtotal: open.subtotal,
    vatBp: open.vat_bp,
    vat: open.vat,
    items: [{ description: `Credit for invoice ${open.number}`, amount: open.subtotal }]
  }, at);
  if (keptPrice > 0) await issueMediaInvoice(db, dealId, at, keptPrice);
}

// server/marketplace/market.ts
var MarketError = class extends Error {
};
var aed = (fils) => `AED ${(fils / 100).toLocaleString("en-US", { minimumFractionDigits: fils % 100 ? 2 : 0, maximumFractionDigits: 2 })}`;
var lockSlot = (db, id) => {
  signalSlot(db, id);
  return one(db, `select * from slots where id = $1 for update`, [id]);
};
async function requireBrief(db, slot, buyerId, brief, client) {
  const outlet2 = await one(db, `select o.channel, o.blocked_industries, o.blocked_advertisers from placements p join outlets o on o.id = p.outlet_id where p.id = $1`, [slot.placement_id]);
  const onFile = (await db.query(`select brief from bids where slot_id = $1 and buyer_id = $2 and brief is not null order by created_at desc limit 1`, [slot.id, buyerId])).rows[0]?.brief;
  const used = brief == null && onFile ? onFile : brief;
  const problems = briefProblems(used, outlet2.channel);
  if (problems.length) throw new MarketError(problems.join(" "));
  await ownFile(db, used.draftFileKey, buyerId);
  const unsafe = brandSafetyProblem(brief ?? onFile, outlet2) ?? (client ? brandSafetyProblem({ industry: client.industry ?? void 0, advertiser: client.name }, outlet2) : null);
  if (unsafe) throw new MarketError(unsafe);
}
async function ownFile(db, key, buyerId) {
  const id = typeof key === "string" && key.startsWith("files/") ? key.slice(6) : "";
  if (!/^[0-9a-f-]{36}$/i.test(id) || !(await db.query(`select 1 from files where id = $1 and company_id = $2`, [id, buyerId])).rows.length)
    throw new MarketError("Upload the creative again: that file was not found.");
}
async function assertMarketOpen(db, slot, at) {
  const { market } = await one(db, `select o.market from placements p join outlets o on o.id = p.outlet_id where p.id = $1`, [slot.placement_id]);
  if (!(await setting(db, "open_markets", at)).includes(market)) throw new MarketError("This market is coming soon. Join the waiting list to hear when it opens.");
}
async function tagFor(db, a, buyerId, amount) {
  let clientId = a.clientId ?? null, brief = void 0;
  if (a.campaignId) {
    const c = (await db.query(`select client_id, brief from campaigns where id = $1 and buyer_id = $2 and status = 'active'`, [a.campaignId, buyerId])).rows[0];
    if (!c) throw new MarketError("Choose one of your active campaigns.");
    if (c.client_id && clientId && c.client_id !== clientId) throw new MarketError("This campaign is for another client.");
    clientId = c.client_id ?? clientId;
    brief = c.brief ?? void 0;
  }
  if (!clientId) return { campaignId: a.campaignId ?? null, clientId: null, client: null, brief };
  const client = (await db.query(`select * from clients where id = $1 and buyer_id = $2 and status = 'active' for update`, [clientId, buyerId])).rows[0];
  if (!client) throw new MarketError("Choose one of your active clients.");
  return { campaignId: a.campaignId ?? null, clientId, client, brief };
}
async function insertBid(db, slot, b, at) {
  const { bid_seq } = await one(db, `update slots set bid_seq = bid_seq + 1 where id = $1 returning bid_seq`, [slot.id]);
  return one(
    db,
    `insert into bids (slot_id, buyer_id, kind, amount, max_amount, seq, status, brief, created_at, campaign_id, client_id) values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) returning *`,
    [slot.id, b.buyerId, b.kind, b.amount, b.max ?? null, bid_seq, b.status ?? "active", b.brief == null ? null : JSON.stringify(b.brief), at, b.campaignId ?? null, b.clientId ?? null]
  );
}
var reserveFloor = (slot, price, max) => {
  const reserve = slot.reserve_price == null ? null : Number(slot.reserve_price);
  return reserve != null && price < reserve && max >= reserve ? reserve : price;
};
async function placeBid(db, a, at) {
  const slot = await lockSlot(db, a.slotId);
  if (slot.status !== "open" || slot.sale_type !== "auction" || at >= slot.closes_at) throw new MarketError("Bidding is closed for this slot.");
  await assertMarketOpen(db, slot, at);
  const tag = await tagFor(db, a, a.buyerId, Math.max(a.maxAmount ?? a.amount, a.amount));
  await requireBrief(db, slot, a.buyerId, a.brief ?? tag.brief, tag.client);
  const step = await setting(db, "min_step_bp", at);
  const max = Math.max(a.maxAmount ?? a.amount, a.amount);
  let top;
  if (slot.top_buyer_id === a.buyerId) {
    if (a.amount <= slot.top_amount && max <= slot.top_max) throw new MarketError("You are already the top bidder at this amount.");
    if (a.amount > slot.top_amount && a.amount < minNextBid(slot.top_amount, step))
      throw new MarketError(`Your bid must be at least ${aed(minNextBid(slot.top_amount, step))}.`);
    const amount = Math.max(a.amount, slot.top_amount);
    const bid = await insertBid(db, slot, { buyerId: a.buyerId, kind: "bid", amount, max: Math.max(max, slot.top_max), brief: a.brief ?? tag.brief, campaignId: tag.campaignId, clientId: tag.clientId }, at);
    top = { bidId: bid.id, amount, buyerId: a.buyerId, max: Math.max(max, slot.top_max) };
  } else if (a.amount < (slot.top_amount ? minNextBid(slot.top_amount, step) : slot.starting_price)) {
    throw new MarketError(`Your bid must be at least ${aed(slot.top_amount ? minNextBid(slot.top_amount, step) : slot.starting_price)}.`);
  } else if (!slot.top_amount) {
    const bid = await insertBid(db, slot, { buyerId: a.buyerId, kind: "bid", amount: a.amount, max, brief: a.brief ?? tag.brief, campaignId: tag.campaignId, clientId: tag.clientId }, at);
    top = { bidId: bid.id, amount: a.amount, buyerId: a.buyerId, max };
  } else if (max > slot.top_max) {
    const price = reserveFloor(slot, Math.max(a.amount, Math.min(max, minNextBid(slot.top_max, step))), max);
    await db.query(`update bids set status = 'outbid' where slot_id = $1 and buyer_id = $2 and status = 'active'`, [slot.id, slot.top_buyer_id]);
    const { outlet: outlet2 } = await one(db, `select brand_name(o) outlet from placements p join outlets o on o.id = p.outlet_id where p.id = $1`, [slot.placement_id]);
    const autoBidder = slot.top_max > slot.top_amount;
    await notify(db, slot.top_buyer_id, "bid.outbid", null, { slotId: slot.id, outlet: outlet2, label: slot.label, ...autoBidder ? { max: slot.top_max } : {}, top: price }, at);
    const bid = await insertBid(db, slot, { buyerId: a.buyerId, kind: "bid", amount: price, max, brief: a.brief ?? tag.brief, campaignId: tag.campaignId, clientId: tag.clientId }, at);
    top = { bidId: bid.id, amount: price, buyerId: a.buyerId, max };
  } else {
    await insertBid(db, slot, { buyerId: a.buyerId, kind: "bid", amount: a.amount, max, status: "outbid", brief: a.brief ?? tag.brief, campaignId: tag.campaignId, clientId: tag.clientId }, at);
    const price = reserveFloor(slot, Math.min(slot.top_max, Math.max(slot.top_amount, minNextBid(max, step))), slot.top_max);
    const bid = price > slot.top_amount ? await insertBid(db, slot, { buyerId: slot.top_buyer_id, kind: "auto", amount: price, max: slot.top_max }, at) : { id: slot.top_bid_id };
    top = { bidId: bid.id, amount: price, buyerId: slot.top_buyer_id, max: slot.top_max };
    if (price > slot.top_amount) {
      const { outlet: outlet2 } = await one(db, `select brand_name(o) outlet from placements p join outlets o on o.id = p.outlet_id where p.id = $1`, [slot.placement_id]);
      await notify(
        db,
        slot.top_buyer_id,
        price >= slot.top_max ? "bid.auto_cap" : "bid.auto_raised",
        null,
        { slotId: slot.id, outlet: outlet2, label: slot.label, amount: price, max: slot.top_max },
        at
      );
    }
  }
  const floored = reserveFloor(slot, top.amount, top.max);
  if (floored > top.amount) top = { ...top, amount: floored, bidId: (await insertBid(db, slot, { buyerId: top.buyerId, kind: "auto", amount: floored, max: top.max }, at)).id };
  await db.query(
    `update slots set top_bid_id = $2, top_amount = $3, top_buyer_id = $4, top_max = $5 where id = $1`,
    [slot.id, top.bidId, top.amount, top.buyerId, top.max]
  );
  const leading = top.buyerId === a.buyerId;
  return {
    leading,
    topAmount: top.amount,
    yourMax: leading ? top.max : max,
    minNextBid: minNextBid(top.amount, step),
    // the bid went in but another buyer's auto-bid answered at once: the screen says so instead of "your bid is in"
    beatenByAutoBid: !leading
  };
}
async function requestBuyNow(db, a, at) {
  const slot = await lockSlot(db, a.slotId);
  if (slot.status !== "open" || !slot.buy_now_price || at >= slot.closes_at) throw new MarketError("Buy now is not available for this slot.");
  const open = await db.query(`select 1 from deals where slot_id = $1 and buyer_id = $2 and kind = 'buy_now' and status = 'awaiting_seller'`, [slot.id, a.buyerId]);
  if (open.rowCount) throw new MarketError("You already have a buy-now request on this slot.");
  await assertMarketOpen(db, slot, at);
  const tag = await tagFor(db, a, a.buyerId, Number(slot.buy_now_price));
  await requireBrief(db, slot, a.buyerId, a.brief ?? tag.brief, tag.client);
  const bid = await insertBid(db, slot, { buyerId: a.buyerId, kind: "buy_now", amount: slot.buy_now_price, brief: a.brief ?? tag.brief, campaignId: tag.campaignId, clientId: tag.clientId }, at);
  return openDeal(db, slot, bid, "buy_now", `buyer:${a.buyerId}`, at);
}
async function showInterest(db, a, at) {
  const slot = await lockSlot(db, a.slotId);
  if (slot.status !== "open" || slot.sale_type !== "quick_sale") throw new MarketError("This slot is not a quick sale.");
  await assertMarketOpen(db, slot, at);
  const amount = a.amount ?? slot.starting_price;
  if (amount < slot.starting_price) throw new MarketError(`Offers cannot be below ${aed(slot.starting_price)}.`);
  const tag = await tagFor(db, a, a.buyerId, Number(amount));
  await requireBrief(db, slot, a.buyerId, a.brief ?? tag.brief, tag.client);
  await db.query(`update bids set status = 'withdrawn' where slot_id = $1 and buyer_id = $2 and kind = 'interest' and status = 'active'`, [slot.id, a.buyerId]);
  const bid = await insertBid(db, slot, { buyerId: a.buyerId, kind: "interest", amount, brief: a.brief ?? tag.brief, campaignId: tag.campaignId, clientId: tag.clientId }, at);
  const { outlet: outlet2, seller } = await one(db, `select brand_name(o) outlet, o.company_id seller from placements p join outlets o on o.id = p.outlet_id where p.id = $1`, [slot.placement_id]);
  await notify(db, seller, "interest.received", null, { slotId: slot.id, outlet: outlet2, label: slot.label, amount }, at);
  return bid;
}
async function expireInterests(db, slotId, at) {
  const slot = await lockSlot(db, slotId);
  const gone = (await db.query(`update bids set status = 'not_selected' where slot_id = $1 and kind = 'interest' and status = 'active' returning buyer_id`, [slot.id])).rows;
  const { outlet: outlet2 } = await one(db, `select brand_name(o) outlet from placements p join outlets o on o.id = p.outlet_id where p.id = $1`, [slot.placement_id]);
  for (const b of gone) await notify(db, b.buyer_id, "interest.expired", null, { slotId: slot.id, outlet: outlet2, label: slot.label }, at);
  return gone.length;
}
async function acceptInterest(db, bidId, actor, at) {
  const { slot_id } = await one(db, `select slot_id from bids where id = $1`, [bidId]);
  const slot = await lockSlot(db, slot_id);
  const bid = await one(db, `select * from bids where id = $1 for update`, [bidId]);
  if (slot.status !== "open" || bid.kind !== "interest" || bid.status !== "active" || at >= slot.closes_at) throw new MarketError("This interest can no longer be accepted.");
  const deal = await openDeal(db, slot, bid, "quick_sale", actor, at);
  return accept(db, deal.id, actor, at);
}
async function closeAuction(db, slotId, at) {
  const slot = await lockSlot(db, slotId);
  if (slot.status !== "open" || slot.sale_type !== "auction" || at < slot.closes_at) return null;
  if (!slot.top_bid_id) {
    await db.query(`update slots set status = 'unsold' where id = $1`, [slot.id]);
    return null;
  }
  await db.query(`update slots set status = 'awaiting_seller', round = 1 where id = $1`, [slot.id]);
  const bid = await one(db, `select * from bids where id = $1`, [slot.top_bid_id]);
  const deal = await openDeal(db, slot, bid, "auction", "system", at);
  const { outlet: outlet2 } = await one(db, `select brand_name(o) outlet from placements p join outlets o on o.id = p.outlet_id where p.id = $1`, [slot.placement_id]);
  await notify(db, bid.buyer_id, "bid.won", deal.id, { slotId: slot.id, outlet: outlet2, label: slot.label, amount: bid.amount }, at);
  for (const b of (await db.query(`select distinct buyer_id from bids where slot_id = $1 and buyer_id <> $2 and status <> 'withdrawn'`, [slot.id, bid.buyer_id])).rows)
    await notify(db, b.buyer_id, "bid.closed_lost", null, { slotId: slot.id, outlet: outlet2, label: slot.label, amount: bid.amount }, at);
  if (slot.auto_accept && slot.reserve_price && bid.amount >= slot.reserve_price) return accept(db, deal.id, "system:auto-accept", at);
  return deal;
}
async function refreshConflicts(db, slot, at) {
  const group = [slot.placement_id, slot.air_date];
  for (const h of (await db.query(`select id from slots where placement_id = $1 and air_date = $2 and status = 'held'`, group)).rows) await reopen(db, h.id, at);
  const booked2 = (await db.query(`select kind from slots where placement_id = $1 and air_date = $2 and status = 'booked'`, group)).rows.map((r) => r.kind);
  const hold = /* @__PURE__ */ new Set();
  if (booked2.includes("package")) ["single", "any"].forEach((k) => hold.add(k));
  if (booked2.includes("single") || booked2.includes("any")) hold.add("package");
  const held = hold.size ? (await db.query(`update slots set status = 'held' where placement_id = $1 and air_date = $2 and status = 'open' and kind = any($3) returning id`, [...group, [...hold]])).rows : [];
  held.push(...(await db.query(`update slots set status = 'held' where placement_id = $1 and air_date = $2 and kind = 'any' and status = 'open'
                  and not exists (select 1 from slots s where s.placement_id = $1 and s.air_date = $2 and s.kind = 'single' and s.status = 'open') returning id`, group)).rows);
  for (const h of held) {
    for (const d of (await db.query(`select id, bid_id from deals where slot_id = $1 and status = 'awaiting_seller'`, [h.id])).rows) {
      await transition(db, d.id, "supersede", "system", at, "An overlapping booking was accepted");
      await db.query(`update bids set status = 'not_selected' where id = $1`, [d.bid_id]);
    }
    await releaseBids(db, h.id, at);
    await db.query(`update slots set top_bid_id = null, top_amount = null, top_buyer_id = null, top_max = null where id = $1`, [h.id]);
  }
}
async function releaseBids(db, slotId, at, except) {
  await db.query(`update bids set status = 'not_selected' where slot_id = $1 and buyer_id = $2 and status in ('active', 'outbid')`, [slotId, except ?? null]);
  const gone = (await db.query(`update bids set status = 'not_selected' where slot_id = $1 and status in ('active', 'outbid') returning buyer_id`, [slotId])).rows;
  const buyers = [...new Set(gone.map((b) => b.buyer_id))];
  if (!buyers.length) return;
  const s = await one(db, `select s.label, brand_name(o) outlet from slots s join placements p on p.id = s.placement_id join outlets o on o.id = p.outlet_id where s.id = $1`, [slotId]);
  for (const b of buyers) await notify(db, b, "bid.not_selected", null, { slotId, outlet: s.outlet, label: s.label }, at);
}
async function reopen(db, slotId, at) {
  const s = await one(db, `select * from slots where id = $1`, [slotId]);
  const latest2 = new Date(new Date(s.creative_due_at).getTime() - RELIST_PAY_HOURS * 36e5);
  if (new Date(s.closes_at) > at) return db.query(`update slots set status = 'open' where id = $1`, [slotId]);
  if (latest2 <= at) return db.query(`update slots set status = 'unsold' where id = $1`, [slotId]);
  await db.query(`update slots set status = 'open', sale_type = case when sale_type = 'auction' then 'quick_sale' else sale_type end, closes_at = $2 where id = $1`, [slotId, latest2]);
}
async function accept(db, dealId, actor, at) {
  const pre = await one(db, `select * from deals where id = $1`, [dealId]);
  const slot = await lockSlot(db, pre.slot_id);
  if (!["open", "awaiting_seller"].includes(slot.status)) throw new MarketError("This slot is no longer available.");
  if (pre.status === "awaiting_seller" && pre.next_deadline_at && new Date(pre.next_deadline_at) <= at) throw new MarketError("This request has expired.");
  const rates = await ratesFor(db, pre.seller_id, at);
  await db.query(
    `update deals set commission_bp = $2, media_vat_bp = $3, fee_vat_bp = $4 where id = $1`,
    [dealId, rates.commissionBp, rates.mediaVatBp, rates.feeVatBp]
  );
  const deal = await transition(db, dealId, "accept", actor, at);
  await db.query(`update slots set status = 'booked' where id = $1`, [slot.id]);
  await db.query(`update bids set status = 'selected' where id = $1`, [deal.bid_id]);
  if (deal.kind === "buy_now" || deal.kind === "quick_sale") {
    const others = (await db.query(`update bids set status = 'not_selected' where slot_id = $1 and status in ('active', 'outbid') returning buyer_id, kind`, [slot.id])).rows;
    const { outlet: outlet2 } = await one(db, `select brand_name(o) outlet from placements p join outlets o on o.id = p.outlet_id where p.id = $1`, [slot.placement_id]);
    for (const b of others.filter((b2) => b2.kind === "interest" && b2.buyer_id !== deal.buyer_id))
      await notify(db, b.buyer_id, "interest.not_selected", null, { slotId: slot.id, outlet: outlet2, label: slot.label }, at);
  }
  for (const other of (await db.query(`select id, bid_id from deals where slot_id = $1 and id <> $2 and status = 'awaiting_seller'`, [slot.id, dealId])).rows) {
    await transition(db, other.id, "supersede", "system", at, "Another request was accepted");
    await db.query(`update bids set status = 'not_selected' where id = $1`, [other.bid_id]);
  }
  await refreshConflicts(db, slot, at);
  await issueOrder(db, dealId, at);
  return deal;
}
async function decline(db, dealId, reason, actor, at) {
  if (!reason?.trim()) throw new MarketError("A reason is required to decline.");
  const deal = await transition(db, dealId, "decline", actor, at, reason);
  await afterNoGo(db, deal, at);
  return deal;
}
async function afterNoGo(db, deal, at) {
  const slot = await lockSlot(db, deal.slot_id);
  await db.query(`update bids set status = 'not_selected' where id = $1`, [deal.bid_id]);
  if (deal.kind === "buy_now" && (deal.status === "declined" || slot.status === "open")) return;
  await db.query(`update bids set status = 'not_selected' where slot_id = $1 and buyer_id = $2 and status in ('active', 'outbid')`, [slot.id, deal.buyer_id]);
  await db.query(`update slots set status = 'awaiting_seller' where id = $1`, [slot.id]);
  await refreshConflicts(db, slot, at);
  if (deal.kind === "buy_now" || deal.kind === "quick_sale" || deal.kind === "fixed") return relist(db, slot.id, at);
  const remaining = await db.query(`select 1 from bids where slot_id = $1 and status in ('active', 'outbid') and buyer_id <> $2 limit 1`, [slot.id, deal.buyer_id]);
  const window = await setting(db, "seller_window_hours", at);
  const tooLate = at.getTime() + (window + MIN_PAY_HOURS) * 36e5 > new Date(slot.creative_due_at).getTime();
  if (slot.round > await setting(db, "max_choice_rounds", at) || !remaining.rowCount || tooLate) return relist(db, slot.id, at);
  await db.query(`update slots set status = 'awaiting_choice', choice_deadline_at = $2 where id = $1`, [slot.id, new Date(at.getTime() + window * 36e5)]);
}
async function relist(db, slotId, at) {
  await releaseBids(db, slotId, at);
  await db.query(`update slots set sale_type = case when sale_type = 'auction' then 'quick_sale' else sale_type end, choice_deadline_at = null,
                  top_bid_id = null, top_amount = null, top_buyer_id = null, top_max = null where id = $1`, [slotId]);
  await reopen(db, slotId, at);
  await audit(db, "system", "slot.relisted", "slot", slotId, null, at);
}
var MIN_PAY_HOURS = 4;
var RELIST_PAY_HOURS = 12;

// server/catalog/placements.ts
var noContacts = (p) => {
  if (containsContactDetails([p.name, p.description, p.specs, ...(p.breaks ?? []).map((b) => b.label)].filter(Boolean).join(" \n ")))
    throw new MarketError("Emails and phone numbers are not allowed in what buyers see.");
};
async function checkDeadlines(db, p, at) {
  const need = p.creativeLeadHours + await setting(db, "seller_window_hours", at) + await setting(db, "payment_window_hours", at);
  if (p.closeLeadHours < need)
    throw new MarketError(`Bidding must close at least ${need / 24} days before air so there is time to accept, pay and deliver the creative.`);
}
var mins = (t) => {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
};
function checkTimes(p) {
  if (!p.startsAt || !p.endsAt) return;
  const s = mins(p.startsAt), e = mins(p.endsAt);
  if (e === s || e < s && !(s >= 18 * 60 && e <= 6 * 60)) throw new MarketError("The end time must be after the start time.");
}
async function createPlacement(db, p, actor, at) {
  checkTimes(p);
  await checkDeadlines(db, p, at);
  if (p.reservePrice && p.buyNowPrice && p.reservePrice > p.buyNowPrice) throw new MarketError("The reserve cannot be above the buy-now price.");
  if (p.buyNowPrice && p.buyNowPrice <= p.startingPrice) throw new MarketError("The buy-now price must be above the starting price.");
  if (p.autoAccept && p.saleType === "auction" && !p.reservePrice) throw new MarketError("Set a reserve price to accept bids automatically.");
  if (p.saleType !== "auction" && (p.buyNowPrice || p.reservePrice)) throw new MarketError("Buy-now and reserve prices are for auctions only.");
  if (p.unit === "week" && (p.breaks?.length || p.days.length !== 1)) throw new MarketError("A week-long placement starts on one day and has no breaks.");
  noContacts(p);
  const row = await one(
    db,
    `insert into placements (outlet_id, name, sale_type, days, starts_at_local, ends_at_local, breaks, starting_price, any_break_price,
       package_price, buy_now_price, reserve_price, auto_accept, creative_lead_hours, close_lead_hours, currency,
       format, description, specs, language, unit, listing, horizon_weeks, separation, audiences)
     select $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, case o.market when 'SA' then 'SAR' else 'AED' end,
       $16, $17, $18, $19, $20, $21, $22, $23, $24
     from outlets o where o.id = $1 returning id`,
    [
      p.outletId,
      p.name,
      p.saleType,
      p.days,
      p.startsAt ?? null,
      p.endsAt ?? null,
      JSON.stringify(p.breaks ?? []),
      p.startingPrice,
      p.anyBreakPrice ?? null,
      p.packagePrice ?? null,
      p.buyNowPrice ?? null,
      p.reservePrice ?? null,
      p.autoAccept ?? false,
      p.creativeLeadHours,
      p.closeLeadHours,
      p.format ?? null,
      p.description?.trim() || null,
      p.specs?.trim() || null,
      p.language ?? null,
      p.unit ?? "day",
      p.listing ?? "manual",
      p.horizonWeeks ?? 8,
      p.separation ?? false,
      p.audiences ?? []
    ]
  );
  await audit(db, actor, "placement.created", "placement", row.id, { name: p.name }, at);
  return row.id;
}
var addDays = (date, n2) => new Date(Date.parse(date + "T00:00:00Z") + n2 * 864e5).toISOString().slice(0, 10);
var isoWeekday = (date) => (/* @__PURE__ */ new Date(date + "T12:00:00Z")).getUTCDay() || 7;
var hours2 = (t, h) => new Date(t.getTime() - h * 36e5);
async function generateSlots(db, placementId, fromDate, days, at) {
  const p = await one(db, `select p.*, o.market, c.payouts_enabled from placements p join outlets o on o.id = p.outlet_id
                           join companies c on c.id = o.company_id where p.id = $1`, [placementId]);
  if (!p.payouts_enabled) throw new MarketError("Slots can go live once your payout account is verified.");
  const m = p.market;
  const breaks = p.breaks;
  let made = 0;
  for (let i = 0; i < days; i++) {
    const date = addDays(fromDate, i);
    if (!p.days.includes(isoWeekday(date))) continue;
    const start = atLocal(date, p.starts_at_local?.slice(0, 5) ?? "00:00", m);
    if (p.unit === "week") {
      const closes = hours2(start, p.close_lead_hours);
      if (closes <= at) continue;
      const r = await db.query(
        `insert into slots (placement_id, air_date, kind, label, starts_at, ends_at, sale_type, starting_price, buy_now_price, reserve_price,
           auto_accept, currency, closes_at, creative_due_at, listed_at)
         select $1, $2::date, 'single', $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14
         where not exists (select 1 from slots x where x.placement_id = $1 and x.air_date = $2::date and x.kind = 'single') on conflict do nothing`,
        [
          p.id,
          date,
          "Full week",
          start,
          atLocal(addDays(date, 7), p.starts_at_local?.slice(0, 5) ?? "00:00", m),
          p.sale_type,
          p.starting_price,
          p.buy_now_price,
          p.reserve_price,
          p.auto_accept,
          p.currency,
          closes,
          hours2(start, p.creative_lead_hours),
          at
        ]
      );
      made += r.rowCount ?? 0;
      continue;
    }
    const later2 = (t) => t < (p.starts_at_local?.slice(0, 5) ?? "00:00") ? atLocal(addDays(date, 1), t, m) : atLocal(date, t, m);
    const end = p.ends_at_local ? later2(p.ends_at_local.slice(0, 5)) : null;
    const slots2 = breaks.length === 0 ? [{ kind: "single", label: p.name, startsAt: start, endsAt: end, price: p.starting_price }] : breaks.map((b) => {
      const s = b.at ? later2(b.at) : start;
      return { kind: "single", label: b.label, startsAt: s, endsAt: b.seconds ? new Date(s.getTime() + b.seconds * 1e3) : null, price: p.starting_price };
    });
    if (breaks.length && p.any_break_price) slots2.push({ kind: "any", label: "Any break", startsAt: start, endsAt: end, price: p.any_break_price });
    if (breaks.length && p.package_price) slots2.push({ kind: "package", label: `All ${breaks.length} breaks`, startsAt: start, endsAt: end, price: p.package_price });
    for (const s of slots2) {
      const closes = hours2(s.startsAt, p.close_lead_hours);
      if (closes <= at) continue;
      const r = await db.query(
        `insert into slots (placement_id, air_date, kind, label, starts_at, ends_at, sale_type, starting_price, buy_now_price, reserve_price,
           auto_accept, currency, closes_at, creative_due_at, listed_at)
         select $1, $2::date, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15
         where not ($3 = 'single' and $16::boolean and exists (select 1 from slots x where x.placement_id = $1 and x.air_date = $2::date and x.kind = 'single'))
         on conflict do nothing`,
        [
          p.id,
          date,
          s.kind,
          s.label,
          s.startsAt,
          s.endsAt,
          p.sale_type,
          s.price,
          s.kind === "single" ? p.buy_now_price : null,
          s.kind === "single" ? p.reserve_price : null,
          p.auto_accept,
          p.currency,
          closes,
          hours2(s.startsAt, p.creative_lead_hours),
          at,
          breaks.length === 0
        ]
      );
      made += r.rowCount ?? 0;
    }
  }
  await db.query(`update placements set listed_through = greatest(coalesce(listed_through, $2::date), $2::date) where id = $1`, [p.id, addDays(fromDate, days - 1)]);
  return made;
}
async function topUpRolling(db, at, batch = 20) {
  const due = (await db.query(`select p.id, p.horizon_weeks, p.listed_through::text listed_through, o.market from placements p join outlets o on o.id = p.outlet_id
      join companies c on c.id = o.company_id
      where p.listing = 'rolling' and not p.archived and c.payouts_enabled
        and (p.listed_through is null or p.listed_through < ((($1::timestamptz) at time zone case o.market when 'SA' then 'Asia/Riyadh' else 'Asia/Dubai' end)::date + p.horizon_weeks * 7 - 1))
      order by p.listed_through nulls first limit $2 for update of p skip locked`, [at, batch])).rows;
  let made = 0;
  for (const p of due) {
    const today2 = new Intl.DateTimeFormat("en-CA", { timeZone: p.market === "SA" ? "Asia/Riyadh" : "Asia/Dubai" }).format(at);
    const from2 = p.listed_through && p.listed_through >= today2 ? addDays(p.listed_through, 1) : today2;
    const until = addDays(today2, p.horizon_weeks * 7 - 1);
    const days = Math.round((Date.parse(until) - Date.parse(from2)) / 864e5) + 1;
    if (days > 0) made += await generateSlots(db, p.id, from2, days, at);
  }
  return made;
}

// server/payments/ledger.ts
async function post(db, entries, currency, at) {
  for (const e of entries.filter((e2) => e2.amount > 0))
    await db.query(
      `insert into ledger_entries (at, deal_id, debit, credit, amount, currency, ref) values ($1, $2, $3, $4, $5, $6, $7)`,
      [at, e.dealId ?? null, e.debit, e.credit, e.amount, currency, e.ref ?? null]
    );
}
async function balance(db, account, currency, dealId) {
  const { rows } = await db.query(
    `select (coalesce(sum(case when debit = $1 then amount else 0 end), 0) - coalesce(sum(case when credit = $1 then amount else 0 end), 0))::bigint as b
     from ledger_entries where (debit = $1 or credit = $1) and currency = $2 and ($3::uuid is null or deal_id = $3)`,
    [account, currency, dealId ?? null]
  );
  return rows[0].b;
}
var heldFor = async (db, dealId, currency) => 0 - await balance(db, "held", currency, dealId);

// server/payments/payments.ts
var ratesOf = (d) => ({ commissionBp: d.commission_bp, mediaVatBp: d.media_vat_bp, feeVatBp: d.fee_vat_bp });
var lockDeal = (db, id) => one(db, `select * from deals where id = $1 for update`, [id]);
async function processingCost(db, amount, at) {
  return pct(amount, await setting(db, "processing_fee_bp", at)) + await setting(db, "processing_fee_fixed", at);
}
async function newOp(db, o, at) {
  return one(db, `insert into money_ops (deal_id, company_id, kind, amount, currency, idempotency_key, created_at, updated_at)
                  values ($1, $2, $3, $4, $5, $6, $7, $7) returning *`, [o.dealId, o.companyId ?? null, o.kind, o.amount, o.currency, o.key, at]);
}
async function confirmPayment(provider, a, at) {
  const op = await tx(async (c) => {
    const deal = await lockDeal(c, a.dealId);
    if (deal.buyer_id !== a.buyerId) throw new MarketError("This booking is not yours.");
    if (deal.status !== "awaiting_payment") throw new MarketError("This booking is not waiting for payment.");
    const unknown = (await c.query(`select * from money_ops where deal_id = $1 and kind = 'charge' and status in ('pending', 'requires_action')`, [deal.id])).rows[0];
    if (unknown?.status === "requires_action") throw new MarketError("Your bank is still waiting for you to confirm the last payment.");
    if (unknown) return unknown;
    const { n: n2 } = await one(c, `select count(*)::int n from money_ops where deal_id = $1 and kind = 'charge'`, [deal.id]);
    return newOp(c, { dealId: deal.id, kind: "charge", amount: split(deal.amount, ratesOf(deal)).buyerPays, currency: deal.currency, key: `charge:${deal.id}:${n2 + 1}` }, at);
  });
  const res = await provider.charge({ amount: op.amount, currency: op.currency, paymentMethod: a.paymentMethod, idempotencyKey: op.idempotency_key });
  const out = await tx((c) => recordCharge(c, op.id, res, at));
  if (out.status === "succeeded") await recordFee(provider, op.id, at);
  return res.status === "requires_action" ? { ...out, clientSecret: res.clientSecret } : out;
}
async function recordFee(provider, opId, at) {
  if (!provider.chargeFee) return;
  const op = await one(pool, `select * from money_ops where id = $1`, [opId]);
  if (op.status !== "succeeded" || !op.provider_id) return;
  const fee = await provider.chargeFee(op.provider_id);
  await tx(async (c) => {
    const done = await c.query(`select 1 from ledger_entries where debit = 'processing_fees' and ref = $1`, [`fee ${op.ref}`]);
    if (!done.rowCount) await post(c, [{ debit: "processing_fees", credit: "cash", amount: fee, dealId: op.deal_id, ref: `fee ${op.ref}` }], op.currency, at);
  });
}
async function recordCharge(db, opId, res, at) {
  const op = await one(db, `select * from money_ops where id = $1 for update`, [opId]);
  if (op.status === "succeeded") return { status: "succeeded", ref: op.ref };
  await db.query(
    `update money_ops set status = $2, provider_id = $3, failure = $4, updated_at = $5 where id = $1`,
    [op.id, res.status, res.id, res.failure ?? null, at]
  );
  if (res.status === "failed") await audit(db, "system", "payment.failed", "deal", op.deal_id, { ref: op.ref, failure: res.failure }, at);
  if (res.status === "succeeded") await secure(db, op, at);
  return { status: res.status, ref: op.ref, failure: res.failure };
}
async function secure(db, op, at) {
  const deal = await lockDeal(db, op.deal_id);
  await post(db, [{ debit: "cash", credit: "held", amount: op.amount, dealId: deal.id, ref: op.ref }], op.currency, at);
  if (deal.status !== "awaiting_payment") {
    await newOp(db, { dealId: deal.id, kind: "refund", amount: op.amount, currency: op.currency, key: `refund:${deal.id}:late` }, at);
    return audit(db, "system", "payment.late_refunded", "deal", deal.id, { ref: op.ref }, at);
  }
  await transition(db, deal.id, "pay", `buyer:${deal.buyer_id}`, at, op.ref);
  await issueReceipt(db, deal.id, op.amount, op.ref, at);
  if (await setting(db, "media_invoice_timing", at) === "payment") await issueMediaInvoice(db, deal.id, at);
  await releaseBids(db, deal.slot_id, at, deal.buyer_id);
}
async function settle(db, deal, kept, at) {
  if (kept <= 0) return;
  const rates = ratesOf(deal);
  const price = Math.round(kept * 1e4 / (1e4 + rates.mediaVatBp));
  const s = split(price, rates);
  const payout = kept - s.fee - s.feeVat;
  const seller = `seller_payable:${deal.seller_id}`;
  await post(db, [
    { debit: "held", credit: seller, amount: payout, dealId: deal.id },
    { debit: "held", credit: "nashr_revenue", amount: s.fee, dealId: deal.id },
    { debit: "held", credit: "vat_payable", amount: s.feeVat, dealId: deal.id }
  ], deal.currency, at);
  const owed = await balance(db, `seller_receivable:${deal.seller_id}`, deal.currency);
  const deduct = Math.min(Math.max(owed, 0), payout);
  await post(db, [{ debit: seller, credit: `seller_receivable:${deal.seller_id}`, amount: deduct, dealId: deal.id, ref: "deducted from payout" }], deal.currency, at);
  if (s.fee > 0) await issueCommissionInvoice(db, deal.id, s.fee, s.feeVat, at);
  if (payout - deduct > 0)
    await newOp(db, { dealId: deal.id, companyId: deal.seller_id, kind: "transfer", amount: payout - deduct, currency: deal.currency, key: `transfer:${deal.id}` }, at);
}
async function refund(db, deal, amount, cost, at) {
  const held = await heldFor(db, deal.id, deal.currency);
  const fee = cost === "nashr" ? 0 : await processingCost(db, held, at);
  const toBuyer = cost === "buyer" ? Math.max(amount - fee, 0) : amount;
  if (cost === "buyer") await post(db, [{ debit: "held", credit: "refund_costs", amount: amount - toBuyer, dealId: deal.id, ref: "card cost kept from refund" }], deal.currency, at);
  if (cost === "seller") await post(db, [{ debit: `seller_receivable:${deal.seller_id}`, credit: "refund_costs", amount: fee, dealId: deal.id, ref: "card cost recoverable from seller" }], deal.currency, at);
  if (toBuyer > 0) await newOp(db, { dealId: deal.id, kind: "refund", amount: toBuyer, currency: deal.currency, key: `refund:${deal.id}:${at.getTime()}` }, at);
  await reissueAfterRefund(db, deal.id, Math.round((held - amount) * 1e4 / (1e4 + deal.media_vat_bp)), at);
  await settle(db, deal, held - amount, at);
  await audit(db, "system", "refund.initiated", "deal", deal.id, { toBuyer, cost }, at);
}
async function approve(db, dealId, actor, at) {
  const deal = await transition(db, dealId, "approve", actor, at);
  await settle(db, deal, await heldFor(db, deal.id, deal.currency), at);
  return deal;
}
async function onTimerEvent(db, deal, event, at) {
  if (event === "auto_release") await settle(db, deal, await heldFor(db, deal.id, deal.currency), at);
  if (event === "proof_missed") await refund(db, deal, await heldFor(db, deal.id, deal.currency), "seller", at);
}
async function runMoneyOps(provider, at) {
  const { rows } = await pool.query(`select o.*, c.provider_account,
      (select provider_id from money_ops ch where ch.deal_id = o.deal_id and ch.kind = 'charge' and ch.status = 'succeeded' limit 1) as charge_id
    from money_ops o left join companies c on c.id = o.company_id where o.status = 'pending' and o.kind <> 'charge' order by o.created_at`);
  for (const op of rows) {
    const res = op.kind === "refund" ? await provider.refund({ chargeId: op.charge_id, amount: op.amount, idempotencyKey: op.idempotency_key }) : await provider.transfer({ amount: op.amount, currency: op.currency, destination: op.provider_account, idempotencyKey: op.idempotency_key });
    await tx(async (c) => {
      const cur = await one(c, `select status from money_ops where id = $1 for update`, [op.id]);
      if (cur.status !== "pending") return;
      await c.query(`update money_ops set status = 'succeeded', provider_id = $2, updated_at = $3 where id = $1`, [op.id, res.id, at]);
      await post(c, [op.kind === "refund" ? { debit: "held", credit: "cash", amount: op.amount, dealId: op.deal_id, ref: op.ref } : { debit: `seller_payable:${op.company_id}`, credit: "cash", amount: op.amount, dealId: op.deal_id, ref: op.ref }], op.currency, at);
    });
  }
  return rows.length;
}

// server/shared/media.ts
var family = (m) => m === "newspaper" || m === "magazine" || m === "print" ? "print" : m === "newsletter" || m === "social" || m === "other" ? "digital" : m;

// server/fulfilment/creative.ts
var CREATIVE_SPECS = {
  print: { types: ["application/pdf"], maxMb: 100 },
  digital: { types: ["image/png", "image/jpeg", "image/gif", "application/zip", "video/mp4"], maxMb: 50 },
  radio: { types: ["audio/wav", "audio/mpeg"], maxMb: 100 },
  podcast: { types: ["audio/wav", "audio/mpeg"], maxMb: 100 },
  tv: { types: ["video/mp4", "video/quicktime"], maxMb: 2e3 }
};
var REJECT_REASONS = ["brief_mismatch", "content_standards", "wrong_specs", "other"];
var context = (db, dealId) => one(
  db,
  `select d.*, s.creative_due_at, o.channel from deals d join slots s on s.id = d.slot_id join placements p on p.id = s.placement_id
   join outlets o on o.id = p.outlet_id where d.id = $1`,
  [dealId]
);
var latest = async (db, dealId) => (await db.query(`select * from creatives where deal_id = $1 order by version desc limit 1 for update`, [dealId])).rows[0];
async function uploadCreative(db, a, at) {
  const d = await context(db, a.dealId);
  if (d.buyer_id !== a.buyerId) throw new MarketError("This booking is not yours.");
  if (!["awaiting_payment", "secured"].includes(d.status)) throw new MarketError("Creative can be sent once the publisher has accepted.");
  if (at >= d.creative_due_at) throw new MarketError("The material deadline has passed.");
  const prev = await latest(db, d.id);
  if (prev?.status === "approved") throw new MarketError("The creative is already approved.");
  if (prev?.status === "pending") throw new MarketError("The publisher is still reviewing your last file.");
  const spec = CREATIVE_SPECS[family(d.channel)];
  const problem = !spec.types.includes(a.fileType) ? `This file type isn't accepted for ${d.channel}. Use ${spec.types.join(", ")}.` : a.fileSize > spec.maxMb * 1024 * 1024 ? `The file is larger than ${spec.maxMb} MB.` : null;
  const c = await one(
    db,
    `insert into creatives (deal_id, version, file_key, file_type, file_size, status, reason, uploaded_at, reviewed_at)
                           values ($1, $2, $3, $4, $5, $6, $7, $8, $9) returning *`,
    [d.id, (prev?.version ?? 0) + 1, a.fileKey, a.fileType, a.fileSize, problem ? "technical_issue" : "pending", problem, at, problem ? at : null]
  );
  if (!problem) await notify(db, d.seller_id, "creative.sent", d.id, { version: c.version }, at);
  return c;
}
async function reviewCreative(db, a, at) {
  const d = await context(db, a.dealId);
  if (d.seller_id !== a.sellerId) throw new MarketError("This booking is not yours.");
  const c = await latest(db, d.id);
  if (c?.status !== "pending") throw new MarketError("There is no creative waiting for review.");
  let status = "approved";
  if (a.decision === "changes") {
    const { n: n2 } = await one(db, `select count(*)::int n from creatives where deal_id = $1 and status = 'changes_requested'`, [d.id]);
    if (n2 >= await setting(db, "max_creative_rounds", at) + d.extra_creative_rounds)
      throw new MarketError("Both change rounds are used. Approve the creative or reject it with a reason.");
    if (!a.reason?.trim()) throw new MarketError("Say what needs to change.");
    status = "changes_requested";
  }
  if (a.decision === "technical") status = "technical_issue";
  if (a.decision === "reject") {
    if (!REJECT_REASONS.includes(a.reason)) throw new MarketError("Choose a rejection reason.");
    status = "rejected";
    if (a.reason === "other") await audit(db, `seller:${a.sellerId}`, "creative.rejected_other", "deal", d.id, null, at);
  }
  await db.query(`update creatives set status = $2, reason = $3, reviewed_at = $4 where id = $1`, [c.id, status, a.reason ?? null, at]);
  await notify(db, d.buyer_id, `creative.${status}`, d.id, { version: c.version, reason: a.reason }, at);
  return status;
}

// server/files/attachments.ts
async function assertOwnFiles(db, value, companyId) {
  const ids = [...new Set(JSON.stringify(value ?? null).match(/files\/[0-9a-f-]{36}/gi) ?? [])].map((k) => k.slice(6));
  if (!ids.length) return;
  const { rows } = await db.query(`select id from files where id = any($1::uuid[]) and company_id = $2`, [ids, companyId]);
  if (rows.length !== ids.length) throw new MarketError("Attach only files your own company uploaded.");
}

// server/fulfilment/proof.ts
var PROOF_CHECKLIST = {
  print: [{ key: "tearsheet", label: "the tearsheet" }],
  digital: [{ key: "screenshots", label: "dated screenshots" }, { key: "live_link", label: "the live link" }, { key: "start_time", label: "the start time" }, { key: "end_time", label: "the end time" }],
  radio: [{ key: "as_run_log", label: "the as-run log" }, { key: "audio_clip", label: "the audio clip" }],
  tv: [{ key: "as_run_log", label: "the as-run log" }, { key: "video_clip", label: "the video clip" }],
  podcast: [{ key: "episode_link", label: "the episode link" }, { key: "ad_time", label: "the time of the ad in the episode" }, { key: "audio_clip", label: "the audio clip" }],
  newsletter: [{ key: "screenshots", label: "a screenshot of the sent email" }, { key: "send_time", label: "the send time" }],
  social: [{ key: "live_link", label: "the link to the post" }, { key: "screenshots", label: "dated screenshots" }]
};
function checklistFor(channel, brief) {
  return [...PROOF_CHECKLIST[channel] ?? PROOF_CHECKLIST[family(channel)], ...brief?.disclaimer?.trim() ? [{ key: "disclaimer", label: "confirmation the required disclaimer was included" }] : []];
}
function missingProof(channel, items, brief) {
  return checklistFor(channel, brief).filter((i) => !items[i.key]).map((i) => i.label);
}
async function checkProof(db, dealId, items) {
  const { channel, brief } = await one(db, `select o.channel, (select b.brief from bids b where b.id = d.bid_id) brief from deals d join slots s on s.id = d.slot_id
                                     join placements p on p.id = s.placement_id join outlets o on o.id = p.outlet_id where d.id = $1`, [dealId]);
  const missing = missingProof(channel, items, brief);
  if (missing.length) throw new MarketError(`Add ${missing.join(" and ")} before sending proof.`);
}
async function submitProof(db, a, at) {
  const d = await one(db, `select d.*, s.starts_at, s.ends_at from deals d join slots s on s.id = d.slot_id where d.id = $1`, [a.dealId]);
  if (d.seller_id !== a.sellerId) throw new MarketError("This booking is not yours.");
  if (at < (d.make_good_at ?? d.ends_at ?? d.starts_at)) throw new MarketError("Proof can be sent once the ad has run.");
  await checkProof(db, d.id, a.items);
  await assertOwnFiles(db, a.items, a.sellerId);
  await db.query(`insert into proofs (deal_id, items, note, submitted_at) values ($1, $2, $3, $4)`, [d.id, JSON.stringify(a.items), a.note ?? null, at]);
  const deal = await transition(db, d.id, "submit_proof", `seller:${a.sellerId}`, at);
  const invoiced = await db.query(`select 1 from documents where deal_id = $1 and type = 'media_invoice'`, [d.id]);
  if (!invoiced.rowCount && await setting(db, "media_invoice_timing", at) === "run") await issueMediaInvoice(db, d.id, at);
  await notify(db, d.buyer_id, "proof.ready", d.id, null, at);
  return deal;
}

// server/payments/provider.ts
var FakeProvider = class {
  bal = /* @__PURE__ */ new Map();
  seen = /* @__PURE__ */ new Map();
  // idempotency key → result, like Stripe
  n = 0;
  charges = /* @__PURE__ */ new Map();
  // Ids are unique per instance: the demo seed and the server each run their own fake provider on one database.
  tag = Math.random().toString(36).slice(2, 8);
  once(key, fn) {
    if (!this.seen.has(key)) this.seen.set(key, fn());
    return this.seen.get(key);
  }
  /** Tests share one provider across a fresh database per test. */
  reset() {
    this.bal.clear();
    this.seen.clear();
    this.charges.clear();
  }
  add(currency, delta) {
    this.bal.set(currency, (this.bal.get(currency) ?? 0) + delta);
  }
  async charge(a) {
    return this.once(a.idempotencyKey, () => {
      const id = `ch_${this.tag}_${++this.n}`;
      if (a.paymentMethod.endsWith("0002")) return { id, status: "failed", failure: "Your card was declined." };
      const status = a.paymentMethod.endsWith("3155") ? "requires_action" : "succeeded";
      this.charges.set(id, { amount: a.amount, currency: a.currency, status });
      if (status === "succeeded") this.add(a.currency, a.amount);
      return { id, status };
    });
  }
  /** Simulates the buyer completing 3-D Secure; Stripe would then send charge.succeeded. */
  authenticate(chargeId) {
    const c = this.charges.get(chargeId);
    c.status = "succeeded";
    this.add(c.currency, c.amount);
  }
  async refund(a) {
    return this.once(a.idempotencyKey, () => {
      this.add(this.charges.get(a.chargeId)?.currency ?? "AED", -a.amount);
      return { id: `re_${this.tag}_${++this.n}` };
    });
  }
  /** Demo servers: start from the ledger's cash, since the fake balance lives in memory and the seed ran in another process. */
  prime(currency, amount) {
    this.bal.set(currency, amount);
  }
  /** Tests: the buyer's bank takes a disputed payment (and its fee) back, or returns it when Nashr wins. */
  chargeback(currency, amount) {
    this.add(currency, -amount);
  }
  async transfer(a) {
    return this.once(a.idempotencyKey, () => {
      this.add(a.currency, -a.amount);
      return { id: `tr_${this.tag}_${++this.n}` };
    });
  }
  /**
   * A demo server can run several copies of the app on one database (shared hosting's web server starts more when busy), and each
   * copy's fake balance lives in its own memory, so no single copy sees every demo payment. There the balance is read from the
   * shared books instead (sharedCash). Tests keep the in-memory balance, so the reconciliation they check stays a real check.
   */
  sharedCash;
  async balance(currency) {
    return this.sharedCash ? this.sharedCash(currency) : this.bal.get(currency) ?? 0;
  }
};

// server/fulfilment/issues.ts
async function escalateIssue(db, deal, actor, at) {
  if (deal.status === "issue_open") await transition(db, deal.id, "escalate", actor, at);
  await db.query(`update issues set status = 'escalated', closed_at = $2 where deal_id = $1 and status = 'open'`, [deal.id, at]);
  const { market } = await one(db, `select o.market from slots s join placements p on p.id = s.placement_id join outlets o on o.id = p.outlet_id where s.id = $1`, [deal.slot_id]);
  const decideBy = await addWorkingDays(db, at, await setting(db, "dispute_decision_working_days", at), market);
  await db.query(`update deals set decide_by = $2 where id = $1`, [deal.id, decideBy]);
  for (const c of [deal.buyer_id, deal.seller_id]) await notify(db, c, "dispute.opened", deal.id, { decideBy }, at);
}

// server/fulfilment/prerun.ts
async function requestPreRunChecks(db, at) {
  const lead = await setting(db, "prerun_hours", at);
  const { rows } = await db.query(
    `insert into prerun_checks (deal_id, requested_at)
     select d.id, $1 from deals d join slots s on s.id = d.slot_id
     where d.status = 'secured' and coalesce(d.make_good_at, s.starts_at) - make_interval(hours => $2) <= $1
       and coalesce(d.make_good_at, s.starts_at) > $1
     on conflict do nothing returning deal_id`,
    [at, lead]
  );
  for (const r of rows) {
    const d = await one(db, `select buyer_id, seller_id from deals where id = $1`, [r.deal_id]);
    await notify(db, d.seller_id, "prerun.confirm_slot_and_creative", r.deal_id, null, at);
    await notify(db, d.buyer_id, "prerun.confirm_final_version", r.deal_id, null, at);
  }
  return rows.length;
}

// server/shared/audiences.ts
var AUDIENCES = [
  ["executives", "Business owners and executives", "Founders, C-suite and decision makers across the UAE."],
  ["affluent_expats", "Affluent expats", "High-income expatriate professionals and families."],
  ["arabic_families", "Arabic-speaking families", "Emirati and Arab households, Arabic-first media."],
  ["commuters", "Drive-time commuters", "People on the road in the morning and evening rush."],
  ["property_investors", "Property investors", "Buyers and investors following UAE real estate."],
  ["young_professionals", "Young professionals", "Working adults aged 22 to 35 building their careers."],
  ["students", "Students", "University and college students."],
  ["parents", "Parents", "Mothers and fathers making family decisions."],
  ["tech_adopters", "Tech early adopters", "People who buy new gadgets, apps and services first."],
  ["luxury_shoppers", "Luxury shoppers", "High spenders on fashion, cars, jewellery and travel."],
  ["south_asian_community", "South Asian community", "Hindi, Urdu and Malayalam-speaking residents."],
  ["sports_fans", "Sports fans", "Followers of football, cricket and motorsport."]
];
var AUDIENCE_KEYS = AUDIENCES.map((a) => a[0]);

// server/shared/slot-filter.ts
var currentPrice = (s) => s.topBid ?? s.startingPrice;
var dubaiMinutes = (iso) => {
  const d = new Date(new Date(iso).getTime() + 4 * 36e5);
  return d.getUTCHours() * 60 + d.getUTCMinutes();
};
function daypart(s) {
  const m = dubaiMinutes(s.startsAt);
  if (s.endsAt ? new Date(s.endsAt).getTime() - new Date(s.startsAt).getTime() >= 864e5 : m === 0) return "allday";
  return m < 5 * 60 ? "evening" : m < 12 * 60 ? "morning" : m < 17 * 60 ? "afternoon" : "evening";
}
function matches(f, s, now2 = Date.now()) {
  if (f.channels?.length && !f.channels.includes(s.channel)) return false;
  if (f.saleTypes?.length && !f.saleTypes.includes(s.saleType)) return false;
  if (f.sector) {
    const is = (x) => x.toLowerCase() === f.sector.toLowerCase();
    if ((s.blocked ?? []).some(is) || (s.sectors ?? []).length > 0 && !(s.sectors ?? []).some(is)) return false;
  }
  if (f.maxPrice != null && currentPrice(s) > f.maxPrice) return false;
  if (f.minPrice != null && currentPrice(s) < f.minPrice) return false;
  if (f.dayparts?.length && !f.dayparts.includes(daypart(s))) return false;
  if (f.q?.trim()) {
    const hay = `${s.outlet} ${s.placement ?? ""} ${(s.sectors ?? []).join(" ")}`.toLowerCase();
    if (!f.q.toLowerCase().split(/\s+/).filter(Boolean).every((w) => hay.includes(w))) return false;
  }
  if (f.closingWithinHours != null && new Date(s.closesAt).getTime() - now2 > f.closingWithinHours * 36e5) return false;
  if (f.audiences?.length && !(s.audiences ?? []).some((a) => f.audiences.includes(a))) return false;
  return true;
}

// server/marketplace/search.ts
var DUBAI = `(s.starts_at at time zone 'Asia/Dubai')`;
var MINUTE = `(extract(hour from ${DUBAI}) * 60 + extract(minute from ${DUBAI}))`;
var ALL_DAY = `(case when s.ends_at is null then ${MINUTE} = 0 else s.ends_at - s.starts_at >= interval '1 day' end)`;
var PRICE = `coalesce(s.top_amount, s.starting_price)`;
var POPULAR = `((select count(*) from bids b2 join slots s2 on s2.id = b2.slot_id where s2.placement_id = p.id and b2.created_at > now() - interval '90 days')
  + (select count(*) from deals d2 join slots s2 on s2.id = d2.slot_id where s2.placement_id = p.id and d2.created_at > now() - interval '90 days'))`;
var AUDIENCES_SQL = `(case when cardinality(p.audiences) > 0 then p.audiences else o.audiences end)`;
var DAYPART = {
  allday: ALL_DAY,
  morning: `(not ${ALL_DAY} and ${MINUTE} >= 300 and ${MINUTE} < 720)`,
  afternoon: `(not ${ALL_DAY} and ${MINUTE} >= 720 and ${MINUTE} < 1020)`,
  evening: `(not ${ALL_DAY} and (${MINUTE} >= 1020 or ${MINUTE} < 300))`
};
var SLOT_COLUMNS = `s.*, p.name placement, o.id outlet_id, brand_name(o) outlet, o.channel, o.sectors, coalesce(o.blocked_industries, '{}') blocked, o.audience, ${AUDIENCES_SQL} audiences, o.logo_key, pr.id brand_id, pr.name brand, pr.logo_key brand_logo_key, c.name company, coalesce(bc.n, 0)::int bids, coalesce(bc.mine, false) mine,
  (select d.id from deals d where d.slot_id = s.id order by d.created_at desc limit 1) deal_id`;
var ORDER = {
  time: "s.starts_at, o.name, s.id",
  price_asc: `${PRICE}, s.starts_at, s.id`,
  price_desc: `${PRICE} desc, s.starts_at, s.id`,
  closing: "s.closes_at, s.starts_at, s.id",
  bids: "bids desc, s.starts_at, s.id",
  // most popular: bookings and bids on that product in the last 90 days, worked out by Nashr (buyers see the order only)
  popular: `${POPULAR} desc, s.starts_at, s.id`
};

// server/marketplace/alerts.ts
var OPEN_MARKET = `(select value from settings where key = 'open_markets' order by valid_from desc limit 1) ? o.market`;
async function sendSearchAlerts(db, at) {
  const searches = (await db.query(`select * from saved_searches where alerts and checked_at < $1 order by checked_at for update skip locked`, [at])).rows;
  if (!searches.length) return 0;
  const since = searches.reduce((m, s) => s.checked_at < m ? s.checked_at : m, searches[0].checked_at);
  const slots2 = (await db.query(
    `select s.*, p.name placement, brand_name(o) outlet, o.channel, o.sectors, o.blocked_industries, o.audience, ${AUDIENCES_SQL} audiences from slots s
       join placements p on p.id = s.placement_id join outlets o on o.id = p.outlet_id
     where s.listed_at > $1 and s.listed_at <= $2 and s.status = 'open' and s.closes_at > $2 and ${OPEN_MARKET}`,
    [since, at]
  )).rows.map((r) => ({ listedAt: r.listed_at, starts: r.starts_at, slot: {
    outlet: r.outlet,
    placement: r.placement,
    channel: r.channel,
    saleType: r.sale_type,
    sectors: r.sectors,
    blocked: r.blocked_industries ?? [],
    audience: r.audience,
    audiences: r.audiences,
    startsAt: r.starts_at.toISOString(),
    endsAt: r.ends_at?.toISOString() ?? null,
    closesAt: r.closes_at.toISOString(),
    startingPrice: r.starting_price,
    topBid: r.top_amount
  } }));
  let sent = 0;
  for (const s of searches) {
    const hits = slots2.filter((x) => x.listedAt > s.checked_at && matches(s.filter, x.slot, at.getTime()));
    if (hits.length) {
      const first = hits.reduce((a, b) => b.starts < a.starts ? b : a);
      await notify(db, s.company_id, "search.match", null, { searchId: s.id, name: s.name, count: hits.length, firstAt: first.starts }, at);
      sent++;
    }
    await db.query(`update saved_searches set checked_at = $2 where id = $1`, [s.id, at]);
  }
  return sent;
}

// server/marketplace/sweeper.ts
var TIMER_NOTE = {
  expire: "The publisher did not reply in time",
  lapse: "Payment was not made in time",
  proof_missed: "The publisher did not send proof in time",
  auto_release: "Released automatically after the review window"
};
var REMIND = {
  awaiting_seller: [{ hours: 12, who: "seller_id", kind: "reminder.decide" }, { hours: 2, who: "seller_id", kind: "reminder.decide" }],
  awaiting_payment: [{ hours: 12, who: "buyer_id", kind: "reminder.pay" }],
  in_review: [{ hours: 72, who: "buyer_id", kind: "reminder.review" }, { hours: 24, who: "buyer_id", kind: "reminder.review" }],
  // day 3 and day 1
  issue_open: [{ hours: 24, who: "seller_id", kind: "reminder.issue" }]
};
async function sendReminders(db, at) {
  let sent = 0;
  for (const [status, rules] of Object.entries(REMIND)) for (const r of rules) {
    const { rows } = await db.query(
      `insert into reminders (deal_id, kind, deadline_at, sent_at)
       select d.id, $2 || ':' || $3::text, d.next_deadline_at, $4 from deals d
       where d.status = $1 and d.next_deadline_at > $4 and d.next_deadline_at - make_interval(hours => $3::int) <= $4
       on conflict do nothing returning deal_id, deadline_at`,
      [status, r.kind, r.hours, at]
    );
    for (const x of rows) {
      const d = (await db.query(`select buyer_id, seller_id from deals where id = $1`, [x.deal_id])).rows[0];
      await notify(db, d[r.who], r.kind, x.deal_id, { deadline: x.deadline_at }, at);
    }
    sent += rows.length;
  }
  return sent;
}
async function sweep(at, batch = 100) {
  let handled = 0;
  const skip = [];
  let current = null;
  for (; ; ) {
    let n2;
    try {
      n2 = await tx(async (c) => {
        current = null;
        const slot = (await c.query(`select id from slots where status = 'open' and sale_type = 'auction' and closes_at <= $1 and id <> all($2::uuid[])
                                     order by closes_at limit 1 for update skip locked`, [at, skip])).rows[0];
        if (slot) {
          current = slot.id;
          await closeAuction(c, slot.id, at);
          return 1;
        }
        const quick = (await c.query(`select s.id from slots s where s.status = 'open' and s.sale_type = 'quick_sale' and s.closes_at <= $1 and s.id <> all($2::uuid[])
                                      and exists (select 1 from bids b where b.slot_id = s.id and b.kind = 'interest' and b.status = 'active')
                                      order by s.closes_at limit 1 for update skip locked`, [at, skip])).rows[0];
        if (quick) {
          current = quick.id;
          await expireInterests(c, quick.id, at);
          return 1;
        }
        const choice2 = (await c.query(`select id from slots where status = 'awaiting_choice' and choice_deadline_at <= $1 and id <> all($2::uuid[])
                                       order by choice_deadline_at limit 1 for update skip locked`, [at, skip])).rows[0];
        if (choice2) {
          current = choice2.id;
          await relist(c, choice2.id, at);
          return 1;
        }
        const deal = (await c.query(`select * from deals where next_deadline_at <= $1 and id <> all($2::uuid[]) order by next_deadline_at limit 1 for update skip locked`, [at, skip])).rows[0];
        if (!deal) return 0;
        current = deal.id;
        const event = ON_DEADLINE[deal.status];
        if (!event) {
          await c.query(`update deals set next_deadline_at = null where id = $1`, [deal.id]);
          return 1;
        }
        if (event === "escalate") {
          await escalateIssue(c, deal, "system:timer", at);
          return 1;
        }
        const updated = await transition(c, deal.id, event, "system:timer", at, TIMER_NOTE[event]);
        if (event === "expire" || event === "lapse") await afterNoGo(c, updated, at);
        await onTimerEvent(c, updated, event, at);
        return 1;
      });
    } catch (e) {
      if (!current) throw e;
      skip.push(current);
      console.error(`sweeper: ${current} failed and is skipped this run:`, e?.message ?? e);
      await audit(pool, "system:sweeper", "sweeper.error", "timer", current, { error: String(e?.message ?? e).slice(0, 500) }, at);
      n2 = 1;
    }
    if (!n2 || (handled += n2) >= batch) break;
  }
  handled += await tx((c) => requestPreRunChecks(c, at));
  handled += await tx((c) => sendReminders(c, at));
  handled += await tx((c) => sendSearchAlerts(c, at));
  handled += await tx((c) => topUpRolling(c, at));
  await audit(pool, "system:sweeper", "sweeper.heartbeat", null, null, { handled }, at);
  return handled;
}

// server/seed-history.ts
var H = 36e5;
var DAY = 24 * H;
var NotYet = class extends Error {
};
function rng(seed) {
  return () => {
    seed |= 0;
    seed = seed + 1831565813 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
async function seedHistory(o) {
  const BRIEF_OF = o.briefOf;
  const rand = rng(20261106), weeks = o.weeks ?? 12;
  const pick = (xs) => xs[Math.floor(rand() * xs.length)];
  const provider = new FakeProvider();
  const today2 = o.now.toISOString().slice(0, 10);
  const monday = (d) => {
    const x = new Date(d);
    x.setUTCDate(x.getUTCDate() - (x.getUTCDay() + 6) % 7);
    return x.toISOString().slice(0, 10);
  };
  const from2 = monday(new Date(o.now.getTime() - weeks * 7 * DAY));
  const days = Math.round((Date.parse(today2) - Date.parse(from2)) / DAY);
  const listedAt = new Date(Date.parse(from2) - 10 * DAY);
  const placements = (await pool.query(`select p.id from placements p join outlets o on o.id = p.outlet_id join companies c on c.id = o.company_id
    where c.payouts_enabled and not p.archived`)).rows;
  for (const p of placements) await tx((c) => generateSlots(c, p.id, from2, days, listedAt));
  const slots2 = (await pool.query(`select s.*, o.channel, p.close_lead_hours from slots s join placements p on p.id = s.placement_id join outlets o on o.id = p.outlet_id
    where s.starts_at >= $1 and s.starts_at < $2 and s.kind = 'single' and s.status = 'open' order by s.starts_at`, [from2, new Date(o.now.getTime() + 21 * DAY)])).rows;
  const start = Date.parse(from2), span2 = o.now.getTime() - start;
  let made = 0;
  for (const s of slots2) {
    const starts = new Date(s.starts_at), closes = new Date(s.closes_at), growth = Math.min((starts.getTime() - start) / span2, 1);
    const share = s.channel === "radio" ? 0.16 : s.channel === "tv" ? 0.3 : 0.45;
    if (rand() > share * (0.35 + growth)) continue;
    const buyer2 = rand() < 0.45 ? o.demoBuyer : pick(o.rivals);
    const t = (ms) => {
      if (ms >= o.now.getTime()) throw new NotYet();
      return new Date(ms);
    };
    try {
      let deal, decidedAt;
      if (s.sale_type === "quick_sale") {
        const at = t(starts.getTime() - (130 + rand() * 200) * H);
        const bid = await tx((c) => showInterest(c, { slotId: s.id, buyerId: buyer2, brief: BRIEF_OF(buyer2), campaignId: buyer2 === o.demoBuyer && rand() < 0.3 ? o.campaignId : void 0 }, at));
        decidedAt = t(at.getTime() + (1 + rand() * 6) * H);
        deal = await tx((c) => acceptInterest(c, bid.id, "seller:seed", decidedAt));
      } else if (s.buy_now_price && rand() < 0.2) {
        const at = t(closes.getTime() - (20 + rand() * 80) * H);
        deal = await tx((c) => requestBuyNow(c, { slotId: s.id, buyerId: buyer2, brief: BRIEF_OF(buyer2), campaignId: buyer2 === o.demoBuyer && rand() < 0.3 ? o.campaignId : void 0 }, at));
        decidedAt = t(at.getTime() + (1 + rand() * 8) * H);
        if (rand() < 0.08) {
          await tx((c) => decline(c, deal.id, "The break is held for a sponsor that week.", "seller:seed", decidedAt));
          continue;
        }
        deal = await tx((c) => accept(c, deal.id, "seller:seed", decidedAt));
      } else {
        const step = Math.round(s.starting_price * (0.02 + rand() * 0.06) / 1e4) * 1e4;
        const first = t(closes.getTime() - (40 + rand() * 90) * H);
        if (rand() < 0.5) {
          const rival = pick(o.rivals.filter((r) => r !== buyer2));
          await tx((c) => placeBid(c, { slotId: s.id, buyerId: rival, amount: s.starting_price, brief: BRIEF_OF(rival) }, first));
        }
        const amount = s.starting_price + step * (1 + Math.floor(rand() * 6));
        await tx((c) => placeBid(c, { slotId: s.id, buyerId: buyer2, amount, brief: BRIEF_OF(buyer2), campaignId: buyer2 === o.demoBuyer && rand() < 0.3 ? o.campaignId : void 0 }, t(first.getTime() + (2 + rand() * 20) * H)));
        deal = await tx((c) => closeAuction(c, s.id, closes));
        if (!deal) continue;
        decidedAt = t(closes.getTime() + (1 + rand() * 10) * H);
        if (deal.status === "awaiting_seller") {
          if (rand() < 0.07) {
            await tx((c) => decline(c, deal.id, "The creative category conflicts with a sponsor.", "seller:seed", decidedAt));
            continue;
          }
          deal = await tx((c) => accept(c, deal.id, "seller:seed", decidedAt));
        }
      }
      made++;
      if (rand() < 0.05) continue;
      const paidAt = t(decidedAt.getTime() + (1 + rand() * 20) * H);
      await confirmPayment(provider, { dealId: deal.id, buyerId: buyer2, paymentMethod: "pm_card_4242" }, paidAt);
      const spec = CREATIVE_SPECS[family(s.channel)];
      const sentAt = t(paidAt.getTime() + (1 + rand() * 12) * H);
      if (sentAt < new Date(s.creative_due_at)) {
        await tx((c) => uploadCreative(c, { dealId: deal.id, buyerId: buyer2, fileKey: `seed/${deal.id}`, fileType: spec.types[0], fileSize: 2e6 }, sentAt));
        await tx((c) => reviewCreative(c, { dealId: deal.id, sellerId: deal.seller_id, decision: "approve" }, t(sentAt.getTime() + (1 + rand() * 6) * H)));
      }
      const proofAt = t(starts.getTime() + (2 + rand() * 20) * H);
      const items = Object.fromEntries(checklistFor(s.channel).map((i) => [i.key, `${i.label} for ${s.label}`]));
      await tx((c) => submitProof(c, { dealId: deal.id, sellerId: deal.seller_id, items }, proofAt));
      if (rand() < 0.06) continue;
      const approvedAt = t(proofAt.getTime() + (4 + rand() * 60) * H);
      await tx((c) => approve(c, deal.id, `buyer:${buyer2}`, approvedAt));
      await runMoneyOps(provider, approvedAt);
    } catch (e) {
      if (!(e instanceof MarketError) && !(e instanceof NotYet)) throw e;
    }
  }
  while (await sweep(o.now, 1e3) >= 1e3) {
  }
  return made;
}

// server/demo-creative.ts
import { readFile as readFile2 } from "node:fs/promises";
import { fileURLToPath as fileURLToPath2 } from "node:url";

// server/files/storage.ts
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
var DiskStorage = class {
  constructor(dir2 = process.env.FILES_DIR ?? ".files") {
    this.dir = dir2;
  }
  dir;
  async put(key, bytes) {
    await mkdir(this.dir, { recursive: true });
    await writeFile(join(this.dir, key), bytes);
  }
  get(key) {
    return readFile(join(this.dir, key));
  }
};
function sniffType(b) {
  const at = (i, s) => b.subarray(i, i + s.length).toString("latin1") === s;
  if (at(0, "%PDF")) return "application/pdf";
  if (at(0, "\x89PNG")) return "image/png";
  if (b[0] === 255 && b[1] === 216 && b[2] === 255) return "image/jpeg";
  if (at(0, "GIF8")) return "image/gif";
  if (at(0, "PK")) return "application/zip";
  if (at(4, "ftyp")) return at(8, "qt  ") ? "video/quicktime" : "video/mp4";
  if (at(0, "RIFF") && at(8, "WAVE")) return "audio/wav";
  if (at(0, "ID3") || b[0] === 255 && (b[1] & 224) === 224) return "audio/mpeg";
  return "application/octet-stream";
}

// server/demo-creative.ts
var PICTURE = fileURLToPath2(new URL("../web/public/brand/print-card.jpg", import.meta.url));
var BASE = { advertiser: "Demo brand", industry: "Banking", message: "Demo campaign", language: "english" };
async function demoBriefs(buyers, extra = {}) {
  const bytes = await readFile2(PICTURE), storage = new DiskStorage(), out = /* @__PURE__ */ new Map();
  for (const id of buyers) {
    const f = (await pool.query(`insert into files (company_id, name, type, size, created_at) values ($1, 'draft-creative.jpg', $2, $3, now()) returning id`, [id, sniffType(bytes), bytes.length])).rows[0];
    await storage.put(f.id, bytes);
    out.set(id, { ...BASE, ...extra, draftFileKey: `files/${f.id}` });
  }
  return (buyerId) => out.get(buyerId) ?? (() => {
    throw new Error(`no demo brief for ${buyerId}`);
  })();
}

// server/seed.ts
if (process.env.NODE_ENV === "production" && process.env.NASHR_DEMO !== "1") throw new Error("Refusing to seed demo data in production.");
var AED = (n2) => n2 * 100;
var PASSWORD = "nashr-demo-2026";
await migrate();
await pool.query(`truncate saved_outlets, staff_alerts, ops_runs, reminders, waitlist, files, quote_requests, campaign_lines, campaign_items, campaigns, sessions, invites, users, access_requests, notifications, documents, document_series, creatives, proofs, issues,
  prerun_checks, money_ops, ledger_entries, deal_events, deals, bids, slots, placements, outlets, companies, provider_events restart identity cascade`);
await pool.query(`delete from settings where valid_from > '2000-01-01'`);
var now = /* @__PURE__ */ new Date();
var company = async (name, type) => (await pool.query(
  `insert into companies (name, type, vat_registered, payouts_enabled, provider_account, trn) values ($1, $2, $3, $3, $4, '100000000000003') returning id`,
  [name, type, type === "publisher", type === "publisher" ? "acct_demo" : null]
)).rows[0].id;
var user = (companyId, email, name, role) => pool.query(
  `insert into users (company_id, email, name, role, status, password_hash, created_at) values ($1, $2, $3, $4, 'active', $5, now())`,
  [companyId, email, name, role, hashPassword(PASSWORD)]
);
var outlet = async (companyId, name, nameAr, channel, sectors) => (await pool.query(
  `insert into outlets (company_id, name, name_ar, channel, sectors) values ($1, $2, $3, $4, $5) returning id`,
  [companyId, name, nameAr, channel, sectors]
)).rows[0].id;
var buyer = await company("Northwind Fintech", "buyer");
var rivals = [await company("Al Futtaim Group", "buyer"), await company("Emirates NBD", "buyer"), await company("Etihad Holidays", "buyer")];
await user(buyer, "demo@northwind.ae", "Sara Al Mansoori", "buyer");
var briefOf = await demoBriefs([buyer, ...rivals], { landingUrl: "https://example.com" });
var skyline = await company("Skyline FM", "publisher");
await user(skyline, "sales@skyline.ae", "Tariq", "seller");
var dubaiOne = await company("Dubai One TV", "publisher");
var gulfNews = await company("Gulf News", "publisher");
var khaleej = await company("Khaleej Times", "publisher");
var majlis = await company("The Majlis Podcast", "publisher");
var today = localDay(now, "AE");
var offset = (8 - today.weekday) % 7 || 7;
var from = new Date(Date.parse(today.date + "T00:00:00Z") + offset * 864e5).toISOString().slice(0, 10);
var DETAILS = {
  radio: { description: "A 30-second spot in one ad break of the programme.", specs: "MP3 or WAV, 30 seconds, broadcast-ready." },
  tv: { description: "A 30-second spot in one ad break of the programme.", specs: "MP4 (H.264), 1920 \xD7 1080, 30 seconds, loudness \u221223 LUFS." },
  newspaper: { description: "A page in one edition.", specs: "PDF/X-1a, 300 dpi, sizes on the rate card." },
  digital: { description: "Your brand on the site for the day.", specs: "JPG, PNG or HTML5, up to 150 KB." },
  podcast: { description: "A host-read or produced ad in one position of the episode.", specs: "MP3, 48 kHz, or a script for the host to read." }
};
var list = async (outletId, p) => tx(async (c) => {
  const { channel } = (await c.query(`select channel from outlets where id = $1`, [outletId])).rows[0];
  const id = await createPlacement(c, { outletId, creativeLeadHours: 48, closeLeadHours: 120, ...DETAILS[channel], language: "english", listing: "rolling", horizonWeeks: 4, ...p }, "seed", now);
  await generateSlots(c, id, from, 28, now);
  return id;
});
await list(await outlet(skyline, "Skyline FM", "\u0633\u0643\u0627\u064A \u0644\u0627\u064A\u0646", "radio", ["Banking", "Retail", "Real estate"]), {
  name: "Morning Markets",
  saleType: "auction",
  days: [1, 2, 3, 4, 5],
  startsAt: "06:30",
  endsAt: "09:00",
  startingPrice: AED(3500),
  anyBreakPrice: AED(3500),
  packagePrice: AED(15e3),
  buyNowPrice: AED(5500),
  reservePrice: AED(4e3),
  breaks: [{ label: "Break 1", at: "06:45", seconds: 30 }, { label: "Break 2", at: "07:15", seconds: 30 }, { label: "Break 3", at: "07:45", seconds: 30 }, { label: "Break 4", at: "08:15", seconds: 30 }]
});
await list((await pool.query(`select id from outlets where company_id = $1`, [skyline])).rows[0].id, {
  name: "Drive Home",
  saleType: "quick_sale",
  days: [1, 2, 3, 4, 5],
  startsAt: "16:00",
  endsAt: "19:00",
  startingPrice: AED(4200),
  breaks: [{ label: "Break 1", at: "16:20", seconds: 30 }, { label: "Break 2", at: "17:20", seconds: 30 }]
});
await list(await outlet(dubaiOne, "Dubai One TV", "\u062F\u0628\u064A \u0648\u0646", "tv", ["Banking", "Hospitality"]), {
  name: "Market Open",
  saleType: "auction",
  days: [1, 2, 3, 4, 5],
  startsAt: "10:00",
  endsAt: "10:30",
  startingPrice: AED(12e3),
  buyNowPrice: AED(18e3),
  breaks: [{ label: "Break 1", at: "10:10", seconds: 30 }, { label: "Break 2", at: "10:25", seconds: 30 }]
});
await list(await outlet(gulfNews, "Gulf News", "\u063A\u0644\u0641 \u0646\u064A\u0648\u0632", "newspaper", ["Banking", "Real estate", "Retail"]), {
  name: "Full page",
  saleType: "auction",
  days: [1, 3, 5],
  startingPrice: AED(2e4),
  buyNowPrice: AED(32e3),
  closeLeadHours: 144,
  creativeLeadHours: 48
});
await list(await outlet(khaleej, "Khaleej Times", "\u062E\u0644\u064A\u062C \u062A\u0627\u064A\u0645\u0632", "digital", ["Technology", "Banking"]), {
  name: "Homepage takeover",
  saleType: "quick_sale",
  days: [2, 4],
  startingPrice: AED(9e3),
  closeLeadHours: 96,
  creativeLeadHours: 24
});
await list((await pool.query(`select id from outlets where name = 'Khaleej Times'`)).rows[0].id, {
  name: "Banner for a week",
  saleType: "fixed",
  unit: "week",
  days: [1],
  startingPrice: AED(6500),
  closeLeadHours: 96,
  creativeLeadHours: 24,
  description: "Your banners across the site for seven days.",
  specs: "MPU 300 \xD7 250 and leaderboard 728 \xD7 90, JPG, PNG or HTML5, up to 150 KB."
});
await list((await pool.query(`select id from outlets where name = 'Gulf News'`)).rows[0].id, {
  name: "Half page",
  saleType: "fixed",
  autoAccept: true,
  days: [2, 4],
  startingPrice: AED(11e3),
  closeLeadHours: 144,
  creativeLeadHours: 48,
  description: "A horizontal half page in one edition.",
  specs: "26 \xD7 17 cm, PDF/X-1a, 300 dpi."
});
await list(await outlet(majlis, "The Majlis Podcast", "\u0627\u0644\u0645\u062C\u0644\u0633", "podcast", ["Banking", "Technology"]), {
  name: "Weekly episode",
  saleType: "auction",
  days: [4],
  startsAt: "06:00",
  startingPrice: AED(2500),
  breaks: [{ label: "Pre-roll" }, { label: "Mid-roll" }, { label: "Post-roll" }]
});
for (const [name, audiences, reach, blocked] of [
  ["Skyline FM", ["commuters", "young_professionals", "affluent_expats", "parents"], 18e4, ["Alcohol & nightlife"]],
  ["Dubai One TV", ["arabic_families", "affluent_expats", "sports_fans", "parents"], 65e4, ["Alcohol & nightlife", "Lottery & gaming"]],
  ["Gulf News", ["executives", "property_investors", "affluent_expats", "south_asian_community", "luxury_shoppers"], 42e4, []],
  ["Khaleej Times", ["executives", "tech_adopters", "young_professionals", "south_asian_community", "luxury_shoppers"], 9e5, ["Crypto & trading"]],
  ["The Majlis Podcast", ["executives", "young_professionals", "students"], 35e3, []]
])
  await pool.query(`update outlets set audiences = $2, reach = $3, blocked_industries = $4 where name = $1`, [name, audiences, reach, blocked]);
await applyDemoAudiences(pool);
var slots = (await pool.query(`select id, sale_type, starting_price from slots where status = 'open' order by starts_at limit 60`)).rows;
for (const [i, s] of slots.entries()) {
  if (i % 3) continue;
  await tx(async (c) => {
    if (s.sale_type === "quick_sale") return showInterest(c, { slotId: s.id, buyerId: rivals[i % 3], brief: briefOf(rivals[i % 3]) }, now);
    if (s.sale_type === "fixed") return;
    await placeBid(c, { slotId: s.id, buyerId: rivals[i % 3], amount: s.starting_price, brief: briefOf(rivals[i % 3]) }, now);
    if (i % 2 === 0) await placeBid(c, { slotId: s.id, buyerId: buyer, amount: Math.ceil(s.starting_price * 1.03 / 100) * 100, brief: briefOf(buyer) }, now);
    if (i % 4 === 0) await placeBid(c, { slotId: s.id, buyerId: rivals[(i + 1) % 3], amount: Math.ceil(s.starting_price * 1.07 / 100) * 100, brief: briefOf(rivals[(i + 1) % 3]) }, now);
  });
}
await pool.query(`update outlets set tier = 'Tier 1', audience = 'Business commuters, 25-45', description = 'Dubai''s business radio. Markets, money and the morning drive.', website = 'https://example.com/skyline' where name = 'Skyline FM'`);
await pool.query(`update outlets set tier = 'Tier 1', audience = 'Decision makers, UAE nationals and expats', description = 'English-language daily with a strong business section.' where name = 'Gulf News'`);
for (const [name, channel, sectors, low, high] of [
  ["Arabian Business", "magazine", ["Banking", "Real estate"], 18e3, 26e3],
  ["Dubai Eye 103.8", "radio", ["Retail", "Hospitality"], 2500, 4e3],
  ["The National", "digital", ["Technology", "Banking"], 7e3, 12e3]
])
  await pool.query(`insert into outlets (name, channel, sectors, est_low, est_high) values ($1, $2, $3, $4, $5)`, [name, channel, sectors, AED(low), AED(high)]);
for (const [name, nameAr, channel, low, high] of [["Rotana FM", "\u0631\u0648\u062A\u0627\u0646\u0627 \u0625\u0641 \u0625\u0645", "radio", 4e3, 7e3], ["Arab News", "\u0639\u0631\u0628 \u0646\u064A\u0648\u0632", "newspaper", 15e3, 25e3]])
  await pool.query(
    `insert into outlets (name, name_ar, channel, market, sectors, est_low, est_high, est_currency) values ($1, $2, $3, 'SA', '{Banking,Retail}', $4, $5, 'SAR')`,
    [name, nameAr, channel, low * 100, high * 100]
  );
var campaign = (await pool.query(
  `insert into campaigns (buyer_id, name, budget, start_date, end_date, launch_date, objective, brief, created_at)
    values ($1, 'Q4 business cards launch', $2, $3, ($3::date + 42), $3, 'Awareness', $4, now()) returning id`,
  [buyer, AED(15e4), from, JSON.stringify(briefOf(buyer))]
)).rows[0].id;
await pool.query(`insert into campaign_lines (campaign_id, placement_id, added_at) select $1, p.id, now() from placements p join outlets o on o.id = p.outlet_id
  where not p.archived and o.name in ('Skyline FM', 'Gulf News')`, [campaign]);
var buyNow = (await pool.query(`select s.id from slots s where s.status = 'open' and s.buy_now_price is not null and s.kind = 'single'
  and not exists (select 1 from bids b where b.slot_id = s.id) order by s.starts_at limit 1`)).rows[0];
if (buyNow) await tx(async (c) => {
  const deal = await requestBuyNow(c, { slotId: buyNow.id, buyerId: buyer, brief: briefOf(buyer), campaignId: campaign }, now);
  await accept(c, deal.id, "seller:seed", now);
});
var booked = await seedHistory({ now, demoBuyer: buyer, rivals, campaignId: campaign, briefOf });
var paid = `select d.id, d.buyer_id, d.seller_id from deals d where d.status in ('secured', 'in_review') and`;
var forBuyer = (await pool.query(`${paid} d.buyer_id = $1 order by d.created_at desc limit 1`, [buyer])).rows;
var forSeller = (await pool.query(`select d.id, d.buyer_id, d.seller_id from deals d where d.status in ('secured', 'in_review', 'released')
  and d.seller_id = (select id from companies where name = 'Skyline FM') and d.id <> all($1::uuid[])
  order by d.status <> 'released' desc, d.buyer_id = $2 desc, d.created_at desc limit 1`, [forBuyer.map((d) => d.id), buyer])).rows;
var talk = [...forBuyer, ...forSeller];
var SCRIPTS = [
  [
    ["b", "Hi, our creative is a 30-second spot in Arabic and English. Is a bilingual read fine for this break?"],
    ["s", "Yes, bilingual works well in this slot. Please keep it to 30 seconds including the tag line."],
    ["b", "Great. Can the spot run as the first ad in the break?"],
    ["s", "We can place it first. Our traffic team will confirm the running order the day before."]
  ],
  [["s", "Thanks for booking. We received your brief; the final file is due two days before air."], ["b", "Noted. We will send the final version on Sunday morning."]]
];
for (const [i, d] of talk.entries()) {
  const lines = SCRIPTS[i] ?? [];
  for (const [j, [who, body]] of lines.entries())
    await pool.query(
      `insert into messages (deal_id, company_id, body, created_at) values ($1, $2, $3, $4)`,
      [d.id, who === "b" ? d.buyer_id : d.seller_id, body, new Date(now.getTime() - (lines.length - j) * 47 * 6e4)]
    );
  await pool.query(`insert into message_reads (deal_id, company_id, read_at) values ($1, $2, $3)`, [d.id, d.buyer_id, now]);
}
var DEMO_TOTP = "JBSWY3DPEHPK3PXP";
var nashr = (await pool.query(`insert into companies (name, type) values ('Nashr', 'nashr') returning id`)).rows[0].id;
for (const [email, name, role] of [["omar@nashr.ae", "Omar", "founder"], ["ops@nashr.ae", "Nashr Operations", "admin"]])
  await pool.query(
    `insert into users (company_id, email, name, role, status, password_hash, totp_secret, totp_enabled, created_at) values ($1, $2, $3, $4, 'active', $5, $6, true, now())`,
    [nashr, email, name, role, hashPassword(PASSWORD), DEMO_TOTP]
  );
await pool.query(`insert into access_requests (name, email, phone, role, company, company_type, created_at) values
  ('Huda Al Suwaidi', 'huda@brightagency.ae', '+971501234567', 'Media director', 'Bright Agency', 'agency', now()),
  ('Karim Haddad', 'karim@city1016.ae', '+971559876543', 'Sales manager', 'City 101.6', 'media_outlet', now())`);
await pool.query(`insert into quote_requests (outlet_id, buyer_id, message, created_at) select id, $1, 'Full page in the first week of December, banking section.', now() from outlets where name = 'Arabian Business'`, [buyer]);
var cards = (await pool.query(`insert into clients (buyer_id, name, industry, trn, billing_email, created_at) values ($1, 'Northwind Business Cards', 'Banking', '100345678900003', 'accounts@cards.example', now()) returning id`, [buyer])).rows[0].id;
var loans = (await pool.query(`insert into clients (buyer_id, name, industry, created_at) values ($1, 'Northwind Home Finance', 'Real estate', now()) returning id`, [buyer])).rows[0].id;
await pool.query(`update deals set client_id = case when (select count(*) from deals e where e.buyer_id = deals.buyer_id and e.ref < deals.ref) % 2 = 0 then $2::uuid else $3::uuid end where buyer_id = $1`, [buyer, cards, loans]);
var n = (await pool.query(`select count(*)::int n from slots`)).rows[0].n;
await pool.query(`update users set can_manage = true where role in ('buyer', 'seller')`);
await pool.query(`update users set terms_version = (select value #>> '{}' from settings where key = 'terms_version' order by valid_from desc limit 1), terms_accepted_at = now()`);
console.log(`Seeded ${n} slots from ${from} and ${booked} past bookings. Sign in as demo@northwind.ae (buyer), sales@skyline.ae (seller) or ops@nashr.ae / omar@nashr.ae (staff), password ${PASSWORD}.
Staff authenticator key (development only): ${DEMO_TOTP}`);
await pool.end();
